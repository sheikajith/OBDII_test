rm Application.tar.bz2
sync
cd obd2_lib
make clean
make
cp libOBD2.so ../obd2_app/analytics/lib/
cp libOBD2.so ../obd2_app/standard/lib/
sync
cd ../obd2_app/analytics
make clean
make
cp libanalytics.so  ../standard/lib/
sync
cd ../standard/
make clean
make
sync
cp iWaveOBD2FW ../../
cp lib/libanalytics.so ../../
sync
cd ../../
sync
cp libanalytics.so iWaveOBD2FW Application/
tar -cvjf iWaveOBD2FW.tar.bz2 iWaveOBD2FW libanalytics.so
sync
#tar -cvjf Application.tar.bz2 Application/
sync
rm libanalytics.so iWaveOBD2FW
sync

