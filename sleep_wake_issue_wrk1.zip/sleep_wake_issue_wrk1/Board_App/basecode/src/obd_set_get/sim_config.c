#include <sim_config.h>
#include <stdio.h>
#include <libxml2.h>
#include <stdlib.h>
#include <string.h>
#include <debug.h>



LONG get_sim_config(usb_board *p_frame, sim_config_t *p_sim_config)
{

	sim_config_t sim_config = {0};

	UCHAR apn_name[MAX_APN_NAME_STR_SZ] = {0};
	UCHAR access_point[MAX_ACCEPOINT_STR_SZ] = {0};
	UCHAR is_sim_passord_requiried[5] = {0};
	UCHAR sim_username[MAX_SIM_USERNAME_STR_SZ] = {0};
	UCHAR sim_password[MAX_SIM_PASSWORD_STR_SZ] = {0};
	//network_mode=2G 1 ,3G=2 
	UCHAR  network_mode[5] = {0};
	//flight_mode=ON 1,OFF=2
	UCHAR  flight_mode[5] = {0};


	get_xml_content(XML_FILE, "sim_config","apn_name", apn_name);
	get_xml_content(XML_FILE, "sim_config","access_point", access_point);
	get_xml_content(XML_FILE, "sim_config","password_required", is_sim_passord_requiried);
	get_xml_content(XML_FILE, "sim_config","sim_username", sim_username);
	get_xml_content(XML_FILE, "sim_config","sim_password", sim_password);
	get_xml_content(XML_FILE, "sim_config","mode", network_mode);
	get_xml_content(XML_FILE, "sim_config","flight_mode", flight_mode);

        INFO ("xml APN name = %s\n", apn_name);
        INFO ("xml Access point = %s\n", access_point);
        INFO ("xml is password required= %s\n", is_sim_passord_requiried );
        INFO ("xml sim username = %s\n", sim_username);
        INFO ("xml sim password= %s\n", sim_password);
        INFO ("xml network mode= %s\n", network_mode);
        INFO ("xml flight mode= %s\n", flight_mode);


	memcpy(p_sim_config->apn_name, apn_name, MAX_APN_NAME_STR_SZ);
	memcpy(p_sim_config->access_point, access_point, MAX_ACCEPOINT_STR_SZ);
	memcpy(p_sim_config->is_sim_passord_requiried, is_sim_passord_requiried, 1);
//	p_sim_config->is_sim_passord_requiried = atoi(is_sim_passord_requiried);
	memcpy(p_sim_config->sim_username, sim_username, MAX_SIM_USERNAME_STR_SZ);
	memcpy(p_sim_config->sim_password, sim_password, MAX_SIM_PASSWORD_STR_SZ);
	memcpy(p_sim_config->network_mode, network_mode, 1);
	memcpy(p_sim_config->flight_mode, flight_mode, 1);
//	p_sim_config->network_mode = atoi(network_mode);
//	p_sim_config->flight_mode = atoi(flight_mode);

	INFO ("APN name = %s\n", p_sim_config->apn_name);
	INFO ("Access point = %s\n", p_sim_config->access_point);
	INFO ("is password required= %c\n", p_sim_config->is_sim_passord_requiried );
	INFO ("sim username = %s\n", p_sim_config->sim_username);
	INFO ("sim password= %s\n", p_sim_config->sim_password);
	INFO ("network mode= %c\n", p_sim_config->network_mode);
	INFO ("flight mode= %c\n", p_sim_config->flight_mode);
	
		
        return 0;

}

LONG set_sim_config(usb_board *p_frame, sim_config_t *p_sim_config)
{

	sim_config_t sim_config = {0};

	UCHAR is_sim_passord_requiried_xml[5] = {0};
	//network_mode=2G 1 ,3G=2 
	UCHAR  network_mode_xml[5] = {0};
	//flight_mode=ON 1,OFF=2
	UCHAR  flight_mode_xml[5] = {0};


	UCHAR is_sim_passord_requiried;
	UCHAR network_mode;
	UCHAR flight_mode;
	
	UCHAR network_mode_temp[2];
	UCHAR flight_mode_temp[2];

	if(p_frame == NULL)
	{
		ERROR("Invalid argument\n");
	}

	memcpy(&sim_config, p_frame->payload, sizeof(sim_config_t));

	INFO("sim_config.apn_name = %s", sim_config.apn_name);
	INFO("sim_config.access_point = %s", sim_config.access_point);
	INFO("sim_config.sim_password = %s", sim_config.sim_password);
	INFO("network_mode = %d", sim_config.network_mode[0]);
	INFO("flight_mode = %d ********************", sim_config.flight_mode[0]);
	
	is_sim_passord_requiried = atoi(sim_config.is_sim_passord_requiried);
	network_mode_temp [0] = sim_config.network_mode[0];
	network_mode_temp [1] = '\0';
	network_mode = atoi(network_mode_temp);
	flight_mode_temp [0] = sim_config.flight_mode[0];
	flight_mode_temp [1] = '\0';
	flight_mode = atoi(flight_mode_temp);
	//network_mode = atoi(sim_config.network_mode);
	//flight_mode = atoi(sim_config.flight_mode);

	sprintf(is_sim_passord_requiried_xml,"%d", is_sim_passord_requiried);
	sprintf(network_mode_xml, "%d", network_mode);
	sprintf(flight_mode_xml, "%d", flight_mode);


	INFO("sim_config.apn_name = %s", sim_config.apn_name);
	INFO("sim_config.access_point = %s", sim_config.access_point);
	INFO("is_sim_passord_requiried = %d", sim_config.is_sim_passord_requiried[0]);
	INFO("sim_config.sim_username = %s", sim_config.sim_username);
	INFO("sim_config.sim_password = %s", sim_config.sim_password);
	INFO("network_mode = %d", sim_config.network_mode[0]);
	INFO("flight_mode = %d", sim_config.flight_mode[0]);
	
#if 1

	set_xml_content(XML_FILE, "sim_config","apn_name", sim_config.apn_name);
	set_xml_content(XML_FILE, "sim_config","access_point", sim_config.access_point);
	set_xml_content(XML_FILE, "sim_config","password_required", is_sim_passord_requiried_xml);
	set_xml_content(XML_FILE, "sim_config","sim_username", sim_config.sim_username);
	set_xml_content(XML_FILE, "sim_config","sim_password", sim_config.sim_password);
	set_xml_content(XML_FILE, "sim_config","mode", network_mode_xml);
	set_xml_content(XML_FILE, "sim_config","flight_mode", flight_mode_xml);
#endif

	return 0;

}
