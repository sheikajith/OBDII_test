#include <cloud_config.h>
#include <stdio.h>
#include <libxml2.h>
#include <stdlib.h>
#include <string.h>
#include <debug.h>



LONG cloud_azure_config(usb_board *p_frame, cloud_azure_config_t *p_azure_cloud_config)
{

//	printf("SCR_ID = %x, CMD_ID = %x, type = %x, size = %x, crc = %x, payload = %s\n", device_info.scr_id, device_info.cmd_id, device_info.type, device_info.size, device_info.crc, device_info.payload);
        return 0;

}

LONG get_cloud_azure_config(usb_board *p_frame, cloud_azure_config_t *p_azure_cloud_config)
{
	
	cloud_azure_config_t azure_cloud_config = {0};
	UCHAR host[MAX_HOST_STR_SZ] = {0};
	UCHAR port[MAX_PORT_STR_SZ] = {0};
	UCHAR device_id[MAX_DEVICE_ID_STR_SZ] = {0};
	UCHAR device_type[MAX_DEVICE_TYPE_STR_SZ] = {0};
	UCHAR iot_hub_name[MAX_IOT_HUB_NAME_STR_SZ] = {0};
	UCHAR sas_token[MAX_SAS_TOKEN_STR_SZ] = {0};	

	// Get parameters from XML file.
	get_xml_content(XML_FILE, "cloud_azure", "host", host);
	get_xml_content(XML_FILE, "cloud_azure", "port", port);
	get_xml_content(XML_FILE, "cloud_azure", "device_id", device_id);
	get_xml_content(XML_FILE, "cloud_azure", "device_type", device_type);
	get_xml_content(XML_FILE, "cloud_azure", "iot_hub_name", iot_hub_name);
	get_xml_content(XML_FILE, "cloud_azure", "sas_token", sas_token);

	INFO ("xml Host = %s\n", host);

	// Copy parameters to structure
	memcpy(p_azure_cloud_config->host, host, MAX_HOST_STR_SZ);
	memcpy(p_azure_cloud_config->port, port, MAX_PORT_STR_SZ);
	memcpy(p_azure_cloud_config->device_id, device_id, MAX_DEVICE_ID_STR_SZ);
	memcpy(p_azure_cloud_config->device_type, device_type, MAX_DEVICE_TYPE_STR_SZ);
	memcpy(p_azure_cloud_config->iot_hub_name, iot_hub_name, MAX_IOT_HUB_NAME_STR_SZ);
	memcpy(p_azure_cloud_config->sas_token, sas_token, MAX_SAS_TOKEN_STR_SZ);

	INFO ("Host = %s\n", p_azure_cloud_config->host);
	INFO ("Port = %s\n", p_azure_cloud_config->port);
	INFO ("ID = %s\n", p_azure_cloud_config->device_id);
	INFO ("Type = %s\n", p_azure_cloud_config->device_type);
	INFO ("Name = %s\n", p_azure_cloud_config->iot_hub_name);
	INFO ("SAS = %s\n", p_azure_cloud_config->sas_token);

        return 0;

}

char * replace(
    char const * const original,
    char const * const pattern,
    char const * const replacement
) {
  size_t const replen = strlen(replacement);
  size_t const patlen = strlen(pattern);
  size_t const orilen = strlen(original);

  size_t patcnt = 0;
  const char * oriptr;
  const char * patloc;

  // find how many times the pattern occurs in the original string
  for (oriptr = original; patloc = strstr(oriptr, pattern); oriptr = patloc + patlen)
  {
    patcnt++;
  }

  {
    // allocate memory for the new string
    size_t const retlen = orilen + patcnt * (replen - patlen);
    char * const returned = (char *) malloc( sizeof(char) * (retlen + 1) );

    if (returned != NULL)
    {
      // copy the original string, 
      // replacing all the instances of the pattern
      char * retptr = returned;
      for (oriptr = original; patloc = strstr(oriptr, pattern); oriptr = patloc + patlen)
      {
        size_t const skplen = patloc - oriptr;
        // copy the section until the occurence of the pattern
        strncpy(retptr, oriptr, skplen);
        retptr += skplen;
        // copy the replacement 
        strncpy(retptr, replacement, replen);
        retptr += replen;
      }
      // copy the rest of the string.
      strcpy(retptr, oriptr);
    }
    return returned;
  }
}

LONG set_cloud_azure_config(usb_board *p_frame)
{

	cloud_azure_config_t azure_cloud_config = {0};
	UCHAR sas_token[MAX_SAS_TOKEN_STR_SZ];
	UCHAR port[MAX_PORT_STR_SZ];
	if(p_frame == NULL)
	{
		ERROR("Invalid argument\n");
	}
	
	memcpy(&azure_cloud_config, p_frame->payload, sizeof(azure_cloud_config));
	memcpy(sas_token, azure_cloud_config.sas_token, MAX_SAS_TOKEN_STR_SZ);
//	memcpy(port, azure_cloud_config.port, MAX_PORT_STR_SZ);
	

	char * const newstr = replace(sas_token, "&", "&amp;");

//	ERROR ("port = %s\n", port);

        // Get parameters from XML file.
        set_xml_content(XML_FILE, "cloud_azure", "host", azure_cloud_config.host);
        set_xml_content(XML_FILE, "cloud_azure", "port", azure_cloud_config.port);
        set_xml_content(XML_FILE, "cloud_azure", "device_id", azure_cloud_config.device_id);
        set_xml_content(XML_FILE, "cloud_azure", "device_type", azure_cloud_config.device_type);
        set_xml_content(XML_FILE, "cloud_azure", "iot_hub_name", azure_cloud_config.iot_hub_name);
        set_xml_content(XML_FILE, "cloud_azure", "sas_token", newstr);

        INFO ("Host = %s\n", azure_cloud_config.host);
        INFO ("Port = %s\n", azure_cloud_config.port);
        INFO ("ID = %s\n", azure_cloud_config.device_id);
        INFO ("Type = %s\n", azure_cloud_config.device_type);
        INFO ("Name = %s\n", azure_cloud_config.iot_hub_name);
        INFO ("SAS = %s\n", azure_cloud_config.sas_token); 

        return 0;

}
