#include <threshold_setting.h>
#include <stdio.h>
#include <libxml2.h>
#include <stdlib.h>
#include <debug.h>


LONG get_threshold_setting(usb_board *p_frame, settings_threshold_t *p_threshold_setting)
{

	settings_threshold_t threshold_setting = {0};
	UCHAR harsh_brake_source[1] = {0};
	UCHAR harsh_acceleration_source[1] = {0};
	UCHAR crash_source[1] = {0};
	UCHAR harsh_source[1] = {0};
	UCHAR overspeed_source[1] = {0};
	UCHAR odometer_source[1] = {0};

	UCHAR harsh_brake_threshold[10] = {0};
	UCHAR harsh_acceleration_threshold[10] = {0};
	UCHAR crash_threshold[10] = {0};
	UCHAR harsh_threshold[10] = {0};
	UCHAR overspeed_threshold[5] = {0};
	UCHAR over_temp_threshold[8] = {0};
	UCHAR rpm_threshold[5] = {0};
	UCHAR odometer_base[32] = {0};

	UCHAR overspeed_duration[5] = {0};

	get_xml_content(XML_FILE, "harsh_brake", "source", harsh_brake_source);
	get_xml_content(XML_FILE, "harsh_acceleration", "source", harsh_acceleration_source);
	get_xml_content(XML_FILE, "crash", "source", crash_source);
	get_xml_content(XML_FILE, "harsh", "source", harsh_source);
	get_xml_content(XML_FILE, "overspeed", "source", overspeed_source);
	get_xml_content(XML_FILE, "odometer", "source", odometer_source);

	get_xml_content(XML_FILE, "harsh_brake", "threshold", harsh_brake_threshold);
	get_xml_content(XML_FILE, "harsh_acceleration", "threshold", harsh_acceleration_threshold);
	get_xml_content(XML_FILE, "crash", "threshold", crash_threshold);
	get_xml_content(XML_FILE, "harsh", "threshold", harsh_threshold);
	get_xml_content(XML_FILE, "overspeed", "threshold", overspeed_threshold);
	get_xml_content(XML_FILE, "over_temp", "threshold", over_temp_threshold);
	get_xml_content(XML_FILE, "rpm", "threshold", rpm_threshold);
	get_xml_content(XML_FILE, "overspeed", "duration", overspeed_duration);
	get_xml_content(XML_FILE, "odometer", "base_value", odometer_base);

	INFO ("harsh_brake_source = %c\n",harsh_brake_source[0]);
	INFO ("harsh_acceleration_source = %c\n",harsh_acceleration_source[0]);
	INFO ("crash_source = %c\n", crash_source[0]);
	INFO ("harsh_source = %c\n",harsh_source[0]);
	INFO ("overspeed_source = %c\n",overspeed_source[0]);
	INFO ("odometer_source = %c\n",odometer_source[0]);
	INFO ("harsh_brake_threshold = %s\n",harsh_brake_threshold);
	INFO ("harsh_acceleration_threshold = %s\n",harsh_acceleration_threshold);
	INFO ("crash_threshold = %s\n",crash_threshold);
	INFO ("harsh_threshold = %s\n",harsh_threshold);
	INFO ("overspeed_threshold = %s\n",overspeed_threshold);
	INFO ("overspeed_duration = %s\n", overspeed_duration);
	INFO ("over_temp_threshold = %s\n", over_temp_threshold);

        memcpy(p_threshold_setting->harsh_brake_source, harsh_brake_source, 1);
        memcpy(p_threshold_setting->harsh_acceleration_source, harsh_acceleration_source, 1);
        memcpy(p_threshold_setting->crash_source, crash_source, 1);
        memcpy(p_threshold_setting->harsh_source, harsh_source, 1);
        memcpy(p_threshold_setting->overspeed_source, overspeed_source, 1);
	memcpy(p_threshold_setting->odometer_source, odometer_source, 1);

	p_threshold_setting->harsh_brake_threshold = atof(harsh_brake_threshold);
	p_threshold_setting->harsh_acceleration_threshold = atof(harsh_acceleration_threshold);
	p_threshold_setting->crash_threshold = atof(crash_threshold);
	p_threshold_setting->harsh_threshold = atof(harsh_threshold);
	p_threshold_setting->overspeed_threshold = atoi(overspeed_threshold);
	p_threshold_setting->overspeed_duration = atoi(overspeed_duration);
	p_threshold_setting->over_temp_threshold = atoi(over_temp_threshold);
	p_threshold_setting->rpm_threshold = atoi(rpm_threshold);
	p_threshold_setting->odometer_base = atof(odometer_base);

	INFO ("p_threshold_setting->harsh_brake_source = %c\n", p_threshold_setting->harsh_brake_source[0]);
	INFO ("p_threshold_setting->harsh_acceleration_source = %c\n", p_threshold_setting->harsh_acceleration_source[0]);
	INFO ("p_threshold_setting->crash_source = %c\n", p_threshold_setting->crash_source[0]);
	INFO ("p_threshold_setting->harsh_source = %c\n", p_threshold_setting->harsh_source[0]);
	INFO ("p_threshold_setting->overspeed_source = %c\n", p_threshold_setting->overspeed_source[0]);
	INFO ("p_threshold_setting->odometer_source = %c\n", p_threshold_setting->odometer_source[0]);
	INFO ("p_threshold_setting->harsh_brake_threshold = %f\n", p_threshold_setting->harsh_brake_threshold);
	INFO ("p_threshold_setting->harsh_acceleration_threshold = %f\n", p_threshold_setting->harsh_acceleration_threshold);
	INFO ("p_threshold_setting->crash_threshold = %f\n", p_threshold_setting->crash_threshold);
	INFO ("p_threshold_setting->harsh_threshold = %f\n", p_threshold_setting->harsh_threshold);
	INFO ("p_threshold_setting->overspeed_threshold = %d\n", p_threshold_setting->overspeed_threshold);
	INFO ("p_threshold_setting->overspeed_duration = %d\n", p_threshold_setting->overspeed_duration);
	INFO ("p_threshold_setting->over_temp_threshold = %d\n", p_threshold_setting->over_temp_threshold);
	INFO ("p_threshold_setting->rpm_threshold = %d\n", p_threshold_setting->rpm_threshold);
	INFO ("p_threshold_setting->odometer_base = %f\n", p_threshold_setting->odometer_base);

        return 0;

}

LONG set_threshold_setting(usb_board *p_frame)
{

	settings_threshold_t threshold_setting = {0};
	
        UCHAR harsh_brake_source_xml[5] = {0};
        UCHAR harsh_acceleration_source_xml[5] = {0};
        UCHAR crash_source_xml[5] = {0};
        UCHAR harsh_source_xml[5] = {0};
        UCHAR overspeed_source_xml[5] = {0};
	UCHAR odometer_source_xml[5] = {0};

        UCHAR harsh_brake_threshold_xml[10] = {0};
        UCHAR harsh_acceleration_threshold_xml[10] = {0};
	UCHAR crash_threshold_xml[10] = {0};
	UCHAR harsh_threshold_xml[10] = {0};
	UCHAR overspeed_threshold_xml[5] = {0};
	UCHAR over_temp_threshold_xml[5] = {0};
	UCHAR rpm_threshold_xml[5] = {0};
	UCHAR odometer_base_xml[32] = {0};

	UCHAR overspeed_duration_xml[5] = {0};

	UCHAR harsh_brake_source;
	UCHAR harsh_acceleration_source;
	UCHAR crash_source;
	UCHAR harsh_source;
	UCHAR overspeed_source;
	UCHAR odometer_source = 0;

	UCHAR harsh_brake_source_temp[2];
	UCHAR harsh_acceleration_source_temp[2];
	UCHAR crash_source_temp[2];
	UCHAR harsh_source_temp[2];
	UCHAR overspeed_source_temp[2];
	UCHAR odometer_source_temp[2];

	if(p_frame == NULL)
	{
		ERROR("Invalid arguments\n");
		return -1;
	}

	/* !< Copy payload to threshould settings struct */
	memcpy(&threshold_setting, p_frame->payload, sizeof(settings_threshold_t));

        INFO("harsh_brake_source = %c\n", threshold_setting.harsh_brake_source[0]);
        INFO("harsh_acceleration_source_xml= %c\n", threshold_setting.harsh_acceleration_source[0]);
        INFO("crash_source_xml= %c\n", threshold_setting.crash_source[0]);
        INFO("harsh_source_xml= %c\n", threshold_setting.harsh_source[0]);
        INFO("overspeed_source_xml= %c\n", threshold_setting.overspeed_source[0]);
        INFO("odometer_source_xml= %c\n", threshold_setting.odometer_source[0]);

	INFO("harsh_brake_threshold_xml= %f\n", threshold_setting.harsh_brake_threshold);
        INFO("harsh_acceleration_threshold_xml= %f\n", threshold_setting.harsh_acceleration_threshold);
        INFO("crash_threshold_xml= %f\n", threshold_setting.crash_threshold);
        INFO("harsh_threshold_xml= %f\n", threshold_setting.harsh_threshold);
        INFO("overspeed_threshold_xml= %hd\n", threshold_setting.overspeed_threshold);
        INFO("over_temp_threshold_xml= %hd\n", threshold_setting.over_temp_threshold);
        INFO("rpm_threshold_xml= %hd\n", threshold_setting.rpm_threshold);
        INFO("odometer_base_xml= %f\n", threshold_setting.odometer_base);
        INFO("overspeed_duration_xml= %hd\n", threshold_setting.overspeed_duration);

#if 0

     	harsh_brake_source_temp [0] = threshold_setting.harsh_brake_source[0];
	harsh_brake_source_temp [1] = '\0';
        harsh_brake_source = atoi(harsh_brake_source_temp);

     	harsh_acceleration_source_temp [0] = threshold_setting.harsh_acceleration_source[0];
        harsh_acceleration_source_temp [1] = '\0';
        harsh_acceleration_source = atoi(harsh_brake_source_temp);

     	crash_source_temp [0] = threshold_setting.crash_source[0];
        crash_source_temp [1] = '\0';
        crash_source = atoi(crash_source_temp);

     	harsh_source_temp [0] = threshold_setting.harsh_source[0];
        harsh_source_temp [1] = '\0';
        harsh_source = atoi(harsh_source_temp);

     	overspeed_source_temp [0] = threshold_setting.overspeed_source[0];
        overspeed_source_temp [1] = '\0';
        overspeed_source = atoi(overspeed_source_temp);

	odometer_source_temp [0] = threshold_setting.odometer_source[0];
	odometer_source_temp [1] = '\0';
	odometer_source = atoi(odometer_source_temp);
	sprintf(harsh_brake_source_xml, "%d", harsh_brake_source);
	sprintf(harsh_acceleration_source_xml, "%d", harsh_acceleration_source);
	sprintf(crash_source_xml, "%d", crash_source);
	sprintf(harsh_source_xml, "%d", harsh_source);
	sprintf(overspeed_source_xml, "%d", overspeed_source);
	sprintf(odometer_source_xml, "%d", odometer_source);
#endif

	/* !< Convert UCHAR to string */
	sprintf(harsh_brake_source_xml, "%c", threshold_setting.harsh_brake_source[0]);
	sprintf(harsh_acceleration_source_xml, "%c", threshold_setting.harsh_acceleration_source[0]);
	sprintf(crash_source_xml, "%c", threshold_setting.crash_source[0]);
	sprintf(harsh_source_xml, "%c", threshold_setting.harsh_source[0]);
	sprintf(overspeed_source_xml, "%c", threshold_setting.overspeed_source[0]);
	sprintf(odometer_source_xml, "%c", threshold_setting.odometer_source[0]);

	sprintf(harsh_brake_threshold_xml, "%f", threshold_setting.harsh_brake_threshold);
	sprintf(harsh_acceleration_threshold_xml, "%f", threshold_setting.harsh_acceleration_threshold);
	sprintf(crash_threshold_xml, "%f", threshold_setting.crash_threshold);
	sprintf(harsh_threshold_xml, "%f", threshold_setting.harsh_threshold);
	sprintf(overspeed_threshold_xml, "%hd", threshold_setting.overspeed_threshold);
	sprintf(over_temp_threshold_xml, "%hd", threshold_setting.over_temp_threshold);
	sprintf(rpm_threshold_xml, "%hd", threshold_setting.rpm_threshold);
	sprintf(odometer_base_xml, "%f", threshold_setting.odometer_base);
	sprintf(overspeed_duration_xml, "%hd", threshold_setting.overspeed_duration);


	INFO("harsh_brake_source_xml= %s\n", harsh_brake_source_xml);
	INFO("harsh_acceleration_source_xml= %s\n", harsh_acceleration_source_xml);
	INFO("crash_source_xml= %s\n", crash_source_xml);
	INFO("harsh_source_xml= %s\n", harsh_source_xml);
	INFO("overspeed_source_xml= %s\n", overspeed_source_xml);
	INFO("odometer_source_xml = %s\n", odometer_source_xml);

	INFO("harsh_brake_threshold_xml= %s\n", harsh_brake_threshold_xml);
	INFO("harsh_acceleration_threshold_xml= %s\n", harsh_acceleration_threshold_xml);
	INFO("crash_threshold_xml= %s\n", crash_threshold_xml);
	INFO("harsh_threshold_xml= %s\n", harsh_threshold_xml);
	INFO("overspeed_threshold_xml= %s\n", overspeed_threshold_xml);
	INFO("over_temp_threshold_xml= %s\n", over_temp_threshold_xml);
	INFO("rpm_threshold_xml= %s\n", rpm_threshold_xml);
	INFO("odometer_base_xml= %s\n", odometer_base_xml);
	INFO("overspeed_duration_xml= %s\n", overspeed_duration_xml);

	/* !< Set xml content */
        set_xml_content(XML_FILE, "harsh_brake", "source", harsh_brake_source_xml);
        set_xml_content(XML_FILE, "harsh_acceleration", "source", harsh_acceleration_source_xml);
        set_xml_content(XML_FILE, "crash", "source", crash_source_xml);
        set_xml_content(XML_FILE, "harsh", "source", harsh_source_xml);
        set_xml_content(XML_FILE, "overspeed", "source", overspeed_source_xml);
	set_xml_content(XML_FILE, "odometer", "source", odometer_source_xml);
        set_xml_content(XML_FILE, "harsh_brake", "threshold", harsh_brake_threshold_xml);
        set_xml_content(XML_FILE, "harsh_acceleration", "threshold", harsh_acceleration_threshold_xml);
        set_xml_content(XML_FILE, "crash", "threshold", crash_threshold_xml);
        set_xml_content(XML_FILE, "harsh", "threshold", harsh_threshold_xml);
        set_xml_content(XML_FILE, "overspeed", "threshold", overspeed_threshold_xml);
        set_xml_content(XML_FILE, "over_temp", "threshold", over_temp_threshold_xml);
        set_xml_content(XML_FILE, "rpm", "threshold", rpm_threshold_xml);
        set_xml_content(XML_FILE, "odometer", "base_value", odometer_base_xml);
        set_xml_content(XML_FILE, "overspeed", "duration", overspeed_duration_xml);

        return 0;
}

