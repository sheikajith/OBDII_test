#include <io_status.h>
#include <stdio.h>
#include <unistd.h>
#include <debug.h>
#include <libxml2.h>

#define IG_PIN	10

LONG get_io_status(usb_board *p_frame, st_io_info_rsp_t *p_io_info_st_rsp)
{

	UCHAR ignition_status[1] = {0};
	UCHAR ignition_status_xml[5] = {0};

	UCHAR ain1[1] = {0};
	UCHAR ain1_xml[MAX_AIN1_STATUS_STR_SZ] = {0};

	double ain1_voltage = 0;

	LONG ret;
        if(p_frame == NULL)             
        {                       
                ERROR("Invalid argument\n");
	}

#if 0
	ret = gpio_export(IG_PIN);
	if(ret < 0)
	{
		ERROR ("Unable to export IG pin\n");
	}

	ret = get_gpio(IG_PIN, &ignition_status);
        if(ret < 0)
        {
                ERROR ("Unable to get IG pin value\n");
        }

	/* !<Convert to string to update in xml file*/
	sprintf(ignition_status_xml, "%d", ignition_status);

	/* !< Update IG pin status in xml file*/                            
	set_xml_content(XML_FILE, "io","ignition_pin", ignition_status_xml);

        get_xml_content(XML_FILE, "io","ain1", ain1_xml);

        DEBUG (" ignition_status_xml = %s\n", ignition_status_xml);
        DEBUG (" ain1 = %s\n", ain1_xml);

#endif

	check_adc_voltage(&ain1_voltage);

	sprintf(ain1_xml, "%lf", ain1_voltage);
	
	
        set_xml_content(XML_FILE, "io_status","ain1", ain1_xml);
        get_xml_content(XML_FILE, "io_status","ignition_pin", ignition_status_xml);

        memcpy(p_io_info_st_rsp->ignition_status, ignition_status_xml, 1);
        memcpy(p_io_info_st_rsp->ain1, ain1_xml, MAX_AIN1_STATUS_STR_SZ);

        return 0;

}
