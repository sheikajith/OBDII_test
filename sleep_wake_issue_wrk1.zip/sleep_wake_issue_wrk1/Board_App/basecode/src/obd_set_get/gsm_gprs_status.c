#include <gsm_gprs_status.h>
#include <stdio.h>
#include <debug.h>
#include <common.h>
#include <libxml2.h>

#if 0 
#include<peru_header.h>
#endif

LONG get_gsm_gprs_status(usb_board *p_frame, st_gsm_gprs_info_rsp_t *p_gsm_gprs_info_st_rsp)

{


	UCHAR sim_status[1];
	UCHAR network_status[1];
	
	int connection;

	UCHAR sim_status_xml[5];
	UCHAR network_status_xml[5];


	if(p_frame == NULL)             
	{                       
		ERROR("Invalid argument\n");
	}               
	
#if 0
	/* !< Get sim and network status*/
	sim_status = 0;
	network_status =  0;

	connection = check_connection();

	DEBUG ("connection = %d\n", connection);

	/* !< Convert to string to write in xml */
	sprintf(sim_status_xml, "%d", sim_status);
	sprintf(network_status_xml, "%d", network_status);


	/* !< Update in xml */
        set_xml_content(XML_FILE, "gsm_gprs","sim_status", sim_status_xml );
        set_xml_content(XML_FILE, "gsm_gprs","network_status", network_status_xml);

	
//	/* !< Update response struct */
//	p_gsm_gprs_info_st_rsp->sim_status = sim_status;
//	p_gsm_gprs_info_st_rsp->network_status = network_status;
#endif

        /* !< Update response struct */
//        p_gsm_gprs_info_st_rsp->sim_status = 1;
//        p_gsm_gprs_info_st_rsp->network_status = 1;

        get_xml_content(XML_FILE, "gsm_gprs","sim_status", sim_status_xml);
        get_xml_content(XML_FILE, "gsm_gprs","network_status", network_status_xml);

	DEBUG (" sim_status_xml = %s\n", sim_status_xml);
	DEBUG (" network_status_xml = %s\n", network_status_xml);



	memcpy(p_gsm_gprs_info_st_rsp->sim_status, sim_status_xml, 1);
	memcpy(p_gsm_gprs_info_st_rsp->network_status, network_status_xml, 1);


	return 0;

}
