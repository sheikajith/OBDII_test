#include <general_setting.h>
#include <stdio.h>
#include <libxml2.h>
#include <stdlib.h>
#include <debug.h>


LONG get_general_setting(usb_board *p_frame, settings_general_t *p_general_setting)
{
	settings_general_t general_setting = {0};
	usb_pkt_t general_setting_rsp;
	UCHAR mode[5] = {0};
	UCHAR sampling_frequency[5] = {0};
	UCHAR can_sign[5] = {0};
	UCHAR fatige_detection[5] = {0};
	UCHAR idle_time[5] = {0};

	get_xml_content(XML_FILE, "general","mode", mode);
	get_xml_content(XML_FILE, "general","sampling_frequency", sampling_frequency);
	get_xml_content(XML_FILE, "general","can_sign", can_sign);
	get_xml_content(XML_FILE, "general","fatige_detection", fatige_detection);
	get_xml_content(XML_FILE, "general","idle_time", idle_time);
	
	memcpy (p_general_setting->mode, mode, 1);
	p_general_setting->sampling_frequency = atoi(sampling_frequency);
	p_general_setting->can_sign = atoi(can_sign);
	p_general_setting->fatige_detection = atoi(fatige_detection);
	p_general_setting->idle_time = atoi(idle_time);

	INFO ("p_general_setting->mode = %d\n", p_general_setting->mode);
	INFO ("p_general_setting->sampling_frequency = %d\n", p_general_setting->sampling_frequency);
	INFO ("p_general_setting->can_sign = %d\n", p_general_setting->can_sign);
	INFO ("p_general_setting->fatige_detection = %d\n", p_general_setting->fatige_detection);
	INFO ("p_general_setting->idle_time = %d\n", p_general_setting->idle_time);
	
        return 0;

}

LONG set_general_setting(usb_board *p_frame)
{
	settings_general_t general_setting = {0};


	USHORT mode;
	USHORT sampling_frequency;
	USHORT can_sign;
	USHORT fatige_detection;
	USHORT idle_time;

	UCHAR mode_xml[5] = {0};
	UCHAR sampling_frequency_xml[5] = {0};
	UCHAR can_sign_xml[5] = {0};
	UCHAR fatige_detection_xml[5] = {0};
	UCHAR idle_time_xml[5] = {0};

	UCHAR mode_temp[2];

	if(p_frame == NULL)
	{
		ERROR("Invalid arguments\n");
	}

	memcpy(&general_setting, p_frame->payload, sizeof(settings_general_t));

        INFO ("p_general_setting->mode = %c\n", general_setting.mode);
        INFO ("p_general_setting->sampling_frequency = %d\n", general_setting.sampling_frequency);
        INFO ("p_general_setting->can_sign = %d\n", general_setting.can_sign);
        INFO ("p_general_setting->fatige_detection = %d\n", general_setting.fatige_detection);
        INFO ("p_general_setting->idle_time = %d\n", general_setting.idle_time);


        mode_temp [0] = general_setting.mode[0];
        mode_temp [1] = '\0';
        mode = atoi(mode_temp);

	sprintf(mode_xml, "%d", mode); 	
	sprintf(sampling_frequency_xml, "%d", general_setting.sampling_frequency); 	
	sprintf(can_sign_xml, "%d", general_setting.can_sign);	
	sprintf(fatige_detection_xml, "%d", general_setting.fatige_detection);	
	sprintf(idle_time_xml, "%d", general_setting.idle_time);	

	INFO ("mode_xml =%s\n", mode_xml);
	INFO ("sampling_frequency_xml =%s\n", sampling_frequency_xml);
	INFO ("can_sign_xml =%s\n", can_sign_xml);
	INFO ("fatige_detection_xml =%s\n", fatige_detection_xml);
	INFO ("idle_time_xml =%s\n", idle_time_xml);

        set_xml_content(XML_FILE, "general","mode", mode_xml);
        set_xml_content(XML_FILE, "general","sampling_frequency", sampling_frequency_xml);
        set_xml_content(XML_FILE, "general","can_sign", can_sign_xml);
        set_xml_content(XML_FILE, "general","fatige_detection", fatige_detection_xml);
        set_xml_content(XML_FILE, "general","idle_time", idle_time_xml);

	
        return 0;

}

