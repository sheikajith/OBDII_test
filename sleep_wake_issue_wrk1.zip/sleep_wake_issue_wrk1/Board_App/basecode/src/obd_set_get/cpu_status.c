#include <cpu_status.h>
#include <stdio.h>
#include <sys/sysinfo.h>
#include <debug.h>
#include <libxml2.h>

float get_ddr3_size()
{
	struct sysinfo ddr3_size;
	LONG ret;

	float ram_sz;

	ret = sysinfo(&ddr3_size);
	if(ret < 0)
	{
		ERROR ("Failed to read sysinfo\n");
	}

	ram_sz = (ddr3_size.totalram * ddr3_size.mem_unit) / (1024 * 1024);
	
	return ram_sz;

}

LONG get_nand_size()
{

        FILE *fp;
        char nand_buf[20] = {0};
        int size = 0;

	LONG nand_sz = 0;

        fp = fopen("/sys/class/mtd/mtd0/size", "r");

        size = fread(nand_buf, 1, 20, fp);

        fclose(fp);

	nand_sz += atoi(nand_buf);

	memset(nand_buf, 0, sizeof(nand_buf));

        fp = fopen("/sys/class/mtd/mtd1/size", "r");

        size = fread(nand_buf, 1, 20, fp);

        fclose(fp);

	nand_sz += atoi(nand_buf);


	memset(nand_buf, 0, sizeof(nand_buf));

	fp = fopen("/sys/class/mtd/mtd2/size", "r");

        size = fread(nand_buf, 1, 20, fp);

        fclose(fp);

	nand_sz += atoi(nand_buf);


	memset(nand_buf, 0, sizeof(nand_buf));

        fp = fopen("/sys/class/mtd/mtd3/size", "r");

        size = fread(nand_buf, 1, 20, fp);

        fclose(fp);

	nand_sz += atoi(nand_buf);


	memset(nand_buf, 0, sizeof(nand_buf));

        fp = fopen("/sys/class/mtd/mtd4/size", "r");

        size = fread(nand_buf, 1, 20, fp);

        fclose(fp);

	nand_sz += atoi(nand_buf);


	memset(nand_buf, 0, sizeof(nand_buf));

        fp = fopen("/sys/class/mtd/mtd5/size", "r");

        size = fread(nand_buf, 1, 20, fp);

        fclose(fp);

	nand_sz += atoi(nand_buf);

	memset(nand_buf, 0, sizeof(nand_buf));

        fp = fopen("/sys/class/mtd/mtd6/size", "r");

        size = fread(nand_buf, 1, 20, fp);

        fclose(fp);

	nand_sz += atoi(nand_buf);



	return nand_sz / (1024*1024);

}

LONG get_proc_name(UCHAR *proc_name)
{
	FILE *fp;
	int size = 0;
	char cpuinfo_buf[1024];
	char *model_name;
	char *model_name_token;

	fp = fopen("/proc/cpuinfo", "r");

	if (fp == NULL)
	{
		ERROR ("\nFile unable to open ");
	}

	size = fread(cpuinfo_buf, 1, 1024, fp);


	model_name = strstr(cpuinfo_buf, "model name");


	model_name_token = strtok(model_name, ":\n");
	model_name_token = strtok(NULL, ":\n");

	memcpy(proc_name, model_name_token, strlen(model_name_token));

	INFO ("proc_name = %s\n", proc_name);


	fclose(fp);


	return 0;
}

LONG get_clk_speed(USHORT *clock_speed)
{

	FILE *fp;
	char clock_speed_buf[10];
	int size = 0;

	fp = fopen("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq", "r");

	size = fread(clock_speed_buf, 1, 10, fp);

	*clock_speed = atoi(clock_speed_buf) / 1000;

	fclose(fp);

	return 0;

}
LONG get_cpu_status(usb_board *p_frame, st_cpu_info_req_t *p_cpu_status)
{

	UCHAR proc_name[MAX_PROCESSOR_NAME_STR_SZ] = {0};
	UCHAR clk_speed[MAX_CLK_SPEED_STR_SZ] = {0};
	UCHAR ddr3[MAX_DDR3_STR_SZ] = {0};
	UCHAR nand[MAX_NAND_STR_SZ] = {0};
	float ddr3_sz = 0;
	LONG nand_sz = 0;
	USHORT clock_speed;

	if(p_frame == NULL)
	{
		ERROR("Invalid argument\n");
	}

	ddr3_sz = get_ddr3_size();
	nand_sz = get_nand_size();
	
	sprintf(ddr3, "%f", ddr3_sz);
	sprintf(nand, "%d", nand_sz);

	get_proc_name(proc_name);

	get_clk_speed(&clock_speed);	

	sprintf(clk_speed, "%d", clock_speed);

//	memcpy(clk_speed, "1234", 5);
	//memcpy(nand, "998", 3);

	INFO ("DDR3 = %s\n", ddr3);
	INFO ("NAND = %s\n", nand);

	
	INFO ("clk_speed = %s\n", clk_speed);
	
	memcpy(p_cpu_status->proc_name, proc_name, MAX_PROCESSOR_NAME_STR_SZ);
	memcpy(p_cpu_status->clk_speed, clk_speed, MAX_CLK_SPEED_STR_SZ);
	memcpy(p_cpu_status->ddr3, ddr3, MAX_DDR3_STR_SZ);
	memcpy(p_cpu_status->nand, nand, MAX_NAND_STR_SZ);

	return 0;

}
