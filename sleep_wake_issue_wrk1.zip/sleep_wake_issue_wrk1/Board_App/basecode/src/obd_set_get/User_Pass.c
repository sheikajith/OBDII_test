#include <User_Pass.h>
#include <stdio.h>
#include <libxml2.h>
#include <stdlib.h>
#include <debug.h>
#include <string.h>

LONG get_SOTA_User_Pass(usb_board *p_frame, SOTA_UserPass_t *p_User_Pass)
{
	SOTA_UserPass_t User_Pass = {0};
	UCHAR Username1[MAX_USERNAME1_STR_SZ] = {0};
	UCHAR Password1[MAX_PASSWORD1_STR_SZ] = {0};
	UCHAR Username2[MAX_USERNAME2_STR_SZ] = {0};
	UCHAR Password2[MAX_PASSWORD2_STR_SZ] = {0};
	UCHAR Username3[MAX_USERNAME3_STR_SZ] = {0};
        UCHAR Password3[MAX_PASSWORD3_STR_SZ] = {0};
        UCHAR Username4[MAX_USERNAME4_STR_SZ] = {0};
        UCHAR Password4[MAX_PASSWORD4_STR_SZ] = {0};
	UCHAR Username5[MAX_USERNAME5_STR_SZ] = {0};
        UCHAR Password5[MAX_PASSWORD5_STR_SZ] = {0};


	// Get Parameters from XML File.
	get_xml_content(XML_FILE, "Authentication", "Username1", Username1);
	get_xml_content(XML_FILE, "Authentication", "Password1", Password1);
	get_xml_content(XML_FILE, "Authentication", "Username2", Username2);
	get_xml_content(XML_FILE, "Authentication", "Password2", Password2);
        get_xml_content(XML_FILE, "Authentication", "Username3", Username3);
        get_xml_content(XML_FILE, "Authentication", "Password3", Password3);
        get_xml_content(XML_FILE, "Authentication", "Username4", Username4);
        get_xml_content(XML_FILE, "Authentication", "Password4", Password4);
	get_xml_content(XML_FILE, "Authentication", "Username5", Username5);
        get_xml_content(XML_FILE, "Authentication", "Password5", Password5);


	INFO("xml Username1 = %s\n", Username1);
	INFO("xml Password1 = %s\n", Password1);

	// Copy Parameter to Structure.
	memcpy(p_User_Pass->Username1, Username1, MAX_USERNAME1_STR_SZ);
	memcpy(p_User_Pass->Password1, Password1, MAX_PASSWORD1_STR_SZ);
	memcpy(p_User_Pass->Username2, Username2, MAX_USERNAME2_STR_SZ);
	memcpy(p_User_Pass->Password2, Password2, MAX_PASSWORD2_STR_SZ);
	memcpy(p_User_Pass->Username3, Username3, MAX_USERNAME3_STR_SZ);
        memcpy(p_User_Pass->Password3, Password3, MAX_PASSWORD3_STR_SZ);
        memcpy(p_User_Pass->Username4, Username4, MAX_USERNAME4_STR_SZ);
        memcpy(p_User_Pass->Password4, Password4, MAX_PASSWORD4_STR_SZ);
        memcpy(p_User_Pass->Username5, Username5, MAX_USERNAME5_STR_SZ);
        memcpy(p_User_Pass->Password5, Password5, MAX_PASSWORD5_STR_SZ);


	INFO ("Username1 = %s\n", p_User_Pass->Username1);
	INFO ("Password1 = %s\n", p_User_Pass->Password1);
	INFO ("Username2 = %s\n", p_User_Pass->Username2);
	INFO ("Password2 = %s\n", p_User_Pass->Password2);
        INFO ("Username3 = %s\n", p_User_Pass->Username3);
        INFO ("Password3 = %s\n", p_User_Pass->Password3);
        INFO ("Username4 = %s\n", p_User_Pass->Username4);
        INFO ("Password4 = %s\n", p_User_Pass->Password4);
        INFO ("Username5 = %s\n", p_User_Pass->Username5);
        INFO ("Password5 = %s\n", p_User_Pass->Password5);


	return 0;
}

LONG set_SOTA_User_Pass(usb_board *p_frame)
{
	SOTA_UserPass_t User_Pass = {0};
	UCHAR Username1[MAX_USERNAME1_STR_SZ];
	UCHAR Password1[MAX_PASSWORD1_STR_SZ];
	UCHAR Username2[MAX_USERNAME2_STR_SZ];
	UCHAR Password2[MAX_PASSWORD2_STR_SZ];
        UCHAR Username3[MAX_USERNAME3_STR_SZ];
        UCHAR Password3[MAX_PASSWORD3_STR_SZ];
        UCHAR Username4[MAX_USERNAME4_STR_SZ];
        UCHAR Password4[MAX_PASSWORD4_STR_SZ];
        UCHAR Username5[MAX_USERNAME5_STR_SZ];
        UCHAR Password5[MAX_PASSWORD5_STR_SZ];


	if(p_frame == NULL)
	{
		ERROR("Invalid Argument\n");
	}

	memcpy(&User_Pass, p_frame->payload, sizeof(SOTA_UserPass_t));

	// Get Parameters from XML File.
	set_xml_content(XML_FILE, "Authentication", "Username1", User_Pass.Username1);
	set_xml_content(XML_FILE, "Authentication", "Password1", User_Pass.Password1);
	set_xml_content(XML_FILE, "Authentication", "Username2", User_Pass.Username2);
	set_xml_content(XML_FILE, "Authentication", "Password2", User_Pass.Password2);
        set_xml_content(XML_FILE, "Authentication", "Username3", User_Pass.Username3);
        set_xml_content(XML_FILE, "Authentication", "Password3", User_Pass.Password3);
        set_xml_content(XML_FILE, "Authentication", "Username4", User_Pass.Username4);
        set_xml_content(XML_FILE, "Authentication", "Password4", User_Pass.Password4);
        set_xml_content(XML_FILE, "Authentication", "Username5", User_Pass.Username5);
        set_xml_content(XML_FILE, "Authentication", "Password5", User_Pass.Password5);

	INFO ("Username1 = %s\n", User_Pass.Username1);
	INFO ("Password1 = %s\n", User_Pass.Password1);
	INFO ("Username2 = %s\n", User_Pass.Username2);
	INFO ("Password2 = %s\n", User_Pass.Password2);
        INFO ("Username3 = %s\n", User_Pass.Username3);
        INFO ("Password3 = %s\n", User_Pass.Password3);
        INFO ("Username4 = %s\n", User_Pass.Username4);
        INFO ("Password4 = %s\n", User_Pass.Password4);
        INFO ("Username5 = %s\n", User_Pass.Username5);
        INFO ("Password5 = %s\n", User_Pass.Password5);


	return 0;
}
