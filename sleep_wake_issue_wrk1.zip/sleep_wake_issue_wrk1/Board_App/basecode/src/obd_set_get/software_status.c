#include <software_status.h>
#include <libxml2.h>
#include <stdio.h>
#include <sys/utsname.h>
#include <errno.h>
#include <stdlib.h>
#include <error_macro.h>
#include <debug.h>


LONG get_linux_version(struct utsname *buffer) {
	errno = 0;
	if (uname(buffer) != 0) {
		perror("uname");
		exit(EXIT_FAILURE);
	}
	return EXIT_SUCCESS;
}

LONG get_software_status(usb_board *p_frame, st_software_info_rsp_t *p_software_info)
{
	
	struct utsname buffer;
	LONG ret;
	st_software_info_rsp_t software_info = {0};

	/*!< Validate the input arguments */
	if(p_frame == NULL)
	{
		ERROR("Invalid arguments\n");
	}

	ret = get_linux_version(&buffer);
	if (ret == 0)
	{
		INFO ("release     = %s\nsize = %ld\n", buffer.release, strlen(buffer.release));	
	}
	memcpy(p_software_info->linux_version, buffer.release, strlen(buffer.release));
	
	/*!< locking mechanism required when accessed from different context */
	set_xml_content(XML_FILE,"software","linux_version", p_software_info->linux_version);  
	
	
        return 0;


}
