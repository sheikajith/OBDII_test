#include <device_info.h>
#include <stdio.h>
#include <debug.h>
#include <common.h>
#include <q_gps.h>
#include <errno.h>
#include <libxml2.h>


int get_imei_modem_usb(char *imei_no)
{
	char val[20];
	char at_cmd[10];
	int numberofbytesent, numberofbytesrcvd;
	int serial_fd = 0;
//	FILE *fp;
	int rc = 0;
//	fp = fopen("/home/root/imei.txt","w");

	printf("acm w+ \n");
	sem_wait(ret_4g_value);
	printf("acm w- \n");

	serial_fd = iW_Serial_Init(0,115200);
	if(serial_fd <= 0)
	{
		printf ("get_imei_modem: iW_Serial_Init: failed\n");

		printf("acm fp+ \n");
		sem_post(ret_4g_value);
		printf("acm fp- \n");

		return -1;
	}
	bzero (imei_no,20);
	memset(val, 0x0, 20);
	memset(at_cmd, 0x0, 10);
	strcpy(at_cmd, "ate0\r");
	numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
	if(numberofbytesent <= 0)
	{
		perror("iw_serial_write:\nerror while writing to serial device\n");
		printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
		rc = -1;
	}
	usleep(1000000);
	numberofbytesrcvd = read(serial_fd, val, 20);
	if(numberofbytesrcvd <= 0)
	{
		perror("get_imei_modem:iw_serial_read:\nerror while reading from serial device");
		printf("errno = %d \r\n",errno);
		rc = -1;
	}

	memset(val, 0x0, 20);
	memset(at_cmd, 0x0, 10);
send_again:	strcpy(at_cmd, "at+gsn\r");
	numberofbytesent = write (serial_fd ,at_cmd, strlen(at_cmd));
	if(numberofbytesent <= 0)
	{
		perror("get_imei_modem:iw_serial_write:\nerror while writing to serial device\n");
		printf("errno = %d, serial_fd %d\r\n",errno, serial_fd);
		rc= -1;
	}
	usleep(1000000);
	numberofbytesrcvd = read(serial_fd, val, 20);
	if(numberofbytesrcvd <= 0)
	{
		perror("get_imei_modem:iw_serial_read:\nerror while reading from serial device");
		printf("errno = %d \r\n",errno);
		rc = -1;
	}

	strncpy(imei_no, &val[2], 15);
	printf("1.imei_no:%s\r\n", imei_no);
	if ((imei_no[1] != '6') && (imei_no[0] != '8'))
		goto send_again;
	printf("2.imei_no:%s\r\n", imei_no);
//	fprintf(fp,"id=%s",imei_no);
	memset(val, 0x0, 20);
	memset(at_cmd, 0x0, 10);
//	fclose(fp);
	close(serial_fd);

	printf("acm p+ \n");
	sem_post(ret_4g_value);
	printf("acm p- \n");

	return rc;
}

LONG device_info(usb_board *p_frame, st_dev_info_t *p_dev_info_st_rsp)
{

	UCHAR device_name[MAX_DEVICE_NAME_STR_SZ] = {0};
	UCHAR imei_number[MAX_IMEI_STR_SZ] = {0};
	UCHAR ext_power[MAX_EXT_POWER_STR_SZ] = {0};
	UCHAR int_battery[MAX_INT_POWER_STR_SZ] = {0};

	LONG ret ;

//memset(device_name, 0, MAX_DEVICE_NAME_STR_SZ);

	DEBUG ("Entering  device_info\n");

        if(p_frame == NULL)     
        {                       
                ERROR("Invalid argument\n");
        }

#if 0
	ret = get_imei_modem_usb(imei_number);
	
	if (ret == 0)
	{
		DEBUG ("get_imei_modem success\n");	
	}
	else 
	{
		 memcpy(imei_number, "000000000", 9);
	}
#endif

#if 0
	memcpy(device_name, "OBDIII", 6);                  
	memcpy(imei_number, "123456789", 9);                  
	memcpy(device_name, "OBDII", 5);                  
	memcpy(ext_power, "10", 2);                  
	memcpy(int_battery, "4", 1);                  
#endif
	get_xml_content(XML_FILE, "home","device_name", device_name);
	get_xml_content(XML_FILE, "home","imei", imei_number);
	get_xml_content(XML_FILE, "home","ext_bat", ext_power);
	get_xml_content(XML_FILE, "home","int_bat", int_battery);
#if 1

 	while(1)
	{ 
		if (imei_number[1] == '6' && imei_number[0] == '8')
			break;
		else
			{	
			usleep(500000);
			get_xml_content(XML_FILE, "home","imei", imei_number);
			}

	}
#endif
	
	memcpy(p_dev_info_st_rsp->device_name, device_name, MAX_DEVICE_NAME_STR_SZ);
	memcpy(p_dev_info_st_rsp->imei_number, imei_number, MAX_IMEI_STR_SZ);
	memcpy(p_dev_info_st_rsp->ext_power, ext_power, MAX_EXT_POWER_STR_SZ);
	memcpy(p_dev_info_st_rsp->int_battery, int_battery, MAX_INT_POWER_STR_SZ);

	return 0;
}
