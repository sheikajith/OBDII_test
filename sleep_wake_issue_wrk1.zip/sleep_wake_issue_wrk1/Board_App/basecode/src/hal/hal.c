#include <hal.h>
#include <fcntl.h> 
#include <errno.h> 
#include <stdlib.h>
#include <debug.h>
#include <termios.h>
#include <unistd.h>
#include <error_macro.h>
#include <string.h>

#define DATABITS        8
#define PARITY         'N'
#define STOPBITS        1
#define BAUDRATE        9600

int tty_fd;
fd_set read_fds;
fd_set write_fds;
fd_set except_fds;

int iW_Serial_SetDatabits_usb( struct termios *TermiosPtr, int databits)
{
	TermiosPtr->c_cflag &= ~CSIZE;
	/*  Select 8 data bits */
	if(databits == 5) TermiosPtr->c_cflag |= CS5;
	else if(databits == 6) TermiosPtr->c_cflag |= CS6;
	else if(databits == 7) TermiosPtr->c_cflag |= CS7;
	else  TermiosPtr->c_cflag |= CS8;

	return 0;
}

int iW_Serial_SetStopbits_usb( struct termios *TermiosPtr, int Stopbits)
{
	if(Stopbits == 2)
		TermiosPtr->c_cflag |= CSTOPB;
	else
		TermiosPtr->c_cflag &= ~CSTOPB;
	return 0;
}

int iW_Serial_SetParity_usb( struct termios *TermiosPtr, char Parity)
{
	if(Parity == 'n' || Parity == 'N')
		TermiosPtr->c_cflag &= ~PARENB;
	else if(Parity == 'o' || Parity == 'O')
	{
		TermiosPtr->c_cflag |= PARENB;
		TermiosPtr->c_cflag |= PARODD;
	}
	else
	{
		TermiosPtr->c_cflag |= PARENB;
		TermiosPtr->c_cflag &= ~PARODD;
	}
	return 0;
}


int iW_Serial_SetBaudrate_usb( struct termios* TermiosPtr, int Baudrate)
{
	/* Baud rate */
	speed_t Speed = B50;
	/* Error handling variable */
	int status = 0;

	/* Select the Baud rate */
	if(Baudrate == 460800) Speed = B460800;
	if(Baudrate == 230400) Speed = B230400;
	if(Baudrate == 115200) Speed = B115200;
	if(Baudrate == 57600) Speed = B57600;
	if(Baudrate == 38400) Speed = B38400;
	if(Baudrate == 19200) Speed = B19200;
	if(Baudrate == 9600) Speed = B9600;
	if(Baudrate == 4800) Speed = B4800;
	if(Baudrate == 2400) Speed = B2400;
	if(Baudrate == 1200) Speed = B1200;
	if(Baudrate == 600) Speed = B600;
	if(Baudrate == 300) Speed = B300;
	if(Baudrate == 150) Speed = B150;
	if(Baudrate == 110) Speed = B110;
	if(Baudrate == 75) Speed = B75;

	/* Set the Output baud rate */
	if(cfsetospeed( TermiosPtr, Speed) == -1)
	{
		perror("iW_Serial_SetBaudrate:\nError while \
				setting output baud rate of serial device");
		ERROR ("errno = %d \r\n",errno);

		status = -1;
	}

	/* Set the Input baud rate */
	if(cfsetispeed( TermiosPtr, Speed) == -1)
	{
		perror("iW_Serial_SetBaudrate:\nError while setting input \
				baud rate of serial device");
		ERROR ("errno = %d \r\n",errno);

		status = -1;
	}

	return status;
}

int iW_Serial_Init_usb(int Serial_FD, int baudrate)
{
	int serial_maxfd,ret= 0;
	/* Serial device private informations */
	struct termios OldTermiosPtr;
	struct termios NewTermiosPtr;
	/* Set of serial read descriptors */
	fd_set serial_readfs;

	DEBUG ("Serial_Fd is %d\n",Serial_FD);

	serial_maxfd = Serial_FD+1;
	/* maximum bit entry (fd1) to test */
	FD_ZERO(&serial_readfs);
	/* set testing for source 1 */
	FD_SET(Serial_FD, &serial_readfs);
	tcgetattr(Serial_FD, &OldTermiosPtr);
	memcpy( &NewTermiosPtr, &OldTermiosPtr,\
			sizeof(NewTermiosPtr));
	NewTermiosPtr = OldTermiosPtr;
	/* Set the parameters for the port   */
	/* control modes */
	NewTermiosPtr.c_cflag |= (CLOCAL |CREAD | HUPCL );//| CRTSCTS);
	/* input modes */
	NewTermiosPtr.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP| \
			INLCR|IGNCR|ICRNL|IXON);
	/* output modes */
	NewTermiosPtr.c_oflag &= ~(OPOST);
	/* local modes */
	NewTermiosPtr.c_lflag &= ~(ECHO | ECHONL |ICANON |ISIG|IEXTEN);
	/* XON and XOFF values */
	NewTermiosPtr.c_cc[VSTART] = 0x00;
	NewTermiosPtr.c_cc[VSTOP] =  0x00;
	/* Minimum Data present in the port */
	NewTermiosPtr.c_cc[VMIN] = 1;
	/* Wait Time for data to check for the presence of data in the port */
	NewTermiosPtr.c_cc[VTIME]= 0;
	ret = iW_Serial_SetBaudrate( &NewTermiosPtr, baudrate );
	if (ret == -1){
		ERROR ("iW_Serial_SetBaudrate : failed\n");
		return -1;
	}
	cfmakeraw(&NewTermiosPtr);
	iW_Serial_SetDatabits_usb( &NewTermiosPtr, DATABITS );
	iW_Serial_SetStopbits_usb(&NewTermiosPtr, STOPBITS );
	iW_Serial_SetParity_usb(&NewTermiosPtr, PARITY );
	if((ret = tcsetattr(Serial_FD, TCSANOW, &NewTermiosPtr)) == -1)
		perror ("tcsetattr");	
	DEBUG ("Serial_Fd is %d\n",Serial_FD);
	return 0;
}

/*!
 * \brief
 *   function to Initilize HAL layer .
 *
 * \details
 *   This function will initilize all
 *   Hardware layers
 *
 * \param [in] param
 *  p_app - pointer to app_priv_t structure.
 */


LONG hal_init (app_priv_t *p_app)
{
	LONG ret = OBD_GUI_INF_SUCCESS;
	
	/* Validate input arguments */
	if(p_app == NULL)
	{
		ERROR ("Invalid arguments\n");
		ret = E_HAL_ARG_INVALID;
	}

	DEBUG ("\nEntering hal_init\n");

	/* Allocate memory */
	p_app->hal = malloc (sizeof (obd_hal_t));
        if(p_app->hal == NULL)
        {
                ERROR ("Failed to allocate memory\n");
		ret = E_HAL_MEMORY;
	}       

	while (1)
	{
		if (access( "/dev/ttyUSB4", F_OK ) != -1 )
		{
			sleep(1);
			break;
		}

	}

	p_app->hal->priv = (void*)p_app;

#ifdef INSMOD_USB_NODE
/* If USB uses power regulators, then this should be done in iWOBD2FW.
Otherwise enable above macro */
	system("insmod udc-core.ko");
	system("insmod libcomposite.ko");
	system("insmod ci_hdrc.ko");
	system("insmod usbmisc_imx.ko");
	system("insmod ci_hdrc_imx.ko");
	system("insmod u_serial.ko");
	system("insmod usb_f_serial.ko");
	system("insmod usb_f_acm.ko");
	system("insmod g_serial.ko");
#endif
	if (ret == OBD_GUI_INF_SUCCESS)
	{
		p_app->hal->fd = open(USB_DEV_NODE, O_RDWR);
		if(p_app->hal->fd < 0)
		{
			ERROR ("Failed to open USB device node\n");
			ret = E_HAL_OPEN;
			free(p_app->hal);
		}
		iW_Serial_Init_usb(p_app->hal->fd, BAUDRATE);
	}
	DEBUG ("Exiting hal_init with fd = %d\n", p_app->hal->fd);

	return ret;

}

LONG hal_read(obd_hal_t *p_hal, UCHAR *p_rdbuf, size_t sz)
{
	struct pollfd pollfd;
	LONG ret_read; 
	LONG ret_poll; 
	LONG i = 0; 
	LONG ret = OBD_GUI_INF_SUCCESS;

	app_priv_t *p_app;

	DEBUG ("Entering hal_read\n");

	INFO ("SZ = %ld\n", sz);

	p_app = (app_priv_t *)p_hal->priv;

	ret_read = 0;

        /* Validate input arguments */
        if(p_hal == NULL)
        {
                ERROR("Invalid arguments\n");
                ret = E_HAL_ARG_INVALID;
        }


	pollfd.fd = p_hal->fd;
	pollfd.events = POLLIN;
	pollfd.revents = 0;

	ret_poll = poll( &pollfd, 1, -1);

	if( ret_poll == -1 )
	{
		ERROR("Poll failed\n");
		ret = E_HAL_POLL;
		close(p_hal->fd);
	}
	else
	{
		if (pollfd.revents & POLLIN )
		{
			while (1)
			{
				ret_read = read(p_hal->fd, p_rdbuf + i, sz - i);
				i = i + ret_read;
				INFO (" Total No of bytes read = %d, No of bytes read in 1 iterration i = %d\n", ret_read, i);
				if (i == sz || i == 0)
				{
					if (i == sz)
						break;
					else if (i == 0)
					{
						tcflush(p_hal->fd, TCIFLUSH);
						tcflow(p_hal->fd, TCIOFF);
						usleep(500000);
						tcflow(p_hal->fd, TCION);
						close(p_hal->fd);
						hal_init(p_app);
						protocol_change_stm(p_app->proto, p_app->proto->prot_stm, PROTOCOL_SM_DISCONNECTED);	
						break;
					}
				}
			}
		}
	}	
	for (i = 0; i<ret_read; i++)
	{
		INFO ("Data read p_rdbuf[%d]=%x\n", i, p_rdbuf[i]);
	}
	DEBUG ("Exiting hal_read\n");
	
	return ret;
}

LONG hal_write(obd_hal_t *p_hal, UCHAR *p_rdbuf, size_t sz)
{
	struct pollfd pollfd;
	size_t ret_write; 
	LONG ret = OBD_GUI_INF_SUCCESS;
	
	int i = 0;

	/* Validate input arguments */
	if(p_hal == NULL)
	{
		ERROR("Invalid arguments\n");
		ret = E_HAL_ARG_INVALID;
	}
	
	DEBUG ("Entering hal_write\n");
	INFO ("p_hal->fd = %d\n", p_hal->fd);

	ret_write = write(p_hal->fd, p_rdbuf, sz);

	INFO ("ret_write = %ld\n", ret_write);
	
	for(i=0;i<ret_write;i++)
	{
		INFO ("Respose Buf[%d] = %x\n", i, p_rdbuf[i]);
	}
	if (ret_write != sz)
	{
		ERROR("Could not write frame\n");
		ret = E_HAL_ARG_WRITE;
	}

	return ret;
}

