#include <usb_priv.h>
#include <pthread.h>
#include <protocol.h>
#include <unistd.h>
#include <debug.h>
#include <error_macro.h>
#include <stdbool.h>
#include <termios.h>

/*!
 * \brief
 *   function to process a frame  .
 *
 * \details
 *   This is protocol layer function process the frame.
 *   Based on cmd receiced, this function will perform 
 *   necessary action in board
 * \param [in] param
 *  proto - pointer to obd_gui_cfg_proto_t structure.
 *  p_buff	- Buffer containing one frame
 *  pbuff_sz- size of the buffer
 */

LONG protocol_process_frame (obd_gui_cfg_proto_t *proto, char *p_buff, size_t sz)
{
	usb_board *p_frame;
	usb_board rsp_frame_hdr;
	USHORT cmd_id;
	app_priv_t *app;
	msg_q_t *mq;
	LONG ret = OBD_GUI_INF_SUCCESS;
	LONG ret_dwnld = OBD_GUI_INF_SUCCESS;

	UCHAR type;	
	
	UCHAR cmd_ok = 1;


	/*!< device info status repsonse*/
	st_dev_info_t dev_info_st_rsp = {0};

	/*!< cpu status repsonse*/
	st_cpu_info_req_t cpu_st_rsp = {0};

	/*!< io info status repsonse*/
	st_io_info_rsp_t io_info_st_rsp = {0};

	/*!< gsm_gprs info status repsonse*/
	st_gsm_gprs_info_rsp_t gsm_gprs_info_st_rsp = {0};

	/*!< software status repsonse*/
	st_software_info_rsp_t sw_st_rsp = {0};

	/*!< sim config repsonse*/
	sim_config_t sim_config_rsp = {0};

	/*!< cloud config repsonse*/
	cloud_azure_config_t cloud_config_rsp = {0};

	/*!< general setting  repsonse*/
	settings_general_t general_setting_rsp = {0};

	/*!< threshold setting repsonse*/
	settings_threshold_t threshold_setting_rsp = {0};

	/*!< io setting  repsonse*/
	settings_io_t io_setting_rsp = {0};

	/*!< Whitelisted number response */
        SOTA_Whitelist_Number_t SOTA_Whitelist_Number_rsp = {0};
 
        /*!< SOTA Username, Password Response */
        SOTA_UserPass_t SOTA_User_Pass_rsp = {0};

	/*!< download packet*/
	dwnld_start_param_t dwnld_start_req = {0};

	UCHAR blackbox_buffer[1024] = {0};

	mesg_buffer_t msq_queue = {0};

	/*!< Validate the input arguments */
        if(proto == NULL || p_buff == NULL)
        {
                ERROR ("Invalid parameters\n");
                ret = E_PROTO_ARG_INVALID;
        }

	app = (app_priv_t *)proto->priv;
	
	DEBUG ("Entering protocol_process_frame\n");
	
	p_frame = (usb_board *)p_buff;

	type = p_frame->type;
	
	cmd_id = p_frame->cmd_id;

	/*!< check frame type and change the state machine*/
	if(type == PROTO_FRM_MGMT)
	{
		DEBUG ("PROTO_FRM_MGMT..!! Changing state..\n");
		DEBUG ("CMD ID = %x\n", cmd_id);
		switch(cmd_id)
		{
			case PROTOCOL_SM_CONNECTED_REQ:
				DEBUG ("Connected State\n");
				ret = protocol_change_stm(proto, proto->prot_stm, cmd_id);
				                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("protocol_change_stm error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, PROTOCOL_SM_CONNECTED_RSP, sizeof (UCHAR));
                                        protocol_write (proto, &rsp_frame_hdr, &cmd_ok, sizeof (UCHAR));
                                }
				break;
			case PROTOCOL_SM_XFER_REQ:
				DEBUG ("Transfer State\n");
				ret = protocol_change_stm(proto, proto->prot_stm, cmd_id);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("get_software_status error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, PROTOCOL_SM_XFER_RSP, sizeof (UCHAR));
                                        protocol_write (proto, &rsp_frame_hdr, &cmd_ok, sizeof (UCHAR));
                                }
				break;
			case PROTOCOL_SM_FW_DOWNLOAD_REQ:
				DEBUG ("Download State\n");
				ret = protocol_change_stm(proto, proto->prot_stm, cmd_id);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("get_software_status error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, PROTOCOL_SM_FW_DOWNLOAD_RSP, sizeof (UCHAR));
                                        protocol_write (proto, &rsp_frame_hdr, &cmd_ok, sizeof (UCHAR));
                                }
				break;
			case PROTOCOL_SM_DISCONNECTED_REQ:
				DEBUG ("Disconnected state \n");
				ret = protocol_change_stm(proto, proto->prot_stm, cmd_id);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("get_software_status error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, PROTOCOL_SM_DISCONNECTED_RSP, sizeof (UCHAR));
                                        protocol_write (proto, &rsp_frame_hdr, &cmd_ok, sizeof (UCHAR));
                                }
				break;
			default:
				ERROR ("Invalid frame type\n");
				ret = E_PROTO_FRAME_STM_INVALID;
				break;
		} 	
	}
	else if (type == PROTO_FRM_DATA)
	{ 
		switch (cmd_id)
		{
			case GET_DEV_INFO_REQ:
				INFO ("Case GET_DEV_INFO_REQ\n");
				ret = device_info(p_frame, &dev_info_st_rsp);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("GET_DEV_INFO_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, GET_DEV_INFO_RSP, sizeof (dev_info_st_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&dev_info_st_rsp, sizeof (dev_info_st_rsp));
                                }
				break;
			case CONNECTION_REQ:
				INFO ("Case CONNECTION_REQ\n");
				ret = device_info(p_frame, &dev_info_st_rsp);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("CONNECTION_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, CONNECTION_RSP, sizeof (dev_info_st_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&dev_info_st_rsp, sizeof (dev_info_st_rsp));
                                }
                                break;
			case DEV_STATUS_REQ:
				INFO ("Case DEV_STATUS_REQ\n");
				ret = device_info(p_frame, &dev_info_st_rsp);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("DEV_STATUS_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, DEV_STATUS_RSP, sizeof (dev_info_st_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&dev_info_st_rsp, sizeof (dev_info_st_rsp));
                                }
                                break;
			case CPU_INFO_REQ:
				INFO ("Case CPU_INFO_REQ\n");
				ret = get_cpu_status(p_frame, &cpu_st_rsp);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("CPU_INFO_REQ error\n");
                                        ret = E_GUI_GET;
                                }
#if 1
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, CPU_INFO_RSP, sizeof (cpu_st_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&cpu_st_rsp, sizeof (cpu_st_rsp));
                                }
#endif
				break;
			case IO_INFO_REQ:
				DEBUG ("Case IO_INFO_REQ\n");
				ret = get_io_status(p_frame, &io_info_st_rsp);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("IO_INFO_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr (p_frame, &rsp_frame_hdr, IO_INFO_RSP, sizeof (io_info_st_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&io_info_st_rsp, sizeof (io_info_st_rsp));
                                }
				break;
			case GSM_GPRS_INFO_REQ:
				DEBUG ("Case GSM_GPRS_INFO_REQ\n");
				ret = get_gsm_gprs_status(p_frame, &gsm_gprs_info_st_rsp);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("GSM_GPRS_INFO_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, GSM_GPRS_INFO_RSP, sizeof (gsm_gprs_info_st_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&gsm_gprs_info_st_rsp, sizeof (gsm_gprs_info_st_rsp));
                                }
				break;
			case SOFTWARE_REQ:
				DEBUG ("Case SOFTWARE_REQ\n");
				ret = get_software_status(p_frame, &sw_st_rsp);
				/*On success */
				if(ret != OBD_GUI_INF_SUCCESS) 
				{
					ERROR("SOFTWARE_REQ error\n");
					ret = E_GUI_GET;
				}
				if(ret == OBD_GUI_INF_SUCCESS)
				{
					update_hdr(p_frame, &rsp_frame_hdr, SOFTWARE_RSP, sizeof (sw_st_rsp)); 
					protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&sw_st_rsp, sizeof (sw_st_rsp));
				}
				break;
			case GET_SIM_CONFIG_REQ:
				DEBUG ("Case GET_SIM_CONFIG_REQ\n");
				ret = get_sim_config(p_frame, &sim_config_rsp);
				/*On success */
				if(ret != OBD_GUI_INF_SUCCESS)
				{
					ERROR("get_software_status error\n");
					ret = E_GUI_GET;
				}
				if(ret == OBD_GUI_INF_SUCCESS)
				{
					update_hdr(p_frame, &rsp_frame_hdr, GET_SIM_CONFIG_RSP, sizeof (sim_config_rsp));
					protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&sim_config_rsp, sizeof (sim_config_rsp));
				}
				break;
			case SET_SIM_CONFIG_REQ:
				DEBUG ("Case SET_SIM_CONFIG_REQ\n");
				ret = set_sim_config(p_frame, &sim_config_rsp);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("get_software_status error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, SET_SIM_CONFIG_RSP, sizeof (sim_config_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&sim_config_rsp, sizeof (sim_config_rsp));
					msq_queue.type = SET_SIM_CONFIG_REQ;
					send_msg_q(app->mq->queue, msq_queue);
                                }
				break;
/*
			case CLOUD_AZURE_REQ:
				DEBUG ("CLOUD_AZURE_REQ\n");
				ret = cloud_azure_config(p_frame, &cloud_config_rsp);
				break;
*/
			case GET_CLOUD_AZURE_CONFIG_REQ:
				DEBUG ("Case GET_CLOUD_AZURE_CONFIG_REQ\n");
				ret = get_cloud_azure_config(p_frame, &cloud_config_rsp);
				/*On success */
				if(ret != OBD_GUI_INF_SUCCESS)
				{
					ERROR("GET_CLOUD_AZURE_CONFIG_REQ error\n");
					ret = E_GUI_GET;
				}
				if(ret == OBD_GUI_INF_SUCCESS)
				{
					update_hdr(p_frame, &rsp_frame_hdr, GET_CLOUD_AZURE_CONFIG_RSP, sizeof (cloud_config_rsp));
					protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&cloud_config_rsp, sizeof (cloud_config_rsp));
				}

				break;
			case SET_CLOUD_AZURE_CONFIG_REQ:
				DEBUG ("Case SET_CLOUD_AZURE_CONFIG_REQ\n");
				ret = set_cloud_azure_config(p_frame);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("SET_CLOUD_AZURE_CONFIG_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, SET_CLOUD_AZURE_CONFIG_RSP, 1);
                                        protocol_write (proto, &rsp_frame_hdr, &cmd_ok, 1);
                                        msq_queue.type = SET_CLOUD_AZURE_CONFIG_REQ;
                                        send_msg_q(app->mq->queue, msq_queue);
                                }
				break;
			case GET_GEN_SET_REQ:
				DEBUG ("Case GET_GEN_SET_REQ\n");
				ret = get_general_setting(p_frame, &general_setting_rsp);
				/*On success */
				if(ret != OBD_GUI_INF_SUCCESS)
				{
					ERROR("GET_GEN_SET_REQ error\n");
					ret = E_GUI_GET;
				}
				if(ret == OBD_GUI_INF_SUCCESS)
				{
					update_hdr(p_frame, &rsp_frame_hdr, GET_GEN_SET_RSP, sizeof (general_setting_rsp));
					protocol_write (proto, &rsp_frame_hdr,(UCHAR *) &general_setting_rsp, sizeof (general_setting_rsp));
				}
				break;
			case SET_GEN_SET_REQ:
				DEBUG ("Case SET_GEN_SET_REQ\n");
				ret = set_general_setting(p_frame);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("SET_GEN_SET_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, SET_GEN_SET_RSP, sizeof (general_setting_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&general_setting_rsp, sizeof (general_setting_rsp));
                                        msq_queue.type = SET_GEN_SET_REQ;
                                        send_msg_q(app->mq->queue, msq_queue);
                                }
				break;
			case GET_THRSLD_SET_REQ:
				DEBUG ("Case GET_THRSLD_SET_REQ\n");
				ret = get_threshold_setting(p_frame, &threshold_setting_rsp);
				/*On success */
				if(ret != OBD_GUI_INF_SUCCESS)
				{
					ERROR("GET_THRSLD_SET_REQ error\n");
					ret = E_GUI_GET;
				}
				if(ret == OBD_GUI_INF_SUCCESS)
				{
					update_hdr(p_frame, &rsp_frame_hdr, GET_THRSLD_SET_RSP, sizeof (threshold_setting_rsp));
					protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&threshold_setting_rsp, sizeof (threshold_setting_rsp));
				}
				break;
			case SET_THRSLD_SET_REQ:
				DEBUG ("Case SET_THRSLD_SET_REQ\n");
				ret = set_threshold_setting(p_frame);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("SET_THRSLD_SET_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                { 
                                        update_hdr(p_frame, &rsp_frame_hdr, SET_THRSLD_SET_RSP, sizeof (threshold_setting_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&threshold_setting_rsp, sizeof (threshold_setting_rsp));
                                        msq_queue.type = SET_THRSLD_SET_REQ;
                                        send_msg_q(app->mq->queue, msq_queue);
                                }
				break;
			case GET_IO_SET_REQ:
				DEBUG ("Case GET_IO_SET_REQ\n");
				ret = get_io_setting(p_frame, &io_setting_rsp);
				/*On success */
				if(ret != OBD_GUI_INF_SUCCESS)
				{
					ERROR("GET_IO_SET_REQ error\n");
					ret = E_GUI_GET;
				}
				if(ret == OBD_GUI_INF_SUCCESS)
				{
					update_hdr(p_frame, &rsp_frame_hdr, GET_IO_SET_RSP, sizeof (io_setting_rsp));
					protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&io_setting_rsp, sizeof (io_setting_rsp));
				}
				break;
			case SET_IO_SET_REQ:
				DEBUG ("Case SET_IO_SET_REQ\n");
				ret = set_io_setting(p_frame);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("SET_IO_SET_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, SET_IO_SET_RSP, sizeof (io_setting_rsp));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&io_setting_rsp, sizeof (io_setting_rsp));
                                        msq_queue.type = SET_IO_SET_REQ;
                                        send_msg_q(app->mq->queue, msq_queue);
                                }
				break;
			case GET_BLCAK_BOX_SZ_REQ:
				DEBUG ("Case GET_BLCAK_BOX_SZ_REQ\n");
				ret = get_blackbox_sz(proto, &blackbox_sz);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("GET_BLCAK_BOX_SZ_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, GET_BLCAK_BOX_SZ_RSP, sizeof (ULONG));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)&blackbox_sz, sizeof (ULONG));
                                }
				break;

			case GET_BLCAK_BOX_REQ:
				DEBUG ("Case GET_BLCAK_BOX_REQ\n");
				ret = get_blackbox(proto, blackbox_buffer);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("GET_BLCAK_BOX_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, GET_BLCAK_BOX_RSP, sizeof(blackbox_buffer));
                                        protocol_write (proto, &rsp_frame_hdr, (UCHAR *)blackbox_buffer, sizeof(blackbox_buffer));
                                }
				break;

                        case SYSTEM_REBOOT_REQ:
                                DEBUG ("Case SYSTEM_REBOOT_REQ\n");
                                ret = system_reboot(proto);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("SYSTEM_REBOOT_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, SYSTEM_REBOOT_RSP, sizeof(UCHAR));
                                        protocol_write (proto, &rsp_frame_hdr, &cmd_ok, sizeof(UCHAR));
					system("reboot");	

                                }
                                break;

                        case SYSTEM_RESET_REQ:
                                DEBUG ("Case SYSTEM_RESET_REQ\n");
                                ret = system_reset(proto);
                                /*On success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("SYSTEM_RESET_REQ error\n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, SYSTEM_RESET_RSP, sizeof(UCHAR));
                                        protocol_write (proto, &rsp_frame_hdr, &cmd_ok, sizeof(UCHAR));
                                }
                                break;
                        case GET_SOTA_WHITELIST_NUMBER_REQ:
                                DEBUG("Case GET_SOTA_WHITELIST_NUMBER_REQ\n");
                                ret = get_SOTA_whitelist_number(p_frame, &SOTA_Whitelist_Number_rsp);
                                /* On Success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("GET_SOTA_WHITELIST_NUMBER_REQ Error \n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, GET_SOTA_WHITELIST_NUMBER_RSP, sizeof(SOTA_Whitelist_Number_rsp));
                                        protocol_write(proto, &rsp_frame_hdr, (UCHAR *)&SOTA_Whitelist_Number_rsp, sizeof(SOTA_Whitelist_Number_rsp));
                                }

                                break;
                        case SET_SOTA_WHITELIST_NUMBER_REQ:
                                DEBUG("Case SET_SOTA_WHITELIST_NUMBER_REQ\n");
                                ret = set_SOTA_whitelist_number(p_frame);
                                /* On Success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("SET_SOTA_WHITELIST_NUMBER_REQ Error \n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, SET_SOTA_WHITELIST_NUMBER_RSP, 1);
                                        protocol_write(proto, &rsp_frame_hdr, &cmd_ok, 1);
                                        msq_queue.type = SET_SOTA_WHITELIST_NUMBER_REQ;
                                        send_msg_q(app->mq->queue, msq_queue);
                                }
                                break;
                        case GET_SOTA_USERPASS_REQ:
                                DEBUG("Case GET_SOTA_USERPASS_REQ \n");
                                ret = get_SOTA_User_Pass(p_frame, &SOTA_User_Pass_rsp);
                                /* On Success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("GET_SOTA_USERPASS_REQ Error \n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, GET_SOTA_USERPASS_RSP, sizeof(SOTA_User_Pass_rsp));
                                        protocol_write(proto, &rsp_frame_hdr,(UCHAR *) &SOTA_User_Pass_rsp, sizeof(SOTA_User_Pass_rsp));
                                }
                                break;
                        case SET_SOTA_USERPASS_REQ:
                                DEBUG ("Case SET_SOTA_USERPASS_REQ \n");
                                ret = set_SOTA_User_Pass(p_frame);
                                /* On Success */
                                if(ret != OBD_GUI_INF_SUCCESS)
                                {
                                        ERROR("SET SOTA_USERPASS_REQ Error \n");
                                        ret = E_GUI_GET;
                                }
                                if(ret == OBD_GUI_INF_SUCCESS)
                                {
                                        update_hdr(p_frame, &rsp_frame_hdr, SET_SOTA_USERPASS_RSP, 1);
                                        protocol_write(proto, &rsp_frame_hdr, &cmd_ok, 1);
                                        msq_queue.type = SET_SOTA_USERPASS_REQ;
                                        send_msg_q(app->mq->queue, msq_queue);
                                }
                                break;
								
			default:
                                DEBUG ("Invalid cmd_id\n");
                                break;


		}
	}
	else if (type == PROTO_FRM_DWNLD)
	{
	INFO ("Inside PROTO_FRM_DWNLD\n");
		switch (cmd_id)
		{
//TODO by Keshava: Move all image flag to APP DS. For testing, I will continue with this.
			case DOWNLOAD_START_CMD:
				DEBUG ("Inside DOWNLOAD_START_CMD \n");
				dwnld_start_req.img_type = p_frame->payload[0]; 
				dwnld_start_req.img_size = *((ULONG *)(&p_frame->payload[1]));

				total_img_sz = dwnld_start_req.img_size;
			
				INFO ("dwnld_start_req.img_type = %d\n", dwnld_start_req.img_type);
				INFO ("dwnld_start_req.img_size = %d\n", dwnld_start_req.img_size);

				if (dwnld_start_req.img_type == IMAGE_UBOOT)
				{
					DEBUG ("Selected U-boot for downloading \n");
					DEBUG ("Selected image size = %ld bytes\n",dwnld_start_req.img_size);
					dwnld_send_rsp (proto, p_frame, DOWNLOAD_START_RSP, &cmd_ok, sizeof (UCHAR));
					flag_uboot_enable = 1;
					update_flag = 1;
				}
				else if (dwnld_start_req.img_type == IMAGE_UIMAGE)
				{
					DEBUG ("Selected uImage for downloading \n");
					DEBUG ("Selected image size = %ld bytes\n", dwnld_start_req.img_size);
					dwnld_send_rsp (proto, p_frame, DOWNLOAD_START_RSP, &cmd_ok, sizeof (UCHAR));
					flag_uImage_enable = 1;
					update_flag = 1;
				}
				else if (dwnld_start_req.img_type == IMAGE_OBD2FW_APP)
				{
					DEBUG ("Selected OBD2FW APP for downloading \n");
					DEBUG ("Selected image size = %ld bytes\n", dwnld_start_req.img_size);
					dwnld_send_rsp (proto, p_frame, DOWNLOAD_START_RSP, &cmd_ok, sizeof (UCHAR));
					flag_obd2fwapp_enable = 1;
					update_flag = 1;
				}
				break;
			case DOWNLOAD_FW_CMD:
				ret = dwnld_frame (proto, p_frame, &ret_dwnld);
				dwnld_send_rsp (proto, p_frame, DOWNLOAD_FW_RSP, &cmd_ok, sizeof (UCHAR));
				break;
			case DOWNLOAD_END_CMD:
				/*!< Upgrade the image based on boot media */
				ret = dwnld_upgrade(proto);
				dwnld_send_rsp (proto, p_frame, DOWNLOAD_END_RSP, &cmd_ok, sizeof (UCHAR));
				break;
			default :
				ERROR("Invalid Download CMD id..\n");
				break;
			
		}

	}	
	return ret;
}

void *protocol_thread(void *arg)
{
	app_priv_t *p_app_t;
	char p_buff[MAX_FRAME_SZ];
	size_t sz = 0;
	LONG ret;

	obd_gui_cfg_proto_t *proto = (obd_gui_cfg_proto_t *)arg;
	p_app_t = (app_priv_t *)proto->priv;

	DEBUG ("Thread Created..! Inside protocol_thread\n");
	
	while(1)
	{
		if (proto->prot_stm == PROTOCOL_SM_INIT || proto->prot_stm == PROTOCOL_SM_CONNECTED || proto->prot_stm == PROTOCOL_SM_XFER || proto->prot_stm == PROTOCOL_SM_FW_DOWNLOAD)
		{
			memset(p_buff, 0, MAX_FRAME_SZ);
			INFO ("***Ready to read the data..!!\n");
			/*!< read the packets/frames */
			ret = protocol_read (proto, p_buff, sz);
			if (ret != OBD_GUI_INF_SUCCESS)
			{
				ERROR ("Error while reading frame\n");
				continue;
			}
			/*!< process the packet*/
			ret = protocol_process_frame (proto, p_buff, sz);
			if (ret != OBD_GUI_INF_SUCCESS)
			{
				ERROR ("Error in processing frame\n");
				continue;
			}
			/*!< send the response */
			/*!< process the packet*/
		}


		if (proto->read_buffer == START_READ_BUFFER)
		{


		}
	}
	return NULL;
}

/*!
 * \brief
 *   function to Initilize Protocol .
 *
 * \details
 *   This function will initilize all
 *       resources related to protocol
 *
 * \param [in] param
 *  p_app - pointer to app_priv_t structure.
 */

LONG protocol_init (app_priv_t *p_app)
{
	LONG ret =  OBD_GUI_INF_SUCCESS;
	LONG ret_thread;
	obd_gui_cfg_proto_t *p_proto;

	DEBUG ("Entering protocol_init\n");

	/* Validate parameters */
	if(p_app == NULL)
	{
		ERROR ("Invalid parameters\n");
		ret = E_PROTO_ARG_INVALID;
	}

	if (ret == OBD_GUI_INF_SUCCESS)
	{
		p_proto = p_app->proto = malloc (sizeof (obd_gui_cfg_proto_t));
		if(p_app->proto == NULL)
		{
			ERROR ("Failed to allocate memory\n");
			ret = E_PROTO_MEMORY;
		}
		p_proto = p_app->proto;

		p_proto->priv = (void *)p_app; 
		p_app->proto->prot_stm = PROTOCOL_SM_START; 

		if (ret == OBD_GUI_INF_SUCCESS)
		{
			ret_thread  = pthread_create(&p_app->proto->proto_thread, NULL, protocol_thread, p_app->proto);
			if (ret_thread != 0)
			{
				ERROR("Failed to create a thread\n");
				ret = E_THREAD_OPEN;
			}
			
		}
	}
	return ret;
}

/*!
 * \brief
 *   function to calculate CRC  .
 *
 * \details
 *   This is protocol layer function that will read
 *   data, size and calculate CRC.
 *
 * \param [in] param
 *  p_proto - pointer to protocol structure.
 *  pbuff	- Buffer containing one frame
 *  pbuff_sz- size of the buffer
 *  p_dst_crc- CRC sent along with frame
 */

LONG protocol_verify_crc(obd_gui_cfg_proto_t *p_proto, UCHAR *pbuff, size_t pbuff_sz, USHORT *p_dst_crc)
{
	USHORT gen_crc, vrfy_crc;
	LONG ret = OBD_GUI_INF_SUCCESS;

	int i;
	/*!< Validate input argument */
        if(p_proto == NULL || pbuff == NULL)
        {
                ERROR ("Invalid parameters\n");
                ret = E_PROTO_ARG_INVALID;
        }

	DEBUG ("**Inside protocol_verify_crc **\n");
	vrfy_crc = *p_dst_crc;
	
	INFO ("vrfy_crc = %x\n", vrfy_crc);

	/*!< Gen CRC */
	gen_crc = gen_crc16 (pbuff, pbuff_sz);

	INFO ("gen_crc =%x\n", gen_crc);

	if (gen_crc != vrfy_crc)
	{
		/*!< Error*/
		ERROR ("Invalid CRC received\n");
		ret = E_PROTO_CRC_MISMATCH;
	}

	return ret;
}

bool verify_header(usb_board hdr_frame)
{

	bool ret_val = false;

	switch(hdr_frame.scr_id)
	{

		case CONNECTION_WINDW:                                
		case MAIN_WINDOW_ID:                                  
		case STATUS_CPU_WINDOW_ID:                    
		case STATUS_IO_WINDOW_ID:                   
		case STATUS_GSM_GPRS_WINDOW_ID:      
		case STATUS_SOFTWARE__WINDOW_ID:     
			//SIM CONFIGURATION
		case SIM_CONFIG_WINDOW_ID:                  
			//CLOUD CONFIGURATION 
		case CLOUD_CONFIG_WINDOW_ID:                 
		case CLOUD_AZURE_CONFIG_WINDOW_ID:    
		case CLOUD_AWS_CONFIG_WINDOW_ID:              
		case CLOUD_IBM_CONFIG_WINDOW_ID:             
		case CLOUD_ORACLE_CONFIG_WINDOW_ID:   
		case CLOUD_TCPIP_CONFIG_WINDOW_ID:    
			//SETTINGS
		case SETTINGS_WINDOW_ID:                      
		case SETTINGS_GENERAL_WINDOW_ID:               
		case SETTINGS_THRSHOLD_WINDOW_ID:      
		case SETTINGS_IO_WINDOW_ID:                  
			//FIRMWARE
		case FIRMWARE_WINDOW_ID:                      
			//BLACKBOX
		case BLACK_BOX_WINDOW_ID:                   
			//IMMOBILIZER
		case IMMOBILIZER_WINDOW_ID:                   
			//USRID_PWD
		case USRID_PWD_WINDOW_ID: 
                        //SOTA
                case SOTA_WINDOW_ID:
                case SOTA_WHITELIST_NUMBER_WINDOW_ID:
                case SOTA_USERPASS_WINDOW_ID:
			ret_val = true;
			break;
		default :
			ret_val = false;
                        break;

	}

	if (ret_val == true)
	{

		switch(hdr_frame.cmd_id)
		{
			//CMD ID:
			case GET_DEV_INFO_REQ:
			case CONNECTION_REQ:
			case DEV_STATUS_REQ:
				//STATUS
			case CPU_INFO_REQ:              
			case IO_INFO_REQ:                           
			case GSM_GPRS_INFO_REQ:                  
			case SOFTWARE_REQ:                                  
				//SIM CONFIGUARTION
			case GET_SIM_CONFIG_REQ:                         
			case SET_SIM_CONFIG_REQ:                           
				//CLOUD CONFIGUARTION
			case CLOUD_AZURE_REQ:                                
			case GET_CLOUD_AZURE_CONFIG_REQ:                    
			case SET_CLOUD_AZURE_CONFIG_REQ:                    
				//SETTINGS
			case GET_GEN_SET_REQ:                                
			case SET_GEN_SET_REQ:                                
			case GET_THRSLD_SET_REQ:                             
			case SET_THRSLD_SET_REQ:                              
			case GET_IO_SET_REQ:                                  
			case SET_IO_SET_REQ:
				//FIRMWARE                                  
			case DOWNLOAD_START_CMD:
			case DOWNLOAD_FW_CMD:
			case DOWNLOAD_END_CMD:
				//BLACKBOX
			case GET_BLCAK_BOX_SZ_REQ:
			case GET_BLCAK_BOX_REQ:
                                //SOTA
                        case GET_SOTA_WHITELIST_NUMBER_REQ:
                        case SET_SOTA_WHITELIST_NUMBER_REQ:
                        case GET_SOTA_USERPASS_REQ:
                        case SET_SOTA_USERPASS_REQ:

				//STATE MACHINE
			case PROTOCOL_SM_START_REQ:
			case PROTOCOL_SM_INIT_REQ:
			case PROTOCOL_SM_CONNECTED_REQ:
			case PROTOCOL_SM_XFER_REQ:
			case PROTOCOL_SM_FW_DOWNLOAD_REQ:
			case PROTOCOL_SM_DISCONNECTED_REQ:
			case SYSTEM_REBOOT_REQ:
			case SYSTEM_RESET_REQ:
				ret_val = true;
				break;           
			default :
				ret_val = false;
				break;


		}

	}

	return ret_val;
}


/*!
 * \brief
 *   function to read one frame
 *
 * \details
 *   This is protocol layer function that will read
 *   one frame . 
 *
 * \param [in] param
 *  p_proto - pointer to protocol structure.
 *
 * \param [out] param
 *  p_proto - pointer to protocol structure.
 *  p_buf   - pointer to buffer
 *  size    - size of the buffer
 */

LONG protocol_read_frame (obd_gui_cfg_proto_t *p_proto, char *p_pkt, size_t sz)
{

	usb_board frame = {0};
	usb_board *crc_frame;
	USHORT payload_sz;
	CHAR hdr_buf[PROTO_HDR_SZ];
	UCHAR *pkt;
	UCHAR *payload;
	UCHAR *crc_buf;
	USHORT frame_crc;
	USHORT frame_sz;
	app_priv_t *p_app;
	obd_hal_t *p_hal; 
	ULONG hal_read_ret;
	LONG crc_ret;
	bool hdr;
	ULONG ret = OBD_GUI_INF_SUCCESS;

	int i=0;

	/* !< Validate input argument */
	if(p_proto == NULL)
	{
		ERROR ("Invalid parameters\n");
		ret = E_PROTO_ARG_INVALID;
	}

	DEBUG ("Entering protocol_read_frame\n");

	if(ret == OBD_GUI_INF_SUCCESS)
	{
		p_app = (app_priv_t *)p_proto->priv;
		p_hal = p_app->hal;
		/* !< Read header */
		hal_read_ret = hal_read(p_hal, (UCHAR *)&frame, sizeof (usb_board) - 1);

		INFO ( "\nframe.scr_id = %x\nframe.cmd_id=%x,frame.type=%x,frame.size=%x\n", frame.scr_id, frame.cmd_id, frame.type, frame.size);
		if (hal_read_ret != OBD_GUI_INF_SUCCESS)
		{
			ERROR ("Hal read failed\n");
			ret = E_PROTO_HAL_READ;

		}
		if (ret == OBD_GUI_INF_SUCCESS)
		{
			hdr = verify_header(frame);
			if (hdr != true)
			{
				ERROR ("SCR_ID/CMD ID mismatch..! Discarding buffer\n");
				tcflush(p_hal->fd, TCIFLUSH);
				ret = E_PROTO_HDR_MISMATCH;
			}
			if (ret == OBD_GUI_INF_SUCCESS)
			{
				// One frame size is size of usb_board struct and frame size along with CRC buffer
				frame_sz = sizeof (usb_board) + frame.size + PROTO_CRC_SZ - 1;

				pkt = malloc (frame_sz);

				//payload = malloc(frame.size + PROTO_CRC_SZ +1); //Extra 1 byte is read coz, extra 1 byte is written (newline) from windows application
				payload = malloc(frame.size + PROTO_CRC_SZ); 

				crc_buf = malloc(sizeof (usb_board) + frame.size - 1);

				/*!< Copy the header */
				memcpy(pkt, &frame,  (sizeof (usb_board) - 1));  
				memcpy(crc_buf, &frame,  (sizeof (usb_board) - 1));  

				INFO ("Header succesfully read. Now reading payload\n");
				/*!< read paylod from hardware/interface/DAL */
				hal_read_ret = hal_read(p_hal, payload, frame.size + PROTO_CRC_SZ);
				if (hal_read_ret != OBD_GUI_INF_SUCCESS)
				{
					ERROR ("Hal read failed\n");
					ret = E_PROTO_HAL_READ;

				}

				if ( ret == OBD_GUI_INF_SUCCESS)
				{
					memcpy(&pkt[(sizeof (usb_board) - 1)], payload, frame.size + PROTO_CRC_SZ); 
					memcpy(&crc_buf[(sizeof (usb_board) - 1)], payload, frame.size); 
#if 0
					for(i = 0;i<(sizeof (usb_board) + frame.size - 1);i++)
					{
						DEBUG ("crc_buf[%d]= %x\n", i, crc_buf[i]);
					}
#endif

					crc_frame = (usb_board *) pkt;
					/*!< Check the CRC/CHKSUM */
					crc_ret = protocol_verify_crc(p_proto, crc_buf, sizeof (usb_board) + frame.size - 1, &crc_frame->payload[frame.size]);
					if(ret != OBD_GUI_INF_SUCCESS)
					{
						ERROR ("CRC mismatch\n");
						ret = E_PROTO_CRC_MISMATCH; 
						free(pkt); 
						free(payload); 
						free(crc_buf); 
					}
					if(ret == OBD_GUI_INF_SUCCESS)
					{
						/*!< On success*/
						memcpy (p_pkt, pkt, frame_sz);
						free(pkt); 
						free(payload); 
						free(crc_buf); 
					}
				}
			}
		}
	}
	return ret;
}

/*!
 * \brief
 *   function to read buffer  .
 *
 * \details
 *   This is protocol layer function that will read
 *   data. 
 *
 * \param [in] param
 *  p_proto - pointer to protocol structure.
 *
 * \param [out] param
 *  p_proto - pointer to protocol structure.
 *  p_buf   - pointer toi buffer
 *  size    - size of the buffer
 */

LONG protocol_read (obd_gui_cfg_proto_t *p_proto, char *p_buf, size_t sz)
{

	LONG ret = OBD_GUI_INF_SUCCESS;
	LONG read_frame_ret;

	/*!< Validate input argument */
	if(p_proto == NULL)
	{
		ERROR ("Invalid parameters\n");
		ret = E_PROTO_ARG_INVALID;

	}

	DEBUG ("Entering  protocol_read\n")
	if(ret == OBD_GUI_INF_SUCCESS)
	{
		/*!< Read Packet */
		read_frame_ret = protocol_read_frame (p_proto, p_buf, sz);
		if(read_frame_ret != OBD_GUI_INF_SUCCESS)
		{
			ERROR ("Read frame failed\n");
			ret = E_PROTO_FRAME_INVALID; 
		}

	}
	return ret;
}

/*!
 * \brief
 *   function to frame a buffer  .
 *
 * \details
 *   This function will combine protocol header and .
 * \param [in] param
 *  p_proto - pointer to obd_gui_cfg_proto_t structure.
 *  p_hdr   - pointer to usb_board struct containing header
 *  payload - payload 
 *  sz- size of the payload struct buffer
 * \param [out] param
 * p_rsp_frame - buffer containing hdr and payload
 */

LONG protocol_frame_pkt (obd_gui_cfg_proto_t *p_proto, UCHAR *p_rsp_frame, usb_board *p_hdr, UCHAR *payload, size_t sz)
{
	usb_board *p_frame; 
	LONG ret =  OBD_GUI_INF_SUCCESS;
	/*!< Validate input argument */
	if(p_proto == NULL || p_hdr == NULL || payload == NULL)
	{
		ERROR ("Invalid arguments\n");
		ret = E_PROTO_ARG_INVALID;
	}

	p_frame = (usb_board *)p_rsp_frame;

	p_frame->scr_id = p_hdr->scr_id;
	p_frame->cmd_id = p_hdr->cmd_id;
	p_frame->type = p_hdr->type;
	p_frame->size = p_hdr->size;
	
#if 0
	/*!< TODO memcpy or member copy :*/
	memcpy(p_frame, p_hdr, PROTO_HDR_SZ); 
#endif
	memcpy(&p_frame->payload[0], payload, sz);
	
	return ret;
}

/*!
 * \brief
 *   function to write buffer to hal layer  .
 *
 * \details
 *   This function write buffer to hal layer.
 * \param [in] param
 *  p_proto - pointer to obd_gui_cfg_proto_t structure.
 *  p_rsp_frame   - respose frame 
 *  size- Total number of bytes to be written
 */

LONG protocol_send_frame (obd_gui_cfg_proto_t *p_proto, UCHAR *p_rsp_frame, size_t size)
{
	app_priv_t *p_app;
	obd_hal_t *p_hal;
	LONG ret =  OBD_GUI_INF_SUCCESS;

	if(p_proto == NULL || p_rsp_frame == NULL)
	{
		ERROR ("Invalid arguments\n");
		ret = E_PROTO_ARG_INVALID;
	}

	DEBUG ("Entering protocol_send_frame\n");

	if (ret == OBD_GUI_INF_SUCCESS)
	{
		p_app = (app_priv_t *)p_proto->priv;

		p_hal = p_app->hal;

		ret = hal_write (p_hal, p_rsp_frame, size);
	}

	return 0; 
}

/*!
 * \brief
 *   function to write buffer to hal layer  .
 *
 * \details
 *   This function write buffer to hal layer.
 * \param [in] param
 *  p_proto - pointer to obd_gui_cfg_proto_t structure.
 *  p_hdr   - pointer to usb_board struct containing header
 *  payload - payload 
 *  sz- size of the payload struct buffer
 */

LONG protocol_write (obd_gui_cfg_proto_t *p_proto, usb_board *p_hdr, UCHAR *payload, size_t sz)
{
	UCHAR *p_rsp_frame;
	USHORT size;
	USHORT gen_crc;
	LONG ret =  OBD_GUI_INF_SUCCESS;

	/*!< Validate input argument */
	if(p_proto == NULL || p_hdr == NULL || payload == NULL)
	{
		ERROR ("Invalid arguments\n");
		ret = E_PROTO_ARG_INVALID;
	}

	DEBUG ("Entering protocol_write\n");

	if (ret == OBD_GUI_INF_SUCCESS)	
	{

		size = sizeof (usb_board) + sz + PROTO_CRC_SZ -1;
		p_rsp_frame = malloc (size);

		/*!< frame the response packet*/
		ret = protocol_frame_pkt (p_proto, p_rsp_frame, p_hdr, payload, sz);
		if (ret != OBD_GUI_INF_SUCCESS)
		{
			ERROR ("Failed to frame protocol_frame_pkt\n");
			ret = E_PROTO_FRAME_INVALID; 
			free(p_rsp_frame);
		}
		/* !<Calculte CRC */
		gen_crc = gen_crc16 (p_rsp_frame, size - PROTO_CRC_SZ);
		
		INFO ("gen_crc= %x\n", gen_crc);

		/* !< Add CRC at end of the packet */
		memcpy(&p_rsp_frame[size - PROTO_CRC_SZ], &gen_crc, PROTO_CRC_SZ);
		if (ret == OBD_GUI_INF_SUCCESS)
		{
			ret = protocol_send_frame (p_proto, p_rsp_frame, size);
		}
	}
	return ret;
}

/*!
 * \brief
 *   function to Change state machine .
 *
 * \details
 *   This function will check current 
 *   state machine of the application, and change to new
 *   state machine if change is supported
 *
 * \param [in] param
 *  p_proto - pointer to protocol structure.
 *  old_stm - Old state machine
 *  new_stm - New state machine
 */

LONG protocol_change_stm (obd_gui_cfg_proto_t *p_proto, enum state_machine old_stm, enum state_machine new_stm)
{
	LONG ret =  OBD_GUI_INF_SUCCESS;	

	/* !<Check obd_gui_cfg_proto_t argument */
	if(p_proto == NULL)
	{
		ERROR("Invalid parameters\n");
		ret = E_PROTO_ARG_INVALID;

	}	

	/* !<Check old and new state machine arguments */
	if ((old_stm >= PROTOCOL_SM_INVALID) || (new_stm >= PROTOCOL_SM_INVALID))
	{
		ERROR("Invalid parameters\n");
		ret = E_PROTO_STM_INVALID;
	}

	if(ret == OBD_GUI_INF_SUCCESS)
	{
		switch(old_stm)
		{
			case PROTOCOL_SM_START:
				if (new_stm == PROTOCOL_SM_INIT)
					p_proto->prot_stm = PROTOCOL_SM_INIT;
				else
					ret = E_PROTO_STM_CHANGE_INVALID;	
				break;
			case PROTOCOL_SM_INIT:
				if (new_stm == PROTOCOL_SM_CONNECTED)
					p_proto->prot_stm = PROTOCOL_SM_CONNECTED;
				else if (new_stm == PROTOCOL_SM_DISCONNECTED)
					{
					p_proto->prot_stm = PROTOCOL_SM_DISCONNECTED;
					p_proto->prot_stm = PROTOCOL_SM_INIT;
					}
				else
					ret = E_PROTO_STM_CHANGE_INVALID;
				break;
			case PROTOCOL_SM_CONNECTED:
				switch(new_stm)
				{
					case PROTOCOL_SM_XFER:
					case PROTOCOL_SM_FW_DOWNLOAD:
						p_proto->prot_stm = new_stm;
						break;
					case PROTOCOL_SM_DISCONNECTED:
						p_proto->prot_stm = new_stm;
						p_proto->prot_stm = PROTOCOL_SM_INIT;
						break;
					default :
						ret = E_PROTO_STM_CHANGE_INVALID;
						break;
				}	
				break;
			case PROTOCOL_SM_XFER: 
				switch(new_stm)
				{
					case PROTOCOL_SM_DISCONNECTED:
					case PROTOCOL_SM_CONNECTED:
						p_proto->prot_stm = new_stm;
						break;
					default :
						ret = E_PROTO_STM_CHANGE_INVALID;
						break;
				}
				break;
			case PROTOCOL_SM_FW_DOWNLOAD:
				switch(new_stm)
				{
					case PROTOCOL_SM_CONNECTED:
						p_proto->prot_stm = new_stm;
						break;
					default :
						ret = E_PROTO_STM_CHANGE_INVALID;
						break;
				}
				break;
			case PROTOCOL_SM_DISCONNECTED:
				if (new_stm == PROTOCOL_SM_INIT)
					p_proto->prot_stm = PROTOCOL_SM_INIT;
				else
					ret = E_PROTO_STM_CHANGE_INVALID;
				break;
			/* Invalid case not possible, becuse if case is Invalid, 
				then function would have retured before coming to switch case*/
			case PROTOCOL_SM_INVALID:
			default :
				ret = E_PROTO_STM_CHANGE_INVALID;
				break;

		}	

	}

	return ret;

}

LONG protocol_start (obd_gui_cfg_proto_t *p_proto)
{

	return 0;
}
