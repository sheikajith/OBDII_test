#include <system.h>
#include <debug.h>
#include <error_macro.h>
#include <stdlib.h>

LONG system_reboot(obd_gui_cfg_proto_t *p_proto)
{
	LONG ret = 0;

	system("i2cset -f -y 1 0x6a 0x0d 0x00");
	system("i2cset -f -y 1 0x6a 0x5E 0x00");

//	system("reboot");	

	return ret;
}

LONG system_reset(obd_gui_cfg_proto_t *p_proto)
{
	LONG ret = 0;
	
	system("cp /default.xml /sample.xml");
	INFO ("System Reset Command \n");	

	return ret;
}
