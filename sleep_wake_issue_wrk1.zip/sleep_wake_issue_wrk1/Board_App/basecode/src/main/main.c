#include <stdio.h>
#include <poll.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <getopt.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>

#include <debug.h>


#include <usb_priv.h>
#include <usb_protcol.h>
#include <app.h>
#include <signal.h>

#include <error_macro.h>
    
    
app_priv_t *g_app;
   
void sig_handle (int signo)
{
	pthread_exit(NULL);
} 

static void print_usage(const char *prog)
{
    printf("############################### USB APP Usage #################################\n");
    printf("Usage: %s [-h] [-f xml_file] [-w whitelist_xml_file] [-u Unique_ID] [-v verbose] \n", prog);
    puts("  -f 	main XML file name which contains all the info \n"
         "  -w 	Whitelist xml file which contains number, username and password\n"
         "  -u 	Unique ID which is unique to device(may be CPUID along with IMEI number)\n"
         "  -v 	Choose the level of verbose to display while application is running \n");

    printf("Exmaple Usage: %s -f file.xml -w whitelist.xml -u 1234567 -i kumara -p 12345 -v 1\n", prog);
    exit(1);
}

static void parse_opts ( int argc, char *argv[] )
{
    int c;
    while (( c = getopt_long (argc, argv, "hf:w:u:i:p:v", NULL, NULL )) != -1 )
    {
        switch (c) {
        case 'f': //MAIN XML filename
			x_name = optarg;
            break;
        case 'w': //Whitelist XML file
			w_name = optarg;
            break;
		case 'u': //USER_ID
			unique_id = atoi(optarg);
			break;
		case 'i': //Username for IMMOBILISER functionality
			username = optarg;
			break;
		case 'p': //Passowrd for IMMOBILISER functionality
			password = optarg;
			break;
		case 'v': //Level of verbose
			debug_flag = VERBOSE_ENABLE;
			//verbose = atoi(optarg);
			break;
		case 'h': //print test uasge help
            print_usage(argv[0]);
            break;
        default:
            print_usage(argv[0]);
            break;
        }
    }

}

void *notify_thread(void *arg)
{

	char buffer[256] = {0};	
	LONG status;
	LONG ret;
	mqd_t start_queue;

	signal(SIGUSR1,sig_handle);
	DEBUG ("*******notify_thread********\n");
	while(1)
	{
		memset(buffer, 0, sizeof(buffer));
		start_queue = init_mq(START_MSG_Q); 
		if(start_queue < 0)
		{
			ERROR ("Failed to init msg_queue\n");
			ret = E_APP_MSG_Q_INIT;
		}
//		printf("B4 message queue %d\n",start_queue);
		ret = recv_msg_q_frm_fw(start_queue, buffer, sizeof(buffer));
//		printf("A4 message queue\n");

		DEBUG ("*******recv_msg_q_frm_fw = %s********\n", buffer);
		if(strcmp(buffer, "END") == 0)
		{
			close(g_app->hal->fd);
			ret = pthread_kill(g_app->proto->proto_thread, SIGUSR1);
			if (ret != 0)
				DEBUG ("ERROR = %d\n", errno);
			DEBUG("pthread_kill = %d\n", ret);
			close (g_app->hal->fd);
			free(g_app->hal);
			DEBUG("g_app->hal\n");
			free(g_app->proto);
			DEBUG("g_app->proto\n");
			free(g_app->image);
			DEBUG("g_app->image\n");
			free(g_app->mq);
			DEBUG("g_app->mq\n");
			free(g_app);
			
			while (access( "/dev/ttyUSB4", F_OK ) != -1 );

			/* !< Allocate memory for application data structure */
			g_app = malloc(sizeof (app_priv_t)); // please take care of error case

			if(g_app == NULL)
			{
				ERROR ("Error! memory not allocated.");
				exit(0);
			}

			/* Initialize application */
			status = app_init(g_app);
			if (status != 0)
			{
				ERROR ("Failed to initilize application\n");
			}



		}
		if (mq_close(start_queue) == -1)
			printf("mq_close failed\n");
		if (mq_unlink (START_MSG_Q) == -1)
			printf("mq_unlink failed\n");
	}
}

/*!
 * \brief
 *   main function .
 *      
 * \details
 *   This is the main function of
 *   application that interfaces with GUI.
 *
 * \param [in] param
 *  argc - number of arguments.
 *  argv - input argument.
 */

LONG main(int argc, char **argv)
{

	LONG status;
	LONG ret_thread;
	if(argc < 6)
	{

		/* !< If Argumnets not passed in commandline, Take default arguments*/
		unique_id = UNIQUE_ID;
		verbose = 0;
		debug_flag = VERBOSE_DISABLE;
		x_name = MAIN_XML;
		w_name = WHITELIST_XML;
		username = USERNAME;
		password = PASSWD;
	}
	/* !< Parse the user input */
	parse_opts (argc, argv);

	/* !< Allocate memory for application data structure */
	g_app = malloc(sizeof (app_priv_t)); // please take care of error case

	if(g_app == NULL)
	{
		ERROR ("Error! memory not allocated.");
		exit(0);
	}
#if 0
	ret_thread  = pthread_create(&proto_notify, NULL, notify_thread, NULL);
	if (ret_thread != 0)
	{
		ERROR("Failed to create a thread\n");
	}

#endif

	/* Initialize application */
	status = app_init(g_app); 
	if (status != 0)
	{
		ERROR ("Failed to initilize application\n");
	}





	pthread_join(g_app->proto->proto_thread, NULL);
//	pthread_join(proto_notify, NULL);//commented for killing this application from iWaveOBD2FW application

	/*!< Application usage*/

	/*!< Get command line options, use optargs*/
	/*!< -h help */
	/*!< -f xml file use or default xmlfile */
	/*!< -c while listed mobile number and userids with password */
	/*!< -i unique ID/serial number */
	/*!< -v verbose mode or enable debug */
	/*!< fork + exec the OBD firmware */


	/*!< application protocol should be generic, later USB be can be replaced with any other interface (SPI/I2C/UART)*/
	/*!< Protocol should get the packets from common layer. This common layer should inturn get the data from USB/I2C/SPI/UART */
	/*!< Maintain the Protocol State Diagram */
	/*!< Create a thread to receive the packets from Host interface */
	/*!< Process the received packets accordingly by updating the APP Data structure, XML file and reiniting the application (OBDFW)*/
	/*!< Create data structure for each of the request and response */
	/*!< Synchonisartion between FW and USB */

	return 0;
}
