#ifndef __SYSTEM_H
#define __SYSTEM_H
#include <protocol.h>

LONG system_reboot(obd_gui_cfg_proto_t *p_proto);
LONG system_reset(obd_gui_cfg_proto_t *p_proto);


#endif
