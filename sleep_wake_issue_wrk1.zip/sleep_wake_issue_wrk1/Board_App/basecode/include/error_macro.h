/*!< INclude File Header */
#ifndef __OBD2_GUI_INF_ERR_H_
#define __OBD2_GUI_INF_ERR_H_

#define OBD_GUI_INF_SUCCESS	0
/*!< Add Doxygen comment for macro, variables and function */
#define E_OBD_GUI_INF_MOD_SHIFT     (16)
#define E_OBD_GUI_INF_MOD_MASK     ((1 << E_OBD_GUI_INF_MOD_SHIFT) -1)

#define E_OBD_GUI_INF_ERR_BASE     (0xC0000000)
#define E_HAL_MODULE_BASE    (E_OBD_GUI_INF_ERR_BASE | (1 & E_OBD_GUI_INF_MOD_MASK) << E_OBD_GUI_INF_MOD_SHIFT) /* VAlues??????*/ 
#define E_HAL_MEMORY      (E_HAL_MODULE_BASE + 1) /* VAlues??????*/
#define E_HAL_OPEN        (E_HAL_MODULE_BASE + 2) /* VAlues??????*/
#define E_HAL_ARG_INVALID    (E_HAL_MODULE_BASE + 3) /* VAlues??????*/
#define E_CFG_FILE_OPEN     (E_HAL_MODULE_BASE + 4)
#define E_HAL_POLL     (E_HAL_MODULE_BASE + 5)
#define E_HAL_ARG_WRITE     (E_HAL_MODULE_BASE + 6)

#define E_APP_MODULE_BASE    (E_OBD_GUI_INF_ERR_BASE | (2 & E_OBD_GUI_INF_MOD_MASK) << E_OBD_GUI_INF_MOD_SHIFT) /* VAlues??????*/ 
#define E_APP_HAL_INIT      (E_APP_MODULE_BASE + 1) /* VAlues??????*/
#define E_APP_PROTO_INIT     (E_APP_MODULE_BASE + 2) /* VAlues??????*/
#define E_APP_MSG_Q_INIT    (E_APP_MODULE_BASE + 3) /* VAlues??????*/
#define E_APP_CHANGE_STATE_M    (E_APP_MODULE_BASE + 4) /* VAlues??????*/
#define E_APP_SEM    (E_APP_MODULE_BASE + 5) /* VAlues??????*/

#define E_PROTO_MODULE_BASE    (E_OBD_GUI_INF_ERR_BASE | (3 & E_OBD_GUI_INF_MOD_MASK) << E_OBD_GUI_INF_MOD_SHIFT) /* VAlues??????*/ 
#define E_PROTO_MEMORY      (E_PROTO_MODULE_BASE + 1) /* VAlues??????*/
#define E_THREAD_OPEN        (E_PROTO_MODULE_BASE + 2) /* VAlues??????*/
#define E_PROTO_ARG_INVALID    (E_PROTO_MODULE_BASE + 3) /* VAlues??????*/
#define E_PROTO_STM_INVALID    (E_PROTO_MODULE_BASE + 4) /* VAlues??????*/
#define E_PROTO_STM_CHANGE_INVALID    (E_PROTO_MODULE_BASE + 5) /* VAlues??????*/
#define E_PROTO_FRAME_INVALID    (E_PROTO_MODULE_BASE + 6) /* VAlues??????*/
#define E_PROTO_FRAME_STM_INVALID    (E_PROTO_MODULE_BASE + 7) /* VAlues??????*/
#define E_PROTO_HAL_READ	(E_PROTO_MODULE_BASE + 8)
#define E_PROTO_CRC_MISMATCH	(E_PROTO_MODULE_BASE + 9)
#define E_PROTO_HDR_MISMATCH	(E_PROTO_MODULE_BASE + 10)


#define E_GUI_MODULE_BASE    (E_OBD_GUI_INF_ERR_BASE | (4 & E_OBD_GUI_INF_MOD_MASK) << E_OBD_GUI_INF_MOD_SHIFT) /* VAlues??????*/ 
#define E_GUI_INVALID_ARG      (E_GUI_MODULE_BASE + 1) /* VAlues??????*/
#define E_GUI_GET      (E_GUI_MODULE_BASE + 2) /* VAlues??????*/
//#define E_THREAD_OPEN        (E_GUI_MODULE_BASE + 2) /* VAlues??????*/
//#define E_PROTO_ARG_INVALID    (E_GUI_MODULE_BASE + 3) /* VAlues??????*/
//#define E_PROTO_STM_INVALID    (E_GUI_MODULE_BASE + 4) /* VAlues??????*/
//#define E_PROTO_STM_CHANGE_INVALID    (E_GUI_MODULE_BASE + 5) /* VAlues??????*/
//#define E_PROTO_FRAME_INVALID    (E_GUI_MODULE_BASE + 6) /* VAlues??????*/


/*
#define E_CFG_FILE_OPEN     (E_CFG_FILE_MODULE_BASE + 5)
#define E_CFG_FILE_OPEN     (E_CFG_FILE_MODULE_BASE + 6)
#define E_CFG_FILE_OPEN     (E_CFG_FILE_MODULE_BASE + 7)
*/

#define E_DWNLD_MODULE_BASE    (E_OBD_GUI_INF_ERR_BASE | (5 & E_OBD_GUI_INF_MOD_MASK) << E_OBD_GUI_INF_MOD_SHIFT) /* VAlues??????*/ 
#define E_DWNLD_FRM_FP_UBOOT      (E_DWNLD_MODULE_BASE+ 1) /* VAlues??????*/
#define E_DWNLD_FRM_FP_ZIMAGE      (E_DWNLD_MODULE_BASE + 2) /* VAlues??????*/
#define E_DWNLD_FRM_FP_ROOTFS      (E_DWNLD_MODULE_BASE + 3) /* VAlues??????*/
#define E_DWNLD_FRM_FP_OBD2FW_APP      (E_DWNLD_MODULE_BASE + 4) /* VAlues??????*/


#endif /* __OBD2_GUI_INF_ERR_H_ */

