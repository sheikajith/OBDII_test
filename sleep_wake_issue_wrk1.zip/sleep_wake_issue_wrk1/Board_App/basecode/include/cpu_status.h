#ifndef CPU_STATUS_H_
#define CPU_STATUS_H_

#include <usb_protcol.h>
#include <string.h>

LONG get_cpu_status(usb_board *p_frame, st_cpu_info_req_t *p_cpu_status);

#endif /*CPU_STATUS_H_*/

