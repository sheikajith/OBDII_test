#ifndef WRITE_RSP_H_
#define WRITE_RSP_H_

#include <usb_protcol.h>
#include <string.h>

int write_struct_rsp(usb_pkt_t rsp, size_t size);

#endif

