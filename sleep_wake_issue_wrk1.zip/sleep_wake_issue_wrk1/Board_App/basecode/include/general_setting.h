#ifndef GENERAL_SETTING_H_
#define GENERAL_SETTING_H_

#include <usb_protcol.h>
#include <string.h>


LONG get_general_setting(usb_board *p_frame, settings_general_t *p_general_setting);

LONG set_general_setting(usb_board *p_frame);


#endif /*GENERAL_SETTING_H_*/

