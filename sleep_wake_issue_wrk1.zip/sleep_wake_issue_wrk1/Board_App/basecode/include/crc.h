#include<stdint.h>
#include <stdlib.h>

uint16_t gen_crc16(const uint8_t *data, uint16_t size);
