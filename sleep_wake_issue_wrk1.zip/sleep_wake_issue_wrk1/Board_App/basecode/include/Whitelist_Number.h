#ifndef WHITELIST_NUMBER_H_
#define WHITELIST_NUMBER_H_

#include <usb_protcol.h>
#include <string.h>

LONG SOTA_whitelist_number(usb_board *p_frame, SOTA_Whitelist_Number_t *p_Whitelist_Number);

LONG get_SOTA_whitelist_number(usb_board *p_frame, SOTA_Whitelist_Number_t *p_Whitelist_Number);

LONG set_SOTA_whitelist_number(usb_board *p_frame);

#endif /*WHITELIST_NUMBER_H_*/
