#ifndef DWNLD_H_
#define DWNLD_H_
#include <protocol.h>

LONG dwnld_send_rsp (obd_gui_cfg_proto_t *proto, usb_board *p_dwnld_req, USHORT rsp, UCHAR *payload, size_t sz);

LONG dwnld_frame (obd_gui_cfg_proto_t *p_proto, usb_board *p_dwnld_frm, ULONG *p_st);

LONG dwnld_upgrade (obd_gui_cfg_proto_t *proto);

#endif
