#ifndef DEVICE_INFO_H_
#define DEVICE_INFO_H_

#include <usb_protcol.h>
#include <string.h>

LONG device_info(usb_board *p_frame, st_dev_info_t *p_dev_info_st_rsp);

#endif /*DEVICE_INFO_H_*/
