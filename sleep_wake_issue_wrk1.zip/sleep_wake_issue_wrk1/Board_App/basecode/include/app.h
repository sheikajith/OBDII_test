#ifndef APP_H_
#define APP_H_
#include <usb_priv.h>
#include <stdio.h>
#include <usb_protcol.h>

LONG app_init(app_priv_t *p_app);

LONG update_hdr(usb_board *p_frame, usb_board *p_hdr, USHORT rsp_cmd_hdr, size_t size);

#endif 
