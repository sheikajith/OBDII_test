#ifndef BLACKBOX_H_
#define BLACKBOX_H_
#include <protocol.h>

#define BLACKBOX_FILE "/blackbox.txt"

LONG get_blackbox_sz (obd_gui_cfg_proto_t *p_proto, ULONG *p_st);
LONG get_blackbox (obd_gui_cfg_proto_t *p_proto, UCHAR *blackbox_payload);

#endif



