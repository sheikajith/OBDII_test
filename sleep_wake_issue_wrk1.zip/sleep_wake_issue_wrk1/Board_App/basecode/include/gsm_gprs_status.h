#ifndef GSM_GPRS_STATUS_H_
#define GSM_GPRS_STATUS_H_

#include <usb_protcol.h>
#include <string.h>

LONG get_gsm_gprs_status(usb_board *p_frame, st_gsm_gprs_info_rsp_t *p_gsm_gprs_info_st_rsp);

#endif /*GSM_GPRS_STATUS_H_*/

