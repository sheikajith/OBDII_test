#include <stdio.h>
#include <app.h>
#include <hal.h>
#include <main.h>
#include <debug.h>
#include <sms.h>
#include <errno.h>
#include <standard_queue.h>

/*

   app_init function will initialize the hardware layer of USB2 of modem
   and set modem to message format mode

 */
int app_init()
{
	int ret_val;
	int fd;
	unsigned int value = 0;
	char buf[8];
    	char * myfifo = "/myfifo";
#if 1
	
	if (sem_init_3g ("/sem_3g", value)){
                DEBUG ("Error in creating semaphone file with %d\n",errno);
		return -errno;
	}

	if ((ret_val = sem_init_usb("/sem_16")) == -2){
                DEBUG("sem_init_usb - failed\n");
	}else{
		DEBUG ("sem_init_xml success with %d\n",ret_val);
	}
	/*creating message queue*/
	queue = init_mq(MSG_Q);
	if(queue == FAILURE)
	{
		ERROR("mq_open failed\n");
	}
	else
		DEBUG ("queue created success with %d\n",queue);

	if (access(myfifo,F_OK) == 0)
	{
		unlink(myfifo);
	}
    	/* create the FIFO (named pipe) */
    	ret_val = mkfifo(myfifo, 0666);
	if (ret_val == -1){
    		perror ("mkfifo");
		return -errno;
        }else{
		printf ("mkfifo with ret %d\n",ret_val);
	}

	fd = open(myfifo, O_RDONLY);
	if (fd < 0){
		perror ("app_init_open");
        	unlink(myfifo);
		return -errno;
	}
	memset (buf,'\0',sizeof(buf));	
    	read(fd, buf, 2);
    	DEBUG ("Received: %s\n", buf);
	close(fd);
        unlink(myfifo);
	fd = 0;
	fd = atoi (buf);
	printf ("Sota: Serial fd is %d\n",fd);
	return fd;
#endif
	
}

#if 0
int sem_init_sota (sem_t *sem_val)
{
        sem_val = sem_open("/sota", 0, 0, 0);
         
        if (sem_val == SEM_FAILED) {
                /*
                 * No such file or directory
                 */
                printf("error number =  %d\n",errno);
                if (errno == ENOENT) {
                        if((sem_val = sem_open("/sota",O_CREAT, 0777, 1)) == SEM_FAILED)
                        {
                                perror ("while opening semaphore");
                                DEBUG ("errno = %d\n",errno);
                                ERROR("Error in creating semaphone file\n");
                                return  FAILURE;
                        }
                        else
                                printf ("Success: sem_val is %p\n",sem_val);
                }
        }
        return SUCCESS;
}
#endif
