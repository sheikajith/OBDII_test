#ifndef __LIBXML2__H
#define __LIBXML2__H 

#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <errno.h>



#define XML_FILE "/sample.xml"


int get_xml_content (char *filename, char *parent_node,char *name, char *value);

int set_xml_content (char *filename, char *parent_node,char *name, char *value);



#endif /*__LIBXML2__H*/
