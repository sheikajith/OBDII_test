#ifndef __MAIN_H_
#define __MAIN_H_

/*macros used in application*/
#define HOST_NAME                  1
#define PORT                       2
#define DEVICE_ID                  3
#define DEVICE_TYPE                4
#define IOT_HUB_NAME               5
#define SAS_TOKEN                  6
#define SAMPLING_FREQUENCY         7
#define CAN_SIGN                   8
#define FATIGUE_DETECTION          9
#define IDLE_TIME                 10
#define HARSH_BRAKE_ID            11
#define HARSH_ACCELERATION_ID     12
#define CRASH                     13
#define HARSH                     14
#define OVERSPEED_ID              15
#define ODOMETER_ID               16
#define OVER_TEMPERATURE_ID       17
#define RPM                       18
#define AIN1                      19
#define DOUT1                     20
#define DOUT2                     21
#define DIN1                      22
#define DIN2                      23
#define OSM                       24
#define  MAX_SZ_CMD               30
#define  MAX_FIELDS               100
#define  MAX_FIELDS_BUF           200
#define BAUD_RATE                 115200
#define SUCCESS                   0
#define CTRL_Z                    26
#define CR                        16
#define FAILURE                   -1
#define FAIL                     NULL
#define ZERO                       0
#define MIN_FD                     0
#define ONE                        1
#define TEN                        10
#define MESSAGE_SIZE               10000
#define MEM_CLR                    0x0
#define MAX_DELAY                  30000
#define DELAY_MSG                  500000
#define INPUT                      1
#define OUTPUT                     0
#define DOUT1_GPIO   36
#define DOUT2_GPIO   38
#define IMMOBILIZER  25

#endif
