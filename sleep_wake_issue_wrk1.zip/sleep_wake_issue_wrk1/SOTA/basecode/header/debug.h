#ifndef DEBUG_H_
#define DEBUG_H_

#include <stdio.h>

#define CONSOLE_MSG_OUTPUT	1

#if CONSOLE_MSG_OUTPUT 
  #define LOG_MSG_INFO 	0 
  #define LOG_MSG_ERROR	1 
  #define LOG_MSG_WARN 	1 
  #define LOG_MSG_DEBUG 0 
#endif


#if LOG_MSG_INFO
#define INFO(...)    \
    {\
    printf("INFO: ");  \
    printf(__VA_ARGS__); \
    printf("\r\n"); \
    }
#else
#define INFO(...)
#endif

#if LOG_MSG_DEBUG
#define DEBUG(...)    \
    {\
    printf("DEBUG: Function: %s Line: #%d ", __PRETTY_FUNCTION__, __LINE__);  \
    printf(__VA_ARGS__); \
    printf("\r\n"); \
    }
#else
#define DEBUG(...)
#endif

#if LOG_MSG_WARN
#define WARN(...)   \
    { \
    printf("WARN: Function: %s Line: #%d ", __PRETTY_FUNCTION__, __LINE__);  \
    printf(__VA_ARGS__); \
    printf("\r\n"); \
    }
#else
#define WARN(...)
#endif

#if LOG_MSG_ERROR
#define ERROR(...)  \
    { \
    printf("ERROR: Function: %s Line: #%d ", __PRETTY_FUNCTION__, __LINE__); \
    printf(__VA_ARGS__); \
    printf("\r\n"); \
    }
#else
#define ERROR(...)
#endif

#endif /*CONSOLE_H_*/
