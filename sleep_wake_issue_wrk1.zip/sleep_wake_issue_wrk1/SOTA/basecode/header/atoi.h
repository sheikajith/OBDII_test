#ifndef __ATOI_H_
#define __ATOI_H_

char cmd[10];
char src_thrld[32];

/*global declairation for the function*/
int atoi_to_convert_string_to_intiger (char *token);
char *check_with_source_value (int id,char *source_val);
char *check_with_threshold_value (char *thrld_val);
char *check_command_format (char *command);
char *check_source_value_for_immo (char *src_dely);

#endif
