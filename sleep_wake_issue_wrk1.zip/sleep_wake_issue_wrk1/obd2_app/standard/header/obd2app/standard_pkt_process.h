#ifndef __PKT_PROCESS__
#define __PKT_PROCESS__


#define GPSUPDATE               101
#define IGNITIONON              102
#define IGNITIONOFF             103
#define CARSTATUS               104
#define ACCELEROMETER           105
#define DTCCODE                 106
#define DISCONNECTION           107
#define IMEI_NUMBER             108
#define GYROSCOPE               109
#define GPS_LINK_DOWN           110
#define GPS_LINK_UP             111
#define BATTERY_DRAIN           112

#define DAY_AVG_SPEED           122
#define DAY_AVG_DIST            123

#define TRIP_PAR_ODOMETER       124
#define TRIP_AVG_SPEED		125

#define FUEL_CONSUMPTION	126

#endif
