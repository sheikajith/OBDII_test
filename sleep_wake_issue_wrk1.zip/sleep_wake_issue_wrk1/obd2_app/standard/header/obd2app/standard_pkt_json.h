#ifndef __STD_JSON__
#define __STD_JSON__

int frame_p_odo_pkt_json(char * buffer,char * ts,int dist,int ttl);
int frame_t_avg_spd_pkt_json(char * buffer,char * ts,int dist,int ttl);

#endif
