#ifndef __CLOUD_APP__
#define __CLOUD_APP__ 

#include "cloud_azure.h"

#endif
