#include "application.h"
#include "standard.h"
#include <pthread.h>
#include <malloc.h>
#include "openssl/conf.h"
#include "openssl/err.h"
#include "openssl/engine.h"
#include "openssl/ssl.h"
#include <openssl/opensslv.h>


//pthread_t t_handle[5];

int client_init(Client * dmclient)
{
	dmclient->cfg.server_cfg = (void *)&cfg_azure;
	IOBD_DEBUG_LEVEL3("server_cfg %p \n",(config_azure *)(dmClient.cfg.server_cfg));
	memset(&iotfclient,0,sizeof(iotfclient));
	dmclient->deviceClient = (Iotfclient *)&iotfclient;

	if (sem_init(&standard_cli.send_sem, 0, 1) == -1)
		IOBD_DEBUG_LEVEL2("Sem init failed \n");

	return 0;
}

int get_config()
{
//	char hostname[50]={0};
//	char endpoint[50]={0};
	int rc = 0;
	char value[2];

	set_default_config();

	rc = get_cloud_config ();
	if (rc == OBD2_APP_FAILURE)
		IOBD_DEBUG_LEVEL2 ("get_cloud_config failed");

	get_imei_modem(((config_azure *)(dmClient.cfg.server_cfg))->deviceid);

	strcpy(((config_azure *)(dmClient.cfg.server_cfg))->url,"https://");

	if((strlen(((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName))>0){
                strcat(((config_azure *)(dmClient.cfg.server_cfg))->url, ((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName);
                strcat(((config_azure *)(dmClient.cfg.server_cfg))->url, ".");
                strcat(((config_azure *)(dmClient.cfg.server_cfg))->url, ((config_azure *)(dmClient.cfg.server_cfg))->hostname);
        }else{ 
                strcat(((config_azure *)(dmClient.cfg.server_cfg))->url, ((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	}

	strcat(((config_azure *)(dmClient.cfg.server_cfg))->url,"/devices/");
	strcat(((config_azure *)(dmClient.cfg.server_cfg))->url, ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	strcat(((config_azure *)(dmClient.cfg.server_cfg))->url, ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	strcat(((config_azure *)(dmClient.cfg.server_cfg))->url, "/messages/events");
	strcat(((config_azure *)(dmClient.cfg.server_cfg))->url, "?api-version=2016-02-03");
#if 0
	strcpy (hostname,((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	bzero (((config_azure *)(dmClient.cfg.server_cfg))->hostname,sizeof(((config_azure *)(dmClient.cfg.server_cfg))->hostname));
	if((strlen(((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName))>0){
		strcpy(endpoint,((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName);
		strcat(endpoint,".");
		strcat(endpoint,hostname);
	}

	else
		strcpy(endpoint,hostname);

	strcpy(((config_azure *)(dmClient.cfg.server_cfg))->hostname,endpoint);

	char fullpath[256]={0};

	strcpy(fullpath,"https://");
	strcat(fullpath,((config_azure *)(dmClient.cfg.server_cfg))->hostname);

	strcat(fullpath,"/devices/");
	strcat(fullpath,((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	strcat(fullpath,((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	strcat(fullpath,"/messages/events");

	IOBD_DEBUG_LEVEL4 ("fullpath %s \n",fullpath);

	strcpy(((config_azure *)(dmClient.cfg.server_cfg))->url,fullpath);

#endif
	IOBD_DEBUG_LEVEL1("url %s \n",((config_azure *)(dmClient.cfg.server_cfg))->url);

	IOBD_DEBUG_LEVEL4("id %s\n",((config_azure *)(dmClient.cfg.server_cfg))->deviceid);
	IOBD_DEBUG_LEVEL4("hostname %s \n",((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	IOBD_DEBUG_LEVEL4("port %d \n",((config_azure *)(dmClient.cfg.server_cfg))->port);
	IOBD_DEBUG_LEVEL4("http_deviceId %s \n",((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	IOBD_DEBUG_LEVEL4("http_deviceType %s \n",((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	IOBD_DEBUG_LEVEL4("transactionId %s \n",((config_azure *)(dmClient.cfg.server_cfg))->transactionId);

	rc  = get_xml_content (SRC_XML_FILE, "general", "can_sign", value);
	standard_cli.usb_app.freq.f_can_sign = atoi (value);
	rc  = get_xml_content (SRC_XML_FILE, "general", "sampling_frequency", value);
	standard_cli.usb_app.freq.f_sampling = atoi (value);

	IOBD_DEBUG_LEVEL4 ("out get_config()\n");
	return 0;
}

int get_cloud_config ()
{
	short rc = OBD2_APP_SUCCESS;
	short err = OBD2_APP_SUCCESS;
	char port [10];
	IOBD_DEBUG_LEVEL4 ("get_cloud_config +");
	bzero (port,sizeof(port));
	/* Get parameters from XML file. */
	rc = get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "host", ((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	if (rc != OBD2_APP_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("get_cloud_config failed1");
		err = OBD2_APP_FAILURE;
	}
	rc = get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "port", port);
	if (rc != OBD2_APP_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("get_cloud_config failed2");
		err = OBD2_APP_FAILURE;
	}
	rc = get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "device_id", ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	if (rc != OBD2_APP_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("get_cloud_config failed3");
		err = OBD2_APP_FAILURE;
	}
	rc = get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "device_type", ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	if (rc != OBD2_APP_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("get_cloud_config failed4");
		err = OBD2_APP_FAILURE;
	}
	rc = get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "iot_hub_name", ((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName);
	if (rc != OBD2_APP_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("get_cloud_config failed5");
		err = OBD2_APP_FAILURE;
	}
	rc = get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "sas_token", ((config_azure *)(dmClient.cfg.server_cfg))->sas);
	if (rc != OBD2_APP_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("get_cloud_config failed6");
		err = OBD2_APP_FAILURE;
	}

	((config_azure *)(dmClient.cfg.server_cfg))->port = atoi(port);

	IOBD_DEBUG_LEVEL3 ("Hostname = %s", ((config_azure *)(dmClient.cfg.server_cfg))->hostname);
	IOBD_DEBUG_LEVEL4 ("Port = %d", ((config_azure *)(dmClient.cfg.server_cfg))->port);
	IOBD_DEBUG_LEVEL4 ("Http_device_id = %s", ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	IOBD_DEBUG_LEVEL4 ("Http_deviceType = %s", ((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	IOBD_DEBUG_LEVEL4 ("IoTHubNam = %s", ((config_azure *)(dmClient.cfg.server_cfg))->IoTHubName);
	IOBD_DEBUG_LEVEL3 ("sas = %s", ((config_azure *)(dmClient.cfg.server_cfg))->sas);
	IOBD_DEBUG_LEVEL4 ("get_cloud_config -");

	if (err == OBD2_APP_FAILURE)
		rc = err;

	return rc;
}
void set_default_config()
{
	strcpy(((config_azure *)(dmClient.cfg.server_cfg))->transactionId,"a2dc7095-fbb5-47ad-96a5-9ca3e8a97720");

	((config_azure *)(dmClient.cfg.server_cfg))->port = 443;

}

size_t
RecvResponseCallback ( char *ptr, size_t size, size_t nmemb, char *data ) {
	// handle received data
	IOBD_DEBUG_LEVEL2("callback data %s \n",data);
	return size * nmemb;
}

char gData[512];
static size_t HandleResponse(
		void *Ptr,
		size_t Size,
		size_t NoElements,
		void* Data )
{
	int gDataLen = 0;
	memcpy( &( gData[0] ), Ptr, (Size * NoElements) );
	gDataLen += (Size * NoElements);
	gData[ gDataLen ] = '\0';
	return (Size * NoElements);
}

int cloud_init ()
{
	((Iotfclient *)(dmClient.deviceClient))->o_init_state = 1;
	short rc = OBD2_APP_SUCCESS;
	short err = OBD2_APP_SUCCESS;
	
	IOBD_DEBUG_LEVEL3("cloud_init + \n");
	rc = curl_global_init(CURL_GLOBAL_ALL);
	if (rc != CURLE_OK)
		err = rc;

	((Iotfclient *)(dmClient.deviceClient))->curl = curl_easy_init();
	if (((Iotfclient *)(dmClient.deviceClient))->curl == NULL)
		return OBD2_APP_FAILURE;
	rc = curl_easy_setopt( ((Iotfclient *)(dmClient.deviceClient))->curl,CURLOPT_CAINFO,"/etc/ssl/certs/ca-bundle.crt");
	if (rc != CURLE_OK)
		err = rc;
	rc = curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_VERBOSE, 0);
	if (rc != CURLE_OK)
		err = rc;
	rc = curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_HEADERFUNCTION,HandleResponse );
	if (rc != CURLE_OK)
		err = rc;

//	rc = curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_URL, ((config_azure *)(dmClient.cfg.server_cfg))->url);
	rc = curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_URL, "https://sheik.com" );
	if (rc != CURLE_OK)
		err = rc;
	rc = curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	if (rc != CURLE_OK)
		err = rc;

    rc = curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_CONNECTTIMEOUT, 30L);//wait for 30s to establish connection initially. Once it connected it can be made zero
    if (rc != CURLE_OK)
        err = rc;
	rc = curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_TIMEOUT, 30L);// wait for 60seconds to transfer data
	if (rc != CURLE_OK)
		err = rc;

    IOBD_DEBUG_LEVEL2 ("Cloud_init-");

	return err;
}

int cloud_deinit()
{
	int rc = 0;
	IOBD_DEBUG_LEVEL3(" client_deinit %d +\n",(((Iotfclient *)(dmClient.deviceClient))->o_init_state));

#if 1
    FIPS_mode_set(0);
    CRYPTO_set_locking_callback( NULL );
    CRYPTO_set_id_callback( NULL );

//    sk_SSL_COMP_free( SSL_COMP_get_compression_methods() );
//    sk_SSL_COMP_free( SSL_COMP_free_compression_methods() );

    ENGINE_cleanup();

    CONF_modules_free();
    CONF_modules_unload(1);

    COMP_zlib_cleanup();

    ERR_free_strings();
    EVP_cleanup();

    CRYPTO_cleanup_all_ex_data();
    ERR_remove_state( 0 );
#endif

	if((((Iotfclient *)(dmClient.deviceClient))->o_init_state) != 0)
	{
		IOBD_DEBUG_LEVEL2("system ignition off in sys_sleep() cloud_deinit \n");

		((Iotfclient *)(dmClient.deviceClient))->o_init_state = 0;

	}

    if (((Iotfclient *)(dmClient.deviceClient))->curl != NULL)
    {
        curl_easy_cleanup(((Iotfclient *)(dmClient.deviceClient))->curl);
    }
    else
    {
        printf("else case - curl_easy_cleanup \n" );
    }
    curl_global_cleanup();

    if (malloc_trim(0) == 0)
    {
        IOBD_DEBUG_LEVEL2 ("cloud_deinit: Not possible to release any memory");
    }
    IOBD_DEBUG_LEVEL2 ("Cloud_deinit-");

    return rc;
}
