#include "application.h"
#include "analytics_pkt_process.h"
#include "analytics.h"
#include "analytics_events.h"


void process_analytics_data_packets(){

	int len = 0;
	struct obd_data obddata;
	int rc = 0;
	while (!dmClient.interrupt)
	{

#if 1
        if(appClient.appSleep == APP_SLEEP){
            break;
        }
#endif

        memset( &obddata, 0, sizeof( obddata ) );
		len = mq_receive(data_analytics.analytics_queue_id,(char *) &obddata, sizeof(struct obd_data),NULL);

		if (len == OBD2_APP_FAILURE)
			perror ("process_analytics_data_packets mq_receive");
		IOBD_DEBUG_LEVEL4(" Receive len = %d, errno =%d\r\n",len,errno);
		IOBD_DEBUG_LEVEL2("msg_type = %d\r\n", obddata.msg_type);
#if 0
		if (obddata.msg_type != EXIT_ANALYTICS)
        {
			IOBD_DEBUG_LEVEL4("Receive Data = %s\r\n", obddata.data);
            printf("process_analytics_data_packets exit msgtype received ##############################\n" );
            break;
        }
#endif
retry:
#if 0
		if(appClient.appSleep == APP_SLEEP){
			break;
		}
#endif

		switch(obddata.msg_type)
		{
			case RPM_OVER:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after OVERRPM rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" OVERRPM publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case OVERSPEED:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after OVERSPEED rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" OVERSPEED publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break; 

			case OVERTEMP:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after OVERTEMP rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" OVERTEMP publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break; 
#if 0
			case PNC_BTN:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after PNC_BTN rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" PNC_BTN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break; 
#endif
			case CRASH:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after crash rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" crash publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case HARSH:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after crash rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" h_crn publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case HARSH_ACC:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after h_acc rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" h_acc publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;

			case HARSH_BRK:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after h_brk rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" h_brk publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;

			case FATIGUE_ON:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after ftg rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2("ftg publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;

			case TAN:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after TAN rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2("TAN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;

			case IDLE_ON:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after idl_on rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" idl_on publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;
			case IDLE_OFF:
				rc= publishEventWrapper(obddata.data);
				IOBD_DEBUG_LEVEL4("after idl_off rc: %d\r\n", rc);
				if (rc != SUCCESS) {
					IOBD_DEBUG_LEVEL2(" idl_off publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;

				}
				break;

			default :
				IOBD_DEBUG_LEVEL4 (" Wrong message_type\r\n");
		}
	}

            a_pkt_process_thread_create = 0;
			IOBD_DEBUG_LEVEL4("process_analytics_data_packets exits\n");
}

