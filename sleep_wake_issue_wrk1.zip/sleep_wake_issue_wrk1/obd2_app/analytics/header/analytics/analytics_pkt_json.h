#ifndef __A_PKT_JSON__
#define __A_PKT_JSON__

int frame_o_spd_pkt_json(char * buffer,char * ts,int vehicle_speed,struct gps_rmc_t * gps_rmc,int ttl);
int frame_h_acc_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl);
int frame_h_brk_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl);
int frame_crash_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl);
int frame_o_rpm_pkt_json(char * buffer,char * ts,int rpm,struct gps_rmc_t * gps_rmc,int ttl);
int frame_ftg_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl);
int frame_idle_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl);
int frame_t_odo_pkt_json(char * buffer,char * ts,int tot_odometer,struct gps_rmc_t * gps_rmc,int ttl);
int frame_h_crn_pkt_json(char * buffer,char * ts,struct gps_rmc_t * gps_rmc,int ttl);

#endif
