#ifndef __BLACKBOX_H_
#define __BLACKBOX_H_
#include <stdbool.h>
//#define BLACKBOX_DIR	"/mnt/mtd3/"
#define BLACKBOX_DIR	"/"
#define BLACKBOX_FILENAME "blackbox.txt"
#define BB_MAX_FILE_SZ	314572800

typedef struct _bb_record{
	char ts[30];
	double lat;
	double lon;
	double alt;
	double dir;
	double gps_speed;
	double gps_pdop;
	double gps_hdop;
	double odometer;
	double total_fuel;
	double fuel_level;
	double veh_speed;
	double rpm;
	double eng_load;
	double eng_cool_temp;
	float ext_volt;
	int dtc_num;
	short no_of_sat;
	char gsm_level[4];
	char cell_id[30];
	char lac[30];
	char eng_tot_hrs[15];
}__attribute__((packed, aligned(1)))bb_record_t;

typedef struct _bb_fops {
	long int wr_pos;
	long int rd_pos;
	long int total_avail_bytes;
	int record_sz;
	bool wrap_bit_fg;
	int nrecords; // TODO
	unsigned long bytes_written; 
}bb_fops_t;

typedef struct _blackbox {
	int bb_file;
	bb_record_t bb_rec;
	bb_fops_t bb_fops;
	sem_t rw_lock;
}blackbox_t;

/*Function Declarations*/
void blackbox_thread(void);
int bb_write_single_record (FILE *, char *, size_t);
int bb_get_record_sz (blackbox_t *);
int bb_read_single_record (FILE *, char *, int );
int check_file_size (const char*, long int *sz);
#endif /*__BLACKBOX_H_*/

