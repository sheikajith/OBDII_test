cp -rf obd2_app/standard/iWaveOBD2FW Application/
sync
cp -rf obd2_app/standard/lib/libanalytics.so Application/
sync
cp -rf obd2_lib/libOBD2.so SOTA/basecode/lib/
sync
cd SOTA/basecode/
make clean
sync
make
sync
cp -rf SOTA_APP ../../Application/
sync
cd ../../
sync
tar -cvjf Application.tar.bz2 Application/
sync
