#ifndef __QGPS__
#define __QGPS__

#include<termios.h>

#define TIME_STAMP	1
#define FIX_STATUS 	2
#define CUR_LATITUDE 	3
#define HEMISPHERE 	4
#define CUR_LONGITUDE 	5
#define GREENWICH 	6
#define KNOT_SPEED 	7
#define DIRECTION 	8
#define FIELD_SIZE  	100
#define SERIAL_PORT_ACM0     (0)
#define DATABITS        8
#define PARITY         'N'
#define STOPBITS        1
#define HANDSHAKE       1
#define INFINITE_TIMEOUT 	0
#define SERIAL_FAILURE		-1
#define SERIAL_WAIT_TIMEOUT 	-2
#define GPRS_POWER_ON 		5
#define CTRL_Z 			26

int iW_Serial_SetBaudrate( struct termios* TermiosPtr, int Baudrate);
int iW_Serial_SetDatabits( struct termios *TermiosPtr, int databits);
int iW_Serial_SetStopbits( struct termios *TermiosPtr, int Stopbits);
int iW_Serial_SetParity( struct termios *TermiosPtr, char Parity);
int iW_Serial_Init(int Serial_Port_Number,int baudrate);
int board_init_gps();

#endif

