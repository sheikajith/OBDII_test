#ifndef __SERIAL_H_
#define __SERIAL_H_

#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <termios.h>
#include "common.h"

int uart_init (const char *device, int baudrate);

struct obd_ {
	double res[255];
	float volt;
	char res_buf[255];
};

typedef struct dtccodes{
	char *dtc_str[50];
	int no_codes;	
}dtccodes;

int obd_read_data(char *,char *,struct obd_ *);
int parse_raw_value(char *,char *);
int parse_raw_value_ert(char *,char *);
int config_sleep_wake_trigger_off();
int config_sleep_wake_trigger_on();
int sleep_wake_trigger_off();
int volt_change_wake_trigger_on();
int set_voltage_wake(double *);
//int set_voltage_wake(float *);
int set_voltage_sleep(double *);
//int set_voltage_sleep(float *);
int config_volt_change_wake_trigger();
int volt_change_wake_trigger_off();
int sleep_wake_trigger_on();
int sleep_wake_trigger_onoff();
int iW_Serial_Write(int, char *, size_t);
int iW_Serial_Read(int, char *, long int);
int read_dtc_value(char *, dtccodes *);
#endif
