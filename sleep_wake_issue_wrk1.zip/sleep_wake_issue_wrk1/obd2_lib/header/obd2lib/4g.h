#ifndef __4G_HEADER__
#define __4G_HEADER__

#define SERIAL_PORT_ACM0     		(0)
#ifndef USB_2
#define USB_2          			"/dev/ttyUSB2"
#endif

#define TTYUSB2_BAUD	     		115200
#define DISABLE_ECHO         		"ate0\r" 
#define GSM_SIGNAL_STRENGTH		"at+csq\r"
#define SIM_ID_CMD			"at+qccid\r"
#define IMEI_GET_CMD			"at+gsn\r"
#define GSM_CHECK_REGISTRATION		"at+creg?\r"
#define GSM_CHECK_REGISTRATION_2	"at+creg=2\r"
#define FLIGHT_MODE_EN			"AT+CFUN=0\r"
#define FLIGHT_MODE_DIS			"AT+CFUN=1\r"
#define MODE_2G				"at+qcfg=\"nwscanmode\",1,1\r"
#define MODE_3G				"at+qcfg=\"nwscanmode\",2,1\r"
#define AUTO_MODE			"at+qcfg=\"nwscanmode\",0,1\r"
#define AUTOMODE			1
#define MODE_TYPE_2G			2
#define MODE_TYPE_3G			3
/*length of user id and password*/
#define LENGTH          		25
#define MIN_FD                     	2
#define COMMAND_LEN         		20
#define MEM_CLR                    	0x0
#define MAX_DELAY                  	300000
#define MESSAGE_SIZE               	10000
#define MAX_RESP   		        100
#define MAX_MSG_LEN			160
#define CTRL_Z				26

typedef struct sim_data_pkt{
        char signal_lvl[5];
        char cell_id[30];
        char lac[30];
}sim_data;

int CheckLink(char *ifname);
int check_connection();
int check_registration();
int module_open_fd();
int module_close_fd();
int module_3g_on();
int module_3g_off();
int flight_mode();
int flight_mode_on();
int flight_mode_off();
int enable_nw_registration_with_location ();
int get_gsm_parameters(sim_data *);
int set_cell_network_mode (int);
int GSM_set_to_message_init (int);
int sem_init_3g (const char *, unsigned int value);
int unread_message (char **msg_buf);
int send_sms (char *, char *);
int get_3g_fd ();
#endif //__4G_HEADER__
