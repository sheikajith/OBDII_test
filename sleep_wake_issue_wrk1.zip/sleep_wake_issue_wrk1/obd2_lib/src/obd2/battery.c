#include "battery.h"
#include <stdio.h>
#include <stdlib.h>
#include "debug.h"
#include <string.h>

int i_battery_get_current()
{

	int fd;
	int ret_read;
	char var[50];
	int current = 0;


	fd = open(BATTERY_NODE "/current_now", O_RDONLY);

	if (fd > 0)
	{
		IOBD_DEBUG_LEVEL4 ("#### i_battery_get_current_fd is %d\n",fd);
		lseek(fd, 0, SEEK_SET);
		ret_read = read(fd, var, sizeof(var));
		if( ret_read == OBD2_LIB_FAILURE )
		{
			IOBD_DEBUG_LEVEL2("File read failed\r\n");
		}else{

			lseek(fd, 0, SEEK_SET);
			ret_read = read(fd, &var, sizeof(var));
			current = atoi(var);
		}
		close(fd);
	}
	else {
		perror ("i_battery_get_current: open");
		IOBD_DEBUG_LEVEL3 ("File open error: %d",errno);
	}

	return current;
}

int i_battery_get_voltage()
{
	int fd;
	int ret_read, ret;
	char var[50];
	int voltage = 0;

	fd = open(BATTERY_NODE "/voltage_now", O_RDONLY);

	if (fd > 0)
	{
		IOBD_DEBUG_LEVEL4 ("#### i_battery_get_voltage_fd is %d\n",fd);
		lseek(fd, 0, SEEK_SET);
		ret_read = read(fd, var, sizeof(var));
		
		if(ret_read == OBD2_LIB_FAILURE)
		{
			perror ("i_battery_get_voltage: read");
			IOBD_DEBUG_LEVEL3("File read failed with errno : %d\r\n",errno);
		}else{

			lseek(fd, 0, SEEK_SET);
			ret_read = read(fd, &var, sizeof(var));
			voltage = atoi(var);
        }
        fdatasync( fd );
        fsync( fd );
        ret = posix_fadvise( fd, 0,0,POSIX_FADV_DONTNEED );
        if (ret)
            IOBD_DEBUG_LEVEL2 ("clear_cache: posix_fadvise is %d",ret);
        close(fd);

    }
    else {
        perror ("i_battery_get_voltage: open");
        IOBD_DEBUG_LEVEL3 ("File open error: %d",errno);
    }

    return voltage;
}

int i_battery_get_health()
{
	int fd = 0;
	int ret_read, ret;
	char var[16] = {0};
	int health = 0;
	int rc = 0;

	fd = open(BATTERY_NODE_HEALTH, O_RDONLY);

	if (fd > 2)
	{
		IOBD_DEBUG_LEVEL4 ("#### i_battery_get_health_fd is %d\n",fd);
		lseek(fd, 0, SEEK_SET);
		ret_read = read(fd, var, sizeof(var));
		if( ret_read == OBD2_LIB_FAILURE )
		{
			IOBD_DEBUG_LEVEL2("i_battery_get_health :File read failed %d\r\n",errno);
			rc = OBD2_LIB_FAILURE;
		}
		else{
			lseek(fd, 0, SEEK_SET);
			ret_read = read(fd, &var, sizeof(var));
			IOBD_DEBUG_LEVEL2("battery status is %s\n",var);
			health = strncmp(var, "Good", 4);
			if (health == 0){
				rc = 1;
			}
		}
        fdatasync( fd );
        fsync( fd );
        ret = posix_fadvise( fd, 0,0,POSIX_FADV_DONTNEED );
        if (ret)
            IOBD_DEBUG_LEVEL2 ("clear_cache: posix_fadvise is %d",ret);
        close(fd);
    }
	else{
		rc = OBD2_LIB_FAILURE;
		IOBD_DEBUG_LEVEL2("i_battery_get_health node read error %d\n",errno);
	}
	return rc;
}

