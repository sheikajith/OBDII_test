#include "common.h"
#include <stdlib.h>
/*!
 * \brief
 * gpio_export function to export the gpio
 *
 * \details
 * This function is to export the gpio from arguments
 *
 * \param [in] gpio
 * GPIO pin number
 *
 * \return
 * Success - E_SUCCESS
 */
int gpio_export(int gpio)
{
	char gpio_path[48] = {0};
//	const char gpio_pin[8] = {0};
	int ret = OBD2_LIB_SUCCESS;
	int gpio_fd;

//	sprintf((char *)gpio_pin,"%d",gpio);
	sprintf(gpio_path,"/sys/class/gpio/gpio%d/direction", gpio);
	if (access(gpio_path, F_OK ) == 0){
		ret = OBD2_LIB_SUCCESS;
	}else{
		gpio_fd = open ("/sys/class/gpio/export",O_WRONLY);
		if (gpio_fd == OBD2_LIB_FAILURE)
		{
			ret = -errno;
			goto end;
		}
		ret = write(gpio_fd, &gpio, sizeof int);
		//ret = write(gpio_fd, gpio_pin, sizeof(int));
		if (ret == OBD2_LIB_FAILURE)
		{
			ret = -errno;
		}else{
			ret = OBD2_LIB_SUCCESS;
		}
		close(gpio_fd);
	}
end:
	return ret;
}

/*!
 * \brief
 * get_gpio_direction function to get the gpio value
 *
 * \details
 * This function is to get the gpio value
 *
 * \param [in] gpio
 * GPIO pin number
 *
 * \param [in] value
 * GPIO value
 *
 * \return
 * Success - E_SUCCESS
 */
int get_gpio(int gpio, int * value)
{
	int ret =0;
	int gpio_fd;
	char gpio_path[32] = {0};
	char gpio_buf[10] = {0};

	sprintf(gpio_path, "/sys/class/gpio/gpio%d/value",gpio);

	if (access(gpio_path, F_OK ) == 0){
		gpio_fd = open (gpio_path,O_RDONLY)
		if (gpio_fd == OBD2_LIB_FAILURE)
		{
			ret = -errno;
			goto end;
		}
		ret = read(gpio_fd, void *buf, size_t count);
		ret = fread(gpio_buf, 1, sizeof(gpio_buf), pFile);
		if (ret == strlen(gpio_buf))
		{
			*value = atoi(gpio_buf);
			*value = (*value & (1 << gpio))? 1: 0;
		}else{
			ret = -1;
		}

		fclose(pFile);

	}else{
		ret = -1;
	}
end:
	return ret;
}

int set_gpio_value(int gpio, int value)
{
        int ret;
        FILE * pFile;
        char gpio_path[100] = {0};
        char gpio_buf[10] = {0};

        sprintf(gpio_buf,"%d",value);
        sprintf(gpio_path, "/sys/class/gpio/gpio%d/value",gpio);
        if (access(gpio_path, F_OK ) == 0){
                pFile=fopen(gpio_path, "wr");
                if (pFile==NULL) {
                        printf("File open error \r\n");
                        ret = -errno;
                        goto end;
                }

                ret = fwrite(gpio_buf,1,sizeof(value),pFile);
                if (ret < 0 )
                {
                	IOBD_DEBUG_LEVEL2 ("gpio%d file write error", gpio);
                        ret = -errno;
                }else
                        ret = OBD2_LIB_SUCCESS;

                fclose(pFile);
        }else{
                IOBD_DEBUG_LEVEL2 ("gpio%d file does not exist", gpio);
		ret = -3;
        }
end:
        return ret;
}

int set_gpio_direction(int gpio, int direction)
{
	FILE * pFile = NULL;
	char gpio_path[100] = {0};
	int ret;

	sprintf(gpio_path, "/sys/class/gpio/gpio%d/direction",gpio);
	if (access(gpio_path, F_OK ) == 0){
		pFile=fopen(gpio_path, "w");
		if (pFile==NULL) {
			printf("File open error \r\n");
			ret = -errno;
			goto end;
		}
		if (direction == INPUT)
			ret = fwrite("in",1,2,pFile);
		if (direction == OUTPUT)
			ret = fwrite("out",1,3,pFile);
		if (ret < 0 )
			ret = -errno;
		else
			ret = OBD2_LIB_SUCCESS ;
		fclose(pFile);
	}	
end:
	return ret;
}

int clear_cache (int level)
{
        int ret;
        FILE * pFile;
        char gpio_path[32] = {0};
        char gpio_buf[4] = {0};

        sprintf(gpio_buf,"%d",level);
        strcpy(gpio_path, "/proc/sys/vm/drop_caches");
        if (access(gpio_path, F_OK ) == 0){
                pFile=fopen(gpio_path, "wr");
                if (pFile==NULL) {
                        perror ("clear_cache");
                        ret = -errno;
                        goto end;
                }       

                ret = fwrite(gpio_buf,1,sizeof(level),pFile);
                if (ret < 0 )
                {
                        IOBD_DEBUG_LEVEL2 ("level%d file write error", level);
                        ret = -errno;
                }else
                        ret = OBD2_LIB_SUCCESS;

                fclose(pFile);
        }else{
                IOBD_DEBUG_LEVEL2 ("%s: file does not exist", gpio_path);
                ret = -3; 
        }
end:
        return ret;
}

