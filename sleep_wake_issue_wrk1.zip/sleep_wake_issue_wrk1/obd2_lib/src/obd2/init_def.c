#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mqueue.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <semaphore.h>
#include "init.h"
#include "common.h"

int init_ign_q(_libClient * libclient)
{
	struct mq_attr attr1;
	attr1.mq_flags = 0;
	attr1.mq_maxmsg = MAX_MESSAGES;
	attr1.mq_msgsize = MAX_MSG_SIZE+4;
	attr1.mq_curmsgs = 0;

	libclient->pwr_mgmt_qid = mq_open("/ign_status", O_RDWR | O_CREAT,NULL, &attr1);

	if (libclient->pwr_mgmt_qid == -1)
	{
		IOBD_DEBUG_LEVEL2 (" Message queue create failed ERROR--- %d \r\n",errno);
	}

    IOBD_DEBUG_LEVEL4 ("####libclient->pwr_mgmt_qid is %d\r\n",libclient->pwr_mgmt_qid);
    return libclient->pwr_mgmt_qid;
}

int send_ign_q(_libClient * libclient,struct ign_stat *data)
{
	int rc = OBD2_LIB_SUCCESS;

	IOBD_DEBUG_LEVEL4 ("send_ign_q w+");
	sem_wait(&libclient->ign_sem);
	IOBD_DEBUG_LEVEL4 ("send_ign_q w-");
	//printf("Send Data is %s\r\n",data->msg_type);
        if (mq_send(libclient->pwr_mgmt_qid,(const char*) data, sizeof(struct ign_stat),0)  == OBD2_LIB_FAILURE) {
            IOBD_DEBUG_LEVEL2 ("6.Message Queue send failed ERROR %d\r\n",errno);
            sem_post(&libclient->ign_sem);
            rc = errno;
        }


    IOBD_DEBUG_LEVEL4 ("send_ign_q p+");
    sem_post(&libclient->ign_sem);
    IOBD_DEBUG_LEVEL4 ("send_ign_q p-");
    return rc;
}
