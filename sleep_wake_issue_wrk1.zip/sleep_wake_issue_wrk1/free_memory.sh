while true; do

free -h
sleep 1
done
