#ifndef __STD_QUEUE__
#define __STD_QUEUE__
#include <sys/resource.h>

#define Q_MAX_MESSAGES 	65535
int init_mq (void);
int init_mq_usb (void);
int send_msg_q (struct obd_data *);

#endif
