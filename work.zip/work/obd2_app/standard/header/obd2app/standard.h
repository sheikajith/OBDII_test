#ifndef __FEATURES_STD__
#define __FEATURES_STD__

#include "cloud.h"
#include <time.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include "usb.h"


int blackbox_thread_create;
void process_pkts_thread (void);
void gps_thread (void);
void car_status_thread (void);
void data_read_thread(void);
void car_data_read_thread(void);
void sim_data_read_thread(void);
int check_in_bt_volt (double *);
void check_main_battery_reconnection();
void Memory_status_thread();
	
void accelerometer_thread (void);
void gyroscope_thread (void);
void dtc_code_thread (void);
void p_odometer_thread (void);
void fuel_consumption_thread (void);
int car_data_analytics(double,double,int);
int convert_cardata_strtodouble(char *,double *);
void trip_avg_spd (char *);
int check_prev_avg(void);
int send_y_dist_data(char *,struct tm *);
int send_y_speed_data(char *,struct tm *);
void trip_partial_odo (char *);
int partial_odometer(int);
double fuel_consumption();
int update_total_fuel(double fuel_used);
void can_sign_thread(void);
void check_sim_exchange();
int enable_nw_registration_with_location ();
int save_sim_iccid(char *iccid, size_t);
int get_saved_sim_id(char *iccid, size_t);
void check_sim_exchange();
void process_data_packets();
int fatigue_detection (void);

#define GPS_INIT                0
#define GPS_DOWN_SENT           1
#define GPS_UP_SENT             2
typedef struct avg_speed{
        time_t s_time;
        time_t e_time;
        float average;
}elem_avg_speed;

typedef struct fuel_c_pkt{
        double fuel_economy;
	double total_fuel;
#if 0
	double maf_avg;
	double total_maf;
	int maf_count;	
#endif
}fuel_c_pkt;

typedef struct sim_data_pkt{
	char signal_lvl[5];
	char cell_id[30];
	char lac[30];
}sim_data;

/*keshav*/
struct battery_data{
	int i_battery_health;
	int i_battery_health_indicate;
	double i_battery_volt;
	int i_battery_low_volt;
	int i_battery_cur;
	int i_battery_high_volt;
}battery_data;

typedef struct _standard{
	pthread_t t_handle[8];
	pthread_t sota_thread_id;
        elem_avg_speed speed;
	sem_t send_sem;
	fuel_c_pkt fuel;
	struct gps_pkt g_gps;
	accelerometer_api_priv g_adata;
	car_parameters g_carparams;
	struct timeval led_start,led_stop;
	struct sim_data_pkt sim_data;
	struct battery_data battery;//keshav
	_xml xml_objs;
	USB_APP usb_app;
	int led_state;
	int led_switch;
	int mode;
	uint8_t btry_disconnect;
}_standard;

_standard standard_cli;
int read_req_data(struct gps_pkt * ,accelerometer_api_priv *);
int convert_dtc_integer (char *);
void set_default_config();
int get_gsm_parameters(sim_data *);
void get_dtc_code(char *, size_t);
int read_and_send(struct gps_pkt * ,car_parameters *,char * ,char *);
int get_since_epoch(unsigned long long *);
int cloud_deinit();
int cloud_init ();
#endif
