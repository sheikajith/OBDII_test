#include "application.h"
#include "init_callbacks.h"
#include "stdlib.h"
#include "standard.h"
#include "standard_queue.h"
#include "sota.h"

int main()
{
	int rc = -1;
	struct obd_data obddata;
	char ts[24] = {0};
	struct gps_pkt g_gps;
    
//    pthread_t free_tid;

	IGN_PTRS Ign;
	SLEEP_WAKE sw;
	standard_cli.btry_disconnect = 1;

	Ign.ign_ON    = main_ign_on;
	Ign.ign_OFF   = main_ign_off;
	Ign.dis_stat  = main_dis_stat;
	Ign.bat_drain = main_bat_drain;
	Ign.pnc_btn   = main_pnc_btn;	
	Ign.crash_det = main_crash_det;
	Ign.osm_cb     = main_osm_callback; 
	sw.slp 	      = sys_sleep;
	sw.wake	      = sys_wake;
	sw.slp_dis    = sys_wake_dis;
	//catch interrupt signal
	signal(SIGINT, sigHandler);
	signal(SIGTERM, sigHandler);
	signal(SIGKILL, sigHandler);

   system("chmod +x /iwtest/Application/script.sh /iwtest/Application/monitor.sh");
   system("sh /iwtest/Application/script.sh");

#if 0 //commented to kill usb_application
	/*MQ: OBD2_FW_to_USB_APP*/
	if (init_mq_usb() == OBD2_APP_FAILURE)
	{
		IOBD_DEBUG_LEVEL1 ("USB_APP Message Queue Create Failed\r\n");
	}
#endif
	/*MQ : Share events to Cloud thread*/
	if (init_mq() == OBD2_APP_FAILURE)
	{
		IOBD_DEBUG_LEVEL1 ("Cloud Message Queue Create Failed\r\n");
	}
	/* Init Semaphore for Publish event*/
	if (sem_init(&dmClient.rns_sem, 0, 1) == OBD2_APP_FAILURE)
	{
		IOBD_DEBUG_LEVEL1("Read_n_Send_Sem Create Failed\r\n");
	}


	/* Init Semaphore for init_mq() cloud message queue*/
	if (sem_init(&dmClient.obd_q_sem, 0, 1) == OBD2_APP_FAILURE)
	{
		IOBD_DEBUG_LEVEL1("OBD_Q_Sem Create Failed\r\n");
	}

#ifdef BLACKBOX
	/*Semaphore for blackbox read/write*/	
	if (sem_init(&appClient.bb.rw_lock, 1, 1) == OBD2_APP_FAILURE)
	{
		IOBD_DEBUG_LEVEL1("BB_R_W_lock_Sem Create Failed\r\n");
	}
#endif

	rc = init(&Ign,&sw,&standard_cli.xml_objs);
	if (rc == -1)
		IOBD_DEBUG_LEVEL1("init failed\n");
	rc = update_io_function ();
	if (rc < 0)
        	IOBD_DEBUG_LEVEL1 ("update_io_function failed %d",rc);

	rc = hw_init();
	if(rc < 0)
	{
		IOBD_DEBUG_LEVEL1("hw_init failed \n");
		rc = -1;
		goto exit;
	}

	rc = analytics_init();
	if (rc < 0)
		IOBD_DEBUG_LEVEL1 ("analytics init failed %d",rc);

	rc = client_init(&dmClient);
	if (rc != 0)
		IOBD_DEBUG_LEVEL1("client_init failed\n");

	rc = usb_app_init ();
	if (rc < 0)
		IOBD_DEBUG_LEVEL2 ("usb_app_init failed\n");

	rc = start_pm_client();
	if (rc == OBD2_APP_FAILURE)
		IOBD_DEBUG_LEVEL1("start_pm_client failed\n");

    rc = start_sota_app();
    if (rc < OBD2_APP_SUCCESS)
        IOBD_DEBUG_LEVEL1 ("start_sota_app failed\n");

    rc = check_protocol( 5 );
    if (rc == 1)
        IOBD_DEBUG_LEVEL2 ("Protocol is propretary CAN\n");

    standard_cli.mode = check_mode();

#if ACC_ENABLE
    IOBD_DEBUG_LEVEL4 ("Accelerometer Enabled");	
    rc = acc_sensor_init();
    if (rc != 0){
		IOBD_DEBUG_LEVEL1("acc_sensor_init failed\n");
	}
#endif
#if GYRO_ENABLE	
	IOBD_DEBUG_LEVEL4 ("Gyroscope Enabled");	
	rc = gyro_init();
	if (rc != 0){
		IOBD_DEBUG_LEVEL1("gyro_init failed\n");
	}
#endif
    
	if (standard_cli.mode == 1){

		/* get client configuration */
		rc = get_config();
		if (rc != 0)
			IOBD_DEBUG_LEVEL1("get_config failed\n");
		/* initialising cloud */
		rc = cloud_init();
		if (rc != 0)
			IOBD_DEBUG_LEVEL1("cloud_init failed\n");

		/* Indicate to library about client initialisation */
		server_connection_complete();

		standard_cli.led_switch = 0;
		dmClient.interrupt = 0;
		get_time(ts);

		rc = get_car_data(&standard_cli.g_carparams);
		if (rc == -1)
			IOBD_DEBUG_LEVEL1("get_car_status failed\n");

		rc = convert_raw_data(&standard_cli.g_carparams);
		if (rc == -1)
			IOBD_DEBUG_LEVEL1("convert_raw_data failed\n");

		rc = get_gps_data_wrapper(&standard_cli.g_gps);

		rc = total_odometer();// peru : to update odometer value in RESET and KEY_ON payload
		if (rc == -1)
			IOBD_DEBUG_LEVEL1("total_odometer failed\n");

		memset(&g_gps,'\0',sizeof(struct gps_pkt));

		rc = final_payload_frame (ts, &obddata, "RESET");
		if(rc<0)
			IOBD_DEBUG_LEVEL1("final_payload_frame failed \n");

		rc = publishEvent (obddata.data);

		if(rc<0)
			IOBD_DEBUG_LEVEL1("send data to server failed \n");

        /* disconnection thread */
        rc = init_ign_dis_handler();
        if (rc == -1)
            IOBD_DEBUG_LEVEL1("init_ign_dis_handler failed\n");

        blackbox_thread_create = 0;
		rc = thread_init();
		if (rc == OBD2_APP_FAILURE)
			IOBD_DEBUG_LEVEL1("thread_init failed \n");


#ifdef _ANALYTICS_
		enable_analytics();
#endif

#if 0
    /* Create power management thread */
    if (pthread_create(&(free_tid), NULL, (void*) Memory_status_thread, NULL) != 0) {
        IOBD_DEBUG_LEVEL1 (" pthread_create for Memory_status_thread failed. Closing APP \r\n");
        return -1;
    }
    else
        IOBD_DEBUG_LEVEL1("Memory_status_thread thread is created\n");
#endif

	}
	//indicate_device_exit(standard_cli.t_handle[6]);
	indicate_device_exit();

exit:
	IOBD_DEBUG_LEVEL1("Application exiting with rc %d \n",rc);
	return 0;
}
