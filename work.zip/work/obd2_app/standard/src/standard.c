#include "application.h"
#include <string.h>
#include <pthread.h>
#include "standard.h"
#include "standard_pkt_json.h"
#include "standard_pkt_process.h"
#include "standard_queue.h"
#include "battery.h"
#include "gpio.h"

int dtc_num[256] = {0};
int d_count = 0;
//static bool thread_create = 0;

static int process_pkts_thread_create = 0;
static int data_read_thread_create = 0;
static int car_data_read_thread_create = 0;
static int sim_data_read_thread_create = 0;
static int sample_evt_thread_create = 0;
static int can_sign_thread_create = 0;
static int fuel_consumption_thread_create = 0;


int thread_init(void)
{
	int rc = 0;

	check_sim_exchange();
	check_main_battery_reconnection ();

	if (process_pkts_thread_create == 0){

		if ((rc = pthread_create(&(standard_cli.t_handle[0]), NULL, (void*) process_pkts_thread, NULL)) != OBD2_APP_SUCCESS){
			IOBD_DEBUG_LEVEL2 (" pthread_create for process_pkts_thread failed with %d\r\n",rc);
			perror ("process_pkts_thread");
            printf("\n");
            printf("\n");
            printf("\n");
            system( "free -h" );
            printf("\n");
            printf("\n");
            printf("\n");
			rc = OBD2_APP_FAILURE;
		}
		else{
			IOBD_DEBUG_LEVEL4(" process_pkts_thread is created\n");
			if (pthread_detach (standard_cli.t_handle[0]) != OBD2_APP_SUCCESS){
				IOBD_DEBUG_LEVEL2 ("pthread_detach failed %d",errno);
			}
            process_pkts_thread_create = 1;
		}
	}
    else
    {
           IOBD_DEBUG_LEVEL2 ("process_pkts_thread is already created");    
    }

    if( data_read_thread_create == 0 )
    {
        if ((rc = pthread_create(&(standard_cli.t_handle[3]), NULL, (void*) data_read_thread, NULL)) != OBD2_APP_SUCCESS) {
            IOBD_DEBUG_LEVEL2 (" pthread_create for data_read_thread failed %d\r\n",rc);
            perror ("data_read_thread");
            printf("\n");
            printf("\n");
            printf("\n");
            system( "free -h" );
            printf("\n");
            printf("\n");
            printf("\n");
            rc = OBD2_APP_FAILURE;
        }
        else{
            IOBD_DEBUG_LEVEL4 ("data_read_thread is created\n");
            if (pthread_detach (standard_cli.t_handle[3]) != OBD2_APP_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("pthread_detach failed %d",errno);
            data_read_thread_create = 1;
        }
    }
    else
    {
        IOBD_DEBUG_LEVEL2 ("data_read_thread is already created");
    }

    if( car_data_read_thread_create == 0 )
    {
        if ((rc = pthread_create(&(standard_cli.t_handle[4]), NULL, (void*) car_data_read_thread, NULL)) != OBD2_APP_SUCCESS) {
            IOBD_DEBUG_LEVEL2 (" pthread_create for car_data_read_thread failed%d\r\n",rc);
            perror ("car_data_read_thread");
            printf("\n");
            printf("\n");
            printf("\n");
            system( "free -h" );
            printf("\n");
            printf("\n");
            printf("\n");
            rc = OBD2_APP_FAILURE;
        }
        else{
            IOBD_DEBUG_LEVEL4 ("car_data_read_thread is created\n");
            if (pthread_detach (standard_cli.t_handle[4]) != OBD2_APP_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("pthread_detach failed %d",errno);
            car_data_read_thread_create = 1;

        }
    }
    else
    {
        IOBD_DEBUG_LEVEL2 ("car_data_read_thread is already created");
    }
#if 1
    if( sim_data_read_thread_create == 0 )
    {
        if ((rc = pthread_create(&(standard_cli.t_handle[5]), NULL, (void*) sim_data_read_thread, NULL)) != OBD2_APP_SUCCESS) {
            IOBD_DEBUG_LEVEL2 (" pthread_create for sim_data_read_thread failed%d\r\n",rc);
            perror ("sim_data_read_thread");
            printf("\n");
            printf("\n");
            printf("\n");
            system( "free -h" );
            printf("\n");
            printf("\n");
            printf("\n");
            rc = OBD2_APP_FAILURE;
        }
        else{
            IOBD_DEBUG_LEVEL4 ("sim_data_read_thread is created\n");
            if (pthread_detach (standard_cli.t_handle[5]) != OBD2_APP_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("pthread_detach failed %d",errno);
            sim_data_read_thread_create = 1;
        }
    }
    else
    {
        IOBD_DEBUG_LEVEL2 ("sim_data_read_thread is already created");
    }
#endif
    if( sample_evt_thread_create == 0)
    {
        if ((rc = pthread_create(&(standard_cli.t_handle[1]), NULL, (void*) sample_evt_thread, NULL)) != OBD2_APP_SUCCESS) {
            IOBD_DEBUG_LEVEL2(" pthread_create for sample_evt_thread failed %d\r\n",rc);
            perror ("sample_evt_thread");
            rc = OBD2_APP_FAILURE;
        }
        else{
            IOBD_DEBUG_LEVEL4 ("sample_evt_thread is created\n");
            if (pthread_detach (standard_cli.t_handle[1]) != OBD2_APP_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("pthread_detach failed %d",errno);
            sample_evt_thread_create = 1;
        }
    }
    else
    {
        IOBD_DEBUG_LEVEL2 ("sample_evt_thread is already created");
    }

    if( can_sign_thread_create == 0 )
    {
        if ((rc = pthread_create(&(standard_cli.t_handle[2]), NULL, (void*) can_sign_thread, NULL)) != OBD2_APP_SUCCESS) {
            IOBD_DEBUG_LEVEL2 (" pthread_create for can_sign_thread failed%d \r\n",rc);
            perror ("can_sign_thread");
            printf("\n");
            printf("\n");
            printf("\n");
            system( "free -h" );
            printf("\n");
            printf("\n");
            printf("\n");
            rc = OBD2_APP_FAILURE;
        }
        else{
            IOBD_DEBUG_LEVEL4 ("can_sign_thread is created\n");
            if (pthread_detach (standard_cli.t_handle[2]) != OBD2_APP_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("pthread_detach failed %d",errno);
            can_sign_thread_create = 1;
        }
    }
    else
    {
        IOBD_DEBUG_LEVEL2 ("can_sign_thread is already created");
    }


#ifdef BLACKBOX
#if 1
    if (standard_cli.mode == 1)
    {
        if( blackbox_thread_create == 0 )
        {
            if ((rc = pthread_create(&(standard_cli.t_handle[6]), NULL, (void*) blackbox_thread, NULL) ) != OBD2_APP_SUCCESS){
                IOBD_DEBUG_LEVEL2 (" pthread_create for blackbox_thread failed.%d\r\n",rc);
                perror ("blackbox_thread");
                printf("\n");
                printf("\n");
                printf("\n");
                system( "free -h" );
                printf("\n");
                printf("\n");
                printf("\n");
                rc = OBD2_APP_FAILURE;
            }
            else{
                IOBD_DEBUG_LEVEL4 ("blackbox_thread is created\n");
                if (pthread_detach (standard_cli.t_handle[6]) != OBD2_APP_SUCCESS)
                    IOBD_DEBUG_LEVEL2 ("pthread_detach failed %d",errno);
                blackbox_thread_create = 1;
            }
        }
        else
        {
            IOBD_DEBUG_LEVEL2 ("blackbox_thread is already created");
        }
    }
#endif
#endif

    if((get_car_mode())== 1)
    {
#if 1
        if( fuel_consumption_thread_create == 0 )
        {
            if ((rc = pthread_create(&(standard_cli.t_handle[7]), NULL, (void*) fuel_consumption_thread, NULL)) != OBD2_APP_SUCCESS){
                IOBD_DEBUG_LEVEL2("pthread_create for fuel_consumption_thread failed. fuel consumption data will not be available! \r\n");
                perror ("fuel_consumption_thread");
                printf("\n");
                printf("\n");
                printf("\n");
                system( "free -h" );
                printf("\n");
                printf("\n");
                printf("\n");
                rc = OBD2_APP_FAILURE;
            }
            else{
                IOBD_DEBUG_LEVEL4 (" fuel_consumption_thread is created\n");
                if (pthread_detach (standard_cli.t_handle[7]) != OBD2_APP_SUCCESS)
                    IOBD_DEBUG_LEVEL2 ("pthread_detach failed %d",errno);
                fuel_consumption_thread_create = 1;
            }
        }
        else
        {
            IOBD_DEBUG_LEVEL2 ("fuel_consumption_thread is already created");
        }
#endif
    }
    else{
        IOBD_DEBUG_LEVEL2 ("Device is in Lab mode. fuel_consumption_thread is not created\n");
    }
    return rc;
}


void check_sim_exchange()
{
	int rc = 0;
	char iccid[32]={0};
	char p_iccid[24]={0};
	struct obd_data obd_qdata;
	char ts[32]={0};

	rc = get_sim_id(iccid);
	if (rc != OBD2_APP_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("get_sim_id failed with %d",rc);
	rc = get_saved_sim_id(p_iccid, strlen(iccid));
	if (rc != OBD2_APP_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("get_saved_sim_id failed with %d len %u",rc,strlen(iccid));
		if(strlen(iccid)>0){
			save_sim_iccid(iccid, strlen(iccid));
		}

		return;
	}
	IOBD_DEBUG_LEVEL3("iccid: %s p_iccid %s\r\n", iccid,p_iccid);

	IOBD_DEBUG_LEVEL4 ("strlen(iccid) %d strlen(p_iccid) %d \n",strlen(iccid),strlen(p_iccid));
	if(strlen(iccid)>0){

		if(strlen(p_iccid)>0){

			if((strcmp(p_iccid,iccid))!=0){

				get_time(ts);
				get_gps_data_wrapper(&standard_cli.g_gps);
				get_car_data(&standard_cli.g_carparams);
				convert_raw_data(&standard_cli.g_carparams);
				rc = final_payload_frame (ts, &obd_qdata, "EXCHNG_SIM");
				obd_qdata.msg_type =  EXCHNG_SIM;
				rc = send_msg_q(&obd_qdata);

				if(rc<0){
					printf("send data to server failed \n");
				}
				save_sim_iccid(iccid, strlen(iccid));
			}

		}

	}
}

int get_saved_sim_id(char *iccid, size_t sz)
{
	int sim_fd;

	if((sim_fd = open ("/simid.txt", O_RDONLY)) == OBD2_APP_FAILURE)
	{
		IOBD_DEBUG_LEVEL2 ("get_saved_sim_id : Can't open file\n");
		return errno;
	}
	read (sim_fd, iccid, sz);
	close(sim_fd);
	IOBD_DEBUG_LEVEL3 ("saved iccid is %s \n",iccid);
	return OBD2_APP_SUCCESS;
}

int save_sim_iccid(char *iccid, size_t sz)
{
	int sim_fd;

	IOBD_DEBUG_LEVEL3 ("save_sim_iccid sim_id: %s\r\n", iccid);
	if((sim_fd = open ("/simid.txt", O_WRONLY|O_CREAT)) == OBD2_APP_FAILURE)
	{
		IOBD_DEBUG_LEVEL2 ("3.Can't open simid.txt \n");
		return errno;
	}

	if (write (sim_fd, iccid, sz) == OBD2_APP_FAILURE)
		perror ("save_sim_iccid");
	close(sim_fd);
	IOBD_DEBUG_LEVEL4 ("save_sim_iccid - \n");
	return OBD2_APP_SUCCESS;

}

void process_pkts_thread (void)
{
	IOBD_DEBUG_LEVEL4 ("process_pkts_thread +\n");
	process_data_packets();
	IOBD_DEBUG_LEVEL3 ("process_pkts_thread -\n");
    process_pkts_thread_create = 0;
}


void data_read_thread(void)
{

	int rc = 0;

	while(!dmClient.interrupt)
	{

		if(appClient.appSleep == APP_SLEEP){
			break;
		}

		rc = read_req_data(&standard_cli.g_gps,&standard_cli.g_adata);
		if(rc < 0)
		{
			IOBD_DEBUG_LEVEL2 ("read_req_data failed!\n");
		}
	}
//	sleep(1);// gps_packet will be read in 1 second delay.
	IOBD_DEBUG_LEVEL2 ("data_read_thread exit");
    data_read_thread_create = 0;
}


void sim_data_read_thread(void)
{
	char ts[32]={0};
        int rc = 0;
        struct obd_data obd_qdata;

	IOBD_DEBUG_LEVEL3 ("Enter sim_data_read_thread");	
	standard_cli.battery.i_battery_volt = 0;
	standard_cli.battery.i_battery_low_volt = 0;
	standard_cli.battery.i_battery_high_volt = 0;
	standard_cli.battery.i_battery_cur = 0;
	standard_cli.battery.i_battery_health = 0;
	standard_cli.battery.i_battery_health_indicate = 0;

	rc = enable_nw_registration_with_location();
	if (rc != OBD2_APP_SUCCESS){
		IOBD_ERR ("enable_nw_registration_with_location: +CREG: <stat>\n");	
	}
	else
		IOBD_DEBUG_LEVEL3 ("enable_nw_registration_with_location : rc = %d\n",rc);

	while(!dmClient.interrupt)
	{
		if(appClient.appSleep == APP_SLEEP){
			break;
		}
	
		IOBD_DEBUG_LEVEL4 ("get_gsm_parameters +");
	
		if(access(USB_2,F_OK))
			break;	
		if ((rc = get_gsm_parameters(&standard_cli.sim_data)) != OBD2_APP_SUCCESS){
			IOBD_ERR ("get_gsm_parameters failed %d\n",rc);
		}
		else{
			IOBD_DEBUG_LEVEL4 ("signal_level : %s",standard_cli.sim_data.signal_lvl);	
			IOBD_DEBUG_LEVEL4 ("cell_id : %s",standard_cli.sim_data.cell_id);	
			IOBD_DEBUG_LEVEL4 ("LAC : %s",standard_cli.sim_data.lac);	
		}
		check_in_bt_volt (&standard_cli.battery.i_battery_volt); //i_battery_get_voltage();
		IOBD_DEBUG_LEVEL2 ("Int_bat_Volt: %lf V",standard_cli.battery.i_battery_volt);
#if 0
//		sprintf(volt,"%lf",standard_cli.battery.i_battery_volt);
//		set_xml_content (SRC_XML_FILE, "home", "int_bat",volt);	
		standard_cli.battery.i_battery_cur = i_battery_get_current();
		IOBD_DEBUG_LEVEL2 ("Current : %dmA",standard_cli.battery.i_battery_cur);	
#endif
#if 1
		standard_cli.battery.i_battery_health = i_battery_get_health();

		if(standard_cli.battery.i_battery_health == 0){

			if(standard_cli.battery.i_battery_health_indicate == 0)
			{
				get_time(ts);
				rc = final_payload_frame (ts, &obd_qdata, "BB_FN");
				obd_qdata.msg_type =  BB_FN;
				rc = send_msg_q(&obd_qdata);

				standard_cli.battery.i_battery_health_indicate = 1;
			}
		}
		else if (standard_cli.battery.i_battery_health < 0)
			IOBD_DEBUG_LEVEL2 ("Battery file read error\n");

		if(standard_cli.battery.i_battery_volt < 3.85 && standard_cli.battery.i_battery_volt > 0 && standard_cli.battery.i_battery_low_volt == 0){

			standard_cli.battery.i_battery_high_volt = 0;

			get_time(ts);
			rc = final_payload_frame (ts, &obd_qdata, "BB_LWN");
			obd_qdata.msg_type =  BB_LWN;
			rc = send_msg_q(&obd_qdata);

			standard_cli.battery.i_battery_low_volt = 1;

			/*!< BATTERY_Charge is enabled if less than 3.8V*/
			rc = set_gpio_value(BATTERY_CE, GPIO_LOW);
			if (rc != OBD2_APP_SUCCESS)
				IOBD_DEBUG_LEVEL2 ("BATTERY_CE ON Failed %d",rc);

		}
		else if (standard_cli.battery.i_battery_volt >= 4.1 && standard_cli.battery.i_battery_high_volt == 0){
			/*!< BATTERY_Charge is disabled if bat volt is greater than 4.1V*/
			rc = set_gpio_value(BATTERY_CE, GPIO_HIGH);
			if (rc != OBD2_APP_SUCCESS)
				IOBD_DEBUG_LEVEL2 ("BATTERY_CE OFF Failed %d",rc);
			standard_cli.battery.i_battery_high_volt = 1;
			standard_cli.battery.i_battery_low_volt = 0;
		}

#endif
		sleep (3);// no time constraint to this thread. And it was running continuously so delay was given
	}

	IOBD_DEBUG_LEVEL2 ("sim_data_read_thread exit \n");
    sim_data_read_thread_create = 0;
}

void car_data_read_thread(void)
{
	int rc = OBD2_APP_SUCCESS;

	while(!dmClient.interrupt)
	{

		if(appClient.appSleep == APP_SLEEP){
			break;
		}

		rc = get_car_data(&standard_cli.g_carparams);          // get car data
		if (rc != OBD2_APP_SUCCESS)
			IOBD_DEBUG_LEVEL2 ("get_car_data failed");

		convert_raw_data(&standard_cli.g_carparams);

	}
	IOBD_DEBUG_LEVEL2 ("car_data_read_thread exit \n");
    car_data_read_thread_create = 0;
}

void can_sign_thread(void)
{
	char ts[32]={0};
	int rc = 0;
	struct obd_data obd_qdata;

        //standard_cli.usb_app.freq.f_can_sign = atoi (value);
        IOBD_DEBUG_LEVEL3 ("CAN_Sign frequency %hd",standard_cli.usb_app.freq.f_can_sign);

	while(!dmClient.interrupt)
	{
		if(appClient.appSleep == APP_SLEEP){
			break;
		}
#if 0
		dtc_number = dtc_num[index];
		index++;
		printf("dtc_number in CAN_SIGN = %d\n",dtc_number);
		if(d_count != 0)
		{
			if(((index % d_count) == 0) && (index != 0))
				index = 0;
		}
		else

			index = 0;
#endif
		get_time(ts);
		rc = final_payload_frame (ts, &obd_qdata, "CAN_SIGN");
		obd_qdata.msg_type =  CAN_SIGN;
		rc = send_msg_q(&obd_qdata);
		if (rc == OBD2_APP_SUCCESS){
                                IOBD_DEBUG_LEVEL4 ("Can_Sign event sent to message queue");
		}

		sleep(standard_cli.usb_app.freq.f_can_sign);
	}
	IOBD_DEBUG_LEVEL2 ("can_sign_thread exits\n");
    can_sign_thread_create = 0;
}

void sample_evt_thread (void)
{
	int rc = 0;
	char ts[32]={0};
	struct obd_data obd_qdata;
	char dtc_buf[50] = {0},dtc_backup[50] = {0}, dtc[50] = {0},res_dtc[50] = {0};	
	int i = 0;
	int dtc_count = 1;
	bool flag = 0;
//	rc  = get_xml_content (SRC_XML_FILE, "general", "sampling_frequency", value);  

//	standard_cli.usb_app.freq.f_sampling = atoi (value);
	IOBD_DEBUG_LEVEL3 ("Sampling frequency %hd",standard_cli.usb_app.freq.f_sampling);

	memset(dtc_buf,0,sizeof (dtc_buf));
	memset(dtc_buf,0,sizeof (dtc_backup));
	memset(dtc_buf,0,sizeof (dtc));
	memset(dtc_buf,0,sizeof (res_dtc));
	memset(dtc_num,0,sizeof (dtc_num));
	while(!dmClient.interrupt)
	{
		if(appClient.appSleep == APP_SLEEP){
			break;
		}
		get_time(ts);
		if(flag == 0 && fatigue_detection ()== 1){
			flag = 1;
                        IOBD_DEBUG_LEVEL2("********************************FATIGUE DETECTED************************************\n");

                }

		if (flag == 1){
		        rc = final_payload_frame (ts, &obd_qdata, "FATIGUE_ON");
                        obd_qdata.msg_type = FATIGUE_ON;
                        rc = send_msg_q(&obd_qdata);

                        if(rc < 0)
                        {
                                IOBD_DEBUG_LEVEL2(" FATIGUE_ON send to server failed!\n");
                        }
		}


		get_dtc_code(dtc_buf, sizeof(dtc_buf));
		IOBD_DEBUG_LEVEL3 ("strlen of dtc_buf %d\n",strlen(dtc_buf));

		if(strlen(dtc_buf) > 0)
		{ 
			if(strcmp(dtc_buf,dtc_backup) != 0)
			{
				strcpy(dtc_backup,dtc_buf);
				IOBD_DEBUG_LEVEL2 ("*****DTC CODE GENERATED %s\n",dtc_buf);	
				dtc_count = 1;//clearing count for every new dtc
				strcpy(dtc,dtc_buf);
				/*Checking no of dtc's*/
				for (i = 0;dtc_buf[i]; i++)
				{
					if(dtc_buf[i] == ' ')
						dtc_count++;
				}
				IOBD_DEBUG_LEVEL3 ("no of dtc's = %d\n",dtc_count);
				d_count = 0;
				for (i = 0 ; i < dtc_count ; i++)
				{
					strncpy(res_dtc , dtc ,5);
					strcat(res_dtc,"\0");
					dtc_num[d_count] = convert_dtc_integer (res_dtc);
//					dtc_num[d_count] = dtc_number;
					d_count++;

					if(dtc_count-i > 1)
						strcpy(dtc , dtc+6);
					else 
						d_count = 0;
				}
				IOBD_DEBUG_LEVEL3 ("d_count in sample evt thread is %d\n",d_count);
				for(i = 0; i<dtc_count ; i++)
					printf("dtc_num[%d] = %d\n",i,dtc_num[i]);
			}
					dtc_number = dtc_num[d_count++];
					rc = final_payload_frame (ts, &obd_qdata, "SAMPLING");
					obd_qdata.msg_type =  SAMPLING;
					rc = send_msg_q(&obd_qdata);
					if (d_count == dtc_count)
						d_count = 0;	
		}
		else{
			rc = final_payload_frame (ts, &obd_qdata, "SAMPLING");
			obd_qdata.msg_type =  SAMPLING;
			rc = send_msg_q(&obd_qdata);
			if (rc == OBD2_APP_SUCCESS)
				IOBD_DEBUG_LEVEL3 ("Sampling event sent to message queue");
		}
		sleep (standard_cli.usb_app.freq.f_sampling);
		
	}
	IOBD_DEBUG_LEVEL2 ("sample_event_thread exits");
    sample_evt_thread_create = 0;
}

int convert_dtc_integer (char *dtc)
{
	int dtc_val = 0;

	dtc = dtc+1;
	IOBD_DEBUG_LEVEL3 ("**********dtc = %s\n",dtc);
	dtc_val = atoi ( dtc );
	IOBD_DEBUG_LEVEL3 ("**********dtc_val = %d\n",dtc_val);
	return dtc_val;

}

void fuel_consumption_thread (void)
{
	double fuel_consumed = 0;
	char val_buf1[32];
	int fp1, ret;

	IOBD_DEBUG_LEVEL2 ("1.fuel_consumption_thread fuel is %lf",standard_cli.fuel.total_fuel);
	if (standard_cli.fuel.total_fuel == 0.0)
	{
		if (access("/fuel_c_file1.txt", F_OK )){
			if ((fp1 = open ("/fuel_c_file1.txt", O_WRONLY|O_CREAT|O_SYNC)) == OBD2_APP_FAILURE)
			{
				IOBD_DEBUG_LEVEL2 ("1.Can't open fuel_c_file1.txt errno %d\n",errno);
			}else{
				memset (val_buf1,'\0',sizeof(val_buf1));
				sprintf (val_buf1,"%lf",standard_cli.fuel.total_fuel);

				if (write (fp1, val_buf1, strlen(val_buf1)) == OBD2_APP_FAILURE){
					IOBD_DEBUG_LEVEL2 ("write_failed with %d",errno);
				}else{
					fdatasync(fp1);
					ret = posix_fadvise(fp1, 0,0,POSIX_FADV_DONTNEED);
					if (ret)
						IOBD_DEBUG_LEVEL2 ("1.posix_fadvise ret is %d",ret);
				}
				close(fp1);
			}
		}
		else{
			if ((fp1 = open ("/fuel_c_file1.txt", O_RDONLY|O_SYNC)) == OBD2_APP_FAILURE)
			{
				IOBD_DEBUG_LEVEL2 ("2.Can't open fuel_c_file1.txt errno %d\n",errno);
			}
			else{
				memset (val_buf1, '\0', sizeof(val_buf1));
				read (fp1, val_buf1, sizeof(double));//scanning file1 value
				standard_cli.fuel.total_fuel = atof(val_buf1);
				IOBD_DEBUG_LEVEL2 ("2.fuel_consumption_thread fuel is %lf",standard_cli.fuel.total_fuel);
				close(fp1);
			}
		}	
	}	

	while(!dmClient.interrupt)
	{
		if(appClient.appSleep == APP_SLEEP){
			if ((fp1 = open ("/fuel_c_file1.txt", O_WRONLY|O_CREAT|O_SYNC)) == OBD2_APP_FAILURE)
			{
				IOBD_DEBUG_LEVEL2 ("1.Can't open fuel_c_file1.txt errno %d\n",errno);
			}
			else{
				memset (val_buf1,'\0',sizeof(val_buf1));
				sprintf (val_buf1,"%lf",standard_cli.fuel.total_fuel);
				if (write (fp1, val_buf1, strlen(val_buf1)) == OBD2_APP_FAILURE){
					IOBD_DEBUG_LEVEL2 ("write_failed with %d",errno);
				}else{
					fdatasync(fp1);
					ret = posix_fadvise(fp1, 0,0,POSIX_FADV_DONTNEED);
					if (ret)
						IOBD_DEBUG_LEVEL2 ("2.posix_fadvise ret is %d",ret);
				}
				close(fp1);
			}

			break;
		}

		/* update fuel consumption value */
		if((fuel_consumed = fuel_consumption())>0){
			IOBD_DEBUG_LEVEL2 ("*** FUEL CONSUMED %lf***\n",fuel_consumed);
		}
		sleep(5);
	}
	IOBD_DEBUG_LEVEL2 ("fuel_consumption_thread exits");
    fuel_consumption_thread_create = 0;
}


double fuel_consumption()
{
/*
           MAF - Mass Air Flow Rate - Air flow rate for fuel
           Grams of gas per gram of gasoline = it takes 14.7 gram of air for each gram of gasoline -  MAF/14.7
           Gals gas per second = (MAF/14.7)/(454*6.17) = MAF/(14.7 * 2801.18)
           GPH (Gallons per hour) = (MAF  3600 / (14.7 * 2801.18)) = MAF*0.087426713
	   To convert km/hr to miles/hr VSS(km/h)*0.621317
           Miles Per Galon = MPH/GPH = (VSS(km/h)*0.621317)/(MAF*0.087426713) = (VSS*7.718)/MAF
           Fuel Consumption = GPH * Travel time
           Fuel Consumption = MPG * Distance travelled in miles
           Fuel Consumption = Distance travelled in miles/MPG;
         */
	double MPG = 0.0,GPH = 0.0,LPH = 0.0,KPL = 0.0,fuel_used = 0.0;
	time_t e_time;
        double t_time = 0.0;

	e_time = time(NULL);
	IOBD_DEBUG_LEVEL3 ("fuel_thread end time is %ld",e_time);
        t_time = ((double)(e_time - standard_cli.speed.s_time)/(double)3600);

	IOBD_DEBUG_LEVEL3 ("t_time  %lf\tMAF %lf\n",t_time,car_data.maf_rate);
	if (car_data.maf_rate == 0.0)
		return -1;
	GPH = car_data.maf_rate * 0.087426713;
	IOBD_DEBUG_LEVEL3 ("Fuel Rate %lf gallons per hour\n",GPH);
/*Converting GPH to LPH*/
	LPH = GPH * 3.7854118;
	IOBD_DEBUG_LEVEL3 ("LPH is %lf\n",LPH);
	fuel_used = LPH * t_time;
	standard_cli.fuel.total_fuel += fuel_used; 
	IOBD_DEBUG_LEVEL3 ("fuel_used is %lf\n",fuel_used);
//	update_total_fuel(fuel_used);
/*Instantaneous Fuel Economy*/
	MPG = (7.107 * car_data.veh_speed)/car_data.maf_rate;
	IOBD_DEBUG_LEVEL3 ("Fuel Economy %lf miles per gallon\n",MPG);
	/*converting Miles per gallon to kilometer per litre*/
	KPL = MPG * 0.425144;
	IOBD_DEBUG_LEVEL2 ("Fuel Economy %lf km per litre\n",KPL);

	standard_cli.fuel.fuel_economy = KPL;
	standard_cli.speed.s_time = time(NULL);	
	IOBD_DEBUG_LEVEL3 ("fuel_thread start time is %ld",standard_cli.speed.s_time);
	return standard_cli.fuel.total_fuel;	
}
int update_total_fuel(double fuel_used)
{
	double cur_fuel_val = 0;
	double val1 = 0;
	double val2 = 0;
	char val_buf1[32],val_buf2[32];
	static size_t sz;
	short int file_write = 0,rc = 0;
	int fp1,fp2;

	if(((access("/fuel_c_file1.txt", F_OK )) && (access("/fuel_c_file2.txt", F_OK ))))// if both file does not exists.
        {
                IOBD_DEBUG_LEVEL2 ("update_total_fuel: both file does not exist\n");
		if ((fp1 = open ("/fuel_c_file1.txt", O_WRONLY|O_CREAT)) == OBD2_APP_FAILURE)
                {
                        IOBD_DEBUG_LEVEL2 ("1.Can't open fuel_c_file1.txt errno %d\n",errno);
			return OBD2_APP_FAILURE;
                }
		else 
			rc = 1;
		file_write = 1;
                close(fp1);
		cur_fuel_val = fuel_used;
        }
	else if(((!access("/fuel_c_file1.txt", F_OK)) && (!access("/fuel_c_file2.txt", F_OK))))//if both file exists considering one file is corrupted
	{
		if ((fp1 = open ("/fuel_c_file1.txt", O_RDONLY)) == OBD2_APP_FAILURE)
		{
			IOBD_DEBUG_LEVEL2 ("2.Can't open fuel_c_file1.txt errno %d\n",errno);
			rc = 0;
		}else{
			read (fp1,val_buf1, sizeof(double));//scanning file1 value
			val1 = atof(val_buf1);
			IOBD_DEBUG_LEVEL2 ("2.val_buf1 = %s val1 = %lf\n",val_buf1, val1);
			close(fp1);
		}
		if ((fp2 = open ("/fuel_c_file2.txt", O_RDONLY)) == OBD2_APP_FAILURE)
		{
			IOBD_DEBUG_LEVEL2 ("2.Can't open fuel_c_file2.txt errno %d\n",errno);
			rc = 0;
		}else{
			read (fp2,val_buf2, sizeof(double));//scanning file1 value
			val2 = atof(val_buf2);
			IOBD_DEBUG_LEVEL2 ("2.val_buf1 = %s val1 = %lf\n",val_buf2, val2);
			close(fp2);
		}

		if(val1 == 0)//check file 1 corrupted
		{
                        cur_fuel_val = val2 + fuel_used; 
                        IOBD_DEBUG_LEVEL3 ("2.inside if (val1 == 0) --------cur_fuel_val = %lf\n",cur_fuel_val);
                        file_write = 1;
			rc = 1;
                }
                else if (val2 == 0)//check file2 corrupted
                {
                        cur_fuel_val = val1 + fuel_used;
                        IOBD_DEBUG_LEVEL3 ("2. inside if (val2 == 0) --------cur_fuel_val = %lf\n",cur_fuel_val);
                        file_write = 2;
			rc = 1;
                }
		else{
			if (val1 > val2){
				cur_fuel_val = val1 + fuel_used;
                        	file_write = 2;
				IOBD_DEBUG_LEVEL3 ("val1 > val2\n");
			}
			else if (val2 > val1){
				cur_fuel_val = val2 + fuel_used;
                        	file_write = 1;
				IOBD_DEBUG_LEVEL3 ("val2 > val1\n");
			}
			else if (val1 == val2){
				cur_fuel_val = val1 + fuel_used;
                        	file_write = 1;
			}
		}
        }
	else if(!access("/fuel_c_file1.txt", F_OK))//if file1 exists
        {
		if((fp1 = open("/fuel_c_file1.txt", O_RDONLY)) == OBD2_APP_FAILURE)//open file1
		{
			IOBD_DEBUG_LEVEL2 ("3.Can't open fuel_c_file1.txt errno %d\n",errno);
			rc = 0;
		}else{
			rc = 1;
			memset (val_buf1,'\0',sizeof(val_buf1));
			read (fp1,val_buf1, sizeof(double));//scanning file1 value
			cur_fuel_val = atof(val_buf1);
			IOBD_DEBUG_LEVEL2 ("3.val_buf1 = %s cur_fuel_val = %lf\n",val_buf1, cur_fuel_val);
			close(fp1);
		}
		IOBD_DEBUG_LEVEL3 ("3.<-----------cur_fuel_val = %lf fuel_used = %lf \n",cur_fuel_val,fuel_used);
                cur_fuel_val += fuel_used;
                file_write = 2;
                IOBD_DEBUG_LEVEL3 ("3.----------->cur_fuel_val = %lf\n",cur_fuel_val);
        }
        else if(!access("/fuel_c_file2.txt", F_OK))//if file2 exists
        {
		if((fp2 = open("/fuel_c_file2.txt", O_RDONLY)) == OBD2_APP_FAILURE)//open file1
                {
                        IOBD_DEBUG_LEVEL3 ("4.Can't open fuel_c_file2.txt errno %d\n",errno);
			rc = 0;
                }
		else{
			rc = 1;
			memset (val_buf2,'\0',sizeof(val_buf2));
			read (fp2, val_buf2, sizeof(double));//scanning file1 value
			cur_fuel_val = atof(val_buf2);
			IOBD_DEBUG_LEVEL2 ("4.val_buf2 = %s cur_fuel_val = %lf\n",val_buf2, cur_fuel_val);
			close(fp2);
		}
                IOBD_DEBUG_LEVEL3 ("4.<-----------cur_fuel_val = %lf fuel_used = %lf\n",cur_fuel_val,fuel_used);
                cur_fuel_val += fuel_used;
                IOBD_DEBUG_LEVEL3 ("4.----------->cur_fuel_val = %lf\n",cur_fuel_val);
                file_write = 1;
        }
	
	if(file_write == 1)
        {
		if((fp1 = open("/fuel_c_file1.txt", O_WRONLY|O_CREAT)) == OBD2_APP_FAILURE)//open file1
                {
                        IOBD_DEBUG_LEVEL2 ("5.Can't open fuel_c_file1.txt errno %d\n",errno);
			rc = 0;
                }
		else{
			rc = 1;
			memset (val_buf1,'\0',sizeof(val_buf1));
			sprintf (val_buf1,"%lf",cur_fuel_val);
			sz = strlen(val_buf1);
			if (write (fp1, val_buf1, sz) == OBD2_APP_FAILURE)
				IOBD_DEBUG_LEVEL2 ("write_failed with %d",errno);
			IOBD_DEBUG_LEVEL3 ("value %lf written to fuel_c_file1.txt\n",cur_fuel_val);
			close(fp1);
			system("sync");
		}
                if(!access("/fuel_c_file2.txt", F_OK))
                        system("rm /fuel_c_file2.txt");
                system("sync");
                system("sync");
        }
        else if (file_write == 2)
        {
		if((fp1 = open("/fuel_c_file2.txt", O_WRONLY|O_CREAT)) == OBD2_APP_FAILURE)//open file1
                {
                        IOBD_DEBUG_LEVEL2 ("6.Can't open fuel_c_file2.txt errno %d\n",errno);
			rc = 0;
                }
		else{
			memset (val_buf1,'\0',sizeof(val_buf1));
			sprintf (val_buf1,"%lf",cur_fuel_val);
			sz = strlen(val_buf1);
			if (write (fp1, val_buf1, sz) == OBD2_APP_FAILURE)
				IOBD_DEBUG_LEVEL2 ("write_failed with %d",errno);
			IOBD_DEBUG_LEVEL3 ("value %lf written to fuel_c_file2.txt\n",cur_fuel_val);
			close(fp1);
			system("sync");
		}
                if(!access("/fuel_c_file1.txt", F_OK))
                        system("rm /fuel_c_file1.txt");
                system("sync");
                system("sync");
        }
        standard_cli.fuel.total_fuel = cur_fuel_val;
        IOBD_DEBUG_LEVEL3 ("***********total_fuel %lf*********\n",standard_cli.fuel.total_fuel);
        return rc;
}

int get_gps_data_wrapper(struct gps_pkt * gps)
{
	int ret = 0;
	size_t nbytes;
	/*RMC*/
	ret=get_gps_rmc_data(gps->gps_rmc.nmea, &nbytes);
	ParseRMC(&gps->gps_rmc, nbytes);
	/*GGA*/
	ret = get_gps_gga_data(gps->gps_gga.nmea, &nbytes);
	ParseGGA(&gps->gps_gga, nbytes);
	/*GSV*/
	ret = get_gps_gsv_data(gps->gps_gsv.nmea, &nbytes);
	ParseGSV(&gps->gps_gsv, nbytes);

	/*GSA*/
	ret = get_gps_gsa_data(gps->gps_gsa.nmea, &nbytes);
	ParseGSA(&gps->gps_gsa, nbytes);	

	return ret;

}

int read_req_data(struct gps_pkt * gps,accelerometer_api_priv *adata)
{
	int rc = 0;

	IOBD_DEBUG_LEVEL4 ("read_req_data get_g_lib +\n");
	get_gps_data_wrapper(gps);
	IOBD_DEBUG_LEVEL4 ("read_req_data get_g_lib -\n");

	get_since_epoch(&msts);
	return rc;
}

int ParseGSA(struct gps_gsa_t *gps_gsa, size_t nbytes)
{
	int j,k,l;
	char field[20][100] = {{0}};

	if (gps_gsa == NULL || nbytes <= 0)
		return OBD2_APP_FAILURE;

	for(j=0,k=0,l=0;j<nbytes;j++,l++)
	{
		for(;(gps_gsa->nmea[j] != ',') && (gps_gsa->nmea[j] != '\0');k++,j++)
		{
			field[l][k] = gps_gsa->nmea[j];
		}
		field[l][k] = '\0';
		k=0;
	}

	gps_gsa->pdop = atof(field[PDOP]);
	gps_gsa->hdop = atof(field[HDOP]);
	gps_gsa->vdop = atof(field[VDOP]);

	IOBD_DEBUG_LEVEL4 ("PDOP: %f  HDOP: %f VDOP: %f \n",gps_gsa->pdop, gps_gsa->hdop,gps_gsa->vdop);
	return OBD2_APP_SUCCESS;
}

int ParseGGA(struct gps_gga_t *gps_gga, size_t nbytes)
{
	int j,k,l;
	char field[15][100] = {{0}};

	if (gps_gga == NULL || nbytes <= 0)
		return OBD2_APP_FAILURE;

	for(j=0,k=0,l=0;j<nbytes;j++,l++)
	{
		for(;(gps_gga->nmea[j] != ',') && (gps_gga->nmea[j] != '\0');k++,j++)
		{
			field[l][k] = gps_gga->nmea[j];
		}
		field[l][k] = '\0';
		k=0;
	}

	gps_gga->altitude = atof(field[ALTITUDE]);
	gps_gga->geoid = atof(field[GEOID]);

	IOBD_DEBUG_LEVEL4 ("Altitude %f Geoid %f \n",gps_gga->altitude, gps_gga->geoid);
	return OBD2_APP_SUCCESS;
}

int ParseGSV(struct gps_gsv_t *gps_gsv, size_t nbytes)
{
	int j,k,l;
	char field[20][100] = {{0}};

	if (gps_gsv == NULL || nbytes <= 0)
		return OBD2_APP_FAILURE;

	for(j=0,k=0,l=0;j<nbytes;j++,l++)
	{
		for(;(gps_gsv->nmea[j] != ',') && (gps_gsv->nmea[j] != '\0');k++,j++)
		{
			field[l][k] = gps_gsv->nmea[j];
		}
		field[l][k] = '\0';
		k=0;
	}

	gps_gsv->no_f_sat = atoi(field[NO_OF_SAT]);
	IOBD_DEBUG_LEVEL4 ("No. Satellite View: %d\n",gps_gsv->no_f_sat);
	return OBD2_APP_SUCCESS;
}

int ParseVTG(struct gps_vtg_t *gps_vtg, size_t nbytes)
{
	int j,k,l;
	char field[20][100] = {{0}};

	if (gps_vtg == NULL || nbytes <= 0)
		return OBD2_APP_FAILURE;

	for(j=0,k=0,l=0;j<nbytes;j++,l++)
	{
		for(;(gps_vtg->nmea[j] != ',') && (gps_vtg->nmea[j] != '\0');k++,j++)
		{
			field[l][k] = gps_vtg->nmea[j];
		}
		field[l][k] = '\0';
		k=0;
	}

	gps_vtg->speed = atof(field[KMPH_SPEED]);
	gps_vtg->direction = atof(field[DIRECTION]);

	printf("GPS Speed: %f GPS Direction: %f\n",gps_vtg->speed,gps_vtg->direction);
	return OBD2_APP_SUCCESS;
}

int ParseRMC(struct gps_rmc_t *gps_rmc, size_t nbytes)
{
	int j,k,l;
	char field[20][100] = {{0}};
	static double prev_lat = 0.0, prev_lon = 0.0;
 
	if (gps_rmc == NULL || nbytes <= 0)
		return OBD2_APP_FAILURE;

	IOBD_DEBUG_LEVEL4 (" ParseRMC rmc_nmea %s \n",gps_rmc->nmea);
	for(j=0,k=0,l=0;j<nbytes;j++,l++)
	{
		for(;(gps_rmc->nmea[j] != ',') && (gps_rmc->nmea[j] != '\0');k++,j++)
		{
			field[l][k] = gps_rmc->nmea[j];
			if(l > 16)
				break;
		}
		field[l][k] = '\0';
		k=0;
	}

	if(*field[RMA_FIX_STATUS] != 'A'){
		IOBD_DEBUG_LEVEL2("\nGPS Not Valid\n");
		gps_rmc->latitude = prev_lat;
		gps_rmc->longitude = prev_lon;
		gps_rmc->gps_valid = 0;	
	}else{
		IOBD_DEBUG_LEVEL2("GPS is Valid!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");

		gps_rmc->hour = atoi(field[TIME_STAMP]) / 10000;
		gps_rmc->minutes = (atoi(field[TIME_STAMP])/100) % 100;
		gps_rmc->seconds = atoi(field[TIME_STAMP]) % 100;

		gps_rmc->latitude = (fmod(atof(field[RMA_CUR_LATITUDE]),100.00)/60) +  (atoi(field[RMA_CUR_LATITUDE])/100);
		prev_lat = gps_rmc->latitude;
		if (*field[RMA_HEMISPHERE] != 'N')
			gps_rmc->latitude = -gps_rmc->latitude;

		gps_rmc->longitude = (fmod(atof(field[RMA_CUR_LONGITUDE]),100.00)/60 ) + (atoi(field[RMA_CUR_LONGITUDE])/100);
		prev_lon = gps_rmc->longitude;
		if (*field[RMA_GREENWICH] != 'E')
			gps_rmc->longitude = -gps_rmc->longitude;

		gps_rmc->speed = atof(field[RMA_KNOT_SPEED]);

		gps_rmc->direction = atof(field[RMA_DIRECTION]);

		gps_rmc->gps_valid = 1;
		IOBD_DEBUG_LEVEL4 ("speed is %f knots\n",gps_rmc->speed);
		gps_rmc->speed = gps_rmc->speed * 1.852;
		IOBD_DEBUG_LEVEL2 ("gps_rmc->latitude : %f gps_rmc->longitude: %f  gps_rmc->speed : %fkm/hr gps_rmc->direction:%f deg\n",gps_rmc->latitude,gps_rmc->longitude, gps_rmc->speed, gps_rmc->direction);
	}
	return gps_rmc->gps_valid;
}

void check_main_battery_reconnection()
{
        struct obd_data obd_qdata;
        int rc = 0;
        char ts[32]={0};

        get_time(ts);

        if(standard_cli.btry_disconnect == 1){
                standard_cli.btry_disconnect = 0;

                get_gps_data_wrapper(&standard_cli.g_gps);
                get_car_data(&standard_cli.g_carparams);
                convert_raw_data(&standard_cli.g_carparams);
                rc = final_payload_frame (ts, &obd_qdata, "MB_RN");
                obd_qdata.msg_type =  MB_RN;
                rc = send_msg_q(&obd_qdata);

                if(rc<0)
                        IOBD_DEBUG_LEVEL2 ("send data to server failed \n");
        }
}

void Memory_status_thread( )
{
    while( 1 )
    {
        printf("\n");
        printf("\n");
        printf("\n");
        printf("\n");
        printf("%s - Check Memory status ##################################\n", __FUNCTION__ );
        system("free -h");
        printf("\n");
        printf("\n");
        printf("\n");
        printf("\n");
		sleep( 1 );
    }
}
