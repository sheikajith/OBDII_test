#include "application.h"
#include "standard_queue.h"

int init_mq(void)
{
	struct mq_attr attr;
	attr.mq_flags = 0;
	attr.mq_maxmsg = Q_MAX_MESSAGES;

	//attr.mq_msgsize = MAX_MSG_SIZE+4+64;
	attr.mq_msgsize = MAX_SIZE+sizeof(int);

	attr.mq_curmsgs = 0;

	/* set the resource limitation to infinity, such that errno24 doesn't happen */
	struct rlimit rlim;
	memset(&rlim, 0, sizeof(rlim));
	rlim.rlim_cur = RLIM_INFINITY;
	rlim.rlim_max = RLIM_INFINITY;

	setrlimit(RLIMIT_MSGQUEUE, &rlim);
	/* Destroy the queue if exists */
	if(mq_unlink("/obd_q")== OBD2_APP_FAILURE)
		IOBD_DEBUG_LEVEL2("%s:Message queue delete failed ERROR--- %d \r\n",__func__, errno);

	dmClient.obd_queue_id = mq_open("/obd_q", O_RDWR | O_CREAT,NULL, &attr);

	if (dmClient.obd_queue_id == (mqd_t) OBD2_APP_FAILURE)
	{
		IOBD_DEBUG_LEVEL2 ("%s:Message queue create failed ERROR--- %d \r\n",__func__, errno);
	}
	IOBD_DEBUG_LEVEL4 ("####/obd_q msg_q_id is %d\r\n",dmClient.obd_queue_id);

	return dmClient.obd_queue_id;
}

int init_mq_usb(void)
{
	struct mq_attr attr;
	attr.mq_flags = 0;
	attr.mq_maxmsg = 256;

	//attr.mq_msgsize = MAX_MSG_SIZE+4+64;
	attr.mq_msgsize = 100;

	attr.mq_curmsgs = 0;

	/* set the resource limitation to infinity, such that errno24 doesn't happen */
	struct rlimit rlim;
	memset(&rlim, 0, sizeof(rlim));
	rlim.rlim_cur = RLIM_INFINITY;
	rlim.rlim_max = RLIM_INFINITY;

	setrlimit(RLIMIT_MSGQUEUE, &rlim);
#if 0
	/* Destroy the queue if exists */
	if(mq_unlink("/obd_q")==-1)
		printf("1.Message queue delete failed ERROR--- %d \r\n",errno);
#endif
	dmClient.fw_to_usb_id = mq_open ("/fw_to_usb_q", O_RDWR | O_CREAT,NULL, &attr);

	if (dmClient.obd_queue_id == (mqd_t) OBD2_APP_FAILURE)
	{
		IOBD_DEBUG_LEVEL2 (" %s:Message queue create failed ERROR--- %d \r\n",__func__, errno);
	}
	else{
		IOBD_DEBUG_LEVEL4 ("####fw_to_usb_id is %d\r\n",dmClient.fw_to_usb_id);
	}

	return dmClient.fw_to_usb_id;
}


void deinit_mq()
{

//	if(mq_close(dmClient.obd_queue_id)==-1)
//		printf(" Message queue close failed ERROR--- %d \r\n",errno);

	if(mq_close(dmClient.fw_to_usb_id) ==  OBD2_APP_FAILURE)
		IOBD_DEBUG_LEVEL2 ("%s:Message queue close failed ERROR--- %d \r\n",__func__, errno);

	//if(mq_unlink("/obd_q")==-1)
	//	printf(" Message queue delete failed ERROR--- %d \r\n",errno);

	if(mq_unlink("/fw_to_usb_q")== OBD2_APP_FAILURE)
		IOBD_DEBUG_LEVEL2 ("%s:Message queue delete failed ERROR--- %d \r\n",__func__, errno);

}

int send_msg_q(struct obd_data *data)
{
	int rc = 0;
	IOBD_DEBUG_LEVEL3 ("send_msg_q w+");
	sem_wait(&dmClient.obd_q_sem);
	IOBD_DEBUG_LEVEL3 ("send_msg_q w-");
	if (mq_send(dmClient.obd_queue_id, (const char *)data, sizeof(struct obd_data),0)  == (mqd_t) OBD2_APP_FAILURE) {
		IOBD_DEBUG_LEVEL2 ("%s:Message Queue send failed ERROR %d\r\n",__func__, errno);
		sem_post(&dmClient.obd_q_sem);
		rc = -1;
	}
	IOBD_DEBUG_LEVEL3 ("send_msg_q p+");
	sem_post(&dmClient.obd_q_sem);
	IOBD_DEBUG_LEVEL3 ("send_msg_q p-");
	return rc;
}

int send_notification(const char *data)
{
        int rc = 0;
        IOBD_DEBUG_LEVEL3 ("send_notification +");
        if (mq_send(dmClient.fw_to_usb_id, data, strlen(data)+1,0)  == -1) {
                IOBD_DEBUG_LEVEL2 ("2.Message Queue send failed ERROR %d\r\n",errno);
                rc = -1;
        }
        IOBD_DEBUG_LEVEL2 ("send_notification!!!!!!!!!!!!!\n");
        return rc;
}

