#include "application.h"
#include "analytics.h"
#include "analytics_events.h"
#include "analytics_queue.h"

int init_an_mq(void)
{
	struct mq_attr attr;
	attr.mq_flags = 0;
	attr.mq_maxmsg = MAX_MESSAGES;

	//attr.mq_msgsize = MAX_MSG_SIZE+4+64;
	attr.mq_msgsize = MAX_SIZE + sizeof(int);

	attr.mq_curmsgs = 0;

	/* set the resource limitation to infinity, such that errno24 doesn't happen */
	struct rlimit rlim;
	memset(&rlim, 0, sizeof(rlim));
	rlim.rlim_cur = RLIM_INFINITY;
	rlim.rlim_max = RLIM_INFINITY;

	setrlimit(RLIMIT_MSGQUEUE, &rlim);

	/* Destroy the queue if exists */
	if(mq_unlink("/obd_analytics_q")==-1)
		IOBD_DEBUG_LEVEL2 (" %s:Message queue delete failed ERROR--- %d \r\n", __func__, errno);

	data_analytics.analytics_queue_id = mq_open("/obd_analytics_q", O_RDWR | O_CREAT,NULL, &attr);

	if (data_analytics.analytics_queue_id == -1)
	{
		IOBD_DEBUG_LEVEL2 ("4.Message queue create failed ERROR--- %d \r\n",errno);
		return -1;
	}
	IOBD_DEBUG_LEVEL3 (" data_analytics.analytics_queue_id is %d\r\n",data_analytics.analytics_queue_id);

	return data_analytics.analytics_queue_id;
}

void deinit_an_mq()
{
	if(mq_unlink("/obd_analytics_q")==-1){
		IOBD_DEBUG_LEVEL2 (" Message queue delete failed ERROR--- %d \r\n",errno);
	}else{
		IOBD_DEBUG_LEVEL3 (" Message queue delete success \r\n");
	}
}

int send_msg_an_q(struct obd_data *data)
{
	int rc = 0;
	IOBD_DEBUG_LEVEL2 ("send_msg_an_q w+");
	sem_wait(&data_analytics.analytics_q_sem);
	IOBD_DEBUG_LEVEL3 ("Send Data is %s\r\n",data->data);
	if (mq_send(data_analytics.analytics_queue_id, (const char *)data, sizeof(struct obd_data),0)  == -1) {
		IOBD_DEBUG_LEVEL2 ("5.Message Queue send failed ERROR %d\r\n",errno);
		perror ("send_msg_an_q");
		sem_post(&data_analytics.analytics_q_sem);
		rc = -1;
	}
	sem_post(&data_analytics.analytics_q_sem);
	IOBD_DEBUG_LEVEL2 ("send_msg_an_q p-");
	return rc;
}


