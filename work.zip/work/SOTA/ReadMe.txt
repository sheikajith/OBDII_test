
SOTA Application Compilation Procedure
-------------------------------------

Steps to follow:
  1) Checkout / export the SOTA source code
  2) Extract the dependency library required for SOTA Compilation using below commands,
	a. cd SOTA
	b. tar -xvf Sota_depencies.tar.bz2
  3) To Build the SOTA APP use the below command,
	$make
  4) SOTA_APP will be generated if compilation is successful.
