#ifndef __APP_H_
#define __APP_H_
#define MSG_Q           "/usb_q"
/*global declairation*/
int app_init();
int unread_message (char **);
int sem_init_3g (const char *, unsigned int value);
int sem_init_usb (const char *);
#endif
