#ifndef __SMS_H_
#define __SMS_H
#include <standard_queue.h>

/*smaple.xml data*/
#define FIRMWARE_VERSION	"iW-prfyb-BN-01-R1.0-Rel1.7"
#define WHITELIST_NUMBER       20
#define USER_ID                 5
#define PASSWORD                5
#define FILE_NAME      "/sample.xml" /*file name*/
#define WHITELIST_NODE    "whitelist_Number"
#define AUTHENTICATION_USER  "Authentication"
/*for SET and GET command */
#define CLOUD_AZURE            "cloud_azure"
#define GENERAL_SETTING        "general"
#define HARSH_BRAKE            "harsh_brake"
#define HARSH_ACCELERATION     "harsh_acceleration"
#define HARSH_CRASH            "crash"
#define HARSH_FUNCTION         "harsh"
#define OVERSPEED              "overspeed"
#define ODOMETER               "odometer"
#define OVER_TEMPERATURE       "over_temp"
#define RPM_SETTING            "rpm"
#define AIN1_SETTING           "ain1"
#define DIN1_SETTING           "din1"
#define DIN2_SETTING           "din2"
#define DOUT1_SETTING          "dout1"
#define DOUT2_SETTING          "dout2"
#define CPU_STATUS             "cpu"
#define IO_STATUS              "io_status"
#define GSM_GPRS               "gsm_gprs"
#define SOFTWARE               "software"
#define OSM_CONFIG             "osm"

/*azure clould properties*/
#define AZURE_HOST             "host"
#define AZURE_PORT             "port"
#define AZURE_DEVICE_ID        "device_id"
#define AZURE_DEVICE_TYPE      "device_type"
#define AZURE_HUB_NAME         "iot_hub_name"
#define AZURE_SAS_TOKEN        "sas_token"

/*general settings for devices*/
#define GENERAL_FREQUENCY           "sampling_frequency"
#define GENERAL_CAN_SIGN_PAYLOAD    "can_sign"
#define GENERAL_FATIGUE_DETECTION   "fatige_detection"
#define GENERAL_IDLE_TIME           "idle_time"
#define GENERAL_OSM_TIME            "osm_time"
#define GENERAL_WAIT_TIME            "wait_time"

/*cpu status properties*/
#define PROCESSOR                   "processor"
#define CLOCK_SPEED                 "clock_speed"
#define DDR3_STATUS                 "ddr3"
#define NAND_FLASH                  "nand"

/*io_status properties*/
#define AIN1_STATUS                "ain1"
#define IGNITION_PIN               "ignition_pin"

/*gsm_gprs properties*/
#define SIM_STATUS                 "sim_status"
#define NETWORK_STATUS             "network_status"

/*software status*/
#define LINUX_VERSION             "linux_version"

/*harsh break id property 11*/
#define HARSH_BRAKE_SOURCE         "source"
#define HARSH_BRAKE_THRESHOLD      "threshold"

/*harsh acceleration  id property 12*/
#define HARSH_ACCELERATION_SOURCE   "source"
#define HARSH_ACCELERATION_THRESHOLD   "threshold"

/*crash  id property 13*/
#define CRASH_SOURCE               "source"
#define CRASH_THRESHOLD            "threshold"

/*harsh id property 14*/
#define HARSH_SOURCE                "source"
#define HARSH_THRESHOLD              "threshold"

/*overspeed  id property 15*/
#define OVERSPEED_SOURCE             "source"
#define OVERSPEED_THRESHOLD          "threshold"
#define OVERSPEED_DURATION           "duration"

/*odometer  id property 16*/
#define ODOMETER_SOURCE                "source"
#define ODOMETER_THRESHOLD             "base_value"
/*over_temp id property 17*/ 
#define OVERTEMP_THRESHOLD          "threshold"
/*rpm id property  18*/
#define RPM_THRESHOLD               "threshold"
/*AIN id property 19*/
#define AIN1_SOURCE                 "source"

/*DOUT1 id property 20 */
#define DOUT1_SOURCE                "source"
#define DOUT1_VALUE                 "value"
#define DOUT_DELAY		    "delay"

/*DOUT2 id property 21 */
#define DOUT2_SOURCE                "source"
#define DOUT2_VALUE                 "value"

/*DIN1 id property 22 */
#define DIN_SOURCE                  "source"
#define DIN_VALUE                   "value"


#define PROCESSOR_NAME      0
#define CLOCK               1
#define DDR                 2
#define NAND                3
#define AIN1_VAL            4
#define IGNITION            5
#define SIM                 6
#define NETWORK             7
#define LINUX               8


#define MAX_NUM            300
#define TRUE                 1
#define MAX_LENGTH         200
#define MAX_VALUE           20  
#define COMMAND_LEN         20
#define MAX_RESP            100

/*token macros*/

#define USER            0
#define PASSWORD_ID     1
#define COMMAND         2
#define ID_PROPERTY     3
#define SOURCE          4
#define THRESHOLD       5
#define DURATION        6
#define IMMO_STATUS     3
#define DELAY           4 

/*length of user id and password*/
#define LENGTH          256

/*source pin status*/
#define SOURCE_ONE      "1"
#define SOURCE_TWO      "2"
#define SOURCE_THREE    "3"
#define SOURCE_FOUR     "4"
#define PRIORITY_ONE    "1"
#define PRIORITY_TWO    "2"
#define STATUS_ZERO     "0"
#define STATUS_ONE      "1"
#define RELAY           "1"
#define BUZZER          "2"
#define PANIC_BUTTON    "3"
#define IGNITION_PN     "4"
#define THREE            3

#define SET_CLOUD_AZURE_CONFIG_REQ                      (0x02B2)
#define SET_GEN_SET_REQ                                 (0x02C1)
#define SYSTEM_RESET_REQ                                (0x07C1)
#define SET_IO_SET_REQ                                  (0x02C5)
#define SET_THRSLD_SET_REQ                              (0x02C3)



/*global declaration*/

typedef struct info
{
	char source_threshold[MAX_NUM];
	char user_id[LENGTH];
	char password[LENGTH];
        char command[LENGTH];
	int  id_property;
	char value[LENGTH];
        char threshold[LENGTH];
	char duration[LENGTH];
	char property_name[LENGTH];
	char delay[LENGTH];
	char immo_status[4];
	char fwver[32];
	char panic_button[2];
	char relay[2];
	char ignition_pin[2];
	char buzzer[2];
	int gpio_status;
}user_info;

user_info user_msg_fmt;

/*global variables*/

int ret;
mqd_t queue;

/*function declairation*/
int GSM_set_to_message_init (int serl_fd);
int message_splitting (char *str);
int compare_with_whitelist_number (char *phone_number);
int check_for_authentication (char *userid, char *passwd);
int check_with_message_format (char msg_string[]);
int check_with_the_SET_GET_command (user_info msg_fmt);
int frame_the_response_message (user_info msg_info);
int send_sms (char *, char*);
int set_gpio_value(int gpio, short value);

#endif
