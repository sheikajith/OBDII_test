#ifndef __STD_QUEUE__
#define __STD_QUEUE__
#include <mqueue.h>
#include <sys/resource.h>
#include <errno.h>
//#include <usb_protcol_typedefs.h>
#include <stdio.h>

#define Q_MAX_MESSAGES  100
#define MAX_MSG_SIZE	64


#if 0
// structure for message queue 
typedef struct mesg_buffer {
	CHAR usb_param_name[100]
	CHAR usb_param_value[100];
} mesg_buffer_t;
#endif

typedef struct mesg_buffer {
	short type; /*!< notification*/
//	CHAR size; /*!< notification*/
//	CHAR payload[1];
} mesg_buffer_t;



mqd_t init_mq(char *queue_name);
void deinit_mq(mqd_t msg_queue_id, char *queue_name);
int send_msg_q(mqd_t msg_queue_id, struct mesg_buffer buffer);
int recv_msg_q(mqd_t msg_queue_id, struct mesg_buffer *buffer, size_t size);
int recv_msg_q_frm_fw(mqd_t msg_queue_id, char *buffer, size_t size);
#endif
