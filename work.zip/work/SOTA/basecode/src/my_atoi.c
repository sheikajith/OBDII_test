#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <atoi.h>
#include <main.h>
#include <debug.h>


/*
   atoi function will convert the string into intiger
   so my_atoi is similer to that it will convert id_propery value to intoger value
   if it contains any character means alphabatic charecters it will return -1;
   or it will return the converted intiger value to the next process

 */
int atoi_to_convert_string_to_intiger (char *token)
{
	int res = ZERO;
	if (token == NULL)
	{
		return FAILURE;
	}
	while (*token != '\0')
	{
		if (isdigit(*token) != SUCCESS)
		{
			res = res * TEN + (*token - '0');
			token++;
			if (*token == '\r')
			{
				token++;
				if (*token == '\n')
				{
					token++;
					if (*token == '\r')
					{
						token++;
						if (*token == '\n')
							token++;
						else
							return FAILURE;

					}
				}
				else
					return FAILURE;
			}
		}
		else
			return FAILURE;
	}
	return res;
}
/*this API is validate the tokens of the received message if the token having invalid character then failure return from the function*/
char *check_with_source_value (int id,char *source_val)
{
	int index = ZERO;
	memset (src_thrld, MEM_CLR, sizeof(src_thrld));
	/*validation for the function variables*/
	if (id <= ZERO || source_val == NULL)
	{
		return FAIL;
	}
	if (id == HOST_NAME || id == DEVICE_TYPE || id == SAS_TOKEN || id == IOT_HUB_NAME)
	{
		while (*source_val != '\0')
		{
			if (*source_val == ':' || *source_val == ';')
			{
				return FAIL;
			}
			src_thrld[index] = *source_val;
			index++;
			source_val++;
			if (*source_val == '\r')
			{
				source_val++;
				if (*source_val == '\n')
				{
					source_val++;
					if (*source_val == '\r')
					{
						source_val++;
						if (*source_val == '\n')
							source_val++;
						else
							return FAIL;
					}
				}
				else
					return FAIL;
			}
		}
	}
	else
	{
		while (*source_val != '\0')
		{
			if (isdigit(*source_val) != SUCCESS)
			{
				src_thrld[index] = *source_val;
				index++;
				source_val++;
				if (*source_val == '\r')
				{
					source_val++;
					if (*source_val == '\n')
					{
						source_val++;
						if (*source_val == '\r')
						{
							source_val++;
							if (*source_val == '\n')
								source_val++;
							else
								return FAIL;
						}
					}
					else
						return FAIL;
				}
			}
			else
			{
				return FAIL;
			}
		}
	}

	return src_thrld;
}
/* function to validate the threshold value */
char *check_with_threshold_value (char *thrld_val)
{
	int index = ZERO;
	/*validation for the function variables*/
	if (thrld_val == NULL) 
	{
		return FAIL;
	}
	memset (src_thrld, MEM_CLR, sizeof(src_thrld));

	while (*thrld_val != '\0')
	{
		if (isdigit(*thrld_val) != SUCCESS || *thrld_val == '.')
		{
			src_thrld[index] = *thrld_val;
			index++;
			if (*thrld_val == '.' && strstr (thrld_val+1, "."))
				return FAIL;
			thrld_val++;
			if (*thrld_val == '\r')
			{
				thrld_val++;
				if (*thrld_val == '\n')
				{
					thrld_val++;
					if (*thrld_val == '\r')
					{
						thrld_val++;
						if (*thrld_val == '\n')
							thrld_val++;
						else
							return FAIL;
					}
				}
				else
					return FAIL;
			}
		}
		else
		{
			return FAIL;
		}
	}

	return src_thrld;
}
/*function for check the command foramat*/
char *check_command_format (char *command)
{
	int index = ZERO;
	if (command == NULL)
	{
		return FAIL;
	}
	memset (cmd, MEM_CLR, sizeof(cmd)); 
	while (*command != '\0')
	{

		if (isalpha(*command) != SUCCESS)
		{
			cmd[index] = *command;
			index++;
			command++;
			if (*command == '\r')
			{
				command++;
				if (*command == '\n')
				{
					command++;
					if (*command == '\r')
					{
						command++;
						if (*command == '\n')
							command++;
						else
							return FAIL;

					}

				}
				else 
					return FAIL;
			}
		}
		else
			return FAIL;
	}
	return cmd;
}


/*check for the immobaliser source and delay value is proper*/
char *check_source_value_for_immo (char *src_dely)
{
	int index = ZERO;
	/*validation for function parameters*/
	if (src_dely == NULL)
	{
		return FAIL;
	}
	memset (src_thrld, MEM_CLR, sizeof(src_thrld));
	while (*src_dely != '\0')
	{
		if (isdigit(*src_dely) != SUCCESS)
		{
			src_thrld[index] = *src_dely;
			index++;
			src_dely++;
			if (*src_dely == '\r')
			{
				src_dely++;
				if (*src_dely == '\n')
				{
					src_dely++;
					if (*src_dely == '\r')
					{
						src_dely++;
						if (*src_dely == '\n')
							src_dely++;
						else
							return FAIL;
					}
				}
				else
					return FAIL;
			}
		}
		else
			return FAIL;
	}
	return src_thrld;
}
