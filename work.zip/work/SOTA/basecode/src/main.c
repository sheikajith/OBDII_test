#include <stdio.h>
#include <string.h>
#include <main.h>
#include <app.h>
#include <sms.h>
#include <stdlib.h>
#include <debug.h>
#include <unistd.h>
int main()
{
	int res;
	static int serial_fd;
	char *buffer = NULL;
	/*app init function to intitialize the hardware layer and set the GSM to text mode message format*/

	res = app_init();
	/*validation for serial fd*/
	if (res < 0)
	{
		DEBUG ("app_init fails\n");
	}
	else if (res){
		serial_fd = res;
init_again:	res = GSM_set_to_message_init (serial_fd);
		if (res == FAILURE){
			ERROR ("at command response not valid\n");
			sleep(3);
			goto init_again;
		}
	}
	while(1)
	{
		/*continuous loop for the message reading and processing*/
		/*30000 delay for the next set for reading message*/
		usleep (DELAY_MSG);
		/*function call to read the unread messages*/
		res = unread_message (&buffer);
		/*after reading messages store in buffer so validate the buffer its not going to be NULL*/
		if (res != SUCCESS)
		{
			ERROR ("Error in the getting message\n");
		}
		else
		{
		//	DEBUG ("buffer is %s\n\n",buffer);
			/*funcion call for splitting mesaage and sender_id and text message is extracted form buffer for each message*/
			res = message_splitting (buffer);
			/*validation for the return result*/
			if (res != SUCCESS)
			{
				ERROR("function fails to split the message");
			}
			free (buffer);
		}
	}
	return SUCCESS;
}




