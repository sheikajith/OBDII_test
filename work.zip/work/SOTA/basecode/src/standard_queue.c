#include <standard_queue.h>
#include <debug.h>
#include <string.h>

mqd_t init_mq(char *queue_name)
{
        struct mq_attr attr;
		mqd_t msg_queue_id;
        attr.mq_flags = 0;
        attr.mq_maxmsg = Q_MAX_MESSAGES;

        attr.mq_msgsize = MAX_MSG_SIZE;

        attr.mq_curmsgs = 0;

        /* set the resource limitation to infinity, such that errno24 doesn't happen */
        struct rlimit rlim;
        memset(&rlim, 0, sizeof(rlim));
        rlim.rlim_cur = RLIM_INFINITY;
        rlim.rlim_max = RLIM_INFINITY;

        setrlimit(RLIMIT_MSGQUEUE, &rlim);

#if 0
        /* Destroy the queue if exists */
        if(mq_unlink(queue_name)==-1)
                DEBUG("1.Message queue delete failed ERROR--- %d \r\n",errno);
#endif

        msg_queue_id = mq_open(queue_name, O_RDWR | O_CREAT,NULL, &attr);

        if (msg_queue_id == -1)
        {
                DEBUG(" 2.Message queue create failed ERROR--- %d \r\n",errno);
                return -1;
        }

        return msg_queue_id;
}

void deinit_mq(mqd_t msg_queue_id, char *queue_name)
{

	 if(mq_close(msg_queue_id)==-1){
                DEBUG(" Message queue close failed ERROR--- %d \r\n",errno);
	 }else{
                DEBUG(" Message queue close success \r\n");
	 }

	if(mq_unlink(queue_name)==-1){
                DEBUG(" Message queue delete failed ERROR--- %d \r\n",errno);
	}else{
                DEBUG(" Message queue delete success \r\n");
	}


}

int send_msg_q(mqd_t msg_queue_id, struct mesg_buffer buffer)
{
        if (mq_send(msg_queue_id, (const char *)&buffer, sizeof(struct mesg_buffer),0)  == -1) {
                ERROR (" Message Queue send failed ERROR %d\r\n",errno);
        }
	else{
		DEBUG ("Message Queue send Success");
	}
        return 0;
}
int recv_msg_q(mqd_t msg_queue_id, struct mesg_buffer *buffer, size_t size)
{
        if (mq_receive(msg_queue_id, (char *)buffer, size, 0)  == -1) {
                ERROR (" Message Queue recv failed ERROR %d\r\n",errno);
        }
        return 0;
}

int recv_msg_q_frm_fw(mqd_t msg_queue_id, char *buffer, size_t size)
{
        if (mq_receive(msg_queue_id, buffer, size, 0)  == -1) {
                ERROR (" Message Queue recv failed ERROR %d\r\n",errno);
        }
        return 0;
}

