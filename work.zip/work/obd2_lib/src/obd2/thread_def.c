#include"thread.h"
#include"init.h"
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "pwr_mgmt.h"
#include "can_header.h"
#include "4g.h"

IO_PIN_STATE gpio_pin;
int start_pm_client()
{

	/* Create power management thread */
	if (pthread_create(&(libClient.tid[0]), NULL, (void*) pm_thread, NULL) != 0) {
		IOBD_DEBUG_LEVEL1 (" pthread_create for power management failed. Closing APP \r\n");
		return -1;
	}
	else
		IOBD_DEBUG_LEVEL1("powermanagement thread is created\n");

	/* After board_init completes, pause will come out due to SIGUSR1 signal */
	sem_wait(&libClient.sem_board_init_complete);
	IOBD_DEBUG_LEVEL2("Board_init completed\n");

#ifdef __TIMER__
	if(pthread_create(&(libClient.tid[4]), NULL, (void *) timer_event_thread, NULL) != 0) {
		IOBD_DEBUG_LEVEL2 (" pthread_create for timer_thread failed %d\r\n",errno);
		return errno;
	}
	else
		IOBD_DEBUG_LEVEL2("timer_event_thread created\n");
#endif	


	IOBD_DEBUG_LEVEL3 ("Release semaphore\n");
	sem_post(&libClient.sem_board_init_complete);

	return 0;
}

int init_ign_dis_handler()
{
	IOBD_DEBUG_LEVEL3(" init_ign_dis_handler car_mode %d \r\n",libClient.car_mode);

	if(libClient.car_mode == 1) {
		/* Create can thread */
		if (pthread_create(&(libClient.tid[7]), NULL, (void*) ignition_thread, NULL) != 0)
		{
			IOBD_DEBUG_LEVEL2(" pthread_create for CAN failed. Closing APP \r\n");
			return -1;
		}
		else{
			IOBD_DEBUG_LEVEL4(" pthread_create ignition_thread created\r\n");
		}
	}
	libClient.obdflag = 1;
	return OBD2_LIB_SUCCESS;
}


int link_thread (void)
{
	int read_event_ret = 0;
	struct sockaddr_nl addr;


	// Netlink socket creation
	int nl_socket = socket (AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	IOBD_DEBUG_LEVEL4 ("####nl_socket is %d\n",nl_socket);

	sem_init(&libClient.sem_ppp0_link_down, 0, 0);

	if(pthread_create(&(libClient.tid[2]), NULL, (void *)&link_status_thread, NULL)!= OBD2_LIB_SUCCESS)
	{
		IOBD_DEBUG_LEVEL2("link_status_thread failed to create\r\n");
		return OBD2_LIB_FAILURE;
	}
	else{
		IOBD_DEBUG_LEVEL3("link status thread created\n");
	}
	// Socket open error
	if (nl_socket == OBD2_LIB_FAILURE) {
		IOBD_DEBUG_LEVEL2 ("Netlink socket open error, error number %d\n", errno);
	} 
	else 
	{
		memset ((void *) &addr, 0, sizeof (addr));

		// Kernel user interface
		addr.nl_family = AF_NETLINK;

		// Get the process ID
		addr.nl_pid = getpid ();

		/* Listen to the RTMGRP_LINK (network interface create/delete/up/down events) 
		   and RTMGRP_IPV4_IFADDR (IPv4 addresses add/delete events) */
		addr.nl_groups = RTMGRP_LINK | RTMGRP_IPV4_IFADDR | RTMGRP_IPV6_IFADDR;
		// Bind the socket an address to netlink group
		if (bind (nl_socket, (struct sockaddr *) &addr, sizeof (addr)) < 0){ 
			IOBD_DEBUG_LEVEL2 ("Netlink socket bind failed, error number %d\n", errno);
		}else 
		{
			while (1) 
			{
				read_event_ret = read_event (nl_socket);
				if (read_event_ret < 0) 
					IOBD_DEBUG_LEVEL2 ("Netlink read_event() error, error number %d\n", errno);

			}
		}
	}
	return OBD2_LIB_SUCCESS;
}

void link_status_thread()
{
	pthread_t id = pthread_self();
	int try_count = 0;


	if(pthread_equal(id,libClient.tid[2])){
		while(1){
			IOBD_DEBUG_LEVEL2("wait for semaphore in link_status_thread\r\n");
			sem_wait(&libClient.sem_ppp0_link_down);
			do{
				if (!access(USB_2,F_OK)){
					if (libClient.mod_init == 1){
						IOBD_DEBUG_LEVEL3("calling pppd \r\n");
						system("pppd call gprs_4g");//added bec it takes 15 seconds to establish connection
						try_count++;
						IOBD_DEBUG_LEVEL3("count %d\r\n",try_count);
						if(try_count == 40 && (!access(USB_2,F_OK))){
							flight_mode();
							try_count = 0;
						}
						//system("pppd call gprs_4g");
					}
				}
				sleep(1);

			}while(libClient.ppp0_link_status == LINK_DOWN);
			try_count = 0;
		}
	}
}

int board_thread (void)
{
	float voltage;
	char volt[20];

	bzero(volt,sizeof(volt));

	while(1)
	{
		system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
		system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
		system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
		system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled
		read_car_voltage(&voltage);  
		sprintf(volt,"%f",voltage);
		set_xml_content (SRC_XML_FILE, "home", "ext_bat",volt);	
		if(voltage < 3.0){
			board_init_4g_uart();
		}
		else{
			/*!< BATTERY_Charge enabled*/
			if (set_gpio_value(BATTERY_CE, GPIO_LOW) != OBD2_LIB_SUCCESS)
				IOBD_DEBUG_LEVEL2 ("BATTERY_CE off Failed");

			board_init_4g_usb();	
		}

		sem_wait(&libClient.sem_board_init);
		IOBD_DEBUG_LEVEL3 ("Board_semaphore Released");
	}
	return 0;


}

int GPIO_config(void)
{
	int ret = OBD2_LIB_SUCCESS;
	/* GPIO to turn on/off 3G module */
	ret = gpio_export(MODEM_PWRKEY);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("3G module PWRKEY export Failed with %d",ret);
	ret = set_gpio_direction(MODEM_PWRKEY, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("3G module PWRKEY set direction Failed with %d",ret);

	/* GPIO to turn on/off Status LED */
	ret = gpio_export(STATUS_LED);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("STATUS_LED export Failed with %d",ret);
	ret = set_gpio_direction(STATUS_LED, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("STATUS_LED set direction Failed with %d",ret);

	/* GPIO to turn on/off USB Power switch */
	ret = gpio_export(MODEM_USB_SWITCH);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("3G module USB_SW export Failed with %d",ret);
	ret = set_gpio_direction(MODEM_USB_SWITCH, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("3G module USB_SW set direction Failed with %d",ret);

	/* GPIO to enable/disbale battery charging 0-enable 1- disable*/
	ret = gpio_export(BATTERY_CE);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("BATTERY_CE export Failed with %d",ret);
	ret = set_gpio_direction(BATTERY_CE, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("BATTERY_CE set direction Failed with %d",ret);

	/* GPIO to turn on/off 12V regulator */
	ret = gpio_export(REG_12V);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_12V export Failed with %d",ret);
	ret = set_gpio_direction(REG_12V, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_12V set direction Failed with %d",ret);

	/* GPIO to turn on/off 4V4 regulator */
	ret = gpio_export(REG_4V4);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_4V4 export Failed with %d",ret);
	ret = set_gpio_direction(REG_4V4, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_4V4 set direction Failed with %d",ret);

	/* GPIO to turn on/off 3V3 regulator */
	ret = gpio_export(REG_3V3);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_3V3 export Failed with %d",ret);
	ret = set_gpio_direction(REG_3V3, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_3V3 set direction Failed with %d",ret);

	/* GPIO to turn on/off Buzzer */
	ret = gpio_export(DOUT1);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("DOUT1 export Failed with %d",ret);
	ret = set_gpio_direction(DOUT1, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("DOUT1 set direction Failed with %d",ret);

	/* GPIO to turn on/off Relay */
	ret = gpio_export(DOUT2);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("DOUT2 export Failed with %d",ret);
	ret = set_gpio_direction(DOUT2, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("DOUT2 set direction Failed with %d",ret);

	/* GPIO to turn on/off Interpretter CAN */
	ret = gpio_export(INTERPRETTER_CAN_EN);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("INTERPRETTER_CAN_EN export Failed with %d",ret);
	ret = set_gpio_direction(INTERPRETTER_CAN_EN, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("INTERPRETTER_CAN_EN set direction Failed with %d",ret);

	/* GPIO to turn on/off CPU CAN */
	ret = gpio_export(CPU_CAN_EN);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("CPU_CAN_EN export Failed with %d",ret);
	ret = set_gpio_direction(CPU_CAN_EN, OUTPUT); 
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("CPU_CAN_EN set direction Failed with %d",ret);

	return ret;
}

int read_event (int sockint)
{
	int status = 0;
	char buf[4096] = {0};
	struct iovec iov = {buf, sizeof buf };
	struct sockaddr_nl snl;
	struct msghdr msg = { (void *) &snl, sizeof snl, &iov, 1, NULL, 0, 0 };
	struct nlmsghdr *h;
#if 0
	FILE *fp;
	char buf_status[200];
#endif
	char ifname[1024] = {0};
	struct ifinfomsg *ifi;

	status = recvmsg (sockint, &msg, 0);

	if (status <= 0) {
		IOBD_DEBUG_LEVEL2("Error has occurred\r\n");
	}
	else {
		for (h = (struct nlmsghdr *) buf; NLMSG_OK (h, (unsigned int) status);h = NLMSG_NEXT (h, status)) {
			if (h->nlmsg_type == NLMSG_DONE) {
				return 0;
			}
			else if (h->nlmsg_type == RTM_NEWLINK) {
				ifi = NLMSG_DATA(h);
				if_indextoname (ifi->ifi_index,ifname);
				IOBD_DEBUG_LEVEL2 ("iwave: netlink_link_state: Link %s %s\n",ifname,(ifi->ifi_flags & IFF_RUNNING)?"Up":"Down");

				if(((ifi->ifi_flags & IFF_RUNNING) == 0) && (strcmp(ifname, "ppp0") == 0)){
#if 0
					fp = fopen("/home/root/link_status.txt","r+");
					strcpy(buf_status, "link is down");
					fwrite(&buf_status, strlen(buf_status), 1, fp);
					fclose(fp);
#endif
					set_xml_content (SRC_XML_FILE, "gsm_gprs", "network_status","0");
					/* if link status was up before, then kill pppd */
					if (libClient.ppp0_link_status == LINK_UP){
						IOBD_DEBUG_LEVEL3 ("killall pppd");
						system("killall pppd");
					}
					/* Update the link status */
					libClient.ppp0_link_status = LINK_DOWN;

					IOBD_DEBUG_LEVEL2 ("releasing Semaphore for  link status thread\n");
					sem_post(&libClient.sem_ppp0_link_down);
				}
				if(((ifi->ifi_flags & IFF_RUNNING) != 0) && (strcmp(ifname, "ppp0") == 0)){
#if 0
					fp = fopen("/home/root/link_status.txt","r+");
					strcpy(buf_status, "link is up");
					fwrite(&buf_status, strlen(buf_status), 1, fp);
					fclose(fp);
#endif
					libClient.ppp0_link_status = LINK_UP;
					set_xml_content (SRC_XML_FILE, "gsm_gprs", "network_status","1");
				}
			}
		}
	}
	return 0;
}

int update_gpio_info (IO_PIN_STATE *io_pin)
{
	int ret = 0;

	gpio_pin.din1  = io_pin->din1;	
	gpio_pin.din2  = io_pin->din2;	
	gpio_pin.dout1[0] = io_pin->dout1[0];	
	gpio_pin.dout1[1] = io_pin->dout1[1];	
	gpio_pin.dout2[0] = io_pin->dout2[0];	
	gpio_pin.dout2[1] = io_pin->dout2[1];	
	gpio_pin.ain1  = io_pin->ain1;	

	if (gpio_pin.dout1[0] == RELAY){
                ret = set_gpio_value(DOUT1,gpio_pin.dout1[1]);/*Relay high in dout1*/
        }
	if (gpio_pin.dout2[0] == RELAY){
                ret = set_gpio_value(DOUT2,gpio_pin.dout2[1]);/*Relay high in dout2*/
        }

	return ret;
}

int get_gpio_event(char *path, char *event) {

	int event_no = 0;	
	FILE *fp;
	char command[100];
	char *intf_conf;
	char *file_name = "/name";
	char event_file[72];
	int i;

	for (i = 0; i < 5; i++){
		sprintf (event_file, "%s%d%s",path,i,file_name);	
		fp = fopen(event_file, "r");
		if (fp == NULL){
			perror (event_file);
			continue;
		}
		else{
			fread(&command, 30, 1, fp);
			fclose (fp);
		}
		intf_conf = strstr(command,event);
		if (intf_conf){
			event_no = i;
			break;
		}
	}

	return event_no;
}	

int key_event_thread()
{
	int fd, rc = 0;
	char ts[100];
	struct input_event ev[64];
	int i, rd;
	struct timeval timeout;
	int retval;
	fd_set rdfs;
	struct ign_stat ign_qdata;
	int ret = 0;
	int event_no;
    char file[50] = {0};
    long sleep_time = 0;
    char time_buf[8];

	event_no = get_gpio_event(GPIO_EVENT_PATH, GPIO_EVENT_NAME);
	IOBD_DEBUG_LEVEL3("the event number of gpio-key is %d\r\n", event_no);

	sprintf(file, "/dev/input/event%d", event_no);

	if ((fd = open (file, O_RDWR)) < 0) {
		IOBD_DEBUG_LEVEL2("Error Occured while opening Device File.!!\n");
		return -1;
	}
	else{
		IOBD_DEBUG_LEVEL4("####key_event_thread Id is %d\n",fd);
	}


	FD_ZERO(&rdfs);
	FD_SET(fd, &rdfs);

	/* timeout wait for 100ms */
	timeout.tv_sec = 0;
	timeout.tv_usec = 10000;

	while(1) {
		retval = select(fd + 1, &rdfs, NULL, NULL, &timeout);//aug2019: changed from fd+2 to fd+1

		if(retval) {
			rd = read(fd, ev, sizeof(ev));
			if (rd < (int) sizeof(struct input_event)) {
				IOBD_DEBUG_LEVEL2("expected %d bytes, got %d\n", (int) sizeof(struct input_event), rd);
				return 1;
			}

			for (i = 0; i < rd / sizeof(struct input_event); i++) {
				IOBD_DEBUG_LEVEL2("i : %d, code : %d, value : %d \r\n", i, ev[i].code, ev[i].value);
				if(ev[i].code == 29 && ev[i].value == 0 && libClient.dev_sleep == DEV_SLEEP) {
					/* put the system to sleep */
					IOBD_DEBUG_LEVEL3 ("Key_event_thread sem_post");
					sem_post(&libClient.ign_off_restart);
					system("echo mem > /sys/power/state");
					config_wakeup_timer_trigger(TIMER_DISABLE, NO_SLEEP_TIME);
					IOBD_DEBUG_LEVEL2("##############SYSTEM_HAS_AWAKE##############");
				}
				else if (ev[i].code == 29 && ev[i].value == 1 && libClient.dev_sleep == DEV_SLEEP ) {
					sem_wait (&libClient.acc_key_thread_lock);
					IOBD_DEBUG_LEVEL3 ("key_lock +\n");
					sem_post (&libClient.acc_key_thread_lock);
					IOBD_DEBUG_LEVEL3 ("key_lock -\n");
					IOBD_DEBUG_LEVEL2("system has wakeup %d %d\r\n",libClient.system_wake_timer,libClient.system_wake_acc);
					if (libClient.system_wake_timer == 1 || libClient.system_wake_acc == 1){
						libClient.system_wake_acc = 0;
						libClient.system_wake_timer = 0;
						break;
					}	
					config_sleep_wake_trigger_off();
					config_wakeup_timer_trigger(TIMER_DISABLE, NO_SLEEP_TIME);

					system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
	                                system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
        	                        system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
                	                system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled

					rc = switch_on_power_rail();
					if (rc != OBD2_LIB_SUCCESS)
						IOBD_DEBUG_LEVEL2 ("key_event_thread switch_on_power_rail failed %d",rc);

					tcflush(libClient.serial_intf.tty_fd, TCIOFLUSH);
					memset(ign_qdata.data,0,sizeof(ign_qdata.data));
					get_time(ts);
					strcpy(ign_qdata.data,ts);
					IOBD_DEBUG_LEVEL2("Wake up timestamp send!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
					ret = check_ign_status(IGNITION_STAT_WITHOUT_DIP);
					if(ret == IGNITION_STATE_BATTERY_DRAIN){
						ign_qdata.msg_type = PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP;
					}
					else if (ret == IGNITION_STATE_DEVICE_REMOVED){
						ign_qdata.msg_type = PM_EVENT_SLEEP_DISCONNECTION;
					}
					else if (ret == IGNITION_STATE_OFF){
						system("i2cset -f -y 1 0x6a 0x58 0x8e");
						ret = config_sleep_wake_trigger_on();
                        printf("config_sleep_wake_trigger_on ret value############################# %d\n", ret );
                        if( ret == IGNITION_STATE_ON_RESTART )
                        {
                            /* make sleep trigger off*/
                            sleep_wake_trigger_off();
                            sleep_wake_trigger_off();

                            /* voltage change wake trigger on */
                            volt_change_wake_trigger_off();

                            /* obd reset */ 
                            obd_reset();
                            obd_reset();

                            ign_qdata.msg_type = PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE;   
                        }
                        else
                        {
                            if( ret == IGNITION_STATE_OFF )
                            {
                                printf("Inside ret == IGNITION_STATE_OFF #####################\n" );
                                /*configuring the timer for Xmin*/
                                memset( time_buf, '\0', sizeof( time_buf ) );
                                get_xml_content (SRC_XML_FILE, OSM_CONFIG, GENERAL_OSM_TIME, time_buf);
                                sleep_time = atol (time_buf);
                                config_wakeup_timer_trigger(TIMER_ENABLE,sleep_time);
                            } 
                            break;
                        }
                    }
                    else{
                        ign_qdata.msg_type = PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE;	
                    }
                    IOBD_DEBUG_LEVEL3("send saved time stamp %s \n",ts);
					rc = send_ign_q(&libClient,&ign_qdata);
					if (rc != OBD2_LIB_SUCCESS)
						IOBD_DEBUG_LEVEL2 ("message sent to PM_thread failed");
				}
				else if (ev[i].code == 30 ){//DIN2 PANIC_BUTTON- 3 IGN_PIN - 4 as per GUI
					IOBD_DEBUG_LEVEL2("inside 30 - DIN2\n");
					get_time(ts);
					if (gpio_pin.din2 == 3 && ev[i].value == 0){
						set_xml_content (SRC_XML_FILE, PARENT_DIN2_SETTING, CHILD_DIN_VALUE, "1");
						if (libClient.init_connect == 1 ){
							if(libClient.ign_fptr.pnc_btn != NULL){
								libClient.ign_fptr.pnc_btn(ts);
							}
							else
								IOBD_DEBUG_LEVEL2("invalid panic_button function address\n");	
						}
					}
					else if (gpio_pin.din2 == 4 && ev[i].value == 0){
						IOBD_DEBUG_LEVEL2 ("IGNITION ON IN DIN2\n");
						set_xml_content (SRC_XML_FILE, PARENT_NODE_IO_STAT, CHILD_NODE_IGN_PIN, "1");
						set_xml_content (SRC_XML_FILE, PARENT_DIN2_SETTING, CHILD_DIN_VALUE, "1");
					}
					else if (gpio_pin.din2 == 4 && ev[i].value == 1){
						IOBD_DEBUG_LEVEL2 ("IGNITION OFF IN DIN2\n");
						set_xml_content (SRC_XML_FILE, PARENT_NODE_IO_STAT, CHILD_NODE_IGN_PIN, "0");
						set_xml_content (SRC_XML_FILE, PARENT_DIN2_SETTING, CHILD_DIN_VALUE, "0");
					}
				}
				else if (ev[i].code == 48){//DIN1
					IOBD_DEBUG_LEVEL2("inside 48 - DIN1\n");
					get_time(ts);
					if (gpio_pin.din1 == 3 && ev[i].value == 0){

						set_xml_content (SRC_XML_FILE, PARENT_DIN1_SETTING, CHILD_DIN_VALUE, "1");
						if (libClient.init_connect == 1 ){
							if(libClient.ign_fptr.pnc_btn != NULL){
								libClient.ign_fptr.pnc_btn(ts);
							}
							else
								IOBD_DEBUG_LEVEL2("invalid panic_button function address\n");	
						}
					}
					else if (gpio_pin.din1 == 4 && ev[i].value == 0){
						IOBD_DEBUG_LEVEL2 ("IGNITION ON IN DIN1\n");
						set_xml_content (SRC_XML_FILE, PARENT_NODE_IO_STAT, CHILD_NODE_IGN_PIN, "1");
						set_xml_content (SRC_XML_FILE, PARENT_DIN1_SETTING, CHILD_DIN_VALUE, "1");
					}
					else if (gpio_pin.din1 == 4 && ev[i].value == 1){
						IOBD_DEBUG_LEVEL2 ("IGNITION OFF IN DIN1\n");
						set_xml_content (SRC_XML_FILE, PARENT_NODE_IO_STAT, CHILD_NODE_IGN_PIN, "0");
						set_xml_content (SRC_XML_FILE, PARENT_DIN1_SETTING, CHILD_DIN_VALUE, "0");
					}
				}
			}
		}
		FD_ZERO(&rdfs);
		FD_SET(fd, &rdfs);
		/* timeout wait for 100ms */
		timeout.tv_sec = 0;
		timeout.tv_usec = 10000;
	}
	close(fd);   // Close the device
}

#ifdef __TIMER__
int timer_event_thread()
{
	int rtc_fd,ret;
	struct ign_stat ign_qdata;
	int retval;
	float voltage;
	unsigned long data;
	fd_set rdfs;

	rtc_fd = open (TIMER_CFG_FILE, O_RDWR);
	if (rtc_fd == OBD2_LIB_FAILURE){
		IOBD_DEBUG_LEVEL2 ("timer_event_thread:open failed with %d\n",errno);
		return OBD2_LIB_FAILURE;
	}else {
		IOBD_DEBUG_LEVEL4("####Device File Opened Successfully !! /dev/rtc0 is %d\n",rtc_fd);
	}

	FD_ZERO(&rdfs);
	FD_SET(rtc_fd, &rdfs);


	while(1){
		IOBD_DEBUG_LEVEL3 ("timer_thread : select +");
retry:		retval = select(rtc_fd + 2, &rdfs, NULL, NULL, NULL);
		IOBD_DEBUG_LEVEL2 ("timer_thread : select -");

		if(retval) {
			/*Accelerometer wakeup disable*/
			system("i2cset -f -y 1 0x6a 0x58 0x0e");				
			libClient.system_wake_timer = 1;

			ret = read(rtc_fd, &data, sizeof(unsigned long));
			config_wakeup_timer_trigger(TIMER_DISABLE, 0);
			if (ret == OBD2_LIB_FAILURE){
				IOBD_DEBUG_LEVEL1 ("Error Occured while Reading RTC File...!!!!\n");
				goto retry;
			}

			system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
	                system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
        	        system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
                	system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled

			/*!< 12 V Switch */
		        IOBD_DEBUG_LEVEL3 ("12 V Regulator on");
        		ret = set_gpio_value(REG_12V, GPIO_HIGH);
        		if (ret != OBD2_LIB_SUCCESS)
                		IOBD_DEBUG_LEVEL2 ("REG_12V on Failed %d",ret);
        		/*!< 4V4 Switch */
        		ret = set_gpio_value(REG_4V4, GPIO_HIGH);
        		if (ret != OBD2_LIB_SUCCESS)
        		        IOBD_DEBUG_LEVEL2 ("REG_4V4 on Failed %d",ret);
        		/*!< 3V3 Switch */
        		ret = set_gpio_value(REG_3V3, GPIO_HIGH);
		        if (ret != OBD2_LIB_SUCCESS)
                		IOBD_DEBUG_LEVEL2 ("REG_3V3 on Failed %d",ret);

			IOBD_DEBUG_LEVEL2 ("system wakeup with timer : retval : %d , data : %lu\r\n", retval, data);
			config_sleep_wake_trigger_off();
			read_car_voltage(&voltage);  
			if (voltage > 3.0)
				ign_qdata.msg_type = PM_EVENT_SLEEP_MODE_OSM;
			else
				ign_qdata.msg_type = PM_EVENT_SLEEP_DISCONNECTION;
			ret = send_ign_q(&libClient,&ign_qdata);
			if (ret != OBD2_LIB_SUCCESS)
				IOBD_DEBUG_LEVEL2 ("message to pm_thread_queue failed with %d",ret);
		}
		FD_SET(rtc_fd, &rdfs);
	}
	IOBD_DEBUG_LEVEL2("%s : close value is :%d\r\n", __func__, rtc_fd);
	close(rtc_fd);   // Close the device
}
#endif

int board_init_4g_uart()
{
	int ret;
	struct hostent *hostinfo;
	char *hostname = "google.com";
	double in_bat_volt = 0.0;
	char volt[10]={0};
    int ping_count;
    short module_reset = 0;
    short module_init_count = 0;

	ret = check_in_bt_volt (&in_bat_volt);	
	if (ret == FILE_OPEN_ERROR)
		IOBD_DEBUG_LEVEL2 ("board_init_4g_uart: check_in_bt_volt failed %d\n",ret);

        set_xml_content (SRC_XML_FILE, PARENT_NODE_HOME, CHILD_NODE_IMEI, "000000000000000");
	sprintf(volt,"%lf",in_bat_volt);
	if (strlen(volt) < 10){
		set_xml_content (SRC_XML_FILE, PARENT_NODE_HOME, CHILD_NODE_INTBAT, volt);			
	}else{
		set_xml_content (SRC_XML_FILE, PARENT_NODE_HOME, CHILD_NODE_INTBAT, "0.1111");
	}
	ret = module_3g_on ();
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("uart_module_3g_on failed with ret %d",ret);

    while(1)
    {
        if(access("/dev/ttyUSB4",F_OK)){
            continue;
        }
        else{
            IOBD_DEBUG_LEVEL1 ("\nModule Initialization Completed\n");
            //system("pppd call gprs_4g");
            break;
        }
    }

check_reg:
    ret = check_registration ();
    system ("/iwtest/Application/application &");
    while(ret == -2);//if sim not inserted block
    system ("/iwtest/Application/SOTA_APP &");
    ping_count = 0;
    module_reset = 0;

    while(1){

        if (module_reset == 1)
        {
reset:          ret = module_3g_off();
                if (ret != OBD2_LIB_SUCCESS)
                    IOBD_DEBUG_LEVEL2 ("module_3g_off failed with %d\n",ret);

                ret = module_3g_on ();
                if (ret != OBD2_LIB_SUCCESS)
                    IOBD_DEBUG_LEVEL2 ("module_3g_on failed with %d\n",ret);

                while(1)
                {
                    if(access(USB_4,F_OK) != OBD2_LIB_SUCCESS){
                        module_init_count++;
                        if(module_init_count == 10){
                            IOBD_DEBUG_LEVEL1("Module Initialization Loading....");
                            module_init_count = 0;
                            goto reset;
                        }
                        usleep (300000);
                        continue;
                    }
                    else{
                        IOBD_DEBUG_LEVEL1("Module Initialization Completed");
                        break;
                    }
                }
                goto check_reg;
        }

        hostinfo = gethostbyname (hostname);
        if (hostinfo == NULL){
            system ("pppd call gprs_4g");
            IOBD_DEBUG_LEVEL1("-> no connection!_uart %d\n",libClient.ppp0_link_status);
            usleep(900000);
            ping_count++;
            if (ping_count == 60){
                module_reset = 1;
            }
            continue;
        }
        else{
            IOBD_DEBUG_LEVEL1("-> connection established!_uart\n");
            break;
        }
    }

    while(1)
    {
        ret = check_connection();
        IOBD_DEBUG_LEVEL1("Uart ---- check_connection link value is %d \n",ret);
        if(ret == 1){
            agps_init();
            break;
        }
        usleep(200000);
    }

    if(libClient.fresh_boot != 1 ){
        if(libClient.s_w.wake!=NULL){
            IOBD_DEBUG_LEVEL1(" Call application slp_disconnection handler callback \n");
            libClient.s_w.slp_dis();
        }
        else{
            IOBD_DEBUG_LEVEL1("wakeup handler not provided for application \n");
        }
    }
    else
    {
        while(1)
        {
            ret = check_connection();
            IOBD_DEBUG_LEVEL1("check_connection link value is %d \n",ret);
            if(ret == 1){
                /* NanC : */
                ntp_server_update();
                break;
            }
            usleep(200000);
        }
        /* NaN : First boot */
        sem_post(&libClient.sem_board_init_complete);
        libClient.fresh_boot = 0;
    }
    return 0;
}

int board_init_4g_usb()
{

	int ret = 0;
	struct hostent *hostinfo;
	char *hostname = "google.com";
	int ping_count;
	short module_reset = 0;
	short module_init_count = 0;
	double in_bat_volt = 0.0;
	char volt[20]={0};


	ret = check_in_bt_volt (&in_bat_volt);	
	if (ret == FILE_OPEN_ERROR)
		IOBD_DEBUG_LEVEL2 ("board_init_4g_usb: check_in_bt_volt failed %d\n",ret);

        set_xml_content (SRC_XML_FILE, PARENT_NODE_HOME, CHILD_NODE_IMEI, "000000000000000");
	sprintf(volt,"%lf",in_bat_volt);
	if (strlen(volt) < 10){
		set_xml_content (SRC_XML_FILE, PARENT_NODE_HOME, CHILD_NODE_INTBAT, volt);			
	}else{
		set_xml_content (SRC_XML_FILE, PARENT_NODE_HOME, CHILD_NODE_INTBAT, "0.1111");
	}
	ret = module_3g_on ();
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("module_3g_on failed with %d\n",ret);

	while(1)
	{
		if(access(USB_4,F_OK)){
			continue;
		}
		else{
			IOBD_DEBUG_LEVEL1 ("\nModule Initialization Completed\n");
			break;
		}
	}
check_reg: ret = check_registration ();
	system ("/iwtest/Application/application &");
		IOBD_DEBUG_LEVEL2 ("########ret is %d\n",ret);
	   while(ret == -2);//if sim not inserted block
	system ("/iwtest/Application/SOTA_APP &");
	   ping_count = 0;
	   module_reset = 0;
	   libClient.mod_init = 1;
	while(1)
	{
		if (module_reset == 1)
		{
reset:			ret = module_3g_off();
			if (ret != OBD2_LIB_SUCCESS)
				IOBD_DEBUG_LEVEL2 ("module_3g_off failed with %d\n",ret);

			ret = module_3g_on ();
			if (ret != OBD2_LIB_SUCCESS)
				IOBD_DEBUG_LEVEL2 ("module_3g_on failed with %d\n",ret);

			while(1)
			{
				if(access(USB_4,F_OK) != OBD2_LIB_SUCCESS){
					module_init_count++;
					if(module_init_count == 10){
						IOBD_DEBUG_LEVEL1("Module Initialization Loading....");
						module_init_count = 0;
						goto reset;
					}
					usleep (300000);
					continue;
				}
				else{
					IOBD_DEBUG_LEVEL1("Module Initialization Completed");
					break;
				}
			}
			goto check_reg;
		}
			hostinfo = gethostbyname (hostname);
			if (hostinfo == NULL)
			{
				system ("pppd call gprs_4g");
				sleep (1);
				IOBD_DEBUG_LEVEL1("No connection down!!! ping_count %d\n",ping_count);
				ping_count++;
				if (ping_count == 60){
					module_reset = 1;
				}
				continue;
			}
			else 
			{
				IOBD_DEBUG_LEVEL1("-> connection established! ping_count %d\n",ping_count);
				ping_count = 0;
				break;
			}
	}

	/* NaN : Moved from sampleDev */
	while(1)
	{
		ret = check_connection();
		IOBD_DEBUG_LEVEL1("check_connection link value is %d \n",ret);
		if(ret == 1){
			agps_init();
			break;
		}
		usleep(200000);
	}

	if(libClient.fresh_boot != 1 ){
		if(libClient.s_w.wake!=NULL){
			IOBD_DEBUG_LEVEL1 (" Call application wake up  handler callback \n");
			libClient.s_w.wake();
		}
		else{
			IOBD_DEBUG_LEVEL1 ("wakeup handler not provided for application \n");
		}
	}
	else
	{
		while(1)
		{
			ret = check_connection();
			IOBD_DEBUG_LEVEL1("check_connection link value is %d \n",ret);
			if(ret == 1){
				/* NanC : */
				ntp_server_update();
				break;
			}
			usleep(200000);
		}
		sem_post(&libClient.sem_board_init_complete);
		libClient.fresh_boot = 0;
	}
	return 0;
}

void pm_enable(void)
{
	libClient.powermgmt = 1;
}

void pm_disable(void)
{
	libClient.powermgmt = 0;
}

int raw_can_enable(void)
{
	int ret = 0;

	if(libClient.set_raw_can == 1)
		ret = 1;
	else
		ret = 0;

	return ret;		
}

int get_ign_stat_voltage_no_dip()
{
	float volt_val;
	int ret;

	read_car_voltage(&volt_val);

	if(volt_val > 24.0)
		read_car_voltage(&volt_val);

	if(volt_val < 13.1){
		if(volt_val < 11.9){//battery drain threshold need to be updated here
			if(volt_val < 4.0)
				ret = IGNITION_STATE_DEVICE_REMOVED;
			else
				ret = IGNITION_STATE_BATTERY_DRAIN;
		}
		else
			ret = IGNITION_STATE_OFF;
	}
	else
		ret = IGNITION_STATE_ON;


	IOBD_DEBUG_LEVEL4("volt_val : %f, ret : %d \r\n", volt_val, ret);

	return ret;

}

float get_ext_power_voltage()
{
	float volt_val = 0;
	IOBD_DEBUG_LEVEL4("get_ext_power_voltage +\n");
	read_car_voltage(&volt_val);
	IOBD_DEBUG_LEVEL4("get_ext_power_voltage volt_val %f -\n",volt_val);

	return volt_val;

}
int _pause_ ()
{
	int rc = 1;
	IOBD_DEBUG_LEVEL2 ("Function Paused!!!!!!!!!!!!!!!");
    while (libClient.init_connect == 0);
	IOBD_DEBUG_LEVEL2 ("Function Released!!!!!!!!!!!!!!!");
	return rc;

}


//int indicate_device_exit(pthread_t id)
int indicate_device_exit()
{
	int rc = 0;
	IOBD_DEBUG_LEVEL2("Waiting for thread to join \n");
	rc = pthread_join((libClient.tid[0]), NULL);
	IOBD_DEBUG_LEVEL2("Thread joined \n");
	return rc;
}

void server_connection_complete(void)
{
    check_protocol( 1 );
    
    if(libClient.check_raw_can == 1) {
        libClient.set_raw_can = 1;
        can_init(500000);
    }
    else
    {
        libClient.set_raw_can = 0;
    }
    libClient.init_connect = 1;
}
#ifdef __TIMER__
int config_wakeup_timer_trigger(bool enable, long secs)
{
        char enable_alarm[100];

        if(enable) {
                sprintf(enable_alarm, TIMER_WAKEUP_ALARM_ENABLE, secs);
                system(enable_alarm);
		IOBD_DEBUG_LEVEL2 ("Timer wakeup alarm of %lu enabled",secs);	
        }
        else {
                system(TIMER_WAKEUP_ALARM_DISABLE);
		IOBD_DEBUG_LEVEL2 ("Timer wakeup alarm disabled");	
        }

        return 0;
}
#endif
