#include "q_gps.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include "init.h"

int agps_init()
{
	int rc = 0; // need to replace the below system call and make as an api. this rc can be used during API mode

	system("/home/root/example -token aeu2IC0knkmvwWCvvXUYJQ -test online -p /dev/ttymxc2 -b 9600 -gnss gps/glo");
	
//	sleep (7);// Added as we are running agps in back ground so giving some delay to comeplete. it will take aprox 6s
	return rc;
}

int gps_init(void)
{
	int fd;
	if ((fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1)
	{
		IOBD_DEBUG_LEVEL2("Cannot open output file\r\n");
		exit(1);
	}

	return fd;
}

void gps_deinit()
{
	int ret = 0;
	if (libClient.gps_node_open == 1){
		tcflush(libClient.gps_fd,TCIOFLUSH);
		usleep (500000);//required to make flush work, for some reason
		ret = close(libClient.gps_fd);
		if (ret == OBD2_LIB_FAILURE)
			IOBD_DEBUG_LEVEL2 ("gps_deinit failed with %d :%d\n", libClient.gps_fd, errno);
	}
}

/*
   RMC,225446.33,A,4916.45,N,12311.12,W,000.5,054.7,191194,020.3,E,A*68
   225446.33    Time of fix 22:54:46 UTC
   A            Status of Fix A = Autonomous, valid; 
   D = Differential, valid; V = invalid
   4916.45,N    Latitude 49 deg. 16.45 min North
   12311.12,W   Longitude 123 deg. 11.12 min West
   000.5        Speed over ground, Knots
   054.7        Course Made Good, True north
   191194       Date of fix  19 November 1994
   020.3,E      Magnetic variation 20.3 deg East
   A            FAA mode indicator (NMEA 2.3 and later)
   A=autonomous, D=differential, E=Estimated,
   N=not valid, S=Simulator, M=Manual input mode
 *68          mandatory nmea_checksum

 * SiRF chipsets don't return either Mode Indicator or magnetic variation.
 */

int get_gps_rmc_data(char * rmc_nmea, size_t * g_nbytes)
{
	char char_read;
	char dummy_buf[500];
	size_t nbytes = 0;
	ssize_t bytes_read;
	int counter = 0;
	int rc = 0;
	char buf[200];

	memset(buf,'\0',sizeof(buf));

//	IOBD_DEBUG_LEVEL4 ("%s:gps_sem++",__func__);	
	sem_wait(&libClient.gps_sem);

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			IOBD_DEBUG_LEVEL2("Cannot open output file\r\n");
		}
		else{
			IOBD_DEBUG_LEVEL2 ("####libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			enable_gps_odo (); // to enable odo and disable VTG
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 500);
		}
	}
	while(1)
	{
		counter++;
		bytes_read = read(libClient.gps_fd, &char_read, 1);
		if (bytes_read == OBD2_LIB_FAILURE){
			rc = -errno;
			break;
		}
			
		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if( (strncmp(buf, "GNRMC", 5) == 0) )
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
					if(char_read == '*')
						break;
				}
				break;
			}
		}
	}	
	sem_post(&libClient.gps_sem);
//	IOBD_DEBUG_LEVEL4 ("%s:gps_sem--",__func__);	


	*g_nbytes = nbytes;
	strcpy(rmc_nmea,buf);
	return rc;
}


int get_gps_vlw_data(char * rmc_nmea, size_t * g_nbytes)
{
        char char_read;
        char dummy_buf[500];
        size_t nbytes = 0;
        ssize_t bytes_read;
        int counter = 0;
        int rc = 0;
        char buf[200];

        memset(buf,'\0',sizeof(buf));
//	IOBD_DEBUG_LEVEL2 ("%s:gps_sem++",__func__);	
	sem_wait(&libClient.gps_sem);

        if (libClient.gps_node_open == 0){
                //Dummy read to clear all the serial data initially
                if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
                        IOBD_DEBUG_LEVEL2("Cannot open output file\r\n");
                }
                else{
                        enable_gps_odo (); // to enable odo and disable VTG
                        IOBD_DEBUG_LEVEL2 ("####libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
                        libClient.gps_node_open = 1;
                        read(libClient.gps_fd, &dummy_buf, 500);
                }
        }
        while(1)
        {
                counter++;
                bytes_read = read(libClient.gps_fd, &char_read, 1);
                if (bytes_read == OBD2_LIB_FAILURE){
                        rc = -errno;
                        break;
                }

                if(char_read == '$'){
                        for(nbytes=0; nbytes<5;nbytes++){
                                read(libClient.gps_fd, &char_read,1);
                                *(buf+nbytes) = char_read;
                        }

                        if( (strncmp(buf, "GNVLW", 5) == 0) )
                        {
                                for(nbytes=5; char_read != '\n';nbytes++){
                                        read(libClient.gps_fd, &char_read,1);
                                        *(buf+nbytes) = char_read;
                                        if(char_read == '*')
                                                break;
                                }
                                break;
                        }
                }
        }

	sem_post(&libClient.gps_sem);
        *g_nbytes = nbytes;
        strcpy(rmc_nmea,buf);
        return rc;
}



int get_gps_gsv_data(char * gsv_nmea, size_t * g_nbytes)
{

	char char_read;
	char dummy_buf[8*1024];
	size_t nbytes;
	int counter = 0;
	int rc = 0;
	char buf[200] = {0};

	memset(buf,'\0',sizeof(buf));
//	IOBD_DEBUG_LEVEL2 ("%s:gps_sem++",__func__);	
	sem_wait(&libClient.gps_sem);

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			IOBD_DEBUG_LEVEL2("Cannot open output file\r\n");
		}
		else{
			enable_gps_odo (); // to enable odo and disable VTG
			IOBD_DEBUG_LEVEL2 ("####libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 8*1024);
		}
	}

	while(1)
	{
		counter++;
		read(libClient.gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if((strncmp(buf, "GPGSV", 5) == 0))
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
					if(char_read == '*')
						break;
				}
				break;
			}
		}
	}               
	sem_post(&libClient.gps_sem);
//	IOBD_DEBUG_LEVEL2 ("%s:gps_sem--",__func__);	

	*g_nbytes = nbytes;
	strcpy(gsv_nmea,buf);

	return rc; 
}

int get_gps_gga_data(char * gga_nmea, size_t * g_nbytes)
{
	char char_read;
	char dummy_buf[8*1024];
	size_t nbytes;
	int counter = 0;
	int rc = 0;
	char buf[200] = {0};

	memset(buf,'\0',sizeof(buf));
//	IOBD_DEBUG_LEVEL2 ("%s:gps_sem++",__func__);	
	sem_wait(&libClient.gps_sem);

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			IOBD_DEBUG_LEVEL2("Cannot open output file\r\n");
		}
		else{
			enable_gps_odo (); // to enable odo and disable VTG
			IOBD_DEBUG_LEVEL2 ("####libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 8*1024);
		}
	}

	while(1)
	{
		counter++;
		read(libClient.gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if((strncmp(buf, "GNGGA", 5) == 0))
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					if(char_read == '*')
						break;
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
				}
				break;
			}
		}
	}
	sem_post(&libClient.gps_sem);
//	IOBD_DEBUG_LEVEL2 ("%s:gps_sem--",__func__);	

	*g_nbytes = nbytes;
	strcpy(gga_nmea,buf);

	return rc;
}
#if 0
int get_gps_vtg_data(char * vtg_nmea, size_t * g_nbytes)
{
	char char_read;
	char dummy_buf[8*1024];
	size_t nbytes;
	int counter = 0;
	int rc = 0;
	char command[100] = {0};
	char buf[200] = {0};

	bzero(buf,sizeof(buf));
	sem_wait(&libClient.gps_sem);

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			IOBD_DEBUG_LEVEL2("Cannot open output file\r\n");
		}
		else{
			enable_gps_odo (); // to enable odo and disable VTG
			IOBD_DEBUG_LEVEL3("libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 8*1024);
		}
	}

	tcflush(libClient.gps_fd,TCIOFLUSH);

	while(1)
	{
		counter++;
		read(libClient.gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if((strncmp(buf, "GNVTG", 5) == 0))
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					if(char_read == '*')
						break;
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
				}
				break;
			}
		}
	}
	sem_post(&libClient.gps_sem);

	*g_nbytes = nbytes;
	memcpy(vtg_nmea, buf, nbytes);

	IOBD_DEBUG_LEVEL3("vtg_nmea buf %s nbytes %d \n",buf,nbytes);
	IOBD_DEBUG_LEVEL3("vtg_nmea %s g_nbytes %d \n",vtg_nmea,*g_nbytes);

	return rc;
}
#endif

int get_gps_gsa_data(char * gsa_nmea, size_t * g_nbytes)
{
	char char_read;
	char dummy_buf[8*1024];
	size_t nbytes;
	int counter = 0;
	int rc = 0;
	char buf[200] = {0};

	memset(buf,'\0',sizeof(buf));
//	IOBD_DEBUG_LEVEL2 ("%s:gps_sem++",__func__);	
	sem_wait(&libClient.gps_sem);

	if (libClient.gps_node_open == 0){
		//Dummy read to clear all the serial data initially
		if ((libClient.gps_fd = open("/dev/ttymxc2", O_RDWR | O_CREAT | O_TRUNC)) == -1){
			IOBD_DEBUG_LEVEL2 ("Cannot open output file\r\n");
		}
		else{
			enable_gps_odo (); // to enable odo and disable VTG
			IOBD_DEBUG_LEVEL2 ("####libClient.gps_fd in get_gps_data is  %d\n",libClient.gps_fd);
			libClient.gps_node_open = 1;
			read(libClient.gps_fd, &dummy_buf, 8*1024);
		}
	}

	while(1)
	{
		counter++;
		read(libClient.gps_fd, &char_read, 1);

		if(char_read == '$'){
			for(nbytes=0; nbytes<5;nbytes++){
				read(libClient.gps_fd, &char_read,1);
				*(buf+nbytes) = char_read;
			}

			if((strncmp(buf, "GNGSA", 5) == 0))
			{
				for(nbytes=5; char_read != '\n';nbytes++){
					if(char_read == '*')
						break;
					read(libClient.gps_fd, &char_read,1);
					*(buf+nbytes) = char_read;
				}
				break;
			}
		}
	}
	sem_post(&libClient.gps_sem);
//	IOBD_DEBUG_LEVEL2 ("%s:gps_sem--",__func__);	

	*g_nbytes = nbytes;
	strcpy(gsa_nmea, buf);

	return rc;
}

int enable_gps_odo ()
{
        int numberofbytesent, ret;
        int serial_fd;
//        const char car_profile[]= {0xb5,0x62,0x06,0x1e,0x14,0x00,0x00,0x00,0x00,0x00,0x01,0x03,0x00,0x00,0x19,0x46,0x19,0x56,0x0a,0x32,0x00,0x00,0x99,0x4c,0x00,0x00,0x3b,0xeb};
        const char car_profile[]= {0xb5,0x62,0x06,0x1e,0x14,0x00,0x00,0x00,0x00,0x00,0x01,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x0a,0x32,0x00,0x00,0x99,0x4c,0x00,0x00,0x5d,0x2d};//1st one
        const char vlw_enable[]= {0xb5,0x62,0x06,0x01,0x08,0x00,0xf0,0x0f,0x00,0x01,0x00,0x00,0x00,0x00,0x0f,0x91};
        const char vtg_disable[]= {0xb5,0x62,0x06,0x01,0x08,0x00,0xf0,0x05,0x00,0x00,0x00,0x00,0x00,0x00,0x04,0x46};

        serial_fd = libClient.gps_fd; 
	IOBD_DEBUG_LEVEL2 ("enable_gps_odo gps_fd is %d\n",serial_fd);
        if(serial_fd <= 0)
        {
                IOBD_DEBUG_LEVEL2 ("%s: iW_Serial_Init: failed %d\n",__func__, errno);
                return OBD2_LIB_FAILURE;
        }else{
                numberofbytesent = write (serial_fd, car_profile, sizeof(car_profile));
                usleep(500000);
                if(numberofbytesent <= 0)
                {
			IOBD_DEBUG_LEVEL2("enable_gps_odo : failed due to %d",errno);
                        ret = OBD2_LIB_FAILURE;
                }else{
                        ret = OBD2_LIB_SUCCESS;
                }
                numberofbytesent = write (serial_fd, vlw_enable, sizeof(vlw_enable));
		usleep(500000);
                if(numberofbytesent <= 0)
                {
			IOBD_DEBUG_LEVEL2("enable_gps_odo : failed due to %d",errno);
                        ret = OBD2_LIB_FAILURE;
                }else{
                        ret = OBD2_LIB_SUCCESS;
                }
                numberofbytesent = write (serial_fd, vtg_disable, sizeof(vtg_disable));
		usleep(500000);
                if(numberofbytesent <= 0)
                {
			IOBD_DEBUG_LEVEL2("enable_gps_odo : failed due to %d",errno);
                        ret = OBD2_LIB_FAILURE;
                }else{
                        ret = OBD2_LIB_SUCCESS;
                }
	}

        return ret;
}

#if 0
void enable_only_rmc()
{
	int rc = 0;
	IOBD_DEBUG_LEVEL2("inside enable_only_rmc\n");
	rc = system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x02\x00\x00\x00\x00\x00\x01\x02\x32"" > /dev/ttymxc2");//GSA
	if(rc < 0)
		IOBD_DEBUG_LEVEL2("GSA disable failed");
	system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x05\x00\x00\x00\x00\x00\x00\x04\x46"" > /dev/ttymxc2");//VTG
	if(rc < 0)
		IOBD_DEBUG_LEVEL2("VTG disable failed");
	system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x03\x00\x00\x00\x00\x00\x00\x02\x38"" > /dev/ttymxc2");//GSV
	if(rc < 0)
		IOBD_DEBUG_LEVEL2("GSV disable failed");
	system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x01\x00\x00\x00\x00\x00\x00\x00\x2A"" > /dev/ttymxc2");//GLL
	if(rc < 0)
		IOBD_DEBUG_LEVEL2("GLL disable failed");
	system("echo -e ""\xB5\x62\x06\x01\x08\x00\xF0\x00\x00\x00\x00\x00\x00\x00\xFF\x23"" > /dev/ttymxc2");//GGA
	if(rc < 0)
		IOBD_DEBUG_LEVEL2("GGA disable failed");

	IOBD_DEBUG_LEVEL3("exit enable_only_rmc\n");

}
#endif
