/* headers */
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/dir.h>
#include <linux/types.h>
#include <string.h>
#include <poll.h>
#include <endian.h>
#include <getopt.h>
#include <inttypes.h>
#include <math.h>
#include <semaphore.h>
#include "iio_utils.h"
#include "acc_ism330dlc.h"
#include "obd2lib.h"
#include <signal.h>
#include "init.h"
#include "pwr_mgmt.h"
#include <malloc.h>
#include"thread.h"


static int init_state = 0;
static struct iio_channel_info *channels; 
static int num_channels;
static accelerometer_api_priv adata;
static int acc_init_flag = 0;
static int event_no = 0;
int scan_size;
pthread_t acc_thread_id;
sem_t acc_lock;
static char event_file[72];
static int interrupt;
void process_scan_acc(char *, struct iio_channel_info *, int);
void print2byte_acc(int, struct iio_channel_info *, int);

void signal_h(int signo)
{
	interrupt = 1;
	IOBD_DEBUG_LEVEL2 ("acc:interrupt received !!!!\n");
        //pthread_exit(NULL);;
}

int acc_sensor_init()
{
	int ret;

	event_no = get_gpio_event(ACC_MAIN_PATH, ACC_EVENT_NAME);	

	sprintf (event_file, "%s%d%s", ACC_MAIN_PATH, event_no, ACC_SUB_PATH_SCAN);
	IOBD_DEBUG_LEVEL4 ("1.event_file : %s",event_file);

	/*!< Acclerometer x-axis interupt enable*/
	ret = write_sysfs_int (ACC_INTERRUPT_X_AXIS, event_file, ENABLE);
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("1.acc_init: ret %d",ret);
		init_state = 0;
		return ret;
	}
	/*!< Acclerometer y-axis interupt enable*/
	ret = write_sysfs_int (ACC_INTERRUPT_Y_AXIS, event_file, ENABLE);
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("2.acc_init: ret %d",ret);
		init_state = 0;
		return ret;
	}
	/*!< Acclerometer z-axis interupt enable*/
	ret = write_sysfs_int (ACC_INTERRUPT_Z_AXIS, event_file, ENABLE);
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("3.acc_init: ret %d",ret);
		init_state = 0;
		return ret;
	}
	bzero (event_file, sizeof (event_file));
	sprintf (event_file, "%s%d",ACC_MAIN_PATH,event_no);

	IOBD_DEBUG_LEVEL4 ("2.event_file : %s",event_file);

	ret = build_channel_array (event_file, &channels, &num_channels);	
	if (ret != OBD2_LIB_SUCCESS){
                IOBD_DEBUG_LEVEL2 ("2.acc_init: ret %d",ret);
		init_state = 0;
                return ret;
        }
	scan_size = size_from_channelarray (channels, num_channels);

	bzero (event_file, sizeof (event_file));
	sprintf (event_file, "%s%d%s",ACC_MAIN_PATH, event_no, ACC_SUB_PATH_BUF);

	IOBD_DEBUG_LEVEL4 ("3.event_file : %s",event_file);

        /* Enable the buffer */
        ret = write_sysfs_int (ACC_BUFFER_ENABLE, event_file, ENABLE);

	/*!< switch ON Acc in high performance mode (416Hz) */
        system("i2cset -f -y 1 0x6a 0x10 0x60");
	
	/* Enable data ready interrupt*/
	system("i2cset -f -y 1 0x6a 0x0d 0x01");

	/*!< Motion Detection Configuration */
	system("i2cset -f -y 1 0x6a 0x58 0x0e");/*disable acc interrupt*/
	system("i2cset -f -y 1 0x6a 0x59 0x89");
	system("i2cset -f -y 1 0x6a 0x5A 0x06");
	system("i2cset -f -y 1 0x6a 0x5B 0x00");
	system("i2cset -f -y 1 0x6a 0x5E 0x40");

	if (sem_init(&acc_lock, 0, 1) == -1){
                IOBD_DEBUG_LEVEL2("Sem Create Failed\r\n");
	}
	
	if (acc_init_flag == 0){
		if((pthread_create(&(acc_thread_id), NULL, (void *) accelerometer_read_thread, NULL))!= 0) {
                        IOBD_DEBUG_LEVEL2 ("pthread_create for accelerometer_read_thread failed\n");
                        return OBD2_LIB_FAILURE;
                }
		else{
			IOBD_DEBUG_LEVEL2 ("Accelerometer thread created successfully");
			if (pthread_detach (acc_thread_id) != OBD2_LIB_SUCCESS)
				IOBD_DEBUG_LEVEL2 ("accelerometer_read_thread :pthread_detach failed %d",errno);
			acc_init_flag = 1;
			init_state = 1;
		}
	}
	return ret;
}

int acc_init()
{
	int rc = 0;
	/* Enable data ready interrupt*/
        rc = system("i2cset -f -y 1 0x6a 0x0d 0x01");
	/*disable acc interrupt*/
	rc = system("i2cset -f -y 1 0x6a 0x58 0x0e");
	
	return rc;
}

int acc_deinit()
{
	int ret = 0;

	IOBD_DEBUG_LEVEL4 ("acc_deinit +");
	if (acc_init_flag == 1 && init_state == 1){
		/* Disable data ready interrupt of Accelerometer*/
		ret = system("i2cset -f -y 1 0x6a 0x0d 0x00");
//		ret = sem_destroy (&acc_lock);
		IOBD_DEBUG_LEVEL2 ("acc_deinit %d",ret);
	}

	return ret;
}

void accelerometer_read_thread (void)
{
	int ret;
	char *buffer_access;
	unsigned long buf_len = 128;
	int fp, i = 0;
	int toread;
	int retval;
	fd_set rdfs;
	ssize_t read_size;
	char *data;
	float volt;
	struct ign_stat ign_qdata;
	char ts[64] = {0};

	data = malloc(scan_size*buf_len);
	if (!data) {
		ret = -ENOMEM;
		goto exit_thread;
	}

	ret = asprintf(&buffer_access, "/dev/iio:device%d", event_no);
	if (ret < 0) {
		ret = -ENOMEM;
	}else{

		toread = buf_len;

		/* Attempt to open non blocking the access dev */
		fp = open(buffer_access, O_RDONLY | O_NONBLOCK);
		if (fp == OBD2_LIB_FAILURE) { /* If it isn't there make the node */
			IOBD_DEBUG_LEVEL2("Failed to open %s\n", buffer_access);
			ret = -errno;
			free (buffer_access);
			if (malloc_trim(0) == 0)
                        IOBD_DEBUG_LEVEL2 ("accelerometer_read_thread1: Not possible to release any memory");
		}
		else{
			IOBD_DEBUG_LEVEL4 ("####Accelerometer thread fp = %d\n",fp);
			free (buffer_access);
			if (malloc_trim(0) == 0)
                        IOBD_DEBUG_LEVEL2 ("accelerometer_read_thread2: Not possible to release any memory");

			FD_ZERO(&rdfs);
			FD_SET(fp, &rdfs);

			while(1) {
				if (interrupt == 1){
					interrupt = 0;
					break;
				}
				retval = select(fp + 1 , &rdfs, NULL, NULL, NULL);

				if(retval) {
					if(libClient.dev_sleep == DEV_SLEEP) {
						IOBD_DEBUG_LEVEL2("****************DATA READY INTERRUPT RECEIVED***********************\r\n");
						config_wakeup_timer_trigger(TIMER_DISABLE, 0);
#if 1
						sem_wait (&libClient.acc_key_thread_lock);
						IOBD_DEBUG_LEVEL2 ("acc_lock +\n");
#endif
						libClient.dev_sleep = DEV_WAKE;
						read_car_voltage(&volt);
						if (volt > 24.0)
							read_car_voltage(&volt);
						if (volt > 4.0 && libClient.system_wake_timer == 0){
							libClient.system_wake_acc = 1;
#if 1
							sem_post (&libClient.acc_key_thread_lock);
							IOBD_DEBUG_LEVEL2 ("acc_lock -\n");
#endif
							config_sleep_wake_trigger_off();
							memset(ign_qdata.data,0,sizeof(ign_qdata.data));
							get_time(ts);
							memset(ign_qdata.data,0x0,256);
							ign_qdata.msg_type = PM_EVENT_ACCEL_WAKE;
							strcpy(ign_qdata.data,ts);
							ret = send_ign_q(&libClient,&ign_qdata);
						}
						else {
#if 1
							if (libClient.system_wake_timer == 1){
								sem_post (&libClient.acc_key_thread_lock);
								obd_reset();
								obd_reset();
								obd_reset();
							}
                            else
                            {
                                sem_post (&libClient.acc_key_thread_lock);                                
                            }
							libClient.dev_sleep = DEV_SLEEP;
#endif
						}
					}

					read_size = read(fp, data, toread*scan_size);
					if (read_size == -EAGAIN) {
						IOBD_DEBUG_LEVEL2("nothing available\n");
						continue;
					}
					for (i = 0; i < read_size/scan_size; i++){
						sem_wait (&acc_lock);
						process_scan_acc (data + scan_size * i, channels, num_channels);
						sem_post (&acc_lock);
					}
				}

				usleep (300000); 
				FD_ZERO(&rdfs);
				FD_SET(fp, &rdfs);
			}

			close(fp);
		}
	}
	if (data){
		free (data);
		if (malloc_trim(0) == 0)
			IOBD_DEBUG_LEVEL2 ("accelerometer_read_thread3: Not possible to release any memory");
	}
exit_thread:
	IOBD_DEBUG_LEVEL2("accelerometer_read_thread Exits %d\n",ret);
	/* NaND : adata must be of type accelerometer_api_priv. dont use char buffer */
}

/**
 * process_scan() - print out the values in SI units
 * @data:               pointer to the start of the scan
 * @channels:           information about the channels. Note
 *  size_from_channelarray must have been called first to fill the
 *  location offsets.
 * @num_channels:       number of channels
 **/
void process_scan_acc(char *data, struct iio_channel_info *channels, int num_channels)
{
        int k;
        int channel_num;

        for (k = 0; k < num_channels; k++){
                switch (channels[k].bytes) {
                        /* only a few cases implemented so far */
                case 2:
                        channel_num = k;
                        print2byte_acc (*(uint16_t *)(data + channels[k].location),
                                   &channels[k], channel_num);
                        break;
                case 4:
                        if (!channels[k].is_signed) {
                                uint32_t val = *(uint32_t *)
                                        (data + channels[k].location);
                                IOBD_DEBUG_LEVEL2("%05f ", ((float)val +
                                                 channels[k].offset)*
                                       channels[k].scale);

                        }
                        break;
                case 8:
                        if (channels[k].is_signed) {
                                int64_t val = *(int64_t *)
                                        (data +
                                         channels[k].location);
                                if ((val >> channels[k].bits_used) & 1)
                                        val = (val & channels[k].mask) |
						~channels[k].mask;
                                /* special case for timestamp */
                                if (channels[k].scale == 1.0f &&
                                    channels[k].offset == 0.0f){
                                        IOBD_DEBUG_LEVEL2("%" PRId64 " ", val);
				}else{
                                        IOBD_DEBUG_LEVEL2("%05f ", ((float)val + channels[k].offset)*channels[k].scale);
				}
                        }
                        break;
                default:
                        break;
                }
	}
}

void print2byte_acc(int input, struct iio_channel_info *info, int channel_num)
{
        float final_val;
        /* First swap if incorrect endian */
        if (info->be)
                input = be16toh((uint16_t)input);
        else
                input = le16toh((uint16_t)input);

        /*
         * Shift before conversion to avoid sign extension
         * of left aligned data
         */
        input = input >> info->shift;
        if (info->is_signed) {
                int16_t val = input;
                val &= (1 << info->bits_used) - 1;
                val = (int16_t)(val << (16 - info->bits_used)) >>
                        (16 - info->bits_used);
                final_val = (float)(val + info->offset)*info->scale;
                IOBD_DEBUG_LEVEL4("%05f ", ((float)val + info->offset)*info->scale);
        } else {
                uint16_t val = input;
                val &= (1 << info->bits_used) - 1;
                IOBD_DEBUG_LEVEL4("%05f ", ((float)val + info->offset)*info->scale);
                final_val = ((float)val + info->offset)*info->scale;
        }
        if(channel_num == 0)
                adata.x = (double) final_val;
        if(channel_num == 1)
                adata.y = (double) final_val;
        if(channel_num == 2){
                adata.z = (double) final_val;
                adata.acc = sqrt((adata.x * adata.x) + (adata.y * adata.y) + (adata.z * adata.z));
                IOBD_DEBUG_LEVEL4 ("x: %05f, y: %05f, z: %05f, acc: %05f\r\n", adata.x, adata.y, adata.z, adata.acc);
        }
}

int get_accelerometer (accelerometer_api_priv *acc)
{
	if (acc == NULL){
		IOBD_DEBUG_LEVEL2 ("Not valid argument");
		return OBD2_LIB_FAILURE;	
	}	
	sem_wait (&acc_lock);
	acc -> x = adata.x;
	acc -> y = adata.y;
	acc -> z = adata.z;
	acc -> acc = adata.acc;
	sem_post (&acc_lock);
	IOBD_DEBUG_LEVEL2("Accelerometer value: x : %f y: %f z: %f acc: %f",acc -> x, acc -> y, acc -> z,acc -> acc);	
	IOBD_DEBUG_LEVEL2("acceleration : %lf\n",acc -> acc - 9.8);
	return OBD2_LIB_SUCCESS;
}
