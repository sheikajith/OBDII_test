#include <stdio.h>
#include <stdlib.h>
#include "4g.h"
#include "q_gps.h"
#include "init.h"
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include "obd2lib.h"
#include "pwr_mgmt.h"
#include "err_macro.h"
#include <stdbool.h>

static int flight_on;

int sem_init_3g (const char *sem_name, unsigned int value)
{

        libClient.acm_node = sem_open(sem_name, O_CREAT | O_EXCL, 0777, value);
	if (libClient.acm_node == SEM_FAILED){
		libClient.acm_node = sem_open(sem_name, O_CREAT, 0777, value);
        	if (libClient.acm_node == SEM_FAILED){
			IOBD_DEBUG_LEVEL4 ("Error in creating semaphone file with %d\n",errno);
                        return OBD2_LIB_FAILURE;
		}

	}
	return OBD2_LIB_SUCCESS;
}

int get_imei_modem(char *imei_no)
{
	char val[20];
	int numberofbytesent, numberofbytesrcvd;
	int rc = OBD2_LIB_SUCCESS;

	IOBD_DEBUG_LEVEL1("acm w+ \n");
	sem_wait(libClient.acm_node);
	IOBD_DEBUG_LEVEL2("acm w- \n");
#ifdef _SERIAL_FD_
	libClient.serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(libClient.serial_fd <= 0)
	{
		IOBD_DEBUG_LEVEL4 ("get_imei_modem: iW_Serial_Init: failed\n");

		IOBD_DEBUG_LEVEL3("acm fp+ \n");
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL3("acm fp- \n");

		return OBD2_LIB_FAILURE;
	}
#endif
	bzero (imei_no,20);
	memset(val, 0x0, 20);
	numberofbytesent = write (libClient.serial_fd, DISABLE_ECHO, strlen(DISABLE_ECHO));
	if(numberofbytesent <= 0)
	{
		perror("get_imei_modem");
		IOBD_DEBUG_LEVEL3("errno = %d, serial_fd %d\r\n",errno, libClient.serial_fd);
		rc = OBD2_LIB_FAILURE;
	}
	usleep(1000000);
	numberofbytesrcvd = read(libClient.serial_fd, val, 20);
	if(numberofbytesrcvd <= 0)
	{
		perror("get_imei_modem_read");
		IOBD_DEBUG_LEVEL3("errno = %d \r\n",errno);
		rc = OBD2_LIB_FAILURE;
	}

	memset(val, 0x0, 20);
send_again:numberofbytesent = write (libClient.serial_fd , IMEI_GET_CMD, strlen(IMEI_GET_CMD));
	if(numberofbytesent <= 0)
	{
		perror("get_imei_modem_write");
		IOBD_DEBUG_LEVEL3("errno = %d, serial_fd %d\r\n",errno, libClient.serial_fd);
		rc= OBD2_LIB_FAILURE;
	}
	usleep(1000000);
	numberofbytesrcvd = read(libClient.serial_fd, val, 20);
	if(numberofbytesrcvd <= 0)
	{
		perror("get_imei_modem_read");
		IOBD_DEBUG_LEVEL3("errno = %d \r\n",errno);
		rc = OBD2_LIB_FAILURE;
	}

	strncpy(imei_no, &val[2], 15);
	if ((imei_no[1] != '6') && (imei_no[0] != '8'))
		goto send_again;

	IOBD_DEBUG_LEVEL3("imei_no:%s\r\n", imei_no);
	memset(val, 0x0, 20);
#ifdef _SERIAL_FD_
	close(libClient.serial_fd);
#endif
	IOBD_DEBUG_LEVEL3("acm p+ \n");
	sem_post(libClient.acm_node);
	IOBD_DEBUG_LEVEL4("%s:acm p- \n",__func__);

	return rc;
}

int check_connection()
{
	return libClient.ppp0_link_status;
}

int flight_mode()
{

	char val[300];
	int numberofbytesent;
	int rc = 0;

	IOBD_DEBUG_LEVEL3 ("Entered Flight mode\n");
	IOBD_DEBUG_LEVEL3 ("acm w+ \n");
	sem_wait(libClient.acm_node);
	IOBD_DEBUG_LEVEL1 ("acm w- \n");

	if (flight_on != 1){
#ifdef _SERIAL_FD_
		libClient.serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
		if(libClient.serial_fd <= 0)
		{
			IOBD_DEBUG_LEVEL3 ("flight_mode: iW_Serial_Init: failed\n");
			IOBD_DEBUG_LEVEL3 ("acm fp+ \n");
			sem_post(libClient.acm_node);
			IOBD_DEBUG_LEVEL1 ("acm fp- \n");
			return OBD2_LIB_FAILURE;

		}
#endif
		memset(val, 0x0, 200);
		numberofbytesent = write (libClient.serial_fd, FLIGHT_MODE_EN, strlen(FLIGHT_MODE_EN));
		if(numberofbytesent <= 0)
		{
			perror("flight_mode_write");
			IOBD_DEBUG_LEVEL3 ("errno = %d, serial_fd %d\r\n",errno, libClient.serial_fd);
			rc = OBD2_LIB_FAILURE;
			goto exit;
		}
		usleep (500000);
		memset(val, 0x0, 200);
		numberofbytesent = write (libClient.serial_fd, FLIGHT_MODE_DIS, strlen(FLIGHT_MODE_DIS));
		if(numberofbytesent <= 0)
		{
			perror("flight_mode_write");
			IOBD_DEBUG_LEVEL3 ("errno = %d, serial_fd %d\r\n",errno, libClient.serial_fd);
			rc = OBD2_LIB_FAILURE;
		}
		while(1){
			if (access("/dev/ttyUSB4",F_OK))
				break;
                        read(libClient.serial_fd, val,20);
//                        IOBD_DEBUG_LEVEL4("response after module on\n res = %s\n",val);
                        if (strstr (val,"CPIN")){
                                if (strstr(val,"READY")){
                                        set_xml_content (SRC_XML_FILE, "gsm_gprs", "sim_status","1");
 //                                       IOBD_DEBUG_LEVEL4 ("sim status READY\n");
                                }
                                else if (strstr(val,"NOT")){
                                        set_xml_content (SRC_XML_FILE, "gsm_gprs", "sim_status","0");
                                        set_xml_content (SRC_XML_FILE, "gsm_gprs", "network_status","0");
                                        IOBD_DEBUG_LEVEL2 ("sim status NOT INSERTED\n");
                                        rc = -2;
                                        break;
                                }
                        }
                        if (strstr(val,"PB DONE"))
                                break;
        	}

#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
	}
exit:
	IOBD_DEBUG_LEVEL4 ("acm p+ \n");
	sem_post(libClient.acm_node);
	IOBD_DEBUG_LEVEL4 ("acm p- \n");

	return rc;
}

int flight_mode_on()
{
	int rc = 0,numberofbytesent;

	IOBD_DEBUG_LEVEL3 ("Entered Flight mode_on\n");
	IOBD_DEBUG_LEVEL3 ("acm w+ \n");
	sem_wait(libClient.acm_node);
	IOBD_DEBUG_LEVEL4 ("acm w- \n");

#ifdef _SERIAL_FD_
	libClient.serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(libClient.serial_fd <= 0)
	{
		IOBD_DEBUG_LEVEL3 ("flight_mode_on: iW_Serial_Init: failed\n");
		IOBD_DEBUG_LEVEL3 ("acm fp+ \n");
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL1 ("acm fp- \n");
		return OBD2_LIB_FAILURE;

	}
#endif

	numberofbytesent = write (libClient.serial_fd, FLIGHT_MODE_EN, strlen(FLIGHT_MODE_EN));
	if(numberofbytesent <= 0)
	{
		perror("flight_mode_on_write");
		IOBD_DEBUG_LEVEL3 ("errno = %d, serial_fd %d\r\n",errno, libClient.serial_fd);
		rc = -1;
		goto exit;
	}

	flight_on = 1;
exit:
#ifdef _SERIAL_FD_
	close(libClient.serial_fd);
#endif
	IOBD_DEBUG_LEVEL3 ("acm p+ \n");
	sem_post(libClient.acm_node);
	IOBD_DEBUG_LEVEL1 ("acm p- \n");

	return rc;
}

int flight_mode_off()
{

	int rc = 0,numberofbytesent;

	IOBD_DEBUG_LEVEL3 ("Entered Flight mode_off\n");
	IOBD_DEBUG_LEVEL3 ("acm w+ \n");
	sem_wait(libClient.acm_node);
	IOBD_DEBUG_LEVEL1 ("acm w- \n");

#ifdef _SERIAL_FD_
	libClient.serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(libClient.serial_fd <= 0)
	{
		IOBD_DEBUG_LEVEL3 ("flight_mode_off: iW_Serial_Init: failed\n");
		IOBD_DEBUG_LEVEL1 ("acm fp+ \n");
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL3 ("acm fp- \n");
		return OBD2_LIB_FAILURE;

	}
#endif
	numberofbytesent = write (libClient.serial_fd, FLIGHT_MODE_DIS, strlen(FLIGHT_MODE_DIS));
	if(numberofbytesent <= 0)
	{
		perror("flight_mode_off_write");
		IOBD_DEBUG_LEVEL3 ("errno = %d, serial_fd %d\r\n",errno, libClient.serial_fd);
		rc = OBD2_LIB_FAILURE;
		goto exit;
	}

	flight_on = 0;
	
exit:
#ifdef _SERIAL_FD_
	close(libClient.serial_fd);
#endif
	IOBD_DEBUG_LEVEL3 ("acm p+ \n");
	sem_post(libClient.acm_node);
	IOBD_DEBUG_LEVEL1 ("acm p- \n");

	return rc;
}

int module_3g_on()
{
	int ret = OBD2_LIB_SUCCESS;

	/*!< P4V4 Switch*/
	ret = set_gpio_value(REG_4V4, GPIO_HIGH);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("REG_4V4 on Failed %d",ret);
	usleep (500000);
	/*!< USB power Switch */
	ret = set_gpio_value(MODEM_USB_SWITCH, GPIO_HIGH);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("3G module USB_SWITCH set Failed with %d",ret);
	usleep (10000);
	ret = set_gpio_value(MODEM_PWRKEY, GPIO_HIGH);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("3G module PWRKEY set Failed with %d",ret);

	usleep (500000);
	ret = set_gpio_value(MODEM_PWRKEY, GPIO_LOW);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("3G module PWRKEY set Failed with %d",ret);
	usleep (800000);
	ret = set_gpio_value(MODEM_PWRKEY, GPIO_HIGH);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("3G module PWRKEY set Failed with %d",ret);
	sleep(2);// required to perform insmod properly: /*peru*/

	system ("insmod /usb/udc-core.ko");
	system ("insmod /usb/libcomposite.ko");
	system ("insmod /usb/ci_hdrc.ko");
	system ("insmod /usb/usbmisc_imx.ko");
	system ("insmod /usb/ci_hdrc_imx.ko");
	system ("insmod /usb/u_serial.ko");
	system ("insmod /usb/usb_f_serial.ko");
	system ("insmod /usb/usb_f_acm.ko");
	system ("insmod /usb/g_serial.ko");

	return ret;
}

int module_3g_off()
{
	int ret = 0;
	int count = 1;

	libClient.mod_init = 0;//stopping link_status_thread to run pppd.
	/* make 3g module off */
	ret = system ("ifconfig ppp0 down");
	if (ret != OBD2_LIB_SUCCESS)
		perror ("3g_off_system");
	ret = system ("killall pppd");
	if (ret != OBD2_LIB_SUCCESS)
		perror ("3g_off_pppd");
	ret = tcflush(libClient.serial_fd, TCIOFLUSH);
	if (ret != OBD2_LIB_SUCCESS)
		perror ("tcflush");
	usleep(100000);
	system ("killall SOTA_APP");

	ret = close(libClient.serial_fd);
	if (ret != OBD2_LIB_SUCCESS)
		perror ("3g_off_close");

	system ("killall application");
        ret = system ("rmmod g_serial");
        ret = system ("rmmod usb_f_acm");
        ret = system ("rmmod usb_f_serial");
        ret = system ("rmmod u_serial");
        ret = system ("rmmod ci_hdrc_imx");
        ret = system ("rmmod usbmisc_imx");
        ret = system ("rmmod ci_hdrc");
        ret = system ("rmmod libcomposite");
	ret = system ("rmmod udc-core");
	ret = set_gpio_value(MODEM_PWRKEY, GPIO_HIGH);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("3G module PWRKEY set Failed with %d",ret);
	usleep(300000);
	ret = set_gpio_value(MODEM_PWRKEY, GPIO_LOW);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("3G module PWRKEY set Failed with %d",ret);
	sleep(1);
	ret = set_gpio_value(MODEM_PWRKEY, GPIO_HIGH);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("3G module PWRKEY set Failed with %d",ret);

	/* wait for 30 secs during turning off 4g module */
	//	count = 15;
	/* NaN : check on status every second */
	while(1){
		sleep(1);
		IOBD_DEBUG_LEVEL4 ("While Sleep count %d\n",count);
		count++;
		if((count == 10) || (access("/dev/ttyUSB4",F_OK)))//before 30
			break;

	}
	/*!< USB power Switch */
        ret = set_gpio_value(MODEM_USB_SWITCH, GPIO_LOW);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("3G module USB_SWITCH off Failed with %d",ret);

	usleep (100000);
	/*!< P4V4 Switch*/
        ret = set_gpio_value(REG_4V4, GPIO_LOW);
        if (ret != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("REG_4V4 off Failed %d",ret);

	if (clear_cache(1))	
		IOBD_DEBUG_LEVEL2("clear_cache level1 failed")
	return ret;
}

int get_3g_fd ()
{
	if (libClient.serial_fd > 2)
		return libClient.serial_fd;
	else
		return OBD2_LIB_FAILURE;
}
int check_registration()
{
	/*commented for R2.0*/
	bool flag = 0;
	int ret = 0;
	char val[300];
	char imei[20];
	struct timespec time_out;
    struct timeval start_modem_on, end_modem_on;
    int duration_modem_on = 0;

	if (clock_gettime(CLOCK_REALTIME, &time_out) == -1)
                IOBD_DEBUG_LEVEL2 ("clock_gettime error");
        time_out.tv_sec += 1;

	IOBD_DEBUG_LEVEL3 ("acm w+ \n");
    sem_timedwait(libClient.acm_node, &time_out);
	IOBD_DEBUG_LEVEL2 ("%s:acm w- \n",__func__);

	libClient.serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(libClient.serial_fd <= 0)
	{
		IOBD_DEBUG_LEVEL2 ("%s:iW_Init: iW_Serial_Init: failed\n",__func__);
		IOBD_DEBUG_LEVEL3 ("acm fp+ \n");
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL3 ("acm fp- \n");

		return OBD2_LIB_FAILURE;
	}

    gettimeofday(&start_modem_on, NULL);

    while(1){
        gettimeofday(&end_modem_on, NULL);	
        duration_modem_on = ((end_modem_on.tv_usec-start_modem_on.tv_usec)+(end_modem_on.tv_sec-start_modem_on.tv_sec)*1000000)/1000000;

        ret = read(libClient.serial_fd, val,20);
        IOBD_DEBUG_LEVEL4("response after module on res = %s and ret = %d\n",val, ret );
        if (strstr (val,"CPIN")){
            if (strstr(val,"READY")){
                set_xml_content (SRC_XML_FILE, "gsm_gprs", "sim_status","1");
                IOBD_DEBUG_LEVEL3 ("sim status READY\n");
            }
            else if (strstr(val,"NOT")){
                set_xml_content (SRC_XML_FILE, "gsm_gprs", "sim_status","0");
                set_xml_content (SRC_XML_FILE, "gsm_gprs", "network_status","0");
                IOBD_DEBUG_LEVEL2 ("sim status NOT INSERTED\n");
                flag = 1;
                break;
            }
        }		
        if (strstr(val,"PB DONE"))
            break;

        if( duration_modem_on > 10 )
        {
            break;
        }
    }
#ifdef _SERIAL_FD_
	close(libClient.serial_fd);//this is commented to keep iW_Serial_init in one place and use the fd in other api's
#endif
	IOBD_DEBUG_LEVEL3 ("acm p+ \n");
	sem_post(libClient.acm_node);
	IOBD_DEBUG_LEVEL1 ("acm p- \n");
	ret = get_imei_modem (imei);
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("get_imei_modem failed %d\n",ret);
	if (flag)
		ret = -2;
        set_xml_content (SRC_XML_FILE, PARENT_NODE_HOME, CHILD_NODE_IMEI, imei);
        set_xml_content (DFL_SRC_XML_FILE, PARENT_NODE_HOME, CHILD_NODE_IMEI, imei);
        set_xml_content (SRC_XML_FILE, PARENT_NODE_CLOUD, CHILD_NODE_DEVICE_ID, imei);
//        set_xml_content (SRC_XML_FILE, PARENT_NODE_CLOUD, CHILD_NODE_DEVICE_ID, "001");
	return ret;
}

int get_sim_id(char *sim_id)
{
	char * sim_id_ptr;
	char temp_str[32]={0};
	char val[64] = {0};
//	char val[100] = {0};
	int numberofbytesent, numberofbytesrcvd;

	IOBD_DEBUG_LEVEL3("get_sim_id + \n");

	IOBD_DEBUG_LEVEL3("acm w+ \n");
	sem_wait(libClient.acm_node);
	IOBD_DEBUG_LEVEL2("%s: %d acm w- \n",__func__,__LINE__);
#ifdef _SERIAL_FD_
	libClient.serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,115200);
	if(libClient.serial_fd <= 0)
	{
		IOBD_DEBUG_LEVEL3 ("get_sim_id: iW_Serial_Init: failed\n");
		IOBD_DEBUG_LEVEL3("%s:%d acm fp+ \n",__func__, __LINE__);
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL4("%s:%d acm fp- \n",__func__, __LINE__);
		return OBD2_LIB_FAILURE;
	}
#endif
	memset(val, 0x0, sizeof( val ));
	numberofbytesent = write (libClient.serial_fd, DISABLE_ECHO, strlen(DISABLE_ECHO));
	if(numberofbytesent <= 0)
	{
		IOBD_DEBUG_LEVEL3("%s:%d acm fp+ \n",__func__, __LINE__);
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL4("%s:%d acm fp- \n",__func__, __LINE__);
		return OBD2_LIB_FAILURE;
	}
	usleep(500000);
	numberofbytesrcvd = read(libClient.serial_fd, val, sizeof( val )); 
	if(numberofbytesrcvd <= 0)
	{
		perror("get_sim_id_read");
		IOBD_DEBUG_LEVEL3("errno = %d \r\n",errno);
	}

	memset(val, 0x0, sizeof( val ));
	numberofbytesent = write (libClient.serial_fd , SIM_ID_CMD, strlen(SIM_ID_CMD));
	if(numberofbytesent <= 0)
	{
		perror("get_sim_id_write");
		IOBD_DEBUG_LEVEL3("errno = %d, serial_fd %d\r\n",errno, libClient.serial_fd);
	}
	usleep(500000);
	numberofbytesrcvd = read(libClient.serial_fd, val, sizeof( val ));
	if(numberofbytesrcvd <= 0)
	{
		perror("get_sim_id_read");
		IOBD_DEBUG_LEVEL3("errno = %d \r\n",errno);
	}
	else{
		sim_id_ptr = strtok(val, ":");
		sim_id_ptr = strtok(NULL, "\n");

		strcpy(temp_str,sim_id_ptr+1);
		strncpy(sim_id,temp_str,strlen(temp_str)-1);
		IOBD_DEBUG_LEVEL3("sim_id_ptr: %s\r\n", sim_id_ptr);
		IOBD_DEBUG_LEVEL3("sim_id: %s\r\n", sim_id);
	}
	memset(val, 0x0, sizeof( val ));
#ifdef _SERIAL_FD_
	close(libClient.serial_fd);
#endif
	IOBD_DEBUG_LEVEL3("acm p+ \n");
	sem_post(libClient.acm_node);
	IOBD_DEBUG_LEVEL4("%s:acm p- \n",__func__);
	IOBD_DEBUG_LEVEL3("get_sim_id iccid %s \n",sim_id);
	return OBD2_LIB_SUCCESS;
}

int set_cell_network_mode (int type)
{
	char val [64];	
	int ret;

	IOBD_DEBUG_LEVEL3("acm w+");
        sem_wait(libClient.acm_node);
        IOBD_DEBUG_LEVEL4("%s:acm w-",__func__);
#ifdef _SERIAL_FD_
	if(access(USB_2,F_OK)){
                IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
                sem_post(libClient.acm_node);
                return E_4G_USB_DISCONNECT;
        }
	else{
		libClient.serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,TTYUSB2_BAUD);
		if(libClient.serial_fd <= 0)
		{
			IOBD_ERR("Ret_Val: %d Lib_Err_no: 0x%x\r\n", libClient.serial_fd, E_4G_USB_INIT);
			IOBD_DEBUG_LEVEL3("acm fp+");
			sem_post(libClient.acm_node);
			IOBD_DEBUG_LEVEL4("%s:acm fp- \n",__func__);
			return E_4G_USB_INIT;
		}
	}
#endif
	memset(val, 0x0, sizeof(val));
	if(access(USB_2,F_OK)){
		IOBD_DEBUG_LEVEL3("ttyUSB2 is removed %d",__LINE__);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		IOBD_DEBUG_LEVEL3("acm fp+");
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL4("%s:acm p- \n",__func__);
		return E_4G_USB_DISCONNECT;
	}
	else{
		ret = iW_Serial_Write (libClient.serial_fd, DISABLE_ECHO, strlen(DISABLE_ECHO));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			IOBD_DEBUG_LEVEL3("acm fp+");
			sem_post(libClient.acm_node);
			IOBD_DEBUG_LEVEL4("%s:acm fp- \n",__func__);
			return E_4G_USB_WRITE;
		}
		else
			IOBD_DEBUG_LEVEL3("iW_Serial_Write : ret = %d",ret);
		usleep(500000);
		if (ret == OBD2_LIB_SUCCESS){
			if(access(USB_2,F_OK)){
				IOBD_DEBUG_LEVEL3("ttyUSB2 is removed %d",__LINE__);
#ifdef _SERIAL_FD_
				close(libClient.serial_fd);
#endif
				IOBD_DEBUG_LEVEL3("acm fp+");
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4("%s:acm fp- \n",__func__);
				return E_4G_USB_DISCONNECT;
			}
			ret = iW_Serial_Read (libClient.serial_fd, val, sizeof(val));
			if (ret != OBD2_LIB_SUCCESS){
#ifdef _SERIAL_FD_
				close(libClient.serial_fd);
#endif
				IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
				IOBD_DEBUG_LEVEL3("acm fp+");
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4("%s:acm fp- \n",__func__);
				return E_4G_USB_READ;
			}
			else
				IOBD_DEBUG_LEVEL3("iW_Serial_Read: buf : %s",val);
		}
	}
	memset(val, 0x0, sizeof(val));
	if(access(USB_2,F_OK)){
		IOBD_DEBUG_LEVEL3("ttyUSB2 is removed %d",__LINE__);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		IOBD_DEBUG_LEVEL3("acm fp+");
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL4("acm fp- \n");
		return E_4G_USB_DISCONNECT;
	}
	else{
		if (type == MODE_TYPE_2G){
			ret = iW_Serial_Write (libClient.serial_fd, MODE_2G, strlen(MODE_2G));
			IOBD_DEBUG_LEVEL2 ("2G_MODE set");
		}
		else if (type == MODE_TYPE_3G){
			ret = iW_Serial_Write (libClient.serial_fd, MODE_3G, strlen(MODE_3G));
			IOBD_DEBUG_LEVEL3 ("3G_MODE set");
		}
		else{
			ret = iW_Serial_Write (libClient.serial_fd, AUTO_MODE, strlen(AUTO_MODE));
			IOBD_DEBUG_LEVEL3 ("AUTO_MODE set");
		}
		if (ret != OBD2_LIB_SUCCESS){
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
			IOBD_DEBUG_LEVEL3("acm fp+");
			sem_post(libClient.acm_node);
			IOBD_DEBUG_LEVEL4("acm fp- \n");
			return E_4G_USB_WRITE;
		}

		usleep(500000);
		if (ret == OBD2_LIB_SUCCESS){
			if(access(USB_2,F_OK)){
				IOBD_DEBUG_LEVEL3("ttyUSB2 is removed %d",__LINE__);
#ifdef _SERIAL_FD_
				close(libClient.serial_fd);
#endif
				IOBD_DEBUG_LEVEL3("acm fp+");
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4("acm fp- \n");
				return E_4G_USB_DISCONNECT;
			}
			ret = iW_Serial_Read (libClient.serial_fd, val, sizeof(val));
			if (ret != OBD2_LIB_SUCCESS){
				IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
#ifdef _SERIAL_FD_
				close(libClient.serial_fd);
#endif
				IOBD_DEBUG_LEVEL3("acm fp+");
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4("acm fp- \n");
				return E_4G_USB_READ;
			}
		}
	}
#ifdef _SERIAL_FD_
	close(libClient.serial_fd);
#endif
	IOBD_DEBUG_LEVEL3("acm p+");
	sem_post(libClient.acm_node);
	IOBD_DEBUG_LEVEL4("%s:acm p- \n",__func__);
	return OBD2_LIB_SUCCESS;
}


int get_gsm_parameters(sim_data *gsm_param)
{
	char *signal_ptr;
	char *lac_ptr;
	char * c_id_ptr;
	char val[100];
	short ret = 0;

	IOBD_DEBUG_LEVEL3("acm w+");
	sem_wait(libClient.acm_node);
	IOBD_DEBUG_LEVEL4("acm w-");

#ifdef _SERIAL_FD_
	if(access(USB_2,F_OK)){
		IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
		sem_post(libClient.acm_node);
		return E_4G_USB_DISCONNECT;
	}
	else{
		libClient.serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,TTYUSB2_BAUD);
		if(libClient.serial_fd <= 0){
			IOBD_ERR("Ret_Val: %d Lib_Err_no: 0x%x\r\n", libClient.serial_fd, E_4G_USB_INIT);
			IOBD_DEBUG_LEVEL3("acm fp+");
			sem_post(libClient.acm_node);
			IOBD_DEBUG_LEVEL4("acm fp- \n");
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			return E_4G_USB_INIT;
		}       
	}
#endif

	memset(val, 0x0, sizeof(val));
	if(access(USB_2,F_OK)){
		IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
		sem_post(libClient.acm_node);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		return E_4G_USB_DISCONNECT;
	}

	ret = iW_Serial_Write (libClient.serial_fd, DISABLE_ECHO, strlen(DISABLE_ECHO));
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		sem_post(libClient.acm_node);
		return E_4G_USB_WRITE;
	} 
	usleep(500000);
	if (ret == OBD2_LIB_SUCCESS){
		if(access(USB_2,F_OK)){
			IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
			sem_post(libClient.acm_node);
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			return E_4G_USB_DISCONNECT;
		}
		ret = iW_Serial_Read (libClient.serial_fd, val, sizeof(val));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			sem_post(libClient.acm_node);
			return E_4G_USB_READ;
		}
	}
	/******************************SIGNAL STRENGTH*********************************/	
	memset(val, 0x0, sizeof(val));
	if(access(USB_2,F_OK)){
		IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
		sem_post(libClient.acm_node);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		return E_4G_USB_DISCONNECT;
	}
	ret = iW_Serial_Write (libClient.serial_fd, GSM_SIGNAL_STRENGTH, strlen(GSM_SIGNAL_STRENGTH));
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		sem_post(libClient.acm_node);
		return E_4G_USB_WRITE;
	} 
	usleep(500000);
	if (ret == OBD2_LIB_SUCCESS){
		if(access(USB_2,F_OK)){
			IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
			sem_post(libClient.acm_node);
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			return E_4G_USB_DISCONNECT;
		}
		ret = iW_Serial_Read (libClient.serial_fd, val, sizeof(val));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			sem_post(libClient.acm_node);
			return E_4G_USB_READ;
		}
	}


	signal_ptr = strtok(val, ":");
	signal_ptr = strtok(NULL, ",");

	strcpy(gsm_param-> signal_lvl,signal_ptr+1);
	IOBD_DEBUG_LEVEL4("signal_ptr:%s\r\n", signal_ptr+1);
	IOBD_DEBUG_LEVEL4("signal_range:%s\r\n", gsm_param-> signal_lvl);
	/************************************CELL ID***********************************/	
	memset(val, 0x0, sizeof(val));
	if(access(USB_2,F_OK)){
		IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		sem_post(libClient.acm_node);
		return E_4G_USB_DISCONNECT;
	}

	ret = iW_Serial_Write (libClient.serial_fd, GSM_CHECK_REGISTRATION, strlen(GSM_CHECK_REGISTRATION));
	if (ret != OBD2_LIB_SUCCESS){
		IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		sem_post(libClient.acm_node);
		return E_4G_USB_WRITE;
	}
	usleep(500000);
	if (ret == OBD2_LIB_SUCCESS){
		if(access(USB_2,F_OK)){
			IOBD_DEBUG_LEVEL3 ("ttyUSB2 disconnected %d",__LINE__);
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			sem_post(libClient.acm_node);
			return E_4G_USB_DISCONNECT;
		}
		ret = iW_Serial_Read (libClient.serial_fd, val, sizeof(val));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			sem_post(libClient.acm_node);
			return E_4G_USB_READ;
		}
	}

	c_id_ptr = strtok(val, "\"");
	c_id_ptr = strtok(NULL, "\"");
	if(c_id_ptr != NULL){
		IOBD_DEBUG_LEVEL3 ("c_id_ptr :%s\r\n", c_id_ptr);
		strcpy(gsm_param->cell_id, c_id_ptr);
		IOBD_DEBUG_LEVEL3("cell_id :%s\r\n",gsm_param->cell_id);
	}
	/*********************************LAC CODE*****************************/
	lac_ptr = strtok(NULL, "\"");
	lac_ptr = strtok(NULL, "\"");
	if(lac_ptr != NULL){
		IOBD_DEBUG_LEVEL3 ("lac_ptr :%s\r\n", lac_ptr);
		strcpy(gsm_param->lac,lac_ptr);
		IOBD_DEBUG_LEVEL3("gsm_param->lac :%s\r\n",gsm_param->lac);
	}

	memset(val, 0x0, sizeof(val));

#ifdef _SERIAL_FD_
	close(libClient.serial_fd);
#endif

	IOBD_DEBUG_LEVEL3("acm p+");
	sem_post(libClient.acm_node);
	IOBD_DEBUG_LEVEL1("acm p-");

	IOBD_DEBUG_LEVEL3 ("get_gsm_parameters - ret %hd",ret);
	return ret;
}

int enable_nw_registration_with_location ()
{
	char val [56];	
	int ret;

	IOBD_DEBUG_LEVEL4("%s: acm w+",__func__);
	sem_wait(libClient.acm_node);
	IOBD_DEBUG_LEVEL3("acm w-");
#ifdef _SERIAL_FD_
	libClient.serial_fd = iW_Serial_Init(SERIAL_PORT_ACM0,TTYUSB2_BAUD);
	if(libClient.serial_fd <= 0)
	{
		IOBD_ERR("Ret_Val: %d Lib_Err_no: 0x%x\r\n", libClient.serial_fd, E_4G_USB_INIT);
		IOBD_DEBUG_LEVEL3("acm fp+");
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
		return E_4G_USB_INIT;
	}
#endif
	memset(val, 0x0, sizeof(val));
	if(access(USB_2,F_OK)){
		IOBD_DEBUG_LEVEL3("ttyUSB2 is removed %d",__LINE__);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		IOBD_DEBUG_LEVEL3("acm fp+");
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
		return E_4G_USB_DISCONNECT;
	}
	else{
		ret = iW_Serial_Write (libClient.serial_fd, DISABLE_ECHO, strlen(DISABLE_ECHO));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			IOBD_DEBUG_LEVEL3("acm fp+ \n");
			sem_post(libClient.acm_node);
			IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
			return E_4G_USB_WRITE;
		}
		else
			IOBD_DEBUG_LEVEL3("iW_Serial_Write : ret = %d",ret);
		usleep(500000);
		if (ret == OBD2_LIB_SUCCESS){
			if(access(USB_2,F_OK)){
				IOBD_DEBUG_LEVEL3("ttyUSB2 is removed %d",__LINE__);
#ifdef _SERIAL_FD_
				close(libClient.serial_fd);
#endif
				IOBD_DEBUG_LEVEL3("acm fp+ \n");
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
				return E_4G_USB_DISCONNECT;
			}
			ret = iW_Serial_Read (libClient.serial_fd, val, sizeof(val));
			if (ret != OBD2_LIB_SUCCESS){
				IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
#ifdef _SERIAL_FD_
				close(libClient.serial_fd);
#endif
				IOBD_DEBUG_LEVEL3("acm fp+ \n");
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
				return E_4G_USB_READ;
			}
			else
				IOBD_DEBUG_LEVEL3("iW_Serial_Read: buf : %s",val);
		}
	}
	memset(val, 0x0, sizeof(val));
	if(access(USB_2,F_OK)){
		IOBD_DEBUG_LEVEL3("ttyUSB2 is removed %d",__LINE__);
#ifdef _SERIAL_FD_
		close(libClient.serial_fd);
#endif
		IOBD_DEBUG_LEVEL3("acm fp+ \n");
		sem_post(libClient.acm_node);
		IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
		return E_4G_USB_DISCONNECT;
	}
	else{
		ret = iW_Serial_Write (libClient.serial_fd, GSM_CHECK_REGISTRATION_2, strlen(GSM_CHECK_REGISTRATION_2));
		if (ret != OBD2_LIB_SUCCESS){
			IOBD_ERR("iW_Serial_Write: Error_no: %d", ret);
#ifdef _SERIAL_FD_
			close(libClient.serial_fd);
#endif
			IOBD_DEBUG_LEVEL3("acm fp+ \n");
			sem_post(libClient.acm_node);
			IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
			return E_4G_USB_WRITE;
		}
		else
			IOBD_DEBUG_LEVEL3("iW_Serial_Write : ret = %d",ret);
		usleep(500000);
		if (ret == OBD2_LIB_SUCCESS){
			if(access(USB_2,F_OK)){
				IOBD_DEBUG_LEVEL3("ttyUSB2 is removed %d",__LINE__);
#ifdef _SERIAL_FD_
				close(libClient.serial_fd);
#endif
				IOBD_DEBUG_LEVEL3("acm fp+ \n");
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
				return E_4G_USB_DISCONNECT;
			}
			ret = iW_Serial_Read (libClient.serial_fd, val, sizeof(val));
			if (ret != OBD2_LIB_SUCCESS){
				IOBD_ERR("iW_Serial_Read: Error_no: %d", ret);
#ifdef _SERIAL_FD_
				close(libClient.serial_fd);
#endif
				IOBD_DEBUG_LEVEL3("acm fp+ \n");
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
				return E_4G_USB_READ;
			}
			else
				IOBD_DEBUG_LEVEL3("iW_Serial_Read : buffer = %s",val);
		}
	}
#ifdef _SERIAL_FD_
	close(libClient.serial_fd);
#endif
	IOBD_DEBUG_LEVEL3("acm p+ \n");
	sem_post(libClient.acm_node);
	IOBD_DEBUG_LEVEL4("%s: acm fp- \n",__func__);
	return OBD2_LIB_SUCCESS;
}

/*
   function to read messages using AT commands\
   AT+CMGF=1 => this command will set the GSM to text mode
   AT+CSMP=17,167,0,241 => To set the additional text mode parameters
   AT+CSCS = \"IRA\" => selects the TE character set "IRA"
 */
int GSM_set_to_message_init (int fd)
{
        int index = 0, count = 0;
        char result[LENGTH] = {0};
        char *resp_ptr = NULL;
	char r_at_cmd[COMMAND_LEN] = {0};
	int numberofbytesent, numberofbytesrcvd; 
        /*command to set GSM to text  messages mode*/
        const char *tmp_buf[] = {"ATE0\r","AT+CMGF=1\r", "AT+CSMP=17,167,0,241\r", "AT+CSCS=\"IRA\"\r"};
        /*calculating the number of commands executed*/
        int max_count = sizeof(tmp_buf)/sizeof(tmp_buf[0]);
	
	libClient.serial_fd = fd;
        /*checking for the received parameter is greater than one*/
        if (libClient.serial_fd <= MIN_FD)
        {
                return OBD2_LIB_FAILURE;
        }

        for (count = 0; count < max_count; count++)
        {
		IOBD_DEBUG_LEVEL3 ("GSM_set_to_message_init w+");
		/*Locking the Critical section*/
		sem_wait(libClient.acm_node);
		IOBD_DEBUG_LEVEL4 ("GSM_set_to_message_init w-");
                /* discards data written to the object referred to by fd but not transmitted*/
                //tcflush (libClient.serial_fd, TCIOFLUSH);
                IOBD_DEBUG_LEVEL3 ("Write command : %s\n", tmp_buf[count]);
                /*write system call to execute the AT command*/
                numberofbytesent = write (libClient.serial_fd ,tmp_buf[count], strlen(tmp_buf[count]));
                if (numberofbytesent <= 0)
                {
                        perror ("GSM_set_to_message_init");
                        IOBD_DEBUG_LEVEL3 ("errno = %d, serial_fd %d\r\n",errno, libClient.serial_fd);
			sem_post(libClient.acm_node);
                        return OBD2_LIB_FAILURE;
                }else{
                        /*adding max delay for getting response*/
                        usleep (MAX_DELAY);
                        memset (r_at_cmd, MEM_CLR, sizeof(r_at_cmd));
                        /*read system call to get the response of the command*/
                        numberofbytesrcvd = read (libClient.serial_fd, r_at_cmd, COMMAND_LEN);
                        if (numberofbytesrcvd <= 0)
                        {
				perror ("GSM_set_to_message_init_read");
                                IOBD_DEBUG_LEVEL3 ("errno = %d \r\n",errno);
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4 ("GSM_set_to_message_init fp-");
                                return OBD2_LIB_FAILURE;
                        }else{
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4 ("GSM_set_to_message_init p-");
                                memset (result, MEM_CLR, sizeof(result));
                                for (index = 0; index < numberofbytesrcvd; index++){
                                        result[index] = r_at_cmd[index];
                                }
                                IOBD_DEBUG_LEVEL3 ("SMS mode setting at command response:%s\n",result);
                                if ((resp_ptr = strstr (result, "OK")) == NULL)
					return OBD2_LIB_FAILURE;
			}
		}
	}
	return OBD2_LIB_SUCCESS;
}

/*
   unread message are read and already read messages are deleted
   AT+CMGD=1,1 => this command will delete the already read messages
   AT+CMGL=\"REC+CMGL\" => this command read the unread messages 
   message_buffer is character array it will store the response of the AT_CMGL command 
 */
int unread_message (char **msg_buf)
{
	int count = 0;
	size_t msg_sz = 0;
	char *res_ptr = NULL;
	char message_buffer[10000];
	int numberofbytesent, numberofbytesrcvd; 
	bool overrun = false;
	char mesg_buf [1024];// sometimes 3message clubbed and increase lenght more than 300 bytes.
	//	char r_at_cmd[MESSAGE_SIZE] = {0};
	/*command to read the messages and delete the message*/
	const char *msg_read[] = {"AT+CMGD=1,1\r", "AT+CMGL=\"REC UNREAD\"\r"};
	/*calculating the number of commands executed*/
	int max_count = sizeof(msg_read)/sizeof(msg_read[0]);
	/*checking for the received parameter is greater than one*/
	if (libClient.serial_fd <= MIN_FD)
	{
		return OBD2_LIB_FAILURE;
	}
	for (count = 0; count < max_count; count++)
	{
		/* discards data written to the object referred to by fd but not transmitted*/
		// tcflush (libClient.serial_fd, TCIOFLUSH);// Is it required??
		/*write system call to execute the AT command*/
		IOBD_DEBUG_LEVEL3 ("%s:%d sem w+",__func__,__LINE__);
read_again:	sem_wait(libClient.acm_node);
		IOBD_DEBUG_LEVEL3 ("%s:sem w-",__func__);
		IOBD_DEBUG_LEVEL3("%s: ATcommand[%d] is %s",__func__, count, msg_read[count]);
		numberofbytesent = write (libClient.serial_fd, msg_read[count], strlen(msg_read[count]));
		if (numberofbytesent <= 0)
		{
			perror ("unread_message_write");
			IOBD_DEBUG_LEVEL3 ("errno = %d, serial_fd %d\r\n", errno, libClient.serial_fd);
			IOBD_DEBUG_LEVEL3 ("%s:sem fp+",__func__);
			sem_post(libClient.acm_node);
			IOBD_DEBUG_LEVEL4 ("%s:sem fp-",__func__);
			return OBD2_LIB_FAILURE;
		}else{
			/*adding minimum delay for getting response*/
			usleep (MAX_DELAY);
			if (overrun == false){
				memset (message_buffer, MEM_CLR, sizeof(message_buffer));
				numberofbytesrcvd = read (libClient.serial_fd, message_buffer, MESSAGE_SIZE);
				IOBD_DEBUG_LEVEL4 ("111111111\tlength of the message: %u\nMessage: %s", strlen(message_buffer), message_buffer);
			}
			else
			{
				memset (mesg_buf, MEM_CLR, sizeof(mesg_buf));
				numberofbytesrcvd = read (libClient.serial_fd, mesg_buf, sizeof (mesg_buf));
				IOBD_DEBUG_LEVEL4 ("22222222\tlength of the message: %u\nMessage: %s", strlen(mesg_buf), mesg_buf);
				if (strlen(mesg_buf) < 30){
					sem_post(libClient.acm_node);
					usleep (300000);
					goto read_again;
				}

			}
			//memset (r_at_cmd, MEM_CLR, COMMAND_LEN);
			/*read system call to get the response of the command*/
			if (numberofbytesrcvd <= 0)
			{
				perror ("unread_message_read");
				IOBD_DEBUG_LEVEL3 ("errno = %d \r\n",errno);
				IOBD_DEBUG_LEVEL3 ("%s:%d sem fp+",__func__,__LINE__);
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4 ("%s:%d sem fp-",__func__,__LINE__);
				return OBD2_LIB_FAILURE;
			}else{
				IOBD_DEBUG_LEVEL3 ("%s:%d sem p+",__func__,__LINE__);
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL3 ("%s:%d sem p-",__func__,__LINE__);

				if (overrun == true){
					strcat(message_buffer, mesg_buf);

					IOBD_DEBUG_LEVEL4 ("********************\nlength of the message: %u\nMessage: %s\n*****************", strlen(message_buffer), message_buffer);
				}
				msg_sz = strlen(message_buffer) + 1;
				if (strstr (message_buffer, "set 6:") != NULL && overrun == false){
					if ((strstr (message_buffer, "=device") == NULL) || (strstr (message_buffer, "=iothubowner") == NULL)){
						overrun = true;
						IOBD_DEBUG_LEVEL4 ("length of the message: %d\nMessage: %s", msg_sz, message_buffer);
						goto read_again;
					}
				}
					if ((res_ptr = strstr (message_buffer, "OK")) == NULL)
						return OBD2_LIB_FAILURE;
			}
		}
	}

		*msg_buf = malloc (msg_sz);
		if (*msg_buf == NULL)
			return -ENOMEM;
		else
			memset (*msg_buf, MEM_CLR, msg_sz);

		strcpy (*msg_buf, message_buffer);

		return OBD2_LIB_SUCCESS;
}


/*function to send the framed response to the command centre by sending SMS to the same senderid*/
int send_sms (char *msg_response, char *sender_number)
{
	short count = 0;
	int idx = 0;
	char p = '"';
	bool overrun = false;
	char response[COMMAND_LEN] = {0};
	char send_command[COMMAND_LEN] = {0};
	int numberofmsgbyte = 0;
	int numberofbytesent, numberofbytesrcvd;
	char r_at_cmd[COMMAND_LEN] = {0};
	char msg_buf[256] = {0};	
	int sz = strlen(msg_response);

	IOBD_DEBUG_LEVEL4 ("send_sms szof resp is %d\n",sz);
	if (sz > MAX_MSG_LEN)
		overrun = true;

	/*checking for the received parameter is not equal to NULL*/
	if (msg_response == NULL)
	{
		return OBD2_LIB_FAILURE;
	}
	for (idx = 1; idx < 5; idx++)
	{
		sem_wait(libClient.acm_node);
		if (overrun == true && idx < 3)
			sprintf (send_command,"AT+QCMGS=%c%s%c,153,%d,2\r",p, sender_number, p, idx);
		else
			sprintf (send_command,"AT+CMGS =%c%s%c\r",p, sender_number, p);
		//tcflush (fd_value, TCIOFLUSH);
		/*write system to execute the at command in command line*/
		numberofbytesent = write (libClient.serial_fd, send_command, strlen(send_command));
		if (numberofbytesent <= 0)
		{
			sem_post(libClient.acm_node);
			perror ("send_sms");
			return OBD2_LIB_FAILURE;
		}else{
			/*maximum delay for at command response 300ms*/
			usleep (MAX_DELAY);
			/*read system call to read the response get from the at command*/
			numberofbytesrcvd = read (libClient.serial_fd, r_at_cmd, COMMAND_LEN);
			if (numberofbytesrcvd <= 0)
			{
				sem_post(libClient.acm_node);
				perror ("1.send_sms");
				return OBD2_LIB_FAILURE;
			}
		}
		if (sz > MAX_MSG_LEN){
			strncpy(msg_buf, msg_response, 90);
			sprintf (msg_buf, "%s%c", msg_buf, CTRL_Z);//in sas-token value starts from 15th byte.
			sz = sz - 90;
			strcpy (msg_response, msg_response + 90);
			IOBD_DEBUG_LEVEL4 ("222.msg_buf is %s\nmsg_response is %s\n\n",msg_buf,msg_response);			
		}
		else{
			strcpy (msg_buf, msg_response);
			sz = sz - MAX_MSG_LEN;
		}
			IOBD_DEBUG_LEVEL4 ("msg_buf is %s",msg_buf);			

		/*write system to enter the framed response in command line*/
		numberofmsgbyte = write (libClient.serial_fd, msg_buf, strlen(msg_buf));
		if (numberofmsgbyte <= 0)
		{
			sem_post(libClient.acm_node);
			perror ("send_sms");
			IOBD_DEBUG_LEVEL3 ("errno = %d, fd_value %d\r\n", errno, libClient.serial_fd);
			return OBD2_LIB_FAILURE;
		}else{
			memset (msg_buf, MEM_CLR, sizeof(msg_buf));
			//usleep (MAX_DELAY);
			/*maximum delay for at command response 300ms*/
			while (1){
				sleep (1);
				memset (response, MEM_CLR, sizeof(response));
				/*read system call to read the response get from the at command*/
				numberofbytesrcvd = read (libClient.serial_fd, response, COMMAND_LEN);

				if ((strstr (response, "OK")) == NULL && count != 15){
					count++;
				}else{
					IOBD_DEBUG_LEVEL4 ("#####################the count is %hd\n",count);
					count = 0;
					break;
				}
			}

			if (numberofbytesrcvd <= 0)
			{
				sem_post(libClient.acm_node);
				perror ("2.send_sms");
				IOBD_DEBUG_LEVEL3 ("errno = %d \r\n",errno);
				return OBD2_LIB_FAILURE;
			}else{
				sem_post(libClient.acm_node);
				IOBD_DEBUG_LEVEL4 ("recieved response is : %s %d\n",response,sz);
			}
		}
		/*if at command execute successfully then the response is OK otherwise ERROR
		  check for OK response */
		if ((strstr (response,"OK")) != NULL && sz < 0){
			IOBD_DEBUG_LEVEL4 ("%s: Successfully sent with idx is %d\n",__func__, idx);
			break;
		}
	}
	if (idx == 5)
		return OBD2_LIB_FAILURE;
	else
		return OBD2_LIB_SUCCESS;
}

