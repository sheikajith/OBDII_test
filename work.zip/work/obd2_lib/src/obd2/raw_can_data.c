#include <can_header.h>
#include "obd2lib.h"
#include <stdbool.h>
const int canfd_on = 1;
static bool can_interrupt_flag;
static int can_receive_thread_create;

void sig_h(int signo)
{
	can_interrupt_flag = true;

}

int start_can_receive_thread()
{
    if( can_receive_thread_create == 0 )
    {
        if(pthread_create(&(libClient.tid[6]), NULL, (void *) can_receive_thread, NULL) != 0)
        {
            return -errno;
        }
        else{
            IOBD_DEBUG_LEVEL4 ("can_thread created successfully");
            if (pthread_detach (libClient.tid[6]) != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("can_thread: pthread_detach failed %d",errno);
            can_receive_thread_create = 1;
        }
    }
    else
    {
        IOBD_DEBUG_LEVEL2 ("can_receive_thread is already created");
    }
    return OBD2_LIB_SUCCESS;
}

int can_init(int bps)
{
	int rc = OBD2_LIB_SUCCESS;
        char cmd[48];
        char str[] = "ip link set can0 up type can bitrate";
        
	sprintf(cmd,"%s %d", str, bps);

	can_interrupt_flag = false;

	/*!< Interpreter CAN OFF */
        rc = set_gpio_value(INTERPRETTER_CAN_EN, GPIO_HIGH);
        if (rc != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("INTERPRETTER_CAN_EN on Failed %d",rc);
	/*!< CPU CAN ON */
        rc = set_gpio_value(CPU_CAN_EN, GPIO_LOW);
        if (rc != OBD2_LIB_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("CPU_CAN_EN on Failed %d",rc);
	
        system(cmd);

	rc = start_can_receive_thread();
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("start_can_receive_thread failed with %d",rc);

        return rc;
}

int can_receive_thread () 
{
	/*For MCU Implementation:
	  1) Wait for response.
	  2) Once received copy the response to global structure.
	  3) impletement isotp for response size greater than 8 bytes.
	 */

	int s;
	struct sockaddr_can addr;
	struct timeval timeout;
	fd_set rdfs;
	int retval;
	int nbytes;
        struct iovec iov;
        struct msghdr msg;
	struct canfd_frame frame;
	char ctrlmsg[CMSG_SPACE(sizeof(struct timeval)) + CMSG_SPACE(sizeof(__u32))];

        s = socket(PF_CAN, SOCK_RAW, CAN_RAW);

        if (s < 0) {
                perror("socket");
                return -errno;
        }

        addr.can_family = AF_CAN;
        addr.can_ifindex = if_nametoindex("can0");

        /* try to switch the socket into CAN FD mode */
        setsockopt(s, SOL_CAN_RAW, CAN_RAW_FD_FRAMES, &canfd_on, sizeof(canfd_on));

        if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
                perror("bind");
                return -errno;
        }

        iov.iov_base = &frame;
        msg.msg_name = &addr;
        msg.msg_iov = &iov;
        msg.msg_iovlen = 1;
        msg.msg_control = &ctrlmsg;

	while(1) {
		/* timeout wait for 20ms */
		timeout.tv_sec = 0;
		timeout.tv_usec = 20000;

		FD_SET(s, &rdfs);
		if (can_interrupt_flag == true)
			break;
		retval = select(s + 1, &rdfs, NULL, NULL, &timeout);
		if (retval){

			if (FD_ISSET(s, &rdfs)) {

				/* these settings may be modified by recvmsg() */
				iov.iov_len = sizeof(frame);
				msg.msg_namelen = sizeof(addr);
				msg.msg_controllen = sizeof(ctrlmsg);
				msg.msg_flags = 0;

				nbytes = recvmsg(s, &msg, 0);

                if (nbytes < 0) {
                    perror("read");
                    if (can_interrupt_flag == true)
                        break;
                } 

				//printf("frame.can_id : %x: %x %x %x %x %x %x %x %x\r\n", frame.can_id, frame.data[0], frame.data[1], frame.data[2], frame.data[3], frame.data[4], frame.data[5], frame.data[6], frame.data[7]);

				if(frame.can_id == 0x610) { //has to be changed to 0x610
					CAN_Res.speed[0] = frame.data[2];
				}
				if(frame.can_id == 0x1C4) { //has to be changed to 0x1c4
					CAN_Res.rpm[0] = frame.data[0];
					CAN_Res.rpm[1]= frame.data[1];
				}
			}
		}
	}

	close(s);
	IOBD_DEBUG_LEVEL2 ("can_receive_thread exits\n");
    can_receive_thread_create = 0;
	return 0;
}          

int can_deinit()
{
	int rc = 0;

	signal(SIGUSR1, sig_h);

	rc = pthread_kill(libClient.tid[6], SIGUSR1);
    usleep( 100000 );

	system("ifconfig can0 down");

	return rc;
}
