#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "init.h"

int ntp_server_update()
{
	int ret;
	int l=0;

	system("unlink /etc/localtime");
	system ("date -s 2018.07.30-00:00:00");
	
	system("ln -s /usr/share/zoneinfo/UTC /etc/localtime");

	IOBD_DEBUG_LEVEL3("ntpdate start\n\r");
	ret = system("ntpdate pool.ntp.org");

	IOBD_DEBUG_LEVEL3("ntpdate ret = %d\n",ret);
	while (ret != OBD2_LIB_SUCCESS){
		++l;
		IOBD_DEBUG_LEVEL2 ("ntpdate failed retry l = %d",l);
		if (l == 1)
			system("ntpdate jp.pool.ntp.org");
		if (l == 2)
			system("ntpdate id.pool.ntp.org");
		if (l == 3)
			system("ntpdate asia.pool.ntp.org");
		if (l == 4)
			break;
	}
		
	IOBD_DEBUG_LEVEL3("ntpdate end\n\r");

	ret = system("hwclock -w");
	if (ret != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("hwclock failed!!!!");

	return ret;
}

