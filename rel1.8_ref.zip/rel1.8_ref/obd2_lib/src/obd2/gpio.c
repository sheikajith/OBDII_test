#include "common.h"
#include <stdlib.h>
/*!
 * \brief
 * gpio_export function to export the gpio
 *
 * \details
 * This function is to export the gpio from arguments
 *
 * \param [in] gpio
 * GPIO pin number
 *
 * \return
 * Success - E_SUCCESS
 */
int gpio_export(int gpio)
{
	int pFile;
	
	int ret = OBD2_LIB_SUCCESS;
	char gpio_path[48] = {0};
	char gpio_buf[8] = {0};

	sprintf(gpio_buf,"%d",gpio);
	sprintf(gpio_path,"/sys/class/gpio/gpio%d/direction", gpio);
	if (access(gpio_path, F_OK ) == 0){
		ret = 0;
	}else{
		pFile=open("/sys/class/gpio/export", O_WRONLY);
		if (pFile == OBD2_LIB_FAILURE) {
			printf("File open error \r\n");
			ret = -errno;
			goto end;
		}
		ret = write(pFile, gpio_buf, strlen(gpio_buf));
		if (ret == OBD2_LIB_FAILURE)
		{
			ret = -errno;
		}else{
			fdatasync(pFile);
			ret = posix_fadvise(pFile, 0,0,POSIX_FADV_DONTNEED);
			if (ret)
				IOBD_DEBUG_LEVEL2 ("clear_cache: posix_fadvise is %d",ret);
			ret = OBD2_LIB_SUCCESS;
		}
		close(pFile);
	}
end:
	return ret;
}

/*!
 * \brief
 * get_gpio_direction function to get the gpio value
 *
 * \details
 * This function is to get the gpio value
 *
 * \param [in] gpio
 * GPIO pin number
 *
 * \param [in] value
 * GPIO value
 *
 * \return
 * Success - E_SUCCESS
 */
int get_gpio(int gpio, int * value)
{
	int ret =0;
	int pFile;
	char gpio_path[32] = {0};
	char gpio_buf[4] = {0};

	sprintf(gpio_path, "/sys/class/gpio/gpio%d/value",gpio);

	if (access(gpio_path, F_OK ) == 0){
		pFile = open(gpio_path, O_RDONLY);
		if (pFile == OBD2_LIB_FAILURE) {
			printf("File open error \r\n");
			ret = -1;
			goto end;
		}

		ret = read(pFile, gpio_buf, 1);
		if (ret == OBD2_LIB_FAILURE)
		{
			ret = -1;
		}else{
			*value = atoi(gpio_buf);
			*value = (*value & (1 << gpio))? 1: 0;
		}

		close(pFile);

	}else{
		ret = -1;
	}
end:
	return ret;
}

int set_gpio_value(int gpio, short value)
{
        int ret;
        int pFile;
        char gpio_path[32] = {0};
        char gpio_buf[4] = {0};

        sprintf(gpio_buf,"%d",value);
        sprintf(gpio_path, "/sys/class/gpio/gpio%d/value",gpio);


        if (access(gpio_path, F_OK ) == 0){
		pFile = open(gpio_path, O_WRONLY);
                if (pFile == OBD2_LIB_FAILURE) {
                        printf("File open error \r\n");
                        ret = -errno;
                        goto end;
                }
                ret = write(pFile, gpio_buf, strlen(gpio_buf));
                if (ret == OBD2_LIB_FAILURE)
                {
                        ret = -errno;
                }else{
			fdatasync(pFile);
			ret = posix_fadvise(pFile, 0,0,POSIX_FADV_DONTNEED);
			if (ret)
				IOBD_DEBUG_LEVEL2 ("clear_cache: posix_fadvise is %d",ret);
			ret = OBD2_LIB_SUCCESS;
		}

                close(pFile);
       }else{
                IOBD_DEBUG_LEVEL2 ("gpio%d file does not exist", gpio);
		ret = -3;
        }
end:
        return ret;
}

int set_gpio_direction(int gpio, int direction)
{
	int pFile = 0;
	char gpio_path[48] = {0};
	int ret;

	sprintf(gpio_path, "/sys/class/gpio/gpio%d/direction",gpio);
	if (access(gpio_path, F_OK ) == 0){
		pFile = open(gpio_path, O_WRONLY);
                if (pFile == OBD2_LIB_FAILURE) {
			printf("File open error \r\n");
			ret = -errno;
			goto end;
		}
		if (direction == INPUT)
                	ret = write(pFile, "in", strlen("in"));
			if (ret == OBD2_LIB_FAILURE){
				perror ("set_gpio_direction");
                }else{
			fdatasync(pFile);
			ret = posix_fadvise(pFile, 0,0,POSIX_FADV_DONTNEED);
			if (ret)
				IOBD_DEBUG_LEVEL2 ("clear_cache: posix_fadvise is %d",ret);
			ret = OBD2_LIB_SUCCESS;
		}
		if (direction == OUTPUT)
                	ret = write(pFile, "out", strlen("out"));
			if (ret == OBD2_LIB_FAILURE){
				perror ("set_gpio_direction");
				ret = -errno;
                }else{
			fdatasync(pFile);
			ret = posix_fadvise(pFile, 0,0,POSIX_FADV_DONTNEED);
			if (ret)
				IOBD_DEBUG_LEVEL2 ("clear_cache: posix_fadvise is %d",ret);
			ret = OBD2_LIB_SUCCESS;
		}
		close(pFile);
	}	
end:
	return ret;
}

int clear_cache (int level)
{
        int ret;
        int pFile;
        char gpio_path[32] = {0};
        char gpio_buf[4] = {0};

        sprintf(gpio_buf,"%d",level);
        strcpy(gpio_path, "/proc/sys/vm/drop_caches");
        if (access(gpio_path, F_OK ) == 0){
		pFile = open(gpio_path, O_WRONLY);
                if (pFile == OBD2_LIB_FAILURE) {
                        perror ("clear_cache");
                        ret = -errno;
                        goto end;
		}       

		ret = write(pFile, gpio_buf, strlen(gpio_buf));
		if (ret < 0 )
		{
			IOBD_DEBUG_LEVEL2 ("level%d file write error", level);
			ret = -errno;
		}else{
			fdatasync(pFile);
			ret = posix_fadvise(pFile, 0,0,POSIX_FADV_DONTNEED);
			if (ret)
				IOBD_DEBUG_LEVEL2 ("clear_cache: posix_fadvise is %d",ret);

			ret = OBD2_LIB_SUCCESS;
		}

		close(pFile);
	}else{
		IOBD_DEBUG_LEVEL2 ("%s: file does not exist", gpio_path);
		ret = -3; 
	}
end:
        return ret;
}

