#ifndef __IIOUTILS_H_
#define __IIOUTILS_H_ 
/* IIO - useful set of util functionality
 *
 * Copyright (c) 2008 Jonathan Cameron
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as published by
 * the Free Software Foundation.
 */

#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <stdint.h>
#include <dirent.h>
#include <errno.h>

/* Made up value to limit allocation sizes */
#define IIO_MAX_NAME_LENGTH 30

#define FORMAT_SCAN_ELEMENTS_DIR "%s/scan_elements"
#define FORMAT_TYPE_FILE "%s_type"

struct iio_channel_info {
	char *name;
	char *generic_name;
	float scale;
	float offset;
	unsigned index;
	unsigned bytes;
	unsigned bits_used;
	unsigned shift;
	uint64_t mask;
	unsigned be;
	unsigned is_signed;
	unsigned location;
};

void process_scan(char *, struct iio_channel_info *, int);
void print2byte(int , struct iio_channel_info *, int);
int size_from_channelarray(struct iio_channel_info *, int);
int iioutils_break_up_name(const char *full_name, char **generic_name);
int iioutils_get_type(unsigned *is_signed, unsigned *bytes, unsigned *bits_used, unsigned *shift, uint64_t *mask, unsigned *be,
                const char *device_dir, const char *name, const char *generic_name);
int iioutils_get_param_float(float *output, const char *param_name, const char *device_dir, const char *name, const char *generic_name);
void bsort_channel_array_by_index(struct iio_channel_info **ci_array, int cnt);
int build_channel_array(const char *device_dir, struct iio_channel_info **ci_array, int *counter);
int find_type_by_name(const char *name, const char *type);
int _write_sysfs_int(char *filename, char *basedir, int val, int verify);
int write_sysfs_int(char *filename, char *basedir, int val);
int write_sysfs_int_and_verify(char *filename, char *basedir, int val);
int _write_sysfs_string(char *filename, char *basedir, char *val, int verify);
int write_sysfs_string_and_verify(char *filename, char *basedir, char *val);
int write_sysfs_string(char *filename, char *basedir, char *val);
int read_sysfs_posint(char *filename, char *basedir);
int read_sysfs_float(char *filename, char *basedir, float *val);
int read_sysfs_string(const char *filename, const char *basedir, char *str);
int size_from_channelarray(struct iio_channel_info *channels, int num_channels);
#endif // __IIOUTILS_H_
