#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>

#include <linux/can.h>
#include <linux/can/raw.h>

#include<stdint.h>


typedef struct can_data {
        uint8_t speed[5];
        uint8_t rpm[5];
}CAN_RX;

CAN_RX CAN_Res;

int can_init(int);
int can_deinit();
int can_receive_thread();
