#ifndef __THREAD__H_
#define __THREAD__H_
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <asm/types.h>
#include <linux/netlink.h>
#include <linux/if_link.h>
#include <linux/input.h>
#include <linux/rtnetlink.h>
#include <linux/sched.h> // Required for task states (TASK_INTERRUPTIBLE etc )
#include <linux/kernel.h>
#include <linux/fs.h> // required for various structures related to files liked fops.
#include <sys/socket.h>
#include <sys/types.h>
#include <net/if.h>
#include <assert.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/tcp.h>
#include <sys/time.h>
#include <sys/timerfd.h>
#include <ctype.h>
#include <limits.h>
#include <stdbool.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <math.h>
#include <time.h>
#include <curl/curl.h>
#include <json/json.h>
#include "common.h"
#include "q_gps.h"
#define SNAME "/sync"
/*MACROS*/
#define  NODE_EXP_WITHOUT_GYRO   	"/dev/input/event2"
#define  NODE_EXP_WITH_GYRO      	"/dev/input/event3"
#define RESET 				20
#define GPIO_EVENT_PATH			"/sys/class/input/input" 
#define GPIO_EVENT_NAME			"gpio-keys"
int raw_can_enable(void);
float read_temp_CPU (void);
int pm_thread (void);
int link_thread (void);
void link_status_thread();
int board_thread (void);
int read_event (int);
int GPIO_config(void);
int key_event_thread();
int timer_event_thread();
void ignition_status_thread (void);
void throttle_thread (void);
int ignition_status();
int board_init();
int config_wakeup_timer_trigger(bool, long);
int board_init_4g_uart();
int board_init_4g_usb();
int wait_for_indicate_battery_drain_completed();
int wait_for_indicate_ignition_off_completed();
int wait_for_sys_wake_completed(int);
#endif
