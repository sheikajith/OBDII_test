#ifndef __A_QUEUE__
#define __A_QUEUE__
#include <sys/resource.h>

#define Q_MAX_MESSAGES 	65535
int init_an_mq(void);
int send_msg_an_q(struct obd_data *data);

#endif
