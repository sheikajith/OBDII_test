#include "application.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "init_callbacks.h"
#include "cloud.h"
#include "standard_pkt_process.h"
#include "standard.h"
#include "standard_queue.h"
#include "sota.h"


void main_ign_on (char *ts)
{
	struct obd_data obd_qdata;
	int rc = 0;

	IOBD_DEBUG_LEVEL2("ignition on status in main_ign_on() !!!!!!!!!!!!!!! %s\n",ts);
	rc = final_payload_frame (ts, &obd_qdata, "KEY_ON");
	obd_qdata.msg_type = KEY_ON;
	rc = send_msg_q(&obd_qdata);

	if (rc < 0)
		IOBD_DEBUG_LEVEL2("KEY_ON send to message queue failed!!!\n");
	standard_cli.speed.s_time = time(NULL);	
}


void main_ign_off (char *ts)
{
	int rc = 0;
	struct obd_data obd_qdata;

	/*Exiting all thread*/
	appClient.appSleep = APP_SLEEP;

	rc = final_payload_frame (ts, &obd_qdata, "KEY_OFF");
	rc = publishEvent (obd_qdata.data);
	if(rc<0){
		obd_qdata.msg_type = KEY_OFF;
		rc = send_msg_q(&obd_qdata);
		if(rc<0)
			IOBD_DEBUG_LEVEL2("KEY_OFF: send data to server failed \n");

	}
	else{
		appClient.key_off_set = APP_SLEEP;
		indicate_ignition_off_completed();
	}
}

void main_crash_det (char *ts)
{
	int rc = 0;
	struct obd_data obd_qdata;
	int count = 0;

	IOBD_DEBUG_LEVEL4("Crash Detection event in main_crash_det() %s\n",ts);
	
	appClient.appSleep = APP_SLEEP;

	rc = final_payload_frame (ts, &obd_qdata, "CRASH");
retry:	rc = publishEvent (obd_qdata.data);

        if(rc<0){
                count++;
                IOBD_DEBUG_LEVEL2("send crash data to server failed \n");
                if (count < 5)
                        goto retry;
        }

}

void main_osm_callback (char *ts)
{

	struct obd_data obd_qdata;
	int rc = 0;
	time_t st,end,diff;
	int count = 0;
	long wait_time = 0;
	char time_buf[8];


	IOBD_DEBUG_LEVEL2 ("main_osm_callback called+++\n");
	appClient.appSleep = APP_SLEEP;
	/*get the waiting time*/
        get_xml_content (SRC_XML_FILE, OSM_CONFIG, GENERAL_WAIT_TIME, time_buf);
        wait_time = atol (time_buf);
	printf ("************Waitng time is %lu\n",wait_time);
	rc = final_payload_frame (ts, &obd_qdata, "SAMPLING");
retry:	rc = publishEvent (obd_qdata.data);
	if(rc<0){
		count++;
		IOBD_DEBUG_LEVEL2("send disconnection data to server failed \n");
		if (count < 5)
			goto retry;
	}
	st = time(NULL);
	while (1)
	{
		end = time(NULL);
		diff = end - st;
		IOBD_DEBUG_LEVEL3 ("in Dis_callback :diff : %d",diff);
		if (diff > wait_time)/*Every xmin*/
			break;
		sleep (1);
	}
}
void main_dis_stat (char *ts)
{
	int rc = 0;
	size_t nbytes;
	struct obd_data obd_qdata;
	time_t st,end,diff;
	int count = 0;

	IOBD_DEBUG_LEVEL4("Device Disconnection status in main_dis_stat() %s\n",ts);

	standard_cli.btry_disconnect = 1;	
	appClient.appSleep = APP_SLEEP;
	st = time(NULL);
	while (1)
	{
		end = time(NULL);	
		IOBD_DEBUG_LEVEL4("main_dis_stat w+\n");

		rc = get_gps_rmc_data(standard_cli.g_gps.gps_rmc.nmea, &nbytes);
		if (rc != OBD2_APP_SUCCESS){
			IOBD_DEBUG_LEVEL2 ("main_dis_stat get_gps failed with %d",rc);
		}else if (ParseRMC(&standard_cli.g_gps.gps_rmc, nbytes)){
			break;
		}
		IOBD_DEBUG_LEVEL2("main_dis_stat w-\n");
		IOBD_DEBUG_LEVEL3 ("in Dis_callback : gps_valid is %d",gps_valid);	

		diff = end - st;
		IOBD_DEBUG_LEVEL3 ("in Dis_callback :diff : %d",diff);
		if (diff > 120)/*Every 2min*/
			break;
		sleep (1);
	}
	
	rc = final_payload_frame (ts, &obd_qdata, "MB_CN");
retry:	rc = publishEvent (obd_qdata.data);

	if(rc<0){
		count++;
		IOBD_DEBUG_LEVEL2("send disconnection data to server failed \n");
		if (count < 5)
			goto retry;
	}
}

void main_pnc_btn (char *ts)
{
	struct obd_data obd_qdata;
	int rc = 0;

	rc = final_payload_frame (ts, &obd_qdata, "PNC_BTN");
	obd_qdata.msg_type = PNC_BTN;
	rc = send_msg_q(&obd_qdata);
	if (rc < 0)
		IOBD_DEBUG_LEVEL2("PNC_BTN send to message queue failed!!!\n");

}
void main_bat_drain (char *ts)
{
	int rc = 0;

	struct obd_data obd_qdata;

	rc = final_payload_frame (ts, &obd_qdata, "MB_LWN");
	rc = publishEvent (obd_qdata.data);
	if(rc<0)
		IOBD_DEBUG_LEVEL2("send data to server failed \n");

	IOBD_DEBUG_LEVEL2("Battery Draining alert in main_bat_drain() %s\n",ts);

}

void backup_battery_failure (void)
{
	int rc = 0;
	char ts[64]={0};
	struct obd_data obd_qdata;

	IOBD_DEBUG_LEVEL2("backup_battery_failure \n");
	get_time(ts);
	rc = final_payload_frame (ts, &obd_qdata, "BB_FN");
	obd_qdata.msg_type = BB_FN;
	rc = send_msg_q(&obd_qdata);
	if(rc<0)
		IOBD_DEBUG_LEVEL2("send data to server failed \n");

	return;
}

void backup_battery_low_voltage (void)
{
	int rc = 0;
	IOBD_DEBUG_LEVEL2("backup_battery_low_voltage \n");
	char ts[64]={0};
	struct obd_data obd_qdata;

	get_time(ts);
	rc = final_payload_frame (ts, &obd_qdata, "BB_LWN");
	obd_qdata.msg_type = BB_LWN;
	rc = send_msg_q(&obd_qdata);
	if(rc<0)
		IOBD_DEBUG_LEVEL2("send data to server failed \n");

	return;
}

void sys_sleep (void)
{
	int rc = 0;
	IOBD_DEBUG_LEVEL2("system ignition off in sys_sleep()\n");
	char ts[64]={0};
	struct obd_data obd_qdata;
#if 0
	rc = send_notification ("END");
	if (rc == -1)
		IOBD_DEBUG_LEVEL2("send_notification failed\n");
#endif
	get_time(ts);
	rc = final_payload_frame (ts, &obd_qdata, "SM_ON");
	rc = publishEvent (obd_qdata.data);
	if(rc<0)
		IOBD_DEBUG_LEVEL2("send data to server failed \n");

	IOBD_DEBUG_LEVEL2("Device going to sleep mode\n");
	sleep(2);//to wait till all thread_exit
	hw_deinit();
#if GYRO_ENABLE
	gyro_deinit ();
#endif
	acc_deinit ();
	cloud_deinit();

	sem_destroy (&dmClient.rns_sem);
	sem_destroy (&dmClient.obd_q_sem);
	sem_destroy (&standard_cli.send_sem);
#ifdef BLACKBOX
	sem_destroy (&appClient.bb.rw_lock);
#endif
	//deinit_mq();//commented to kill usb_application
	
	sys_sleep_completed();// to indicate sleep completion status to library

	return;
}
void sys_wake_dis (void)
{
	IOBD_DEBUG_LEVEL2 ("system wakeup in sys_wake_dis() \n");
	//init_mq_usb();	// commented to kill usb_application
	cloud_init();
	server_connection_complete();
	
	
	/* Init Read_and_Send_Semaphore*/
	if (sem_init(&dmClient.rns_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("Sem Create Failed\r\n");
	}
	
	if (sem_init(&standard_cli.send_sem, 0, 1) == -1)
                IOBD_DEBUG_LEVEL2("Sem init failed \n");	

	if (sem_init(&dmClient.obd_q_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("Sem Create Failed\r\n");
	}
	sys_wake_completed();//to indicate wake completion status to library

}
void sys_wake (void)
{
	int rc = 0;

	IOBD_DEBUG_LEVEL3 ("system wakeup in sys_wake() \n");

	rc = start_sota_app();
	if (rc < OBD2_APP_SUCCESS)
		IOBD_DEBUG_LEVEL1 ("start_sota_app failed\n");

	cloud_init();
	acc_init ();	
#if GYRO_ENABLE
	gyro_init ();	
#endif
	/* Indicate to library about client initialisation */
	server_connection_complete();


	//init_mq();// This is commented because this queue need to be alive to send data which is stored before going to sleep. 
	
	//init_mq_usb();// commented to kill usb_application

	IOBD_DEBUG_LEVEL4("Sem Create rns_sem\r\n");

	
	/* Init Read_and_Send_Semaphore*/
	if (sem_init(&dmClient.rns_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("Sem Create Failed\r\n");
	}
	/*Semaphore for frame_buffer*/
	if (sem_init(&standard_cli.send_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("Sem init failed \n");
	}

	/* Init Send_msg_q_Semaphore*/
	if (sem_init(&dmClient.obd_q_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("Sem Create Failed\r\n");
	}

#ifdef BLACKBOX
        /*Semaphore for blackbox read/write*/
        if (sem_init(&appClient.bb.rw_lock, 1, 1) == OBD2_APP_FAILURE)
        {
                IOBD_DEBUG_LEVEL1("BB_R_W_lock_Sem Create Failed\r\n");
        }
#endif

	appClient.appSleep = APP_WAKE;
	create_thread();
	thread_init();

#ifdef _ANALYTICS_
	analytics_thread_init();
#endif

	sys_wake_completed();//to indicate wake completion status to library
	return;
}

void sigHandler(int signo)
{
	IOBD_DEBUG_LEVEL2("**************Signal %d received******************\n",signo);
	dmClient.interrupt = 1;
	system("killall application");
	system("killall SOTA_APP");
	/* NaN : Added */
	exit(0);
}


