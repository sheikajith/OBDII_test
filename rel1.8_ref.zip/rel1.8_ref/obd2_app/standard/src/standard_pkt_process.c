#include "application.h"
#include "standard.h"
#include "standard_pkt_process.h"
#include <netdb.h>
#include "common.h"


void process_data_packets(){

	int len = 0;
	struct obd_data obddata;
	int rc = 0;
	int count = 0;

	while (!dmClient.interrupt)
	{

		len = mq_receive(dmClient.obd_queue_id,(char *) &obddata, sizeof(struct obd_data),NULL);

retry:
		if(appClient.appSleep == APP_SLEEP && appClient.key_off_set == APP_SLEEP)
			break;
	
		IOBD_DEBUG_LEVEL2 (" Receive len = %d, errno =%d\r\n",len,errno);

		if (access("/dev/ttyUSB4",F_OK) || appClient.appSleep == APP_SLEEP){		
			_pause_ ();
			indicate_ignition_off_completed();
		}
		IOBD_DEBUG_LEVEL2 ("msg_type = %d\r\n", obddata.msg_type);
		IOBD_DEBUG_LEVEL4 ("Receive Data = %s\r\n", obddata.data);

		switch(obddata.msg_type)
		{	
			case CAN_SIGN:
				rc = publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2(" CAN_SIGN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
				}
				break;

			case SAMPLING:
				rc = publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2(" SAMPLING publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
				}
				IOBD_DEBUG_LEVEL4 ("SAMPLING Event Sent\n");
				break;

			case FATIGUE_ON:
                                rc = publishEventWrapper(obddata.data);
                                IOBD_DEBUG_LEVEL4("after ftg rc: %d\r\n", rc);
                                if (rc != OBD2_APP_SUCCESS) {
                                        IOBD_DEBUG_LEVEL2("ftg publishEvent Failed rc= %d\r\n",rc);
                                        sleep(1);

                                }
                                break;

			case KEY_ON:
				rc= publishEventWrapper(obddata.data);
				appClient.key_off_set = 0;
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2(" KEY_ON publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					count = count + 1;
					if (count <= 10)
						goto retry;

					count = 0;
				}
				break;

			case KEY_OFF:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2(" KEY_OFF publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					count = count + 1;
					if (count <= 10)
						goto retry;

					count = 0;
				}
				appClient.key_off_set = 1;
				/*Indicate to library about ignition_off*/
				indicate_ignition_off_completed();
				break;

			case EXCHNG_SIM:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2("EXCHNG_SIM publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					count = count + 1;
					if (count <= 10)
						goto retry;

					count = 0;
				}
				break;

			case PNC_BTN:
                                rc= publishEventWrapper(obddata.data);
                                IOBD_DEBUG_LEVEL4("after PNC_BTN rc: %d\r\n", rc);
                                if (rc != OBD2_APP_SUCCESS) {
                                        IOBD_DEBUG_LEVEL2(" PNC_BTN publishEvent Failed rc= %d\r\n",rc);
                                        sleep(1);
					count = count + 1;
					if (count <= 10)
						goto retry;

					count = 0;
                                }
                                break;

			case MB_RN:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2("MB_RN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					count = count + 1;
					if (count <= 10)
						goto retry;

					count = 0;
				}
				break;

			case BB_EN:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2("BB_EN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;
			
			case BLCK_OFF:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2(" BLCK_OFF publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;
			case BB_FN:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2(" BB_FN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;
				/*keshav st*/
			case BB_LWN:
				rc= publishEventWrapper(obddata.data);
				if (rc != OBD2_APP_SUCCESS) {
					IOBD_DEBUG_LEVEL2(" BB_LWN publishEvent Failed rc= %d\r\n",rc);
					sleep(1);
					goto retry;
				}
				break;
				/*keshav end*/
			default :
				IOBD_DEBUG_LEVEL2(" Wrong message_type\r\n");
		}
		if (appClient.key_off_set == 1){
			appClient.key_off_set = 0;
			printf ("##########appClient.key_off_set is resetting...\n");
			break;
		}
	}
		IOBD_DEBUG_LEVEL2("process_data_packets exits\n");
}
