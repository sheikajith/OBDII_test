#include "application.h"
#include <standard_queue.h>
#include "standard.h"
#include <pthread.h>

int usb_app_init ()
{
	int rc = 0;
	standard_cli.usb_app.usb_q_id = usb_mq_init ("/usb_q");
	IOBD_DEBUG_LEVEL4 ("standard_cli.usb_app.usb_q_id %d", standard_cli.usb_app.usb_q_id); 
	rc = create_thread ();
	return rc;
}

int create_thread ()
{
	int rc = 0;
	if (pthread_create(&(standard_cli.usb_app.usb_thread_id), NULL, (void*) usb_notification_thread, NULL) != 0){
		IOBD_ERR(" pthread_create for usb_notification_thread failed. data will not be available! \r\n");
		rc = -1;
	}
	else{
		IOBD_DEBUG_LEVEL3 (" usb_notification_thread is created\n");
		if (pthread_detach (standard_cli.usb_app.usb_thread_id) != OBD2_APP_SUCCESS)
			IOBD_DEBUG_LEVEL2 ("pthread_detach failed %d",errno);
	}

	return rc;

}
mqd_t usb_mq_init(char *queue_name)
{
        struct mq_attr attr;
	mqd_t msg_queue_id;
        attr.mq_flags = 0;
        attr.mq_maxmsg = Q_MAX_MSG;

        attr.mq_msgsize = MAX_MSG_SIZE;

        attr.mq_curmsgs = 0;

#if 0
        /* Destroy the queue if exists */
        if(mq_unlink("/usb_q")==-1)
                IOBD_DEBUG_LEVEL4("1.Message queue delete failed ERROR--- %d \r\n",errno);
#endif
        msg_queue_id = mq_open(queue_name, O_CREAT|O_RDONLY|O_NONBLOCK, NULL, &attr);

        if (msg_queue_id == -1)
        {
                IOBD_DEBUG_LEVEL2(" 2.Message queue create failed ERROR--- %d \r\n",errno);
                return OBD2_APP_FAILURE;
        }
        IOBD_DEBUG_LEVEL4(" obd_queue_id is %d\r\n",msg_queue_id);

        return msg_queue_id;
}

void usb_mq_deinit (mqd_t msg_queue_id)
{

	 if(mq_close(msg_queue_id)==-1){
                IOBD_DEBUG_LEVEL2(" Message queue close failed ERROR--- %d \r\n",errno);
	 }else{
                IOBD_DEBUG_LEVEL2(" Message queue close success \r\n");
	}

	if(mq_unlink("/usb_q")==-1){
                IOBD_DEBUG_LEVEL2(" Message queue delete failed ERROR--- %d \r\n",errno);
	}else{
                IOBD_DEBUG_LEVEL2(" Message queue delete success \r\n");
	}
}

int send_usb_msg_q(mqd_t msg_queue_id, struct mesg_buffer buffer)
{
        if (mq_send(msg_queue_id,(const char *) &buffer, sizeof(struct mesg_buffer),0)  == -1) {
                IOBD_DEBUG_LEVEL2("3.Message Queue send failed ERROR %d\r\n",errno);
		return OBD2_APP_FAILURE;
        }
        return OBD2_APP_SUCCESS;
}

int recv_usb_msg_q(mqd_t msg_queue_id, struct mesg_buffer *buffer, size_t size)
{
        if (mq_receive(msg_queue_id,(char *) buffer, size, 0)  == -1) {
		return OBD2_APP_FAILURE;
        }
        return OBD2_APP_SUCCESS;
}

void usb_notification_thread (void)
{
	int ret;
	char value[64];

	while (!dmClient.interrupt){
		if(appClient.appSleep == APP_SLEEP){
			break;
		}
		ret = recv_usb_msg_q (standard_cli.usb_app.usb_q_id, &usb_app.usb_msg_buf, 256);
		if (ret == EAGAIN){
			usleep (200000);
			continue;
		}
		if (ret == OBD2_APP_SUCCESS){
			switch (usb_app.usb_msg_buf.type)
			{
				case SIM_CONFIG_REQ:
					IOBD_DEBUG_LEVEL4("SIM_CONFIG_REQ received\n");
					set_sim_config();
					break;
				case CLOUD_CONFIG_REQ:
					IOBD_DEBUG_LEVEL4("CLOUD_CONFIG_REQ received\n");
					get_cloud_config ();	
					break;
				case GEN_SETTING_REQ:
					IOBD_DEBUG_LEVEL4("GEN_SETTING_REQ received\n");
					get_xml_content (SRC_XML_FILE, PARENT_NODE_FREQ, SAMPLE_FREQ, value);
					standard_cli.usb_app.freq.f_sampling = atoi(value);			
					get_xml_content (SRC_XML_FILE, PARENT_NODE_FREQ, CAN_SIGN_FREQ, value);
					standard_cli.usb_app.freq.f_can_sign = atoi(value);
					update_time_limit ();
					break;
					 
				case THRESHOLD_SET_REQ:
					IOBD_DEBUG_LEVEL4("THRESHOLD_SET_REQ received\n");
					evt_limits ();
					get_limit ();
					break;
					
				case IO_CONFIG_REQ:
					IOBD_DEBUG_LEVEL4("IO_CONFIG_REQ received\n");
					update_io_function();
					drive_gpio_state ();
					break;
					
				case FIRMWARE_UPGRADE:
					IOBD_DEBUG_LEVEL4("FIRMWARE_UPGRADE_REQ received\n");

					break;
				case BLACK_BOX:
					IOBD_DEBUG_LEVEL4("BLACK_BOX_REQ received\n");

					break;	
			}

		}
	}	
		IOBD_DEBUG_LEVEL2 ("usb_thread exits");
	
}

int write_sim_auth (SIM_CONF *sim)
{
	FILE *fp;

	IOBD_DEBUG_LEVEL4 ("write_sim_auth +\n");
	/*Delete existed Username in gprs_4g file*/
	system("sed -i '/^name/d' /etc/ppp/peers/gprs_4g");
	fp = fopen("/etc/ppp/peers/gprs_4g","a");
	if (fp == NULL)
		return -1;
	/*Write Username to gprs_4g file*/
	fprintf(fp,"name %s\n", sim->user_name);
	fclose(fp);

	/*Delete last line in chap-secrets file*/
        system("sed -i '3d' /etc/ppp/chap-secrets");
	fp = fopen("/etc/ppp/chap-secrets","a");
	if (fp == NULL)
		return -1;
        /*Write Username & Password to chap-secrets file*/
        fprintf(fp,"%s  *  %s \n", sim->user_name, sim->pass_word);
        fclose(fp);

	/*Delete last line in pap-secrets file*/
        system("sed -i '3d' /etc/ppp/pap-secrets");
	fp = fopen("/etc/ppp/pap-secrets","a");
	if (fp == NULL)
		return -1;
        /*Write Username & Password to chap-secrets file*/
        fprintf(fp,"%s  *  %s \n", sim->user_name, sim->pass_word);
        fclose(fp);
	IOBD_DEBUG_LEVEL4 ("write_sim_auth -\n");
	
	return 0;
}


int write_sim_config (SIM_CONF *sim)
{
	FILE *ppp;
	char sim_apn[64];
	char sim_access_pt[64];

	bzero (sim_apn,sizeof (sim_apn));
	bzero (sim_access_pt, sizeof(sim_access_pt));
	
	IOBD_DEBUG_LEVEL4 ("write_sim_config +\n");

	ppp = fopen ("/etc/ppp/chat/gprs", "w");
	if (ppp == NULL)
		return -1;

	strcpy (sim_apn,"OK AT+CGDCONT=1,\"IP\",\"");	      
	strcat (sim->apn,"\"\n");
	strcat (sim_apn, sim->apn);
	IOBD_DEBUG_LEVEL4 ("APN is %s\n",sim_apn);
	sprintf (sim_access_pt, "%s%s%s","OK ATDT", sim->access_pt,"\n");
	IOBD_DEBUG_LEVEL4 ("sim_access_pt is %s\n",sim_access_pt);
	fputs("ABORT \'BUSY\'\n",ppp);
        fputs("ABORT \'NO CARRIER\'\n",ppp);
        fputs("ABORT \'ERROR\'\n",ppp);
        fputs("\'\' AT\n",ppp);
        fputs(sim_apn, ppp);
        fputs(sim_access_pt, ppp);
        fputs("CONNECT \\c\n",ppp);

	fclose (ppp);	
	if (sim->is_password_req == 1)
		write_sim_auth (sim);

	IOBD_DEBUG_LEVEL4 ("write_sim_config -\n");
	
	return 0;
}

int set_sim_config ()
{
	int rc = 0;
	char value [64];
	int val = 0;
	
	bzero(value,sizeof(value));
	get_xml_content (SRC_XML_FILE, PARENT_NODE_SIM, FIELD_NAME_APN, value);
	if (strcmp(value,usb_app.sim_conf.apn) != 0)
		strcpy(usb_app.sim_conf.apn,value);
	IOBD_DEBUG_LEVEL4 ("usb_app.sim_conf.apn - %s",usb_app.sim_conf.apn);

	bzero(value,sizeof(value));
	get_xml_content (SRC_XML_FILE, PARENT_NODE_SIM, FIELD_NAME_ACCESS_PT, value);
	if (strcmp(value,usb_app.sim_conf.apn) != 0)
		strcpy(usb_app.sim_conf.access_pt,value);
	IOBD_DEBUG_LEVEL4 ("usb_app.sim_conf.access_pt - %s",usb_app.sim_conf.access_pt);

	bzero(value,sizeof(value));
	get_xml_content (SRC_XML_FILE, PARENT_NODE_SIM, FIELD_NAME_PASS_REQ, value);
	val = atoi (value);
	if (val != usb_app.sim_conf.is_password_req)
	usb_app.sim_conf.is_password_req = val;
	IOBD_DEBUG_LEVEL4 ("usb_app.sim_conf.is_password_req %d",usb_app.sim_conf.is_password_req);

	if (usb_app.sim_conf.is_password_req == 1)
	{
		bzero(value,sizeof(value));
		get_xml_content (SRC_XML_FILE, PARENT_NODE_SIM, FIELD_NAME_USER_NAME, value);
		strcpy(usb_app.sim_conf.user_name,value);
		IOBD_DEBUG_LEVEL4 ("usb_app.sim_conf.user_name - %s",usb_app.sim_conf.user_name);

		bzero(value,sizeof(value));
		get_xml_content (SRC_XML_FILE, PARENT_NODE_SIM, FIELD_NAME_PASSWORD, value);
		strcpy(usb_app.sim_conf.pass_word,value);
		IOBD_DEBUG_LEVEL4 ("usb_app.sim_conf.pass_word - %s",usb_app.sim_conf.pass_word);
	}

	bzero(value,sizeof(value));
	get_xml_content (SRC_XML_FILE, PARENT_NODE_SIM, FIELD_NAME_FLIGHT, value);
	val = atoi (value);
	if (val != usb_app.sim_conf.is_flight_mode_set){
		usb_app.sim_conf.is_flight_mode_set = val;
		if (usb_app.sim_conf.is_flight_mode_set == 1)
			flight_mode_on ();
		else if (usb_app.sim_conf.is_flight_mode_set == 0)
			flight_mode_off();
		IOBD_DEBUG_LEVEL4 ("usb_app.sim_conf.is_flight_mode_set %d",usb_app.sim_conf.is_flight_mode_set);
	}
	bzero(value,sizeof(value));
	get_xml_content (SRC_XML_FILE, PARENT_NODE_SIM, FIELD_NAME_SIM_MODE, value);
	val = atoi (value);
	if (val != usb_app.sim_conf.mode){
		usb_app.sim_conf.mode = atoi (value);
		IOBD_DEBUG_LEVEL4 ("usb_app.sim_conf.mode %d",usb_app.sim_conf.mode);

		if (usb_app.sim_conf.mode == 1)
			set_cell_network_mode (MODE_TYPE_2G);	
		else if (usb_app.sim_conf.mode == 2)	
			set_cell_network_mode (MODE_TYPE_3G);	
		else
			set_cell_network_mode (AUTOMODE);
	}
		
	rc = write_sim_config(&usb_app.sim_conf); 
		
	return rc;
}
