#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include "sota.h"


int start_sota_app ()
{
	int fd,ret;
	const char * myfifo = "/myfifo";
	char buf[8] = {0};

	ret = get_3g_fd();
	if (ret > 2){
		sprintf (buf,"%d",ret);
		printf ("sota_3g fd is %s\n",buf);
	}else{
		return -1;
	}
	/* write "Hi" to the FIFO */
	fd = open(myfifo, O_WRONLY| O_NONBLOCK);
	if (fd == -1){
		perror ("sota_open");
		return -errno;
	}
	if ((ret = write(fd, buf, strlen(buf))) == -1)
		perror ("sota_write");
	close(fd);

	return ret;
}
