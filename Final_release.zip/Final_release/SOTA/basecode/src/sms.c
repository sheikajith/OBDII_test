#include <stdio.h>
#include <stdlib.h>
#include <hal.h>
#include <sms.h>
#include <main.h>
#include <atoi.h>
#include <libxml2.h>
#include <debug.h>
#include <mqueue.h>
#include<standard_queue.h>
#include <sys/stat.h> 
#include <fcntl.h>           /* For O_* constants */

char sender_number[LENGTH];
/*
   to get the sender number and text message by  splitting the message format
   message format after executing the AT+CMGL=\"REC UNREAD\"
example:
+CMGL: 1,"REC UNREAD","AX-ARWINF",,"19/12/27,11:53:48+22"
One Airtel. One Bill. This new year enjoy best of Airtel's postpaid, Broadband, DTH and Fixedline services in a single bill. 
+CMGL: 2,"REC UNREAD","AX-ARWINF",,"19/12/27,11:53:48+22"
One Airtel. One Bill. This new year enjoy best of Airtel's postpaid, Broadband, DTH and Fixedline services in a single bill. 
+CMGL: 3,"REC UNREAD","+919108242527",,"20/01/06,15:39:10+22"
user1 123456 get 10

OK 
 */
int message_splitting (char *msg_ptr) 
{
	int index = ZERO;
	char *ptr = NULL;
	char *new_ptr = NULL;
	char token[MAX_FIELDS_BUF] = {0};
	/*checking for the received parameter is not equal to NULL*/
	if (msg_ptr == NULL)
	{
		return FAILURE;
	}
	while (1)
	{
		/*message is start with +CMGL so we are checking with this string*/
		if (strstr (msg_ptr, "+CMGL"))
		{
			DEBUG ("received response is = %s\n",msg_ptr);
			/*sender id is start with "\"+" so checking for this string*/
			ptr = strstr (msg_ptr, "\"+");
			if (ptr != NULL)
			{
				ptr++;
				memset (token, MEM_CLR, sizeof(token));
				/*sender id is end with next '"' charecter so till that we are reading */
				for (index = ZERO; *ptr != '\"'; index++, ptr++)
				{
					token[index] = *ptr;
				}
				/*sender id is stored in global variable to send response to command centre*/
				strcpy (sender_number, token);

				/*function call to check the whitelist number*/
				ret = compare_with_whitelist_number (token);
				/*validate return value to next process */
				if (ret == SUCCESS)
				{
					memset (token, MEM_CLR, sizeof(token));
					//DEBUG ("valid sender_id\n");
					for (; *ptr != '\n'; ptr++);
					ptr++;
					/*if more number of message received then read message till next message start 
					  i.e "+CMGL" this is string start of the every message*/
					if (strstr (ptr, "+CMGL"))
					{
						for (index = ZERO; *ptr != '+'; index++, ptr++)
						{
							if(index < MAX_FIELDS_BUF)
							{
								token[index] = *ptr;
							}
							else
							break;
						}
						ptr = strstr(ptr, "+CMGL");
					}
					/*if only one message is present in the buffer then it will read up to "OK"
					  means "OK" is the last string present after reading all messages*/
					else
					{
						new_ptr = strstr (ptr, "OK");
						for (index = ZERO; ptr != new_ptr; index++, ptr++)
						{
							if(index < MAX_FIELDS_BUF)
							{
								token[index] = *ptr;
							}
							else
							{
								break;
							}
						}
					}
					DEBUG ("token %sptr is %sINDEX is %d\n\n",token, ptr, index);

					if (strstr (token, "set 6:")){
						for (; *ptr != '\n'; ptr++);
						ptr++;
						for (index = ZERO;token[index];index++)
							if (token[index] == '\r' || token[index] == '\n')
								break;
						DEBUG ("*******INDEX is %d ptr is %s\ntoken is %s",index, ptr, &token[index-5]);
//						new_ptr = strstr (ptr, "OK");
						for (; *ptr != '\n'; ptr++, index++)
						//for (; ptr != new_ptr; index++, ptr++)
						{
							if(index < MAX_FIELDS_BUF )
							{
                                                                token[index] = *ptr;
                                                        }
							else
                                                        {
                                                                break;
                                                        }
						}
					DEBUG ("****sas-token buffer token is %s",token);
					}
					/*function call to check the message format if valid then 
					  process the message and send response to commannd centre*/
					ret = check_with_message_format (token);
					/*validate the return response to check with next message*/
					if (ret != SUCCESS)
					{
						ERROR("response is not sent to the command centre\n");
					}
					else
					{
						DEBUG("response send to command centre\n")
					}
				}
				/*pointer is assined to msg_ptr*/
					if (ptr != NULL && (new_ptr = strstr (ptr, "+CMGL")) != NULL){
						msg_ptr = new_ptr;
					}
					else{
						break;
					}
			}
			else
			{
				if (msg_ptr == NULL){
					DEBUG ("msg_ptr is NULL##################\n");
					break;
				}
				msg_ptr++;
				/*checking for the next message if message present it has beginning string as "+CMGL" checking for that*/
				ptr = strstr (msg_ptr, "+CMGL");
				if (ptr != NULL)
				{
					msg_ptr = ptr;
				}
				else
				{
					break;
				}
			}
		}else{
			break;
		}
	}
	return SUCCESS;
}
/*
   after getting the phone_number check with whitelist numbers
   in /sample.xml page having 20 whitelist number
   The number will check with 20 whitelist number
   if it is valid whitelist number then store in value to send response  message to command centre 
 */
int compare_with_whitelist_number (char *phone_number)
{
	int count = TRUE;
	char temp[MAX_VALUE] = {0};
	char ph_no[MAX_VALUE] = {0};


	/*checking for the received parameter is not equal to NULL*/
	if (phone_number == NULL)
	{
		return FAILURE;
	}
	while (count <= WHITELIST_NUMBER)
	{
		sprintf (temp, "Number%d", count);
		/*get the whiltelist number and compare with sender_id if is equal,it is valid sender id */
		get_xml_content (FILE_NAME, WHITELIST_NODE, temp, ph_no);
		if (strcmp (phone_number, ph_no) == SUCCESS)
		{
			DEBUG ("phone_number:%s\n", sender_number);
			return SUCCESS;
		}
		else
			count++;
	}
	DEBUG ("NOT valid whitelist number\n");
	return FAILURE;
}
/*
   if the message from the whitelist number then check with message format, userid and password
   for "set" command message format will be =>[username] [password] set [id_property]:[source];[threshold];[duration]
   so having max 7 token in format.and 5 tokens minimum
   for "get" command message format will be => [username] [password] get [id_property]
   so having only 4 tokens in format.
 */
int check_with_message_format (char msg_string[])
{
	char *ptr = NULL;
	int index = ZERO;
	int id_value = ZERO;
	char *ret_src = NULL;
	char buffer[MAX_LENGTH] = {0};
	char tokens[MAX_NUM][MAX_LENGTH] = {"\0"};
	/*checking for the received parameter is not equal to NULL*/
	if (msg_string == NULL) 
	{
		DEBUG ("in msg_string no sms has copied\n");
		return FAILURE;
	}
	/*tokenize the string with strtok message format having perticular delimiter one after the other*/
	/*if received message is not valid format then failure of the API*/
	if((ptr = strstr(msg_string, " ")) != NULL && index < MAX_LENGTH)
	{ 
		while(*msg_string != ' ')
		{
			buffer[index] = *msg_string;
			msg_string++;
			index++;
		}
		strcpy (tokens[USER],buffer);
		INFO("token1 = %s\n",tokens[USER]);
		memset(buffer, MEM_CLR, sizeof(buffer));
		index = ZERO;
	}
	else
	{
		DEBUG("invalid message format\n");
		return FAILURE;
	}
	msg_string++;
	if((ptr = strstr(msg_string, " ")) != NULL && index < MAX_LENGTH)
	{ 
		while(*msg_string != ' ')
		{
			buffer[index] = *msg_string;
			msg_string++;
			index++;
		}
		strcpy (tokens[PASSWORD_ID],buffer);
		INFO("token2 = %s\n",tokens[PASSWORD_ID]);
		memset(buffer, MEM_CLR, sizeof(buffer));
		index = ZERO;
	}
	else
	{
		DEBUG("invalid message format\n");
		return FAILURE;
	}
	msg_string++;
	if((ptr = strstr(msg_string, "get")) != NULL || (ptr = strstr(msg_string, "set")) != NULL)
	{
		if(strstr(msg_string, " "))
		{
			while(*msg_string != ' ')
			{
				buffer[index] = *msg_string;
				msg_string++;
				index++;
			}
			strcpy (tokens[COMMAND],buffer);
			INFO("token3 = %s\n",tokens[COMMAND]);
		}
		else if(strstr(msg_string, "\r\n"))
		{
			while(*msg_string != '\r')
			{
				buffer[index] = *msg_string;
				msg_string++;
				index++;
			}
			strcpy (tokens[COMMAND],buffer);
			INFO("token3 = %s\n",tokens[COMMAND]);
		}
		else
		{
			DEBUG("invalid message format\n");
			return FAILURE;
		}
		memset(buffer, MEM_CLR, sizeof(buffer));
		index = ZERO;

	}
	else
	{
		DEBUG("invalid message format\n");
		return FAILURE;
	}
	msg_string++;
	if(strcmp(tokens[COMMAND], "get") == SUCCESS)
	{
		if(strstr(msg_string, "\r\n"))
		{
			while(*msg_string != '\r')
			{
				buffer[index] = *msg_string;
				msg_string++;
				index++;
			}
			strcpy (tokens[ID_PROPERTY],buffer);
			INFO("token4 = %s\n",tokens[ID_PROPERTY]);
		}
		else
		{
			DEBUG("invalid message format\n");
			return FAILURE;
		}
	}
	if(strcmp(tokens[COMMAND], "set") == SUCCESS || strcmp(tokens[COMMAND], "setimmo") == SUCCESS)
	{
		if(strstr(msg_string, ":" ))
		{
			while(*msg_string != ':')
			{
				buffer[index] = *msg_string;
				msg_string++;
				index++;
			}
			if (strcmp(tokens[COMMAND], "setimmo") == SUCCESS){
				strcpy (tokens[IMMO_STATUS], buffer);
				INFO("token4 = %s\n",tokens[IMMO_STATUS]);
			}else{
				strcpy (tokens[ID_PROPERTY],buffer);
				INFO("token4 = %s\n",tokens[ID_PROPERTY]);
			}
			memset(buffer, MEM_CLR, sizeof(buffer));
			index = ZERO;
			msg_string++;
			if((ptr = strstr(msg_string, ";")) != NULL)
			{
				while(*msg_string != ';')
				{
					buffer[index] = *msg_string;
					msg_string++;
					index++;
				}
				strcpy (tokens[SOURCE],buffer);
				INFO("1.token5 = %s\n",tokens[SOURCE]);
				memset(buffer, MEM_CLR, sizeof(buffer));
				index = ZERO;
				msg_string++;
				if((ptr = strstr(msg_string, ";")) != NULL) 
				{
					while(*msg_string != ';')
					{
						buffer[index] = *msg_string;
						msg_string++;
						index++;
					}
					strcpy (tokens[THRESHOLD],buffer);
					INFO("token6 = %s\n",tokens[THRESHOLD]);
					memset(buffer, MEM_CLR, sizeof(buffer));
					index = ZERO;
				}
				else
				{
					if(strstr(msg_string, "\r\n"))
					{
						while(*msg_string != '\0')
						{
							buffer[index] = *msg_string;
							msg_string++;
							index++;
						}
						strcpy (tokens[THRESHOLD],buffer);
						INFO("token6 = %s\n",tokens[THRESHOLD]);
					}
					memset(buffer, MEM_CLR, sizeof(buffer));
					index = ZERO;
				}
				msg_string++;
				if(strstr(msg_string, "\r\n"))
				{
					while(*msg_string != '\0')
					{
						buffer[index] = *msg_string;
						msg_string++;
						index++;
					}
					strcpy (tokens[DURATION],buffer);
					INFO("token7 = %s\n",tokens[DURATION]);
					memset(buffer, MEM_CLR, sizeof(buffer));
					index = ZERO;
				}
			}
			else
			{
			//	if(strstr(msg_string, "\r\n"))
			//	{
					while(*msg_string != '\0')
					{
						buffer[index] = *msg_string;
						if (*msg_string == '&'){
							strcat(buffer,"amp;");
							index = index + 4;
						}
						msg_string++;
						index++;
					}
					if (strcmp(tokens[COMMAND], "setimmo") == SUCCESS){
						strcpy (tokens[DELAY], buffer);
						INFO("token5 = %s\n",tokens[DELAY]);
					}else{

						strcpy (tokens[SOURCE],buffer);
						INFO("token5 = %s len is %d\n",tokens[SOURCE], strlen (tokens[SOURCE]));
					}
			//	}
				memset(buffer, MEM_CLR, sizeof(buffer));
				index = ZERO;
			}
		}
		else
		{
			DEBUG("invalid message format\n");
			return FAILURE;
		}

	}
	/*argument validation to check wrong message format*/
	if (strcmp (tokens[USER],"\0") == SUCCESS || strcmp (tokens[PASSWORD_ID],"\0") == SUCCESS)
	{
		DEBUG("invalid message format\n");
		return FAILURE;
	}
	strcpy (user_msg_fmt.user_id, tokens[USER]);
	strcpy (user_msg_fmt.password, tokens[PASSWORD_ID]);
	/*function call to check the authentication*/
	ret = check_for_authentication (user_msg_fmt.user_id, user_msg_fmt.password);
	/*validation for the return value*/
	if (ret != SUCCESS)
	{
		DEBUG ("authentication fails\n");
		return FAILURE;
	}
	/*argument validation to check wrong message format*/
	if (strcmp (tokens[COMMAND], "\0") == SUCCESS)
	{
		DEBUG ("invalid message format\n");
		return FAILURE;
	}
	strcpy (user_msg_fmt.command, tokens[COMMAND]);
	/*check for the commands getinfo and getimmo*/
	if (strcmp (user_msg_fmt.command, "getinfo") == SUCCESS || strcmp (user_msg_fmt.command, "getimmo") == SUCCESS || strcmp (user_msg_fmt.command, "getfwver") == SUCCESS)
	{
		if (strcmp (tokens[ID_PROPERTY], "\0") != SUCCESS)
		{
			DEBUG ("invalid message format\n");
			return FAILURE;
		}
	}
	else
	{
		if(strcmp (user_msg_fmt.command, "get") == SUCCESS || strcmp (user_msg_fmt.command, "set") == SUCCESS)
		{
			if (!(strcmp (tokens[ID_PROPERTY], "\0")))
			{
				DEBUG ("invalid message format\n");
				return FAILURE;
			}
			else
			{
				/*atoi function is used to convert string to intiger and it will check with the proper id_property*/
				id_value = atoi_to_convert_string_to_intiger (tokens[ID_PROPERTY]);
				INFO ("id_value:%d\n", id_value);
				if (id_value == FAILURE)
				{
					DEBUG ("invalid id value in message\n");
					return FAILURE;
				}
				user_msg_fmt.id_property = id_value;
			}
		}
		/*check for the valid command set,get,getimmo,setimmo*/
		if (strcmp (user_msg_fmt.command, "get") == SUCCESS)
		{
			/*argument validation to check wrong messgae format*/
			if (strcmp (tokens[SOURCE], "\0") != SUCCESS)
			{
				DEBUG ("invalid message format\n");
				return FAILURE;
			}
		}
		else if (strcmp (user_msg_fmt.command, "set") == SUCCESS)
		{
			/*argument validation to check wrong message format*/
			if (strcmp (tokens[SOURCE], "\0") == SUCCESS)
			{
				DEBUG ("invalid message format\n");
				return FAILURE;
			}

			if (user_msg_fmt.id_property == SAS_TOKEN){
				for (index = 0;tokens[SOURCE][index]; index++){
					if (tokens[SOURCE][index] == '\r' || tokens[SOURCE][index] == '\n' ){
						tokens[SOURCE][index] = '\0';
						break;
					}
				}
				if (tokens[SOURCE] != NULL)
					ret_src = tokens[SOURCE];
				else
					ret_src = FAIL;
			}
			else{
				/*check for fomat of the source it does not contain the character same as like delim*/
				ret_src = check_with_source_value (id_value, tokens[SOURCE]);
			}
			/*validation for the return value*/
			INFO ("return value:%s\n",ret_src);
			if (ret_src == FAIL)
			{
				DEBUG ("invalid message format\n");
				return FAILURE;
			}
			if (id_value == HARSH_BRAKE_ID || id_value == HARSH_ACCELERATION_ID || id_value == CRASH || id_value == HARSH || id_value == OVERSPEED_ID)
			{
				if (strcmp (ret_src, SOURCE_ONE) == SUCCESS || strcmp (ret_src, SOURCE_TWO) == SUCCESS)
				{
					strcpy (user_msg_fmt.value, ret_src);
				}
				else
				{	
					DEBUG ("invalid source value\n");
					return FAILURE;
				}
			}
			else if (id_value == DOUT1 || id_value == DOUT2)
			{
				if (strcmp (ret_src, RELAY) == SUCCESS)
				{
					strcpy (user_msg_fmt.relay, ret_src);
					strcpy (user_msg_fmt.buzzer, BUZZER);
				}
				else if (strcmp (ret_src, BUZZER) == SUCCESS)
				{
					strcpy (user_msg_fmt.relay, ret_src);
					strcpy (user_msg_fmt.buzzer, RELAY);
				}
				else
				{
					DEBUG ("invalid source value\n");
					return FAILURE;
				}
			}
			else if (id_value == AIN1 || id_value == ODOMETER_ID) 
			{
				if (strcmp (ret_src, SOURCE_ONE) != SUCCESS)
				{
					DEBUG ("invalid source value\n");
					return FAILURE;
				}    
				strcpy (user_msg_fmt.value, ret_src);
			}
			else if (id_value == DIN1 || id_value == DIN2)
			{
				if (strcmp (ret_src, PANIC_BUTTON) == SUCCESS)
				{
					strcpy (user_msg_fmt.panic_button, ret_src);
					strcpy (user_msg_fmt.ignition_pin, IGNITION_PN);
				}
				else if (strcmp (ret_src, IGNITION_PN) == SUCCESS)
				{
					strcpy (user_msg_fmt.panic_button, ret_src);
					strcpy (user_msg_fmt.ignition_pin, PANIC_BUTTON);
				}
				else
				{
					DEBUG ("invalid source value\n");
					return FAILURE;
				}
			}
			else
				strcpy (user_msg_fmt.value, ret_src);
			/* validation condition with id_property to confirm message format*/
			if (id_value == HARSH_BRAKE_ID || id_value == HARSH_ACCELERATION_ID || id_value == OVERSPEED_ID || id_value == CRASH || id_value == HARSH || id_value == DOUT1 || id_value == DOUT2 || id_value == ODOMETER_ID || id_value == OSM) 
			{
				/*if user has entered the threshold value then it will copy the value*/ 
				if (strcmp (tokens[THRESHOLD], "\0"))
				{
					/*check for fomat of the source it does not contain the character same as like delim*/
					ret_src = check_with_threshold_value (tokens[THRESHOLD]); 
					/*validation for the return value*/
					INFO ("return value:%s\n",ret_src);
					if (ret_src == FAIL)
					{
						DEBUG ("invalid message format\n");
						return FAILURE;
					}
					if (id_value == DOUT1 || id_value == DOUT2)
					{
						if(strcmp (ret_src, PRIORITY_ONE) == SUCCESS )
						{
							strcpy (user_msg_fmt.threshold, ret_src );
						}
						else if(strcmp (ret_src, PRIORITY_TWO) == SUCCESS){
							strcpy (user_msg_fmt.threshold, "0");
						}
						else
						{
							DEBUG ("invalid source value\n");
							return FAILURE;
						}
					}
					else
						strcpy (user_msg_fmt.threshold, ret_src );
				}	
			}
			else
			{
				if (strcmp (tokens[THRESHOLD], "\0"))
				{
					DEBUG ("invalid message format\n");
					return FAILURE;
				} 
			}
			if (id_value == OVERSPEED_ID)
			{
				/*if user has entered the threshold value then it will copy the value*/ 
				if (strcmp (tokens[DURATION], "\0"))
				{
					/*check for fomat of the source it does not contain the character same as like delim*/
					ret_src = check_with_source_value (id_value, tokens[DURATION]); 
					INFO ("return value:%s\n",ret_src);
					/*validation for the return value*/
					if (ret_src == FAIL)
					{
						DEBUG ("invalid message format\n");
						return FAILURE;
					}
					strcpy (user_msg_fmt.duration, ret_src);
				}
			}
			else
			{
				if (strcmp (tokens[DURATION], "\0"))
				{
					DEBUG ("invalid message format\n");
					return FAILURE;
				}
			}
		}
		else if (strcmp (user_msg_fmt.command, "setimmo") == SUCCESS)
		{
			if (strcmp (tokens[IMMO_STATUS], "\0") == SUCCESS)
			{
				DEBUG ("invalid message format\n");
				return FAILURE;
			}
			ret_src = check_with_source_value (IMMOBILIZER, tokens[IMMO_STATUS]);
			//ret_src = check_source_value_for_immo (tokens[IMMO_STATUS]);
			if (ret_src != FAIL)
			{
				if (strcmp (ret_src, STATUS_ZERO) == SUCCESS || strcmp (ret_src, STATUS_ONE) == SUCCESS) 
				{
					strcpy (user_msg_fmt.immo_status, ret_src);
				}
				else
				{
					DEBUG ("invalid message format\n");
					return FAILURE;
				}
			}
			else
			{
				DEBUG ("invalid message format\n");
				return FAILURE;
			}
			if (strcmp (tokens[DELAY], "\0") != SUCCESS)
			{
				ret_src = check_with_threshold_value (tokens[DELAY]);
//				ret_src = check_source_value_for_immo (tokens[DELAY]);
				if(ret_src != FAIL)
				{
					strcpy (user_msg_fmt.delay, ret_src);
				}
				else
				{
					DEBUG ("invalid message format\n");
					return FAILURE;
				}
			}
		}                            
		else 
		{
			/* if command is other than set,get,getimmo,setimmo,getinfo */
			DEBUG ("invalid command in message format\n");
			return FAILURE;
		}
	}
	/*function call to process the set and get command*/
	ret = check_with_the_SET_GET_command (user_msg_fmt);
	if (ret != SUCCESS)
	{
		DEBUG ("can't set or get the value \n");
		return FAILURE;
	}
	else
	{
		return SUCCESS;
	}
}
/*
   this function will check for the authentication the user id and password is validated 
   if the user id and password are correct then function return success else failure.
   user_id and password are located in xml page get the information and compare with 
   value send by user.
 */
int check_for_authentication (char *userid, char *passwd)
{
	int count = TRUE;
	char username[LENGTH] = {0} ;
	char password[MAX_NUM] = {0} ;
	char usrpswd[LENGTH] = {0};
	if (userid == NULL || passwd == NULL)
	{	
		return FAILURE;
	}
	/*check with user id's and password's to autheticate message*/
	while (count <= USER_ID)
	{
		sprintf (username, "Username%d", count);
		/*function call to get the userid from xml page*/
		get_xml_content (FILE_NAME, AUTHENTICATION_USER, username, usrpswd);
		/*user id validation*/
		if (strcmp (userid, usrpswd) == SUCCESS)
		{
			sprintf (password, "Password%d", count);
			/*function call to get the password from xml page*/
			get_xml_content (FILE_NAME, AUTHENTICATION_USER, password, usrpswd);
			/*password validation*/
			if (strcmp (passwd, usrpswd) == SUCCESS)
			{
				DEBUG ("valid user_id and password\n");
				return SUCCESS;
			}
			else
			{
				count++;
			}
		}
		else
			count++;
	}
	return FAILURE;
}
/*
   if Authentication is success and message is valid format,depend on the command check with xml content
   if it is SET command then the whatever value getting from the command centre message  has to be set it into /sample.xml
   if the command is GET then the whatever values stored in the /sample.xml page that values will be exctracted and stored
 */
int check_with_the_SET_GET_command (user_info msg_fmt)
{
	char value_threshold[LENGTH] = {0}, value_source[LENGTH] = {0}, value_duration[LENGTH] = {0};
	char sas [512];
	//int flag = 0, relay_status;
	int delay_status;
	mesg_buffer_t msq_queue = {0};
	/*check for "get" command*/
	if (strcmp (msg_fmt.command, "get") == SUCCESS)
	{ 
		switch (msg_fmt.id_property)
		{
			case HOST_NAME:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_HOST, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, AZURE_HOST);
				break;
			case PORT:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_PORT, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, AZURE_PORT);
				break;
			case DEVICE_ID:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_DEVICE_ID, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, AZURE_DEVICE_ID);
				break;
			case DEVICE_TYPE:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_DEVICE_TYPE, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, AZURE_DEVICE_TYPE);
				break;
			case IOT_HUB_NAME:	
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_HUB_NAME, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, AZURE_HUB_NAME);
				break;
			case SAS_TOKEN:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_SAS_TOKEN, sas);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, sas);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, AZURE_SAS_TOKEN);
				break;
			case SAMPLING_FREQUENCY:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_FREQUENCY, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, GENERAL_FREQUENCY);
				break;
			case OSM:
				/*function call to get the current xml content from /samaple.xml page*/
                                get_xml_content (FILE_NAME, OSM_CONFIG, GENERAL_OSM_TIME, value_source);
		                get_xml_content (FILE_NAME, OSM_CONFIG, GENERAL_WAIT_TIME, value_threshold);
                                memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
                                sprintf (msg_fmt.source_threshold, "%s;%s", value_source, value_threshold);
                                memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
                                strcpy (msg_fmt.property_name, GENERAL_OSM_TIME);
				break;
			case CAN_SIGN:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_CAN_SIGN_PAYLOAD, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, GENERAL_CAN_SIGN_PAYLOAD);
				break;
			case FATIGUE_DETECTION:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_FATIGUE_DETECTION, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, GENERAL_FATIGUE_DETECTION);
				break;
			case IDLE_TIME:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_IDLE_TIME, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, GENERAL_IDLE_TIME);
				break;
			case HARSH_BRAKE_ID:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_SOURCE, value_source);
				get_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_THRESHOLD, value_threshold);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				sprintf (msg_fmt.source_threshold, "%s:%s", value_source, value_threshold);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, HARSH_BRAKE);
				break;
			case HARSH_ACCELERATION_ID:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_SOURCE, value_source);
				get_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_THRESHOLD, value_threshold);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				sprintf (msg_fmt.source_threshold, "%s:%s", value_source,value_threshold);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, HARSH_ACCELERATION);
				break;
			case CRASH:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, HARSH_CRASH, CRASH_SOURCE, value_source);
				get_xml_content (FILE_NAME, HARSH_CRASH, CRASH_THRESHOLD, value_threshold);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				sprintf (msg_fmt.source_threshold, "%s:%s", value_source, value_threshold);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, HARSH_CRASH);
				break;
			case HARSH:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, HARSH_FUNCTION, HARSH_SOURCE, value_source);
				get_xml_content (FILE_NAME, HARSH_FUNCTION, HARSH_THRESHOLD, value_threshold);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				sprintf (msg_fmt.source_threshold, "%s:%s", value_source, value_threshold);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, HARSH_FUNCTION);
				break;
			case OVERSPEED_ID:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, OVERSPEED, OVERSPEED_SOURCE, value_source);
				get_xml_content (FILE_NAME, OVERSPEED, OVERSPEED_THRESHOLD, value_threshold);
				get_xml_content (FILE_NAME, OVERSPEED, OVERSPEED_DURATION, value_duration);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				sprintf (msg_fmt.source_threshold, "%s:%s:%s", value_source, value_threshold, value_duration);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, OVERSPEED);
				break;
			case ODOMETER_ID:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, ODOMETER, ODOMETER_SOURCE, value_source);
				get_xml_content (FILE_NAME, ODOMETER, ODOMETER_THRESHOLD, value_threshold);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				sprintf (msg_fmt.source_threshold, "%s:%s", value_source, value_threshold);
				DEBUG ("ODOMETER in SWITCH is %s\n",msg_fmt.source_threshold);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, ODOMETER);
				break;
			case OVER_TEMPERATURE_ID:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, OVER_TEMPERATURE, OVERTEMP_THRESHOLD, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, OVER_TEMPERATURE);
				break;
			case RPM:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, RPM_SETTING, RPM_THRESHOLD, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, RPM_SETTING);
				break;
			case AIN1:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, AIN1_SETTING, AIN1_SOURCE, value_source);
				get_xml_content (FILE_NAME, IO_STATUS, AIN1_STATUS, value_threshold);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				sprintf (msg_fmt.source_threshold, "%s:%s", value_source, value_threshold);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, AIN1_SETTING);
				break;
			case DOUT1:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_SOURCE, value_source);
				get_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_VALUE, value_threshold);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				sprintf (msg_fmt.source_threshold, "%s:%s", value_source, value_threshold);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, DOUT1_SETTING);
				break;
			case DOUT2:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, DOUT2_SETTING, DOUT1_SOURCE, value_source);
				get_xml_content (FILE_NAME, DOUT2_SETTING, DOUT1_VALUE, value_threshold);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				sprintf (msg_fmt.source_threshold, "%s:%s", value_source, value_threshold);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, DOUT2_SETTING);
				break;
			case DIN1:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, DIN1_SETTING, DIN_SOURCE, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (value_source, MEM_CLR, sizeof(value_source));
				get_xml_content (FILE_NAME, DIN1_SETTING, DIN_VALUE, value_source);
				strcat(msg_fmt.source_threshold,";");
				strcat(msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, DIN1_SETTING);
				break;
			case DIN2:
				/*function call to get the current xml content from /samaple.xml page*/
				get_xml_content (FILE_NAME, DIN2_SETTING, DIN_SOURCE, value_source);
				memset (msg_fmt.source_threshold, MEM_CLR, MAX_NUM);
				strcpy (msg_fmt.source_threshold, value_source);
				memset (value_source, MEM_CLR, sizeof(value_source));
				get_xml_content (FILE_NAME, DIN2_SETTING, DIN_VALUE, value_source);
				strcat(msg_fmt.source_threshold,";");
				strcat(msg_fmt.source_threshold, value_source);
				memset (msg_fmt.property_name, MEM_CLR, strlen(msg_fmt.property_name));
				strcpy (msg_fmt.property_name, DIN2_SETTING);
				break;
			default:
				ERROR ("Not valid id_property\n");
				return FAILURE;
		}
	}
	/*check for the "set" command*/ 
	else if (strcmp (msg_fmt.command, "set") == SUCCESS)
	{
		switch (msg_fmt.id_property)
		{
			case HOST_NAME:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_HOST, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_HOST, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_CLOUD_AZURE_CONFIG_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case PORT:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_PORT, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME,CLOUD_AZURE,AZURE_PORT,value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_CLOUD_AZURE_CONFIG_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case DEVICE_ID:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_DEVICE_ID, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_DEVICE_ID, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_CLOUD_AZURE_CONFIG_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case DEVICE_TYPE:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_DEVICE_TYPE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_DEVICE_TYPE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_CLOUD_AZURE_CONFIG_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case IOT_HUB_NAME:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_HUB_NAME, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_HUB_NAME, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_CLOUD_AZURE_CONFIG_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case SAS_TOKEN:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_SAS_TOKEN, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, CLOUD_AZURE, AZURE_SAS_TOKEN, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_CLOUD_AZURE_CONFIG_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case SAMPLING_FREQUENCY:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_FREQUENCY, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_FREQUENCY, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_GEN_SET_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case OSM:
				/*function call to set content in /samaple.xml page*/
                                set_xml_content (FILE_NAME, OSM_CONFIG, GENERAL_OSM_TIME, msg_fmt.value);
                                /*for testing purpose we checking with setter value with getter value */
                                get_xml_content (FILE_NAME, OSM_CONFIG, GENERAL_OSM_TIME, value_source);
                                if (strcmp (msg_fmt.value, value_source) == SUCCESS)
                                {
                                        DEBUG ("value set properly\n");
                                }
                                /*if threshold value is entered by user then it will set the content otherwise not */
                                if (msg_fmt.threshold)
                                {
                                        /*function call to set content in /samaple.xml page*/
                                        set_xml_content (FILE_NAME, OSM_CONFIG, GENERAL_WAIT_TIME, msg_fmt.threshold);
                                        /*for testing purpose we checking with setter value with getter value */
                                        get_xml_content (FILE_NAME, OSM_CONFIG, GENERAL_WAIT_TIME, value_threshold);
                                        if (strcmp (msg_fmt.threshold, value_threshold) == SUCCESS)
                                        {
                                                DEBUG ("value set properly\n");
                                        }
                                }
				break;	
			case CAN_SIGN:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_CAN_SIGN_PAYLOAD, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_CAN_SIGN_PAYLOAD, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_GEN_SET_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case FATIGUE_DETECTION:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_FATIGUE_DETECTION, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_FATIGUE_DETECTION, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_GEN_SET_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case IDLE_TIME:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_IDLE_TIME, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, GENERAL_SETTING, GENERAL_IDLE_TIME, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_GEN_SET_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case HARSH_BRAKE_ID:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				get_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_CRASH, CRASH_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				get_xml_content (FILE_NAME, HARSH_CRASH, CRASH_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*if threshold value is entered by user then it will set the content otherwise not */
				if (msg_fmt.threshold)
				{
					/*function call to set content in /samaple.xml page*/
					set_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_THRESHOLD, msg_fmt.threshold);
					/*for testing purpose we checking with setter value with getter value */ 
					get_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_THRESHOLD, value_threshold);
					if (strcmp (msg_fmt.threshold, value_threshold) == SUCCESS)
					{
						DEBUG ("value set properly\n");
					 msq_queue.type =  SET_THRSLD_SET_REQ;
                                        send_msg_q(queue, msq_queue);
					}
				}
				break;
			case HARSH_ACCELERATION_ID:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				get_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_CRASH, CRASH_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				get_xml_content (FILE_NAME, HARSH_CRASH, CRASH_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*if threshold value is entered by user then it will set the content otherwise not */
				if (msg_fmt.threshold)
				{
					/*function call to set content in /samaple.xml page*/
					set_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_THRESHOLD, msg_fmt.threshold);
					/*for testing purpose we checking with setter value with getter value */ 
					get_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_THRESHOLD, value_threshold);
					if (strcmp (msg_fmt.threshold, value_threshold) == SUCCESS)
					{
						DEBUG ("value set properly\n");
					 msq_queue.type =  SET_THRSLD_SET_REQ;
                                        send_msg_q(queue, msq_queue);
					}
				}
				break;
			case CRASH:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_CRASH, CRASH_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, HARSH_CRASH, CRASH_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_SOURCE, msg_fmt.value);
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, HARSH_BRAKE, HARSH_BRAKE_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_SOURCE, msg_fmt.value);
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, HARSH_ACCELERATION, HARSH_ACCELERATION_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*if threshold value is entered by user then it will set the content otherwise not */
				if (msg_fmt.threshold)
				{
					/*function call to set content in /samaple.xml page*/
					set_xml_content (FILE_NAME, HARSH_CRASH, CRASH_THRESHOLD, msg_fmt.threshold);
					/*for testing purpose we checking with setter value with getter value */ 
					get_xml_content (FILE_NAME, HARSH_CRASH, CRASH_THRESHOLD, value_threshold);
					if (strcmp (msg_fmt.threshold, value_threshold) == SUCCESS)
					{
						DEBUG ("value set properly\n");
					 msq_queue.type =  SET_THRSLD_SET_REQ;
                                        send_msg_q(queue, msq_queue);
					}
				}
				break;
			case HARSH:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, HARSH_FUNCTION, HARSH_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, HARSH_FUNCTION, HARSH_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*if threshold value is entered by user then it will set the content otherwise not */
				if (msg_fmt.threshold)
				{
					/*function call to set content in /samaple.xml page*/
					set_xml_content (FILE_NAME, HARSH_FUNCTION, HARSH_THRESHOLD, msg_fmt.threshold);
					/*for testing purpose we checking with setter value with getter value */ 
					get_xml_content (FILE_NAME, HARSH_FUNCTION, HARSH_THRESHOLD, value_threshold);
					if (strcmp (msg_fmt.threshold, value_threshold) == SUCCESS)
					{
						DEBUG ("value set properly\n");
					 msq_queue.type =  SET_THRSLD_SET_REQ;
                                        send_msg_q(queue, msq_queue);
					}
				}
				break;
			case OVERSPEED_ID:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, OVERSPEED, OVERSPEED_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, OVERSPEED, OVERSPEED_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*if threshold value is entered by user then it will set the content otherwise not */
				if (msg_fmt.threshold)
				{
					/*function call to set content in /samaple.xml page*/
					set_xml_content (FILE_NAME, OVERSPEED, OVERSPEED_THRESHOLD, msg_fmt.threshold);
					/*for testing purpose we checking with setter value with getter value */ 
					get_xml_content (FILE_NAME, OVERSPEED, OVERSPEED_THRESHOLD, value_threshold);
					if (strcmp (msg_fmt.threshold, value_threshold) == SUCCESS)
					{
						DEBUG ("value set properly\n");
					}
				}
				/*if duration value is entered by user then it will set the content otherwise not */
				if (msg_fmt.duration)
				{
					/*function call to set content in /samaple.xml page*/
					set_xml_content (FILE_NAME, OVERSPEED, OVERSPEED_DURATION, msg_fmt.duration);
					/*for testing purpose we checking with setter value with getter value */ 
					get_xml_content (FILE_NAME, OVERSPEED, OVERSPEED_DURATION, value_duration);
					if (strcmp (msg_fmt.duration, value_duration) == SUCCESS)
					{
						DEBUG ("value set properly\n");
					 msq_queue.type =  SET_THRSLD_SET_REQ;
                                        send_msg_q(queue, msq_queue);
					}
				}
				break;
			case ODOMETER_ID:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, ODOMETER, ODOMETER_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, ODOMETER, ODOMETER_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*if threshold value is entered by user then it will set the content otherwise not */
				if (msg_fmt.threshold)
				{
					//function call to set content in /samaple.xml page
					set_xml_content (FILE_NAME, ODOMETER, ODOMETER_THRESHOLD, msg_fmt.threshold);
					/*for testing purpose we checking with setter value with getter value*/ 
					get_xml_content (FILE_NAME, ODOMETER, ODOMETER_THRESHOLD, value_threshold);
					if (strcmp (msg_fmt.threshold, value_threshold) == SUCCESS)
					{
						DEBUG ("value set properly\n");
					 msq_queue.type =  SET_THRSLD_SET_REQ;
                                        send_msg_q(queue, msq_queue);
					}
				}
				break;
			case OVER_TEMPERATURE_ID:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, OVER_TEMPERATURE, OVERTEMP_THRESHOLD, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, OVER_TEMPERATURE, OVERTEMP_THRESHOLD, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_THRSLD_SET_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case RPM:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, RPM_SETTING, RPM_THRESHOLD, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, RPM_SETTING, RPM_THRESHOLD, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_THRSLD_SET_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case AIN1:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, AIN1_SETTING, AIN1_SOURCE, msg_fmt.value);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, AIN1_SETTING, AIN1_SOURCE, value_source);
				if (strcmp (msg_fmt.value, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_IO_SET_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case DOUT1:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_SOURCE, msg_fmt.relay);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_SOURCE, value_source);
				if (strcmp (msg_fmt.relay, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, DOUT2_SETTING, DOUT2_SOURCE, msg_fmt.buzzer);
				/*for testing purpose we checking with setter value with getter value */ 
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				get_xml_content (FILE_NAME, DOUT2_SETTING, DOUT2_SOURCE, value_source);
				if (strcmp (msg_fmt.buzzer, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*if threshold value is entered by user then it will set the content otherwise not */
				if (msg_fmt.threshold)
				{
					/*function call to set content in /samaple.xml page*/
					set_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_VALUE, msg_fmt.threshold);
					/*for testing purpose we checking with setter value with getter value */ 
					get_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_VALUE, value_threshold);
					if (strcmp (msg_fmt.threshold, value_threshold) == SUCCESS)
					{
						DEBUG ("value set properly\n");
					 msq_queue.type =  SET_IO_SET_REQ;
                                        send_msg_q(queue, msq_queue);
					}
				}
				break;
			case DOUT2:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, DOUT2_SETTING, DOUT2_SOURCE, msg_fmt.relay);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, DOUT2_SETTING, DOUT2_SOURCE, value_source);
				if (strcmp (msg_fmt.relay, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_SOURCE, msg_fmt.buzzer);
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_SOURCE, value_source);
				if (strcmp (msg_fmt.buzzer, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*if threshold value is entered by user then it will set the content otherwise not */
				if (msg_fmt.threshold)
				{
					/*function call to set content in /samaple.xml page*/
					set_xml_content (FILE_NAME, DOUT2_SETTING, DOUT2_VALUE, msg_fmt.threshold);
					/*for testing purpose we checking with setter value with getter value */ 
					get_xml_content (FILE_NAME, DOUT2_SETTING,DOUT2_VALUE, value_threshold);
					if (strcmp (msg_fmt.threshold, value_threshold) == SUCCESS)
					{
						DEBUG("value set properly\n");
					 msq_queue.type =  SET_IO_SET_REQ;
                                        send_msg_q(queue, msq_queue);
					}
				}
				break;
#if 1
			case DIN1:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, DIN1_SETTING, DIN_SOURCE, msg_fmt.panic_button);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, DIN1_SETTING, DIN_SOURCE, value_source);
				if (strcmp (msg_fmt.panic_button, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, DIN2_SETTING, DIN_SOURCE, msg_fmt.ignition_pin);
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, DIN2_SETTING, DIN_SOURCE, value_source);
				if (strcmp (msg_fmt.ignition_pin, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_IO_SET_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
			case DIN2:
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, DIN2_SETTING, DIN_SOURCE, msg_fmt.panic_button);
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, DIN2_SETTING, DIN_SOURCE, value_source);
				if (strcmp (msg_fmt.panic_button, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
				}
				/*function call to set content in /samaple.xml page*/
				set_xml_content (FILE_NAME, DIN1_SETTING, DIN_SOURCE, msg_fmt.ignition_pin);
				memset (value_source, MEM_CLR, sizeof(value_source)); 
				/*for testing purpose we checking with setter value with getter value */ 
				get_xml_content (FILE_NAME, DIN1_SETTING, DIN_SOURCE, value_source);
				if (strcmp (msg_fmt.ignition_pin, value_source) == SUCCESS)
				{
					DEBUG ("value set properly\n");
					 msq_queue.type =  SET_IO_SET_REQ;
                                        send_msg_q(queue, msq_queue);
				}
				break;
#endif
			default:
				ERROR ("Not valid id_property\n");
				break;
				return FAILURE;
		}
	}
	else if (strcmp (msg_fmt.command,"getinfo") == SUCCESS)
	{
		char value_info[MAX_VALUE][LENGTH] = {"\0"};
		int index = ZERO;
		get_xml_content (FILE_NAME, CPU_STATUS, PROCESSOR, value_info[index]);
		index++;
		get_xml_content (FILE_NAME, CPU_STATUS, CLOCK_SPEED, value_info[index]);
		index++;
		get_xml_content (FILE_NAME, CPU_STATUS, DDR3_STATUS, value_info[index]);
		index++;
		get_xml_content (FILE_NAME, CPU_STATUS, NAND_FLASH, value_info[index]);
		index++;
		get_xml_content (FILE_NAME, IO_STATUS, AIN1_STATUS, value_info[index]);
		index++;
		get_xml_content (FILE_NAME, IO_STATUS, IGNITION_PIN, value_info[index]);
		index++;
		get_xml_content (FILE_NAME, GSM_GPRS, SIM_STATUS, value_info[index]);
		index++;
		get_xml_content (FILE_NAME, GSM_GPRS, NETWORK_STATUS, value_info[index]);
		index++;
		get_xml_content (FILE_NAME,SOFTWARE, LINUX_VERSION, value_info[index]);
		memset (msg_fmt.source_threshold, 0x0, MAX_NUM);
		sprintf (msg_fmt.source_threshold, "Processor,%s,Clock,%s,NAND,%s,DDR3,%s;Ignition,%s,AIN1,%s;sim status,%s,Network status,%s;Linux,%s", value_info[PROCESSOR_NAME], value_info[CLOCK], value_info[DDR], value_info[NAND], value_info[IGNITION], value_info[AIN1_VAL], value_info[SIM], value_info[NETWORK], value_info[LINUX]);
	}
	else if (strcmp(msg_fmt.command,"setimmo") == SUCCESS)
	{
		/*delay to set the relay status*/
		delay_status = atoi (msg_fmt.delay);
		DEBUG ("receive Immo_status is %s : %d msg_fmt.immo_status is %s\n",msg_fmt.delay, delay_status, msg_fmt.immo_status);
		sleep(delay_status);
		delay_status = 0;
		delay_status = atoi(msg_fmt.immo_status);
		DEBUG ("immo_status is %d\n",delay_status);
		/*check for the relay status*/
		get_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_SOURCE, value_source);
		if (strcmp (value_source, RELAY) == SUCCESS)
		{
			set_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_VALUE, msg_fmt.immo_status);
			set_xml_content (FILE_NAME, DOUT1_SETTING, DOUT_DELAY, msg_fmt.delay);
			set_gpio_value(DOUT1_GPIO, delay_status);		
			//flag = 1;
		}
		else
		{
			set_xml_content (FILE_NAME, DOUT2_SETTING, DOUT2_VALUE, msg_fmt.immo_status);
			set_xml_content (FILE_NAME, DOUT2_SETTING, DOUT_DELAY, msg_fmt.delay);
			set_gpio_value(DOUT2_GPIO, delay_status);		
			//flag = 1;
		}
	}
	else if (strcmp(msg_fmt.command,"getimmo") == SUCCESS)
	{
		get_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_SOURCE, value_source);
		if (strcmp (value_source, RELAY) == SUCCESS)
		{
			get_xml_content (FILE_NAME, DOUT1_SETTING, DOUT1_VALUE, value_threshold);
			strcpy (msg_fmt.immo_status, value_threshold);
			DEBUG ("DOUT1: msg_fmt.immo_status is %s\n", msg_fmt.immo_status);
			get_xml_content (FILE_NAME, DOUT1_SETTING, DOUT_DELAY, value_threshold);
			strcpy (msg_fmt.delay, value_threshold);
			DEBUG ("DOUT1: msg_fmt.delay is %s\n",msg_fmt.delay);
		}
		else
		{
			get_xml_content (FILE_NAME, DOUT2_SETTING, DOUT2_VALUE, value_threshold);
			strcpy (msg_fmt.immo_status, value_threshold);
			DEBUG ("DOUT2: msg_fmt.immo_status is %s\n", msg_fmt.immo_status);
			get_xml_content (FILE_NAME, DOUT2_SETTING, DOUT_DELAY, value_threshold);
			strcpy (msg_fmt.delay, value_threshold);
			DEBUG ("DOUT2: msg_fmt.delay is %s\n",msg_fmt.delay);
		}
	}
	else if(strcmp (msg_fmt.command, "getfwver") == SUCCESS)
	{
		strcpy(msg_fmt.fwver, FIRMWARE_VERSION);
	}
	else	
	{
		DEBUG ("Not Proper Command\n");
		return FAILURE;
	}
	/*function call to frame response*/
	ret = frame_the_response_message(msg_fmt);
	if (ret != SUCCESS)
	{
		ERROR ("Fail to frame response\n");
		return FAILURE;
	}
	return SUCCESS;
}

/*
   sending response to command centre for GET command\
 *get COMMAND RESPONSE is 
example:
if id_property having only one value
[Property Name], [ID Property]: [Host_name] 
if id_property having two value
[Property Name], [ID Property]: [source];[threshold]
function to send response to command command centre for SET\
 *set COMMAND response is
example:
Success ID [id_property]
 *getinfo COMMAND response is
 example
 [Tab Name1]: [Field_Name1],[Field_info], [Field_Name2],[Field_info],..;[Tab Name2]: [Field_Name1],[Field_info], [Field_Name2],[Field_info],...;..,etc., 
 *setimmo response is
 example
 Success Immo
 *getimmo response is
 example
Immo: [Immo_status];[delay]

 */ 
int frame_the_response_message (user_info msg_info)
{
	char msg_send[MAX_NUM] = {0};
	char c = ',', s = ':';
	if (strcmp (msg_info.command, "get") == SUCCESS)
	{
		sprintf(msg_send, "%s%c %d%c %s%c",msg_info.property_name, c, msg_info.id_property, s, msg_info.source_threshold, CTRL_Z);
	}
	else if (strcmp(msg_info.command, "set") == SUCCESS)
	{
		sprintf (msg_send, "Success ID %d%c",msg_info.id_property, CTRL_Z);
	}
	else if (strcmp (msg_info.command, "getinfo") == SUCCESS)
	{
		sprintf (msg_send, "%s%c", msg_info.source_threshold, CTRL_Z);
	}
	else if (strcmp (msg_info.command, "setimmo") == SUCCESS)
	{
		sprintf (msg_send, "Success immo%c", CTRL_Z);
	}
	else if (strcmp (msg_info.command, "getimmo") == SUCCESS)
	{
		sprintf (msg_send, "immo%c %s;%s%c", c, msg_info.immo_status, msg_info.delay, CTRL_Z);
	}
	else if(strcmp (msg_info.command, "getfwver") == SUCCESS)
        {
		sprintf (msg_send, "firmware_version: %s%c", msg_info.fwver, CTRL_Z);
        }
	else
	{
		DEBUG ("not valid command\n");
		return FAILURE;
	}
	/*function call to send command to command centre*/
	ret = send_sms (msg_send, sender_number);
	if (ret != SUCCESS)
	{
		DEBUG ("sms not sent to command centre\n");
		return FAILURE;
	} 
	return SUCCESS;
}

