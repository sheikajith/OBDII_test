#ifndef __HAL_H_
#define __HAL_H_

#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <termios.h>

/*#define TIME_STAMP      1
#define FIX_STATUS      2
#define CUR_LATITUDE    3
#define HEMISPHERE      4
#define CUR_LONGITUDE   5
#define GREENWICH       6
#define KNOT_SPEED      7
#define DIRECTION       8
#define FIELD_SIZE      100*/
#define SERIAL_PORT_ACM0     (0)
#define DATABITS        8
#define PARITY         'N'
#define STOPBITS        1
#define HANDSHAKE       1
#define USB_0          "/dev/ttyUSB2"
#define INFINITE_TIMEOUT        0
#define GPRS_POWER_ON           5
#define FIVE                    5
#define SIX                     6
#define SEVEN                   7
#define TWO                     2
#define ONE                     1



/* global declairation*/
int tty_fd;
fd_set read_fds, write_fds, except_fds;


int iW_Serial_SetDatabits (struct termios *TermiosPtr, int databits);
int iW_Serial_Init (int Serial_Port_Number,int baudrate);

#endif
