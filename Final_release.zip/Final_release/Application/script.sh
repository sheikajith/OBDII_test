result=`ps | grep -i "monitor.sh" | grep -v "grep" | wc -l`
if [ $result -ge 1 ]
then
echo "monitor.sh script is already running"
else
echo "monitor.sh script is not running"
sh /iwtest/Application/monitor.sh &
fi
