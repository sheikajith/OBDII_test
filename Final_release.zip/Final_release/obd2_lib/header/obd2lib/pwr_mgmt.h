#ifndef __PWR_MGMT__
#define __PWR_MGMT__

#define DEVICE_RESTART 1
#ifndef USB_2
#define USB_2		"/dev/ttyUSB2"
#endif
#define USB_3		"/dev/ttyUSB3"
#define USB_4		"/dev/ttyUSB4"
#define __TIMER__
#ifdef __TIMER__
#define TIMER_ENABLE			1
#define TIMER_DISABLE			0
#define SLEEP_TIME			900
#define NO_SLEEP_TIME			0
#define TIMER_CFG_FILE			"/dev/rtc0"
#define TIMER_WAKEUP_ALARM_ENABLE	"echo +%lu > /sys/class/rtc/rtc0/wakealarm"
#define TIMER_WAKEUP_ALARM_DISABLE	"echo 0 > /sys/class/rtc/rtc0/wakealarm" 
#endif

#define IGNITION_STAT_WITHOUT_DIP 0
#define IGNITION_STAT_WITH_DIP 1


#define IGNITION_STATE_ON 0
#define IGNITION_STATE_ON_VOLTAGE 2
#define IGNITION_STATE_ON_RESTART 1
#define IGNITION_STATE_DEVICE_REMOVED -1
#define IGNITION_STATE_BATTERY_DRAIN -2
#define IGNITION_STATE_OFF -3

#define PM_EVENT_IGN_ON_NORMAL			1
#define PM_EVENT_IGN_ON_RESTART			2
#define PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE	3
#define PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP	4
#define PM_EVENT_WAKE_DISCONNECTION		5
#define PM_EVENT_IGN_OFF_NORMAL			6
#define PM_EVENT_SLEEP_DISCONNECTION		7		
#define PM_EVENT_ACCEL_WAKE			8
#define PM_EVENT_SLEEP_MODE_OSM			9

#define OBDII_INIT			    		0
#define OBDII_IGNON_NORMAL				1
#define OBDII_IGNON_NORMAL_INDICATE_APP         	2
#define OBDII_IGNON_RESTART_SW_TRIGGER_OFF      	3
#define OBDII_IGNON_RESTART_BOARD_INIT          	4
#define OBDII_IGNON_RESTART_SW_WAIT             	5
#define OBDII_IGNON_RESTART_SW_COMPLETED        	6
#define OBDII_IGNON_RESTART_INDICATE_APP        	7
#define OBDII_VC_SW_TRIGGER_OFF                 	8
#define OBDII_VC_BOARD_INIT                     	9
#define OBDII_VC_SW_WAIT                        	10
#define OBDII_VC_SW_COMPLETED                   	11
#define OBDII_VC_INDICATE_APP                   	12
#define OBDII_BD_SW_TRIGGER_OFF                 	13
#define OBDII_BD_BOARD_INIT                     	14
#define OBDII_BD_SW_WAIT                        	15
#define OBDII_BD_SW_COMPLETED                   	16
#define OBDII_BD_INDICATE_APP                   	17
#define OBDII_BD_INDICATE_COMPLETED             	18
#define OBDII_IGNOFF_NORMAL                     	19
#define OBDII_IGNOFF_NORMAL_INDICATE_APP        	20
#define OBDII_IGNOFF_NORMAL_INDICATE_APP_COMPLETED      21
#define OBDII_REMOVE_DEVICE_REMOVED                     22
#define OBDII_REMOVE_SWITCH_MXC5                        23
#define OBDII_REMOVE_WAIT_FOR_PPP                       24
#define OBDII_DISCONNECT_INDICATE_TO_APP         	25
#define OBDII_DISCONNECT_INDICATE_APP_COMPLETE          26
#define OBDII_OFF_TRIGGER_OFF				27
#define OBDII_OFF_GPIO_OFF				28
#define OBDII_OFF_SLEEP					29
#define OBDII_OFF_START_SLEEP				30
#define OBDII_OFF_SLEEP_INDICATE_TO_APP			31
#define OBDII_OFF_WIFI_SWITCHING_OFF			32
#define OBDII_OFF_4G_SWITCHING_OFF			33
#define OBDII_OFF_4G_OFF				34
#define OBDII_RUNNING					35
#define OBDII_CRASH_DETECT_INDICATE_TO_APP		36
#define OBDII_CRASH_DETECT_INDICATE_APP_COMPLETE	37
#define OBDII_OSM_STARTED				38
#define OBDII_OSM_CALLBACK				39
#define OBDII_OSM_CALLBACK_COMPLETE			40
#endif
