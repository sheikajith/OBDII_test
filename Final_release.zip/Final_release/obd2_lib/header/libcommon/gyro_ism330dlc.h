#ifndef __GYROSCOPE_H__
#define __GYROSCOPE_H__


#define GYRO_MAIN_PATH 		"/sys/bus/iio/devices/iio:device"
#define GYRO_SUB_PATH_SCAN   	"/scan_elements"
#define GYRO_SUB_PATH_BUF    	"/buffer"
#define GYRO_EVENT_NAME		"gyro"
#define GYRO_INTERRUPT_X_AXIS 	"in_anglvel_x_en"
#define GYRO_INTERRUPT_Y_AXIS 	"in_anglvel_y_en"
#define GYRO_INTERRUPT_Z_AXIS 	"in_anglvel_z_en"
#define GYRO_BUFFER_ENABLE    	"enable"
#define ENABLE  		1
#define DISABLE 		0

typedef struct _gyroscope_api_priv
{
   double x,y,z;
} gyroscope_api_priv;

/* global declaration */
int gyro_init();
int gyro_sensor_init();
int gyro_deinit();
void gyroscope_read_thread (void);
int get_gyroscope(gyroscope_api_priv *g_data);

#endif /* #define __GYROSCOPE_H__ */
