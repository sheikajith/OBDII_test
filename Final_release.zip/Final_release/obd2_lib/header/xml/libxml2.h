#ifndef __LIBXML2__H
#define __LIBXML2__H 

#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <errno.h>

#define SEM_OPEN_FILE 	   	"/sem_16"
#define SRC_XML_FILE       	"/sample.xml"
#define DFL_SRC_XML_FILE       	"/default.xml"
#define PARENT_NODE_CLOUD  	"cloud_azure"
#define PARENT_NODE_HOME   	"home"
#define PARENT_NODE_IO_STAT 	"io_status"
#define PARENT_DIN1_SETTING     "din1"
#define PARENT_DIN2_SETTING     "din2"
#define CHILD_NODE_IMEI	   	"imei"
#define CHILD_NODE_INTBAT  	"int_bat"
#define CHILD_NODE_DEVICE_ID 	"device_id"
#define CHILD_NODE_IGN_PIN   	"ignition_pin"
#define CHILD_DIN_VALUE         "value"
#define OSM_CONFIG              "osm"
#define GENERAL_OSM_TIME        "osm_time"
#define GENERAL_WAIT_TIME       "wait_time"

sem_t *ret_value;

int get_xml_content(char *filename, char *parent_node,char *name, char *value);

int set_xml_content(char *filename, char *parent_node,char *name, char *value);

int sem_init_usb (const char *);
int sem_init_4g (const char *,sem_t *);

#endif /*__LIBXML2__H*/
