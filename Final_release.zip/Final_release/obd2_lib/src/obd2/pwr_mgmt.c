#include"thread.h"
#include <stdio.h>
#include"init.h"
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "common.h"
#include "obd2lib.h"
#include "pwr_mgmt.h"
#include "can_header.h"
#include "4g.h"
//extern sem_t *sem_ser;

//static long sleep_time = 0;
//static char time_buf[8];
int pm_thread (void)
{
	int con_status =0;
	short count = 0;
	int rc; 
	struct ign_stat ign_qdata;
	char ts[64] = {0};

//	memset (time_buf, '\0', sizeof(time_buf));
	/* Create link status thread */
	if (pthread_create(&(libClient.tid[1]), NULL, (void*) link_thread, NULL) != 0) {
		IOBD_DEBUG_LEVEL2 (" pthread_create for link_thread failed %d\r\n",errno);
		return errno;
	}
	else
		IOBD_DEBUG_LEVEL2 ("link thread created\n");

	if(pthread_create(&(libClient.tid[3]), NULL, (void *) key_event_thread, NULL) != 0) {
		IOBD_DEBUG_LEVEL2 (" pthread_create for link_thread failed %d\r\n",errno);
		return errno;
	}
	else
		IOBD_DEBUG_LEVEL3("key_event_thread created\n");

	sem_init(&libClient.sem_board_init,0,0);	
	if(pthread_create(&(libClient.tid[5]), NULL, (void *) board_thread, NULL) != 0) 
	{
		IOBD_DEBUG_LEVEL2 (" pthread_create for link_thread failed %d\r\n",errno);
		return errno;
	}

	while (1)
	{
		memset(ts,0,sizeof(ts));
		memset(ign_qdata.data,0,sizeof(ign_qdata.data));

		mq_receive(libClient.pwr_mgmt_qid,(char *) &ign_qdata, sizeof(struct ign_stat), NULL);
		IOBD_DEBUG_LEVEL2("msg_type = %d\r\n", ign_qdata.msg_type);
		strcpy(ts,ign_qdata.data);

		switch(ign_qdata.msg_type)
		{
			case PM_EVENT_IGN_ON_NORMAL:
				/*Accelerometer wakeup disable*/
                                system("i2cset -f -y 1 0x6a 0x58 0x0e");
				IOBD_DEBUG_LEVEL2("PM_EVENT_IGN_ON_NORMAL\r\n");
				update_device_state(&libClient,libClient.state,OBDII_IGNON_NORMAL);
				if(libClient.ign_fptr.ign_ON != NULL){
					update_device_state(&libClient,libClient.state,OBDII_IGNON_NORMAL_INDICATE_APP);
					libClient.ign_fptr.ign_ON(ts);
				}
				else
					IOBD_DEBUG_LEVEL2("invalid ignition_on function address\n");
				start_ignition_thread(&libClient,PM_EVENT_IGN_ON_NORMAL);
				break;
			case PM_EVENT_IGN_ON_RESTART:
				
				/*Accelerometer wakeup disable*/
                                rc = system("i2cset -f -y 1 0x6a 0x58 0x0e");
				if (rc < 0){
					printf ("i2cset failed in PM_EVENT_IGN_ON_RESTART\n");
					perror ("i2cset");
				}

				IOBD_DEBUG_LEVEL2("PM_EVENT_IGN_ON_RESTART\r\n");
				libClient.dev_sleep = DEV_WAKE;
				sem_wait(&libClient.sys_wake);	
				config_sleep_wake_trigger_off();
				/*Added bec board is rebooting when 4v4 is ON and by default reg00 value of bat charger IC is having wrong value as per datasheet 
				 * if R115 resistor is mounted then also reboot is not happening*/
                system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
                system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
                system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
                system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled
                /*!< Switch on power rail */
                switch_on_power_rail ();				
                /* Get the semaphore TIMER_ENABLE and start */
				tcflush(libClient.serial_intf.tty_fd, TCIOFLUSH);

				update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_SW_TRIGGER_OFF);
				IOBD_DEBUG_LEVEL3 ("PM_EVENT_IGN_ON_RESTART: config_sleep_wake_trigger_off");
#ifdef __TIMER__	
				config_wakeup_timer_trigger(TIMER_DISABLE,NO_SLEEP_TIME);
				IOBD_DEBUG_LEVEL3 ("PM_EVENT_IGN_ON_RESTART: TIMER DISABLED!!!!!!!");
#endif
				update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_BOARD_INIT);
				
				/* Wake Board init thread */
				sem_post(&libClient.sem_board_init);

				update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_SW_WAIT);
				/* Wait till board and Application initializes */
				wait_for_sys_wake_completed(PM_EVENT_IGN_ON_RESTART);

				/* Release the semaphore */
				sem_post(&libClient.sys_wake);	
//				sem_post(&libClient.ign_of_sem);

				update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_SW_COMPLETED);

				if(libClient.ign_fptr.ign_ON != NULL){
					update_device_state(&libClient,libClient.state,OBDII_IGNON_RESTART_INDICATE_APP);
					libClient.ign_fptr.ign_ON(ts);
				}
				else
					IOBD_DEBUG_LEVEL2("invalid ignition_on function address\n");

				start_ignition_thread(&libClient,PM_EVENT_IGN_ON_RESTART);
				break;

			case PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE:

                /*Accelerometer wakeup disable*/
                system("i2cset -f -y 1 0x6a 0x58 0x0e");

                IOBD_DEBUG_LEVEL2("PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE\r\n");
                libClient.dev_sleep = DEV_WAKE;
                /* Get the semaphore and start */
				sem_wait(&libClient.sys_wake);	

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_TRIGGER_OFF);
				//config_sleep_wake_trigger_off();

				/* Wake Board init thread */
				update_device_state(&libClient,libClient.state,OBDII_VC_BOARD_INIT);
				sem_post(&libClient.sem_board_init);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_WAIT);
				/* Wait till board and Application initializes */
				wait_for_sys_wake_completed(PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE);

				/* Release the semaphore */
				sem_post(&libClient.sys_wake);	

//                                sem_post(&libClient.ign_of_sem);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_COMPLETED);

				if(libClient.ign_fptr.ign_ON != NULL){
					update_device_state(&libClient,libClient.state,OBDII_VC_INDICATE_APP);
					libClient.ign_fptr.ign_ON(ts);
				}

				start_ignition_thread(&libClient,PM_EVENT_IGN_ON_VOLTAGE_CHANGE_WAKE);	
                break;

            case PM_EVENT_ACCEL_WAKE:

                /*Accelerometer wakeup disable*/
                system("i2cset -f -y 1 0x6a 0x58 0x0e");

                IOBD_DEBUG_LEVEL3("PM_EVENT_ACCEL_WAKE+\r\n");

                sem_wait(&libClient.sys_wake);

                IOBD_DEBUG_LEVEL2("PM_EVENT_ACCEL_WAKE-\r\n");
                update_device_state(&libClient,libClient.state,OBDII_VC_SW_TRIGGER_OFF);
                /* Wake Board init thread */
                update_device_state(&libClient,libClient.state,OBDII_VC_BOARD_INIT);
                /*Release board_init Semaphore*/
                //sem_post(&libClient.sem_board_init);

                update_device_state(&libClient,libClient.state,OBDII_VC_SW_WAIT);
#if 1 // commented during sms-wake up

                system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
                system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
                system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
                system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled

#endif
                switch_on_power_rail();
                board_init_4g_uart();
				/* Wait till board and Application initializes */
				wait_for_sys_wake_completed(PM_EVENT_ACCEL_WAKE);
				/* Release the semaphore */
				sem_post(&libClient.sys_wake);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_COMPLETED);

                                if(libClient.ign_fptr.crash_det != NULL){
                                        update_device_state(&libClient,libClient.state,OBDII_CRASH_DETECT_INDICATE_TO_APP);
                                        libClient.ign_fptr.crash_det(ts);
                                        update_device_state(&libClient,libClient.state,OBDII_CRASH_DETECT_INDICATE_APP_COMPLETE);
                                }
                                /*push device to sleep*/
                                push_device_to_sleep(&libClient, PM_EVENT_ACCEL_WAKE);
				libClient.dev_sleep = DEV_SLEEP;
                                break;

			case PM_EVENT_SLEEP_DISCONNECTION :

				/*Accelerometer wakeup disable*/
				system("i2cset -f -y 1 0x6a 0x58 0x0e");				
#ifdef __TIMER__	
				/*configuring the timer for 15min*/
				config_wakeup_timer_trigger(TIMER_ENABLE,SLEEP_TIME);
				IOBD_DEBUG_LEVEL2 ("PM_EVENT_SLEEP_DISCONNECTION: TIMER CONFIGURED FOR 15MIN WAKEUP!!!!!!!");
#endif
				sem_wait(&libClient.sys_wake);
				update_device_state(&libClient,libClient.state,OBDII_VC_SW_TRIGGER_OFF);
				/* Wake Board init thread */
                                update_device_state(&libClient,libClient.state,OBDII_VC_BOARD_INIT);
				/*Release board_init Semaphore*/
                                sem_post(&libClient.sem_board_init);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_WAIT);
                                /* Wait till board and Application initializes */
                                wait_for_sys_wake_completed(PM_EVENT_SLEEP_DISCONNECTION);
				/* Release the semaphore */
                                sem_post(&libClient.sys_wake);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_COMPLETED);
				
				if(libClient.ign_fptr.dis_stat != NULL){
					update_device_state(&libClient,libClient.state,OBDII_DISCONNECT_INDICATE_TO_APP);
					libClient.ign_fptr.dis_stat(ts);
					update_device_state(&libClient,libClient.state,OBDII_DISCONNECT_INDICATE_APP_COMPLETE);
				}
				/*push device to sleep*/
				rc = push_device_to_sleep(&libClient, PM_EVENT_SLEEP_DISCONNECTION);
				if (rc == IGNITION_STATE_OFF)
					libClient.dev_sleep = DEV_SLEEP;
                                break;

			case PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP:

				IOBD_DEBUG_LEVEL2("PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP\r\n");
                                system("i2cset -f -y 1 0x6a 0x58 0x8e");

				libClient.dev_sleep = DEV_WAKE;
				/* Get the semaphore and start */
				sem_wait(&libClient.sys_wake);	

				update_device_state(&libClient,libClient.state,OBDII_BD_SW_TRIGGER_OFF);
				//config_sleep_wake_trigger_off();

				update_device_state(&libClient,libClient.state,OBDII_BD_BOARD_INIT);
				update_device_state(&libClient,libClient.state,OBDII_BD_SW_WAIT);
				/*Initialise Board init*/
				board_init_4g_uart();
#if 0
				/* Wake Board init thread */
				sem_post(&libClient.sem_board_init);
#endif
				/* Wait till board and Application initializes */
				wait_for_sys_wake_completed(PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP);

				/* Release the semaphore */
				sem_post(&libClient.sys_wake);	
				update_device_state(&libClient,libClient.state,OBDII_BD_SW_COMPLETED);

				if(libClient.ign_fptr.bat_drain != NULL){
					update_device_state(&libClient,libClient.state,OBDII_BD_INDICATE_APP);
					libClient.ign_fptr.bat_drain(ts);
					update_device_state(&libClient,libClient.state,OBDII_BD_INDICATE_COMPLETED);
				}
				else
					IOBD_DEBUG_LEVEL2("invalid battery_drain function address\n");

				rc = push_device_to_sleep(&libClient, PM_EVENT_IGN_ON_BATTERY_DRAIN_WAKEUP);
				if (rc == IGNITION_STATE_OFF)
					libClient.dev_sleep = DEV_SLEEP;
				break;

			case PM_EVENT_IGN_OFF_NORMAL:

				/* Get the semaphore and start */
//				sem_wait(&libClient.ign_of_sem);

				update_device_state(&libClient,libClient.state,OBDII_IGNOFF_NORMAL);
				if(libClient.ign_fptr.ign_OFF != NULL){
					update_device_state(&libClient,libClient.state,OBDII_IGNOFF_NORMAL_INDICATE_APP);
					libClient.ign_fptr.ign_OFF(ts);
//					wait_for_indicate_ignition_off_completed();

					update_device_state(&libClient,libClient.state,OBDII_IGNOFF_NORMAL_INDICATE_APP_COMPLETED);
				}
				else
					IOBD_DEBUG_LEVEL2("invalid ignition_off function address\n");
				rc = push_device_to_sleep(&libClient, PM_EVENT_IGN_OFF_NORMAL);
				if (rc == IGNITION_STATE_OFF)
					libClient.dev_sleep = DEV_SLEEP;
				break;

			/*Added for online sleep mode wakeup*/
			case PM_EVENT_SLEEP_MODE_OSM:
				sem_wait(&libClient.sys_wake);
				update_device_state(&libClient,libClient.state,OBDII_OSM_STARTED);
				/* Wake Board init thread */
                                update_device_state(&libClient,libClient.state,OBDII_VC_BOARD_INIT);
				/*Release board_init Semaphore*/
                                sem_post(&libClient.sem_board_init);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_WAIT);
                                /* Wait till board and Application initializes */
                                wait_for_sys_wake_completed(PM_EVENT_SLEEP_MODE_OSM);
				/* Release the semaphore */
                                sem_post(&libClient.sys_wake);

				update_device_state(&libClient,libClient.state,OBDII_VC_SW_COMPLETED);
				
				if(libClient.ign_fptr.osm_cb != NULL){
					update_device_state(&libClient,libClient.state,OBDII_OSM_CALLBACK);
					libClient.ign_fptr.osm_cb(ts);
					update_device_state(&libClient,libClient.state,OBDII_OSM_CALLBACK_COMPLETE);
				}
				/*push device to sleep*/
				rc = push_device_to_sleep(&libClient, PM_EVENT_SLEEP_MODE_OSM);
				if (rc == IGNITION_STATE_OFF)
					libClient.dev_sleep = DEV_SLEEP;

				break;

			case PM_EVENT_WAKE_DISCONNECTION:
				
				/*Accelerometer wakeup disable*/
				system("i2cset -f -y 1 0x6a 0x58 0x0e");				
#ifdef __TIMER__	
				/*configuring the timer for 15min*/	
				config_wakeup_timer_trigger(TIMER_ENABLE,SLEEP_TIME);
                IOBD_DEBUG_LEVEL2 ("PM_EVENT_WAKE_DISCONNECTION: TIMER CONFIGURED FOR 15MIN WAKEUP!!!!!!!");
#endif
				/* Get the semaphore and start */
				sem_wait(&libClient.ign_of_dis);
			
				update_device_state(&libClient,libClient.state,OBDII_REMOVE_DEVICE_REMOVED);
					update_device_state(&libClient,libClient.state,OBDII_REMOVE_WAIT_FOR_PPP);

					/* Wait for connection for 40 seconds, If no network, go to sleep */
					while(1){
						con_status = check_connection();
						if (con_status == 1 ){
							/* sending disconnection status */
							if(libClient.ign_fptr.dis_stat != NULL){
								update_device_state(&libClient,libClient.state,OBDII_DISCONNECT_INDICATE_TO_APP);
								libClient.ign_fptr.dis_stat(ts);
								update_device_state(&libClient,libClient.state,OBDII_DISCONNECT_INDICATE_APP_COMPLETE);
							}
							break;
						}
						sleep(1);
						count++;
						if (count == 40)
							break;
					}
				

				/* Release the semaphore */
				sem_post(&libClient.ign_of_dis);

				rc = push_device_to_sleep(&libClient, PM_EVENT_WAKE_DISCONNECTION);
				if (rc == IGNITION_STATE_OFF)
					libClient.dev_sleep = DEV_SLEEP;
				break;
			default:
				IOBD_DEBUG_LEVEL3 ("Invalid packet type for power management \n");
		}
	}
}


int switch_on_power_rail ()
{
	int rc = OBD2_LIB_SUCCESS;

	/*!< 12 V Switch */
	IOBD_DEBUG_LEVEL3 ("12 V Regulator on");
	rc = set_gpio_value(REG_12V, GPIO_HIGH);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_12V on Failed %d",rc);
	/*!< 3V3 Switch */
	rc = set_gpio_value(REG_3V3, GPIO_HIGH);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_3V3 on Failed %d",rc);
	/*!< 4V4 Switch */
	rc = set_gpio_value(REG_4V4, GPIO_HIGH);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_4V4 on Failed %d",rc);
	IOBD_DEBUG_LEVEL3 ("4V4 Regulator on");
	/*!< Interpreter CAN ON */
	rc = set_gpio_value(INTERPRETTER_CAN_EN, GPIO_LOW);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("INTERPRETTER_CAN_EN on Failed %d",rc);
	/*!< CPU CAN OFF */
	rc = set_gpio_value(CPU_CAN_EN, GPIO_HIGH);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("CPU_CAN_EN on Failed %d",rc);
	
	return rc;
}

int switch_off_power_rail ()
{
	int rc = OBD2_LIB_SUCCESS;
	/*!< 12 V Switch */
	IOBD_DEBUG_LEVEL3 ("12 V Regulator off");
	rc = set_gpio_value(REG_12V, GPIO_LOW);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_12V off Failed %d",rc);
	/*!< 4V4 Switch */
	rc = set_gpio_value(REG_4V4, GPIO_LOW);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_4V4 off Failed %d",rc);
	/*!< 3V3 Switch */
	rc = set_gpio_value(REG_3V3, GPIO_LOW);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("REG_3V3 off Failed %d",rc);
	/*!< Interpreter CAN SHUTDOWN */
	rc = set_gpio_value(INTERPRETTER_CAN_EN, GPIO_HIGH);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("INTERPRETTER_CAN_EN off Failed %d",rc);
	/*!< CPU CAN SHUTDOWN */
	rc = set_gpio_value(CPU_CAN_EN, GPIO_HIGH);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("CPU_CAN_EN off Failed %d",rc);
	/*!< BATTERY_Charge is disbaled*/
	rc = set_gpio_value(BATTERY_CE, GPIO_HIGH);
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("BATTERY_CE off Failed %d",rc);
	return rc;
}

int push_device_to_sleep(_libClient * libclient,int type)
{
	struct ign_stat ign_qdata;
    char ts[64] = {0};
    int rc = 0;

    long sleep_time = 0;
    char time_buf[8];

    IOBD_DEBUG_LEVEL2("push_device_to_sleep type %d \n",type);
    update_device_state(&libClient,libClient.state,OBDII_OFF_START_SLEEP);
	
	if(libclient->s_w.slp != NULL){
		update_device_state(&libClient,libClient.state,OBDII_OFF_SLEEP_INDICATE_TO_APP);
		IOBD_DEBUG_LEVEL3(" Call application sleep handler callback \n");
		libclient->s_w.slp();
	}
	else{
		IOBD_DEBUG_LEVEL2("Sleep handler not provided for application \n");
	}

	update_device_state(&libClient,libClient.state,OBDII_OFF_4G_SWITCHING_OFF);
	rc = module_3g_off();
	if (rc < 0)
		IOBD_DEBUG_LEVEL2 ("module_3g_off failed\n");
	update_device_state(&libClient,libClient.state,OBDII_OFF_4G_OFF);

	rc = check_ign_status(IGNITION_STAT_WITHOUT_DIP);
#if 0
#ifdef __TIMER__
	if (rc == IGNITION_STATE_OFF)
		config_wakeup_timer_trigger(TIMER_DISABLE,NO_SLEEP_TIME);
#endif
#endif
	IOBD_DEBUG_LEVEL4("pm_thread ret is %d\r\n", rc);
	if(rc == IGNITION_STATE_ON)
	{
		get_time(ts);
		memset(ign_qdata.data,0x0,256);
		ign_qdata.msg_type = PM_EVENT_IGN_ON_RESTART;
		IOBD_DEBUG_LEVEL4("send saved time stamp %s \n",ts);
		strcpy(ign_qdata.data,ts);
		rc = send_ign_q(libclient,&ign_qdata);
		return DEVICE_RESTART;
	}

	update_device_state(&libClient,libClient.state,OBDII_OFF_TRIGGER_OFF);

	rc = config_sleep_wake_trigger_on();
	if (rc == IGNITION_STATE_ON_RESTART){
		get_time(ts);
		memset(ign_qdata.data,0x0,256);
		ign_qdata.msg_type = PM_EVENT_IGN_ON_RESTART;
		strcpy(ign_qdata.data,ts);
		rc = send_ign_q(libclient,&ign_qdata);
		return DEVICE_RESTART;
	}

#ifdef __TIMER__	
	/*Added for online sleep mode wakeup*/
	if (type == PM_EVENT_SLEEP_MODE_OSM || type == PM_EVENT_ACCEL_WAKE || type == PM_EVENT_IGN_OFF_NORMAL){
		/*configuring the timer for Xmin*/
        memset (time_buf, '\0', sizeof(time_buf));
//		get_xml_content (SRC_XML_FILE, OSM_CONFIG, GENERAL_OSM_TIME, time_buf);
//		sleep_time = atol (time_buf);
		sleep_time = 20;
		config_wakeup_timer_trigger(TIMER_ENABLE,sleep_time);
		/*Accelerometer wakeup enable*/
                system("i2cset -f -y 1 0x6a 0x58 0x8e");
	}
#endif
	update_device_state(&libClient,libClient.state,OBDII_OFF_GPIO_OFF);

	switch_off_power_rail ();	
	libClient.system_wake_timer = 0;
	libClient.system_wake_acc = 0;
	update_device_state(&libClient,libClient.state,OBDII_OFF_SLEEP);
	rc = check_interpretter_sleep ();
	return IGNITION_STATE_OFF;
}

int check_interpretter_sleep ()
{
	int ret = 0;
	struct timespec time_out;
	char ts[64] = {0};
        struct ign_stat ign_qdata;

	if (clock_gettime(CLOCK_REALTIME, &time_out) == -1)
		IOBD_DEBUG_LEVEL3 ("clock_gettime error");
	time_out.tv_sec += 10;
	ret = sem_timedwait( &libClient.ign_off_restart, &time_out );
	if(ret < 0){
		IOBD_DEBUG_LEVEL3(" sem_wait returned. errno %d \n",errno);
		memset(ign_qdata.data,0,sizeof(ign_qdata.data));
		get_time(ts);
		ign_qdata.msg_type = PM_EVENT_IGN_ON_RESTART;
		IOBD_DEBUG_LEVEL3("send saved time stamp %s \n",ts);
		strcpy(ign_qdata.data,ts);
		send_ign_q(&libClient,&ign_qdata);
	}
		IOBD_DEBUG_LEVEL3("wait_for_3_sec_check_interpretter_sleep %d\n",ret);

return ret;
}
int wait_for_indicate_battery_drain_completed()
{
	int ret = 0;
	/* Wait until Application indicates sys wake */
	IOBD_DEBUG_LEVEL3("wait_for_battery_drain_completed  + \n");
	ret = sem_wait(&libClient.btry_drain);	
	if (ret == OBD2_LIB_FAILURE)
		ret = errno;
	IOBD_DEBUG_LEVEL3("wait_for_battery_drain_completed  - \n");
	return ret;
}


int wait_for_indicate_ignition_off_completed()
{
	int ret = 0;
	struct timespec time_out;

	/* Wait for the semaphore with timeout.
	   Otherwise device will not move to power save mode,
	   if application fails to indicate the ignition off completion
	 */

	if (clock_gettime(CLOCK_REALTIME, &time_out) == -1)
	{
		IOBD_DEBUG_LEVEL3("clock_get_time error \n");

		/* If get time fails, go without timeout */
		/* Wait until Application indicates sys wake */

	}
	else{
	}
	return ret;
}

int wait_for_sys_wake_completed(int type)
{
       	int ret = 0;
	/* Wait until Application indicates sys wake */
	IOBD_DEBUG_LEVEL3("wait_for_sys_wake_completed type %d + \n",type);
	ret = sem_wait(&libClient.sys_wake);	
	IOBD_DEBUG_LEVEL2("wait_for_sys_wake_completed type %d - \n",type);
        if (ret == OBD2_LIB_FAILURE)
                ret = errno;
        return ret;
}


int start_ignition_thread(_libClient * libclient,int type)
{
       	int ret = 0;
	IOBD_DEBUG_LEVEL2("start_ignition_thread type %d + \n",type);
	update_device_state(&libClient,libClient.state,OBDII_RUNNING);
	ret = sem_post(&libclient->ign_t_sem);
        if (ret == OBD2_LIB_FAILURE)
                ret = errno;
        return ret;
}

int update_device_state(_libClient * libclient,int prev_state,int new_state)
{
	IOBD_DEBUG_LEVEL4("Device state moving from (%d) -> (%d) \n",prev_state,new_state);
	libclient->state = new_state;
	return 0;
}


void ignition_thread (void)
{
	struct ign_stat ign_qdata;
	int rc = 0;
	char ts[64] = {0};

	while (libClient.obdflag !=1)
	{
		sleep(1);
	}
	IOBD_DEBUG_LEVEL3("while ignition thread............ \n");
	while(1)
	{
		/* check for ignition status */
		IOBD_DEBUG_LEVEL3("get ign_t_sem +\n");
		/* If some data has sent to power management thread, then pm_thread will release the semaphore.
		   Otherwise, own thread will post
		 */

		/* Get the semaphore and start */
		sem_wait(&libClient.ign_t_sem);
		IOBD_DEBUG_LEVEL3("get ign_t_sem -\n");

		rc = check_ign_status(IGNITION_STAT_WITH_DIP);
		/* ToDo NaNC : this thread is blocking obd_read_dat. sleep(1) */
		sleep(1);
		/* send ignition on status */
		if(rc == IGNITION_STATE_ON && libClient.state == OBDII_INIT)
		{
			IOBD_DEBUG_LEVEL3("inside ign_on \n");
			IOBD_DEBUG_LEVEL3("Ignition is ON!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1\r\n");

			get_time(ts);
			memset(ign_qdata.data,0x0,256);
			ign_qdata.msg_type = PM_EVENT_IGN_ON_NORMAL;
			IOBD_DEBUG_LEVEL3("send saved time stamp %s \n",ts);
			strcpy(ign_qdata.data,ts);
			IOBD_DEBUG_LEVEL3("ignition on timestamp send %s!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n",ts);
			rc = send_ign_q(&libClient,&ign_qdata);

		}			
		else if(rc == IGNITION_STATE_OFF)
		{
			IOBD_DEBUG_LEVEL3("Ignition is IGN_OFF_NORMAL !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1\r\n");

			get_time(ts);
			memset(ign_qdata.data,0x0,256);
			ign_qdata.msg_type = PM_EVENT_IGN_OFF_NORMAL;
			IOBD_DEBUG_LEVEL3("send saved time stamp %s \n",ts);
			strcpy(ign_qdata.data,ts);

			IOBD_DEBUG_LEVEL2("ignition off timestamp send %s!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n",ts);
			rc = send_ign_q(&libClient,&ign_qdata);

		}
		else if(rc == IGNITION_STATE_DEVICE_REMOVED)
		{
			IOBD_DEBUG_LEVEL3("Ignition is IGNITION_STATE_DEVICE_REMOVED!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1\r\n");

			get_time(ts);
			memset(ign_qdata.data,0x0,256);
			ign_qdata.msg_type = PM_EVENT_WAKE_DISCONNECTION;
			IOBD_DEBUG_LEVEL3("send saved time stamp %s \n",ts);
			strcpy(ign_qdata.data,ts);
			IOBD_DEBUG_LEVEL2("ignition state_device_removed send %s!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n",ts);
			rc = send_ign_q(&libClient,&ign_qdata);

		}
		else{
			IOBD_DEBUG_LEVEL3("post ign_t_sem +\n");
			sem_post(&libClient.ign_t_sem);
			IOBD_DEBUG_LEVEL3("post ign_t_sem +\n");

		}
	}
}


