#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <semaphore.h>
#include "can_header.h"
#include "netinet/in.h"
#include "init.h"
#include "common.h"
#include "q_gps.h"
#include "libxml2.h"
#include "obd2lib.h"
#include"thread.h"
#include "4g.h"

int init_mode_pid(car_parameters *carparams)
{
	int rc = 0;
	char value [5];
	char pid_no[10];
	int i;	
	carparams->modepid = (mode_pid *)calloc(10,sizeof(mode_pid));
	for (i = 0;i<10;i++){
		bzero (pid_no,sizeof(pid_no));
		bzero (value,sizeof(value));
		sprintf(pid_no,"%s%d","pid",i+1);
		rc = get_xml_content (SRC_XML_FILE, "mode_1", pid_no, value);
		strcpy (carparams->modepid[i].pid, value);
		carparams->modepid[i].mode = 1;
	}
		carparams->no_of_pids = i;
	return rc;

}


int set_default_freq_values(struct frequency *freq)
{
	strcpy(freq[0].name,"GPSUPDATE");
	strcpy(freq[0].select,"Yes");
	freq[0].value = 1;

	strcpy(freq[1].name,"CARSTATUS");
	strcpy(freq[1].select,"Yes");
	freq[1].value = 2;

	strcpy(freq[2].name,"ACCELEROMETER");
	strcpy(freq[2].select,"Yes");
	freq[2].value = 2;

	strcpy(freq[3].name,"DTCCODE");
	strcpy(freq[3].select,"Yes");
	freq[3].value = 2;

	strcpy(freq[4].name,"GYROSCOPE");
	strcpy(freq[4].select,"Yes");
	freq[4].value = 2;

	return 0;
}

int init_frequency(struct frequency * freq)
{
	int rc = 0;
	char value [10];
	char sub_node[][24] = {"sampling_frequency", "can_sign", "duration"};

	get_xml_content (SRC_XML_FILE, "general", sub_node[0], value);	
	freq[0].value = atoi(value);
	get_xml_content (SRC_XML_FILE, "general", sub_node[1], value);	
	freq[1].value = atoi(value);
	get_xml_content (SRC_XML_FILE, "overspeed", sub_node[2], value);	
	freq[2].value = atoi(value);

	return rc;
}


int hw_init(void)
{
	int rc = 0;
	IOBD_DEBUG_LEVEL3("hw_init +\n");
#if 1
	system("i2cset -f -y 0 0x6b 0x00 0x17");//input current limiter for battery charger IC.
	system("i2cset -f -y 0 0x6b 0x02 0x82");//charging current limited to 120mA
	system("i2cset -f -y 0 0x6b 0x03 0x11");//pre-charging and terminal charging current limited to 60mA
	system("i2cset -f -y 0 0x6b 0x05 0x8f");//watchdog timer is disabled
#endif
	rc = switch_on_power_rail();
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("hw_init: switch_on_power_rail failed %d",rc);	
	rc = obd_init();	
	/* NaNC */

	IOBD_DEBUG_LEVEL4("hw_init - rc %d \n",rc);
	return rc;
}

void hw_deinit(void)
{
	gps_deinit();
	/* NaNC : Flag reset for gps handle */
	libClient.ppp0_link_status = LINK_DOWN;
	libClient.gps_node_open=0;
	libClient.init_connect = 0;
	if(libClient.set_raw_can == 1)
		can_deinit();
	/*LED OFF*/
	system ("echo 0 > /sys/class/gpio/gpio77/value");

}


int init (IGN_PTRS *ptr,SLEEP_WAKE *sw,_xml * xml_objs)
{
	int rc = 0;
	unsigned int sem_val = 1;

	libClient.ign_fptr.ign_ON   = ptr->ign_ON;
	libClient.ign_fptr.ign_OFF  = ptr->ign_OFF;
	libClient.ign_fptr.dis_stat = ptr->dis_stat;
	libClient.ign_fptr.bat_drain = ptr->bat_drain;
	libClient.ign_fptr.pnc_btn = ptr->pnc_btn;
	libClient.ign_fptr.crash_det = ptr->crash_det;
	libClient.ign_fptr.osm_cb 	= ptr->osm_cb;

	libClient.dev_sleep = DEV_WAKE;

	libClient.s_w.slp 	= sw->slp;
	libClient.s_w.wake	= sw->wake;
	libClient.s_w.slp_dis 	= sw->slp_dis;

	/* Init powermanagement Msg Q */
	if (init_ign_q(&libClient) == OBD2_LIB_FAILURE) {
		IOBD_DEBUG_LEVEL4 ("init_ign_q : Message Queue Create Failed id");
		rc = -1;
	}

	if (sem_init_3g ("/sem_3g", sem_val))
		IOBD_DEBUG_LEVEL2 ("Error in creating semaphone file with %d\n",errno);

	if (sem_init_usb("/sem_16") == -2)
		IOBD_DEBUG_LEVEL2("sem_init_usb - failed\n");
	
	/* Init Semaphore*/
	if (sem_init(&libClient.sem_board_init_complete, 0, 0) == OBD2_LIB_FAILURE)
	{
		IOBD_DEBUG_LEVEL2("libClient.sem_board_init_complete: Sem Create Failed\r\n");
		rc = -1;
	}

	/*Sync between key_event_thread and acc_thread*/
	if (sem_init(&libClient.acc_key_thread_lock, 0, 1) == OBD2_LIB_FAILURE)
	{
		IOBD_DEBUG_LEVEL2("libClient.acc_key_thread_lock: acc_key_thread_lock Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.sys_wake, 0, 1) == OBD2_LIB_FAILURE)
	{
		IOBD_DEBUG_LEVEL2("libClient.sys_wake :sys_wake Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_of_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("libClient.ign_of_sem: ign_of_sem Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_off_restart, 0, 0) == -1)
	{
		IOBD_DEBUG_LEVEL2("libClient.ign_off_restart: ign_off_restart Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_of_dis, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("libClient.ign_of_dis: Sem Create Failed\r\n");
		rc = -1;
	}
	/* Init Semaphore*/
	if (sem_init(&libClient.ign_t_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("libClient.ign_t_sem: ign_t_sem Sem Create Failed\r\n");
		rc = -1;
	}
	if (sem_init(&libClient.btry_drain, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("libClient.btry_drain: btry_drain Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore*/
	if (sem_init(&libClient.ign_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("libClient.ign_sem: Sem Create Failed\r\n");
		rc = -1;
	}

	/* Init Semaphore for obd_read_data*/
	if (sem_init(&libClient.obd_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("libClient.obd_sem: Sem Create Failed\r\n");
		rc = -1;
	}

	if (sem_init(&libClient.gps_sem, 0, 1) == -1)
	{
		IOBD_DEBUG_LEVEL2("libClient.gps_sem: Sem Create Failed\r\n");
		rc = -1;
	}
	IOBD_DEBUG_LEVEL3("\n********************************************************************************\n");
	IOBD_DEBUG_LEVEL3("\n****************************** OBD - Version %s *******************************\n",OBD_VERSION);
	IOBD_DEBUG_LEVEL3("\n********************************************************************************\n");

	libClient.fresh_boot = 1;
	libClient.car_mode = 0;
	libClient.init_connect = 0;
	libClient.gyro_mounted = 0;
	libClient.gps_init_fix = 0;

	rc = init_mode_pid(&libClient.xml_elem.car_params);
	if(rc < 0)
	{
		IOBD_DEBUG_LEVEL2("init_mode_pid failed!!\n");
	}

	memcpy(&xml_objs->car_params,&libClient.xml_elem.car_params,sizeof(car_parameters));

	rc = init_frequency(libClient.xml_elem.freq);
	if(rc < 0)
	{
		IOBD_DEBUG_LEVEL2("init_init_frequency failed!! loading default values \n");
	}
	memcpy(xml_objs->freq,libClient.xml_elem.freq,(sizeof(libClient.xml_elem.freq)));
	rc = GPIO_config();
	if (rc != OBD2_LIB_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("GPIO Config failed");
	return rc;

}

void sys_sleep_completed(void)
{
	IOBD_DEBUG_LEVEL2("sys_sleep_completed \n");
	return;
}

void sys_wake_completed(void)
{
	/* NaNC : Clear all the ignition flags */
	IOBD_DEBUG_LEVEL3(" sys_wake_completed + \n");
	sem_post(&libClient.sys_wake);
	IOBD_DEBUG_LEVEL2(" sys_wake_completed - \n");

	return;
}
