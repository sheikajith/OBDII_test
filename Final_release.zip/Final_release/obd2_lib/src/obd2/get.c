#include <sys/time.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include "init.h"
#include "common.h"
#include <unistd.h>
#include <string.h>
#include "serial.h"
#include "obd2lib.h"
#include "pwr_mgmt.h"

void get_time (char *timebuf)
{
	struct timeval tv;
	struct tm* ptm;
    struct tm t_result;


	char time_string[24];
	long milliseconds;

	/* Obtain the time of day, and convert it to a tm struct.  */
	gettimeofday (&tv, NULL);
	ptm = localtime_r( &tv.tv_sec, &t_result );

	/* Format the date and time, down to a single second.  */
	strftime (time_string, sizeof (time_string), "%Y-%m-%dT%H:%M:%S", ptm);

	/* Compute milliseconds from microseconds.  */
	milliseconds = tv.tv_usec / 1000;

	/* Print the formatted time, in seconds, followed by a decimal point
	   and the milliseconds.  */
	sprintf (timebuf,"%s.%03ldZ", time_string, milliseconds);
	IOBD_DEBUG_LEVEL4("timebuf %s \n",timebuf);
}

int get_serial_no()
{
	char buf_lo[10], buf_hi[10];
	char dummy_buf[2];
	FILE *fp0, *fp1;
	int ret = OBD2_LIB_SUCCESS;

	memset(buf_lo, 0, 10);
	memset(buf_hi, 0, 10);

	/* read unique id lsb */
	fp0 = fopen(CPU_UNIQUE_ID_LO, "r");
	if (fp0 != NULL){
		fread(&dummy_buf, 2, 1, fp0);
		fread(&buf_lo, 8, 1, fp0);
		fclose(fp0);
	}
	else{
		ret = OBD2_LIB_FAILURE;
		goto end;
	}	
	/* read unique id lsb */
	fp1 = fopen(CPU_UNIQUE_ID_HI, "r");
	if (fp1 != NULL){
		fread(&buf_hi, 10, 1, fp1);
		fclose(fp1);
	}
	else{
		ret = OBD2_LIB_FAILURE;
		goto end;
	}	
	/* NaNR : Some Junk characters were observed in IOBD_DEBUG_LEVEL2 */

	IOBD_DEBUG_LEVEL4 ("CPU Unique ID MSB\t:\t %s \r\n", buf_hi);
	IOBD_DEBUG_LEVEL4 ("CPU Unique ID LSB\t:\t 0x%s \r\n", buf_lo);
end:
	return ret;
}

int check_protocol( int count )
{
	char *cmd_buf = "010C";
        char buf[255] = {0};
        struct obd_ obd_data;

	IOBD_DEBUG_LEVEL4 ("checking protocol..............\n");
	while (count--){
//		rc = check_ign_status(IGNITION_STAT_WITH_DIP);
		memset (buf, '\0', sizeof(buf));
		memset (obd_data.res_buf, '\0', sizeof(obd_data.res_buf));
		obd_read_data(cmd_buf,buf,&obd_data);
		if(strncmp(obd_data.res_buf, "41 0C", 5) == 0) {
			libClient.check_raw_can = 0;
			break;
		}
		else{
			libClient.check_raw_can = 1;
			continue;
		}
	}
        IOBD_DEBUG_LEVEL2("libClient.check_raw_can : %d\r\n", libClient.check_raw_can);
	return libClient.check_raw_can;
}

int check_mode()
{
	struct timeval start, end;
	char value[2];
	int rc = -1;

	gettimeofday(&start, NULL);

	while(1) 
	{
		get_xml_content (SRC_XML_FILE, "general", "mode", value);
		libClient.lab_mode = atoi (value);
		IOBD_DEBUG_LEVEL4("in Check_Mode is %d\n",libClient.lab_mode);
		rc = check_ign_status(IGNITION_STAT_WITH_DIP);
		if((rc == IGNITION_STATE_ON || rc == IGNITION_STATE_ON_VOLTAGE) && libClient.car_mode == 0)
		{
			IOBD_DEBUG_LEVEL4 ("Ignition is ON***************\r\n");
			libClient.car_mode = 1;
			break;
		}
		else if(rc == IGNITION_STATE_OFF ) 
		{

			IOBD_DEBUG_LEVEL4 ("Ignition is OFF***************\r\n");
			gettimeofday(&end, NULL);

			libClient.run_time.duration = ((end.tv_usec - start.tv_usec) + (end.tv_sec - start.tv_sec)*1000000)/1000000;

			if(libClient.run_time.duration >= 600) 
			{	 /* write as car mode */
				libClient.car_mode = 1;
				break;
			}
			else if(libClient.lab_mode == 2){
				libClient.car_mode = 0;
				break;
			}

		}
		else if (rc == IGNITION_STATE_DEVICE_REMOVED){
			libClient.car_mode = 1;
			break;
		}
	}
	if(libClient.car_mode == 1){			 
		IOBD_DEBUG_LEVEL2("***********************************THE MODE IS CAR MODE********************\r\n");
	}
	else if(libClient.car_mode == 0){
		IOBD_DEBUG_LEVEL2("******************************THE MODE IS LAB MODE******************\r\n");
	}

	return libClient.car_mode;
}


int get_ign_stat_voltage_check_dip()
{
	int ret = IGNITION_STATE_ON;
	float volt;
	int duration_ign_off;
	struct timeval start_ign_off, end_ign_off;

	read_car_voltage(&volt);

	IOBD_DEBUG_LEVEL4 ("voltage : %f \r\n", volt);

	gettimeofday(&start_ign_off, NULL);

	if(volt < 13.1) {
		while(1) {
			gettimeofday(&end_ign_off, NULL);
			duration_ign_off = ((end_ign_off.tv_usec-start_ign_off.tv_usec)+(end_ign_off.tv_sec-start_ign_off.tv_sec)*1000000)/1000000;

			IOBD_DEBUG_LEVEL2("duration_ign_off : %d \r\n", duration_ign_off);

			read_car_voltage(&volt);
			if(volt < 3.5){
				ret = IGNITION_STATE_DEVICE_REMOVED;
				break;
			}

			if(volt < 13.1 && duration_ign_off >= 8) {
				IOBD_DEBUG_LEVEL2("voltage is less than 13.2 ignition off \r\n");
				if(volt < 11.8){//battery drain threshold need to be updated here
					ret = IGNITION_STATE_BATTERY_DRAIN;
				}
				else{
					ret = IGNITION_STATE_OFF;
				}

				break;
			}
			else if(volt > 13.0) {
				IOBD_DEBUG_LEVEL2("voltage is greater than 13.0 between \r\n");
				ret = IGNITION_STATE_ON;
				break;
			}
		}
	}
	else {
		IOBD_DEBUG_LEVEL2("volatge is greater than 13.2 \r\n");
		ret = IGNITION_STATE_ON_VOLTAGE;
	}

	IOBD_DEBUG_LEVEL4 ("get_ign_stat_voltage_check_dip returns %d \r\n",ret);
	return ret;
}


int check_ign_status(int voltage_dip)
{
	int ret;
	char *cmd_buf = "010C";
	char buf[255] = {0};
	struct obd_ obd_data;

    memset( buf, 0, sizeof( buf ) );
    memset( &obd_data, 0, sizeof( obd_data ) );
	/* send command and receive the data response */
	ret = obd_read_data(cmd_buf,buf,&obd_data);

	if(strncmp(obd_data.res_buf, "41", 2) == 0){
		if(strncmp(obd_data.res_buf, "41 0C 00 00", 11) == 0) {
			IOBD_DEBUG_LEVEL2("iwave: engine is off\r\n");
			if(voltage_dip){
				ret = get_ign_stat_voltage_check_dip();
			}
			else{
				ret = get_ign_stat_voltage_no_dip();	
			}
            ret = IGNITION_STATE_OFF;
		}
		else {
			ret = IGNITION_STATE_ON;
            libClient.check_raw_can = 0;
		}
	}
	else if(ret != IGNITION_STATE_ON && libClient.check_raw_can == 1){
		IOBD_DEBUG_LEVEL2("iwave: engine may be off\r\n");
		if(voltage_dip){
			ret = get_ign_stat_voltage_check_dip();
		}
		else{
			ret = get_ign_stat_voltage_no_dip();
		}
	}
    else
    {
        IOBD_DEBUG_LEVEL2("iwave: engine is off\r\n");
        ret = get_ign_stat_voltage_no_dip();
        if( ret == IGNITION_STATE_DEVICE_REMOVED )
        {
        }
        else
        {
            ret = IGNITION_STATE_OFF;
        }
    }

	return ret;
}

int check_adc_voltage (double *volt)
{
	int fp;
	char buf[10];
	int raw_value;
	double voltage_value;
	int rc = OBD2_LIB_SUCCESS;

	bzero (buf,sizeof(buf));
	
	fp = open(ADC_READ_NODE, O_RDONLY);
	if(fp == OBD2_LIB_FAILURE){
		IOBD_DEBUG_LEVEL2("ADC_READ_NODE: Error opening file\r\n");
		rc = -errno;
		goto end;
	}

	read(fp, buf, sizeof(int));
	close(fp);

	IOBD_DEBUG_LEVEL2 ("adc_volt_buf : %s\n",buf);

	raw_value = (int)strtol(buf, NULL, 10);
	voltage_value = raw_value;
	IOBD_DEBUG_LEVEL2("voltage_value %lf\n",voltage_value);

	*volt = ((((voltage_value / 4096.00) * 3.3 * 7.848) - 2.1621));

	IOBD_DEBUG_LEVEL2("raw_value : %d\t voltage_value: %lf\r\n", raw_value, *volt);
end:
	return rc;
}


int check_in_bt_volt (double *volt)
{
	int fp;
	char buf[10];
	int raw_value = 0;
	double voltage_value = 0.0;
	int rc = 0;

	bzero (buf,sizeof(buf));
	
	fp = open(IN_BT_READ_NODE, O_RDONLY);
	if(fp == OBD2_LIB_FAILURE){
		IOBD_DEBUG_LEVEL2("IN_BT_READ_NODE: Error opening file\r\n");
		rc = FILE_OPEN_ERROR;
		goto end;
	}

	read(fp, buf, sizeof(int));
	close(fp);

	IOBD_DEBUG_LEVEL2 ("In_battery_volt_buf : %s\n",buf);

	raw_value = (int)strtol(buf, NULL, 10);
	voltage_value = raw_value;
	IOBD_DEBUG_LEVEL3("IN_BT_voltage_value %lf\n",voltage_value);

	*volt = ((voltage_value / 4096.00) * 3.3 * 1.5);

	IOBD_DEBUG_LEVEL4("IN_BTRY raw_value : %d\t voltage_value: %lf V\r\n", raw_value, *volt);
end:
	return rc;
}
