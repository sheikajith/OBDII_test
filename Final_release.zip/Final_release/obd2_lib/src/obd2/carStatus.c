#include <stdio.h>
#include"init.h"
#include "obd2lib.h"
#include "pwr_mgmt.h"
#include "commands.h"
#include "serial.h"
#include "can_header.h"
#include <malloc.h>
int get_car_mode()
{
	return libClient.car_mode;
}

int get_car_status(car_parameters *carparams)
{
	int ret;
	char *cmd_buf = NULL;
	const char *cmd_b;
	char buf[255] = {0};
	struct obd_ obd_data;
	char modebuf[4]={0},pidbuf[4]={0},tempbuf[4]={0};
	int no_of_pids = 0;
	no_of_pids = carparams->no_of_pids;
	int in = 0;


	cmd_buf = malloc(sizeof(carparams->modepid[in].mode)+sizeof(carparams->modepid[in].pid));
	if (cmd_buf == NULL)
		return -2;

	while(no_of_pids > 0){
		bzero(cmd_buf,10);
		memset(buf,0,sizeof(buf));
		memset(modebuf,0,sizeof(modebuf));
		memset(pidbuf,0,sizeof(pidbuf));
		memset(tempbuf,0,sizeof(tempbuf));
		sprintf(tempbuf,"%d",carparams->modepid[in].mode);
		if(strlen(tempbuf)<2){
			strcpy(modebuf,"0");
			strcat(modebuf,tempbuf);
		}
		else
			strcpy(modebuf,tempbuf);
		strcpy(cmd_buf,modebuf);
		memset(tempbuf,0,sizeof(tempbuf));
		strcpy(tempbuf,carparams->modepid[in].pid);

		if(strlen(tempbuf)<2){
			strcpy(pidbuf,"0");
			strcat(pidbuf,tempbuf);
		}
		else{
			strcpy(pidbuf,tempbuf);
		}
		strcat(cmd_buf,pidbuf);
		cmd_b = cmd_buf;
		if(libClient.set_raw_can != 1) {
			ret = obd_read_data(cmd_buf,buf,&obd_data);
		}
		else {
			ret = -3;
			usleep(80000);
		}		
		if((strcmp(obd_data.res_buf, "NO DATA") != 0) && (strcmp(obd_data.res_buf, "CAN ERROR") != 0 && (ret == 0))) {

			if((buf[5]== 0x30) && (buf[6]==0x31) && (buf[7]==0x30))
			{
				parse_raw_value_ert(buf,(char *)&carparams->modepid[in].raw_data);
			}
			else
			{
				parse_raw_value(buf,(char *)&carparams->modepid[in].raw_data);
			}
		}
		else {
			if(libClient.set_raw_can == 1) {
				if(strncmp(cmd_b,"010C",4) == 0) {
					carparams->modepid[in].data = ((CAN_Res.rpm[0] << 8 | CAN_Res.rpm[1])/1.28);
					IOBD_DEBUG_LEVEL2("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@RAW_CAN rpm : %f\r\n", carparams->modepid[in].data);
				}
				if(strncmp(cmd_b,"010D",4) == 0) {
					carparams->modepid[in].data = (CAN_Res.speed[0]);
					IOBD_DEBUG_LEVEL2("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@RAW_CAN speed : %f\r\n", carparams->modepid[in].data);
				}
			}	
			IOBD_DEBUG_LEVEL4 ("Mode : %d pid : %s is not supported or ignition is off\r\n",carparams->modepid[in].mode,carparams->modepid[in].pid);
		}

		in++;
		no_of_pids--;
	}
    if( cmd_buf != NULL )
    {
        printf("%d - cmd_buf pointer value ( %p )\n", __FUNCTION__, cmd_buf );
    	free(cmd_buf);
        cmd_buf = NULL;
        cmd_b = NULL;
    }

	return OBD2_LIB_SUCCESS;
}

int get_car_data(car_parameters *outcarparams)
{
	int rc = OBD2_LIB_SUCCESS;
	struct timeval car_start_time,car_end_time;

	if(libClient.init_connect==1)
	{
		/* NaND : parameter must be of type car_parameters. dont pass char buffer. fill the car_parameters and return. dont use char buffer */
		gettimeofday(&car_start_time, NULL);
		rc = get_car_status(&libClient.xml_elem.car_params);

		gettimeofday(&car_end_time, NULL);
		libClient.run_time.car_duration = ((car_end_time.tv_usec - car_start_time.tv_usec) + (car_end_time.tv_sec - car_start_time.tv_sec)*1000000)/1000;
		if(rc < 0)
		{
			IOBD_DEBUG_LEVEL2 ("get_car_data failed %d",rc);
			rc = -1;
			goto exit;
		}
	}
	else
	{
		IOBD_DEBUG_LEVEL2 ("initial connection not completed\n");
		rc = -2;
	}
exit:
	memcpy(outcarparams,&libClient.xml_elem.car_params,sizeof(car_parameters));
	return rc;
}


void get_dtc_code(char *dtc_array, size_t sz)
{
	char *cmd_buf="03";
	char buf[255]={0};
	int ret,i;
	struct obd_ obd_data;
	dtccodes dtc_values;
	struct timeval dtc_start_time,dtc_end_time;

	gettimeofday(&dtc_start_time, NULL);
	ret = obd_read_data(cmd_buf,buf,&obd_data);
	gettimeofday(&dtc_end_time, NULL);
	libClient.run_time.dtc_duration = ((dtc_end_time.tv_usec - dtc_start_time.tv_usec) + (dtc_end_time.tv_sec - dtc_start_time.tv_sec)*1000000)/1000;

	if(libClient.init_connect==1){
		ret = read_dtc_value(buf,&dtc_values);
		if(ret == -1){
			IOBD_DEBUG_LEVEL4("ignition off or mode is not supported\r\n");
			return;
		}

		memset(dtc_array, 0, sz);

		for(i = 0; i < dtc_values.no_codes; i++)
		{
			strcat(dtc_array, dtc_values.dtc_str[i]);
			if(i<(dtc_values.no_codes-1))
				strcat(dtc_array, " ");
		}
		for(i = 0; i < dtc_values.no_codes; i++)
                {
                        if (dtc_values.dtc_str[i] != NULL)
                                free (dtc_values.dtc_str[i]);
                        IOBD_DEBUG_LEVEL2 ("###memory %d freed",i);
                }

	}
	else{
		IOBD_DEBUG_LEVEL2 ("initial condition not completed in dtc_code()\n");
		return;
	}

}

#if 0
float get_internal_battery_voltage()
{

	IOBD_DEBUG_LEVEL2("get_internal_battery_voltage +\n");
	IOBD_DEBUG_LEVEL2("get_internal_battery_voltage -\n");

	return 0;
}

float get_internal_battery_current()
{

	IOBD_DEBUG_LEVEL2("get_internal_battery_current +\n");
	IOBD_DEBUG_LEVEL2("get_internal_battery_current -\n");

	return 0;
}
#endif
