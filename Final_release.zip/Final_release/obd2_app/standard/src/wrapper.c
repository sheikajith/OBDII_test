#include "application.h"


int publishEventWrapper(char* data)
{
	int rc = 0;
	rc = publishEvent(data);
	return rc;
}
