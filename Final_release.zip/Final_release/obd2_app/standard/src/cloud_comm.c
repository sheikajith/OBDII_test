#include "application.h"
#include "cloud.h"
#include "standard.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "libxml2.h"
#include <malloc.h>

struct string
{
    char *ptr;
    size_t len;
};

int publishEvent(char* data)
{
	int rc = -1;
	int duration;
	char led_cmd[64];
	_packet  packet;
	char time[256] ={0};

	IOBD_DEBUG_LEVEL4 ("rns_sem w+");
	sem_wait(&dmClient.rns_sem);
	IOBD_DEBUG_LEVEL4 ("rns_sem w-");
	get_time(time);
    memset( &packet, 0, sizeof( _packet ) );	
	/*Framing header once*/	
	rc = frame_actual_header(&packet,((config_azure *)(dmClient.cfg.server_cfg))->url);
	if(rc<0)
		IOBD_DEBUG_LEVEL2 ("frame custom header failed \n");

	rc = frame_custom_header(&packet, time);
	if(rc<0)
		IOBD_DEBUG_LEVEL2 ("frame custom header failed \n");

	rc = send_curl_data(&packet, data);
	IOBD_DEBUG_LEVEL4 ("rns_sem p+");
	sem_post(&dmClient.rns_sem);
	IOBD_DEBUG_LEVEL4 ("rns_sem p-");

	IOBD_DEBUG_LEVEL4 (" return rc %d \n",rc);
	if(rc > 0){
		rc = check_connection();
		IOBD_DEBUG_LEVEL2 ("send data to server failed: link is %d\n",rc);
		system ("echo 0 > /sys/class/gpio/gpio77/value");
		standard_cli.led_switch = 0;
		rc = OBD2_APP_FAILURE;
	}
	else if (rc < 0){
		IOBD_DEBUG_LEVEL2 ("Invalid Curl handler");
	}
	else{

		if (standard_cli.led_state == 0){
			gettimeofday(&standard_cli.led_start, NULL);
			standard_cli.led_switch = !standard_cli.led_switch;
			sprintf (led_cmd,"%s %d %s","echo",standard_cli.led_switch, "> /sys/class/gpio/gpio77/value");	
				system (led_cmd);
			standard_cli.led_state = 1;
		}
		else{
			gettimeofday(&standard_cli.led_stop, NULL);
			duration = ((standard_cli.led_stop.tv_usec - standard_cli.led_start.tv_usec) + (standard_cli.led_stop.tv_sec - standard_cli.led_start.tv_sec)*1000000)/1000000;
			if (duration > 30)
				standard_cli.led_state = 0;
		}
	}	

	return rc;
}

int final_payload_frame(char * time, struct obd_data *obd_q, char * event)
{
	int rc = 0;
	char buffer[2048]={0};
	_packet packet;

	IOBD_DEBUG_LEVEL4 ("final_payload_frame +");
	sem_wait(&standard_cli.send_sem);
	IOBD_DEBUG_LEVEL3 ("%s:send_sem w+\n",event);

    memset( &packet, 0, sizeof( _packet ) );
	rc = frame_payload(&packet,&standard_cli.g_gps, &standard_cli.g_carparams, event, time);
	if(rc<0){
		IOBD_DEBUG_LEVEL2 ("frame packet failed \n");
		rc = OBD2_APP_FAILURE;
	}
	rc = frame_final_packet(&packet,buffer,sizeof(buffer));

	strncpy(obd_q->data, buffer,strlen(buffer)+1);

	if(rc != OBD2_APP_SUCCESS){
		sem_post(&standard_cli.send_sem);
		IOBD_DEBUG_LEVEL2 ("send_sem fp-\n");
		rc = OBD2_APP_FAILURE;
	}
	sem_post(&standard_cli.send_sem);
	IOBD_DEBUG_LEVEL2 ("%s:send_sem p-\n",event);

	return rc;
}

int frame_actual_header(_packet * packet,char * url)
{
	int rc = 0;

	strcpy(packet->a_header.Accept,"Accept: application/json");
	strcpy(packet->a_header.Content_Type,"Content-Type: application/json");

	strcpy(packet->a_header.iothub_to,"iothub-to: /devices/");
	strcat(packet->a_header.iothub_to,((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);
	strcat(packet->a_header.iothub_to,((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);
	strcat(packet->a_header.iothub_to,"/messages/events");

	strcpy(packet->a_header.Authorization,"Authorization: ");
	strcat(packet->a_header.Authorization,((config_azure *)(dmClient.cfg.server_cfg))->sas);

	strcpy(packet->a_header.Connection,"Connection: Keep-Alive");
	strcpy(packet->a_header.User_Agent,"User-Agent: iothubclient/1.1.22 (Linux; x86_64), iothubclient/1.1.22 (Linux; x86_64)");
	strcpy(packet->a_header.Host,"Host: ");
	strcpy(packet->a_header.Host,((config_azure *)(dmClient.cfg.server_cfg))->hostname);

	return rc;
}


int frame_custom_header(_packet * packet, char *time)
{
	int rc = 0;

	strcpy(packet->c_header.IoTHub_app_transactionId,"IoTHub-app-transactionId: b13a51d5-217a-452d-b322-3f75edf7cc80");
	strcat(packet->c_header.IoTHub_app_deviceId,((config_azure *)(dmClient.cfg.server_cfg))->transactionId);


	strcpy(packet->c_header.IoTHub_app_deviceId,"IoTHub-app-deviceId: ");
	strcat(packet->c_header.IoTHub_app_deviceId,((config_azure *)(dmClient.cfg.server_cfg))->http_deviceId);

	strcpy(packet->c_header.IoTHub_app_deviceType,"IoTHub-app-deviceType: ");
	strcat(packet->c_header.IoTHub_app_deviceType,((config_azure *)(dmClient.cfg.server_cfg))->http_deviceType);

	/* NaNacc - ServiceName must be SERA_TELTONIKA */
	strcpy(packet->c_header.IoTHub_app_serviceName,"IoTHub-app-serviceName: SERA_TELTONIKA");

	strcpy(packet->c_header.IoTHub_app_timestamp,"IoTHub-app-timestamp: ");
	strcat(packet->c_header.IoTHub_app_timestamp,time);

	strcpy(packet->c_header.Authorization,"Authorization: ");
	strcpy(packet->c_header.Authorization,((config_azure *)(dmClient.cfg.server_cfg))->sas);
/*Added Newly for cpaas x.0 platform provided by accenture and SERA by october 10 2020*/
	strcpy(packet->c_header.contentType,"contentType: application/json");

	strcpy(packet->c_header.contentEncoding,"contentEncoding: UTF-8");

	return rc;
}
#ifdef BLACKBOX
int frame_payload_bb(struct gps_pkt * gps,car_parameters *outcarparams)
{
	int rc = 0;
	char since_ts[30]={0};
	char buf[MAX_BUF_SZ];
	char time[32] = {0};

	get_time (time);
	bzero(buf,sizeof(buf));
	sprintf(since_ts,"%llu",msts) ;

	strcpy(appClient.bb.bb_rec.ts,time);	
	appClient.bb.bb_rec.lat = gps->gps_rmc.latitude;
	appClient.bb.bb_rec.lon = gps->gps_rmc.longitude;
	appClient.bb.bb_rec.alt = gps->gps_gga.altitude;
	appClient.bb.bb_rec.dir = gps->gps_rmc.direction;
	appClient.bb.bb_rec.no_of_sat = gps->gps_gsv.no_f_sat;
	appClient.bb.bb_rec.gps_speed = gps->gps_rmc.speed;
	appClient.bb.bb_rec.gps_pdop = gps->gps_gsa.pdop;
	appClient.bb.bb_rec.gps_hdop = gps->gps_gsa.hdop;
	
	appClient.bb.bb_rec.odometer = get_tot_odometer();

	appClient.bb.bb_rec.dtc_num = dtc_number;

	strcpy(appClient.bb.bb_rec.gsm_level,standard_cli.sim_data.signal_lvl);
	appClient.bb.bb_rec.ext_volt = get_ext_power_voltage();

	strcpy(appClient.bb.bb_rec.cell_id,standard_cli.sim_data.cell_id);
	strcpy(appClient.bb.bb_rec.lac,standard_cli.sim_data.lac);

	appClient.bb.bb_rec.total_fuel = standard_cli.fuel.total_fuel;
	appClient.bb.bb_rec.fuel_level = car_data.fuel_level;
	strcpy(appClient.bb.bb_rec.eng_tot_hrs,car_data.engine_run_time);
	
	appClient.bb.bb_rec.rpm = car_data.rpm;
	appClient.bb.bb_rec.veh_speed = car_data.veh_speed;

	appClient.bb.bb_rec.eng_load = car_data.engine_load;

	appClient.bb.bb_rec.eng_cool_temp = car_data.Eng_cool_temp;

#if 0
/*TODO: need to fix buf length*/	
	if (!file_max_sz_update_flag) {
		sprintf(buf, "%s,%.6lf,%.6lf,%.6lf,%.6lf,%hd,%.6lf,%.6lf,%d,"
				"%.6lf,%.6lf,%.6lf,%.6lf,%s,%.6f,%s,%s,%.6lf,%.6lf,%s,"
				"%.6lf,%.6lf\n",appClient.bb.bb_rec.ts, appClient.bb.bb_rec.lat, 
				appClient.bb.bb_rec.lon, appClient.bb.bb_rec.alt, appClient.bb.bb_rec.dir,
				appClient.bb.bb_rec.no_of_sat, appClient.bb.bb_rec.rpm, appClient.bb.bb_rec.veh_speed, 
				appClient.bb.bb_rec.dtc_num, appClient.bb.bb_rec.gps_speed, appClient.bb.bb_rec.gps_pdop,
				appClient.bb.bb_rec.gps_hdop,appClient.bb.bb_rec.odometer, appClient.bb.bb_rec.gsm_level, 
				appClient.bb.bb_rec.ext_volt, appClient.bb.bb_rec.cell_id, appClient.bb.bb_rec.lac, 
				appClient.bb.bb_rec.total_fuel, appClient.bb.bb_rec.fuel_level, appClient.bb.bb_rec.eng_tot_hrs,
			 	appClient.bb.bb_rec.eng_cool_temp, appClient.bb.bb_rec.eng_load);

		appClient.bb.bb_fops.record_sz = strlen (buf);
		IOBD_DEBUG_LEVEL2 ("frame_payload_b buf = %s",buf);
		IOBD_DEBUG_LEVEL2 ("appClient.bb.bb_fops.record_sz = %ld",appClient.bb.bb_fops.record_sz);
		file_max_sz_update_flag = 1;
	}
#endif
	return rc;
}
#endif

int frame_payload(_packet * packet,struct gps_pkt * gps,car_parameters *outcarparams,char * event,char * time)
{
	int rc = 0;
	char v_rpm[10]={0};
	char v_speed[10]={0};
	char i_b_volt[10]={0};
	char i_b_cur[10]={0};
	char pedal_position[10]={0};
	char engine_load[10]={0};
	char since_ts[30]={0};
	char Eng_cool_temp[10]={0};
	char inst_fuel_c[10] = {0};

	rc = sprintf(since_ts,"%llu",msts);
    strcpy(packet->payload.device_id, ((config_azure *)(dmClient.cfg.server_cfg))->deviceid);
	strcpy(packet->payload.EventCode,event);
	strcpy(packet->payload.timestamp,time);
	packet->payload.Latitude = gps->gps_rmc.latitude;
	packet->payload.Longitude = gps->gps_rmc.longitude;
	packet->payload.altitude = gps->gps_gga.altitude;
	packet->payload.direction = gps->gps_rmc.direction;
	packet->payload.gpsSatNum = gps->gps_gsv.no_f_sat;
	//packet->payload.Speed = gps->gps_rmc.speed;
	packet->payload.Speed = car_data.veh_speed;
	packet->payload.gps_pdop = gps->gps_gsa.pdop;
	packet->payload.gps_hdop = gps->gps_gsa.hdop;
	strcpy(packet->payload.sensor,"0");
	//packet->payload.Partial_Odometer=standard_cli.p_odometer.distance;
	packet->payload.Partial_Odometer=0;
	/* ToDo1 */
    packet->payload.Full_Odometer = 0;
    packet->payload.Full_Odometer = get_tot_odometer();
	IOBD_DEBUG_LEVEL4 ("*****Full_Odometer is %f",packet->payload.Full_Odometer);
	packet->payload.DTC_number = dtc_number;
	strcpy(packet->payload.GSM_level,standard_cli.sim_data.signal_lvl);
	packet->payload.ExtPowerVoltage = get_ext_power_voltage();
	strcpy(packet->payload.Cell_ID,standard_cli.sim_data.cell_id);
	strcpy(packet->payload.LAC,standard_cli.sim_data.lac);
	strcpy(packet->payload.PTO,"0");
	packet->payload.TotalFuel = standard_cli.fuel.total_fuel;
	packet->payload.FuelLevel = car_data.fuel_level;
	strcpy(packet->payload.EngineTotHours,car_data.engine_run_time);
	strcpy(packet->payload.ServiceDist,"0");
	strcpy(packet->payload.PTO_eng,"0");
	strcpy(packet->payload.GeofenceZone,"0");
	strcpy(packet->payload.EcoDrivingValue,"0");
/*not required to pass accelerometer data as a part of payload*/
//	sprintf(packet->payload.Accelerometer,"%d,%d,%d",adata->x,adata->y,adata->z);
/*TELEMETRY 88 - RPM*/
    strcpy(packet->payload.telemetry[0].pi,"88");
    strcpy(packet->payload.telemetry[0].std,"TELT");
    if (strcmp (event, "SM_ON") == 0){
        sprintf(v_rpm,"%s","0.0");
    }
    else{
        sprintf(v_rpm,"%lf",car_data.rpm);
    }
    strcpy(packet->payload.telemetry[0].v,v_rpm);
    strcpy(packet->payload.telemetry[0].u,"rpm");
    strcpy(packet->payload.telemetry[0].time,since_ts);

/*TELEMETRY 80 - Veh_speed*/
	strcpy(packet->payload.telemetry[1].pi,"80");
	strcpy(packet->payload.telemetry[1].std,"TELT");
    if (strcmp (event, "SM_ON") == 0){
        sprintf(v_speed,"%s", "0.0");
    }
    else{
        sprintf(v_speed,"%lf",car_data.veh_speed);
    }
    strcpy(packet->payload.telemetry[1].v,v_speed);
	strcpy(packet->payload.telemetry[1].u,"km/h");
	strcpy(packet->payload.telemetry[1].time,since_ts);

/*TELEMETRY 67 - internal_battery_volt*/
	strcpy(packet->payload.telemetry[2].pi,"67");
	strcpy(packet->payload.telemetry[2].std,"TELT");
	sprintf(i_b_volt,"%f",standard_cli.battery.i_battery_volt);
	strcpy(packet->payload.telemetry[2].v,i_b_volt);
	strcpy(packet->payload.telemetry[2].u,"mV");
	strcpy(packet->payload.telemetry[2].time,since_ts);

/*TELEMETRY 68 - internal_battery_current*/
	strcpy(packet->payload.telemetry[3].pi,"68");
	strcpy(packet->payload.telemetry[3].std,"TELT");
	sprintf(i_b_cur,"%d",standard_cli.battery.i_battery_cur);
	strcpy(packet->payload.telemetry[3].v,i_b_cur);
	strcpy(packet->payload.telemetry[3].u,"mA");
	strcpy(packet->payload.telemetry[3].time,since_ts);

/*TELEMETRY 84 - pedal-position*/
	strcpy(packet->payload.telemetry[4].pi,"84");
	strcpy(packet->payload.telemetry[4].std,"TELT");
    if (strcmp (event, "SM_ON") == 0){
        sprintf(pedal_position,"%s","0.0");
    }
    else{
        sprintf(pedal_position,"%lf",car_data.pedal_position);
    }
	strcpy(packet->payload.telemetry[4].v,pedal_position);
	strcpy(packet->payload.telemetry[4].u,"%");
	strcpy(packet->payload.telemetry[4].time,since_ts);

	strcpy(packet->payload.telemetry[5].pi,"85");
	strcpy(packet->payload.telemetry[5].std,"TELT");
    if (strcmp (event, "SM_ON") == 0){
        sprintf(engine_load,"%s","0.0");
    }
    else{
        sprintf(engine_load,"%lf",car_data.engine_load);
    }
	strcpy(packet->payload.telemetry[5].v,engine_load);
	strcpy(packet->payload.telemetry[5].u,"%");
	strcpy(packet->payload.telemetry[5].time,since_ts);

	strcpy(packet->payload.telemetry[6].pi,"127");
	strcpy(packet->payload.telemetry[6].std,"TELT");
    if (strcmp (event, "SM_ON") == 0){
        sprintf(Eng_cool_temp,"%s","0.0");
    }
    else{
        sprintf(Eng_cool_temp,"%lf",car_data.Eng_cool_temp);
    }
	strcpy(packet->payload.telemetry[6].v,Eng_cool_temp);
	strcpy(packet->payload.telemetry[6].u,"%");
	strcpy(packet->payload.telemetry[6].time,since_ts);

	strcpy(packet->payload.telemetry[7].pi,"136");
	strcpy(packet->payload.telemetry[7].std,"TELT");
	sprintf(inst_fuel_c,"%lf",standard_cli.fuel.fuel_economy);
	strcpy(packet->payload.telemetry[7].v,inst_fuel_c);
	strcpy(packet->payload.telemetry[7].u,"%");
	strcpy(packet->payload.telemetry[7].time,since_ts);
	
	return rc;
}

int frame_final_packet(_packet * packet,char * buffer,int size)
{

	char temp[256]={0};
	char volt[20] = {0};

	memset(buffer,0,size);
#if 0
	strcpy(buffer,packet->c_header.IoTHub_app_transactionId);
	strcat(buffer,packet->c_header.IoTHub_app_deviceId);
	strcat(buffer,packet->c_header.IoTHub_app_deviceType);
	strcat(buffer,packet->c_header.IoTHub_app_serviceName);
	strcat(buffer,packet->c_header.IoTHub_app_timestamp);
	strcat(buffer,packet->c_header.Authorization);
#endif

	/* Frame payload */
    sprintf(temp,"{\"deviceId\":\"%s\",",packet->payload.device_id);
    strcpy(buffer,temp);
    memset(temp,0,sizeof(temp));

	sprintf(temp,"{\"EventCode\":\"%s\",",packet->payload.EventCode);
	strcpy(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"timestamp\":\"%s\",",packet->payload.timestamp);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"Latitude\":\"%lf\",",packet->payload.Latitude);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"Longitude\":\"%lf\",",packet->payload.Longitude);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"altitude\":\"%lf\",",packet->payload.altitude);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"direction\":\"%lf\",",packet->payload.direction);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"gpsSatNum\":\"%d\",",packet->payload.gpsSatNum);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"Speed\":\"%lf\",",packet->payload.Speed);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"sensor\":\"%s\",",packet->payload.sensor);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"gps_pdop\":\"%lf\",",packet->payload.gps_pdop);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"gps_hdop\":\"%lf\",",packet->payload.gps_hdop);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"Partial_Odometer\":\"%lf\",",packet->payload.Partial_Odometer);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"Full_Odometer\":\"%f\",",packet->payload.Full_Odometer);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"DTC_number\":\"%d\",",packet->payload.DTC_number);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"GSM_level\":\"%s\",",packet->payload.GSM_level);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"ExtPowerVoltage\":\"%f\",",packet->payload.ExtPowerVoltage);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));
	memset(volt,0,sizeof(volt));
	sprintf(volt,"%f",packet->payload.ExtPowerVoltage);
	set_xml_content (SRC_XML_FILE, "home", "ext_bat",volt);	
	sprintf(temp,"\"Cell_ID\":\"%s\",",packet->payload.Cell_ID);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"LAC\":\"%s\",",packet->payload.LAC);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"PTO\":\"%s\",",packet->payload.PTO);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"TotalFuel\":\"%lf\",",packet->payload.TotalFuel);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"FuelLevel\":\"%lf\",",packet->payload.FuelLevel);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"EngineTotHours\":\"%s\",",packet->payload.EngineTotHours);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"ServiceDist\":\"%s\",",packet->payload.ServiceDist);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"PTO_eng\":\"%s\",",packet->payload.PTO_eng);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"GeofenceZone\":\"%s\",",packet->payload.GeofenceZone);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));

	sprintf(temp,"\"EcoDrivingValue\":\"%s\"",packet->payload.EcoDrivingValue);
	strcat(buffer,temp);
	memset(temp,0,sizeof(temp));
	/* NaNacc -  Telemetry is not required for CAN_SIGN */
	int telemetry = 0;
	telemetry = check_telemetry(packet->payload.EventCode);
	if(telemetry)
	{
		strcpy(temp,",\"Telemetry\":[{");
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"pi\":\"%s\",",packet->payload.telemetry[0].pi);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"std\":\"%s\",",packet->payload.telemetry[0].std);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"v\":\"%s\",",packet->payload.telemetry[0].v);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"u\":\"%s\",",packet->payload.telemetry[0].u);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"time\":\"%s\"",packet->payload.telemetry[0].time);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		strcat(buffer,"},");

		/* */
		strcat(buffer,"{");

		sprintf(temp,"\"pi\":\"%s\",",packet->payload.telemetry[1].pi);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"std\":\"%s\",",packet->payload.telemetry[1].std);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"v\":\"%s\",",packet->payload.telemetry[1].v);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"u\":\"%s\",",packet->payload.telemetry[1].u);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"time\":\"%s\"",packet->payload.telemetry[1].time);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		strcat(buffer,"},");
		/* */
		/* */
		strcat(buffer,"{");

		sprintf(temp,"\"pi\":\"%s\",",packet->payload.telemetry[2].pi);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"std\":\"%s\",",packet->payload.telemetry[2].std);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"v\":\"%s\",",packet->payload.telemetry[2].v);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"u\":\"%s\",",packet->payload.telemetry[2].u);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"time\":\"%s\"",packet->payload.telemetry[2].time);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		strcat(buffer,"},");
		/* */

		/* */
		strcat(buffer,"{");

		sprintf(temp,"\"pi\":\"%s\",",packet->payload.telemetry[3].pi);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"std\":\"%s\",",packet->payload.telemetry[3].std);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"v\":\"%s\",",packet->payload.telemetry[3].v);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"u\":\"%s\",",packet->payload.telemetry[3].u);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"time\":\"%s\"",packet->payload.telemetry[3].time);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		strcat(buffer,"},");
		/* */

		/* */
		strcat(buffer,"{");

		sprintf(temp,"\"pi\":\"%s\",",packet->payload.telemetry[4].pi);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"std\":\"%s\",",packet->payload.telemetry[4].std);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"v\":\"%s\",",packet->payload.telemetry[4].v);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"u\":\"%s\",",packet->payload.telemetry[4].u);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"time\":\"%s\"",packet->payload.telemetry[4].time);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		strcat(buffer,"},");
		/* */

		/* */
		strcat(buffer,"{");

		sprintf(temp,"\"pi\":\"%s\",",packet->payload.telemetry[5].pi);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"std\":\"%s\",",packet->payload.telemetry[5].std);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"v\":\"%s\",",packet->payload.telemetry[5].v);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"u\":\"%s\",",packet->payload.telemetry[5].u);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"time\":\"%s\"",packet->payload.telemetry[5].time);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		strcat(buffer,"},");
		/* */

		/* */
		strcat(buffer,"{");

		sprintf(temp,"\"pi\":\"%s\",",packet->payload.telemetry[6].pi);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"std\":\"%s\",",packet->payload.telemetry[6].std);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"v\":\"%s\",",packet->payload.telemetry[6].v);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"u\":\"%s\",",packet->payload.telemetry[6].u);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"time\":\"%s\"",packet->payload.telemetry[6].time);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		strcat(buffer,"},");
		/* */
		/* */
		strcat(buffer,"{");

		sprintf(temp,"\"pi\":\"%s\",",packet->payload.telemetry[7].pi);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"std\":\"%s\",",packet->payload.telemetry[7].std);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"v\":\"%s\",",packet->payload.telemetry[7].v);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"u\":\"%s\",",packet->payload.telemetry[7].u);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));

		sprintf(temp,"\"time\":\"%s\"",packet->payload.telemetry[7].time);
		strcat(buffer,temp);
		memset(temp,0,sizeof(temp));
		/* */
		strcat(buffer,"}");
		strcat(buffer,"]");
	}

	strcat(buffer,"}");
	//printf("FRAME_FINAL_PACKET buffer %s\n",buffer);
	//printf("return %d\n",rc);
	return 0;
}
int get_since_epoch(unsigned long long * msts)
{

	struct timeval tv;

	gettimeofday(&tv, NULL);

	unsigned long long millisecondsSinceEpoch =
		(unsigned long long)(tv.tv_sec) * 1000 +
		(unsigned long long)(tv.tv_usec) / 1000;

	*msts = millisecondsSinceEpoch;
	return 0;
}


/**
 * \brief : Supportng function to read REST API response
 * \param : Starting location of message buffer
 * \return: NULL
 */
static void init_string( struct string *s )
{
    s->len = 0;
    s->ptr = malloc( s->len + 1 );
    if( s->ptr == NULL )
    {
        fprintf( stderr, "malloc() failed\n" );
        exit( EXIT_FAILURE );
    }
    else
    {
        s->ptr[ 0 ] = '\0';
    }
}


size_t writefunc(void *ptr, size_t size, size_t nmemb, struct string *s)
{
  size_t new_len = s->len + size*nmemb;
  s->ptr = realloc(s->ptr, new_len+1);
  if (s->ptr == NULL) {
    fprintf(stderr, "realloc() failed\n");
    exit(EXIT_FAILURE);
  }
  memcpy(s->ptr+s->len, ptr, size*nmemb);
  s->ptr[new_len] = '\0';
  s->len = new_len;

  return size*nmemb;
}

int send_curl_data(_packet * packet,char * buffer){
	int rc = 0;

    struct string s;

	struct curl_slist *headers = NULL;                      /* http headers to send with request */
	int content_length = 0;
	char con_header[128]={0};

    content_length = strlen(buffer);

#if 0
    /* initialising cloud */
    rc = cloud_init();
    if (rc != 0)
        IOBD_DEBUG_LEVEL1("cloud_init failed\n");
#endif

    init_string( &s );

    sprintf(con_header,"Content-Length: %d",content_length);

    headers = curl_slist_append(headers, packet->a_header.Accept);
	headers = curl_slist_append(headers, packet->a_header.Content_Type);
	headers = curl_slist_append(headers, packet->a_header.iothub_to);
	headers = curl_slist_append(headers, packet->a_header.Authorization);
	headers = curl_slist_append(headers, packet->a_header.Connection);
	headers = curl_slist_append(headers, packet->a_header.User_Agent);
	//headers = curl_slist_append(headers, packet->a_header.iothub_app_temperatureAlert);
	headers = curl_slist_append(headers, packet->a_header.Host);
	headers = curl_slist_append(headers, con_header);
#if 1
	headers = curl_slist_append(headers,packet->c_header.IoTHub_app_transactionId);
	headers = curl_slist_append(headers,packet->c_header.IoTHub_app_deviceId);
	headers = curl_slist_append(headers,packet->c_header.IoTHub_app_deviceType);
	headers = curl_slist_append(headers,packet->c_header.IoTHub_app_serviceName);
	headers = curl_slist_append(headers,packet->c_header.IoTHub_app_timestamp);
	//headers = curl_slist_append(headers,packet->c_header.Authorization);
#endif

    curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_HTTPHEADER, headers);

    curl_easy_setopt( ((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_WRITEFUNCTION, writefunc );
    curl_easy_setopt( ((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_WRITEDATA, &s );

    curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_POSTFIELDS, buffer);
    curl_easy_setopt(((Iotfclient *)(dmClient.deviceClient))->curl, CURLOPT_POSTFIELDSIZE, (long)strlen( buffer ) );

    rc = curl_easy_perform(((Iotfclient *)(dmClient.deviceClient))->curl);
    printf("curl_easy_perform %d - \n", rc);


    if( s.ptr != NULL )
    {
        printf("%s - Freeing s.ptr ( %p ) \n", __FUNCTION__, s.ptr );
        free( s.ptr );
        s.ptr = NULL;
    }
    else
    {
        printf("%s - s.ptr is NULL already\n", __FUNCTION__ );
    }

    curl_slist_free_all(headers);

#if 0
    /* initialising cloud */
    rc = cloud_deinit();
    if (rc != 0)
        IOBD_DEBUG_LEVEL1("cloud_init failed\n");
#endif

    return rc;
}

int check_telemetry(char * event){
	int result = 0;

	if((strcmp(event,"SAMPLING"))==0)
		result = 1;
	else 
		result = 0;

	return result;
}
