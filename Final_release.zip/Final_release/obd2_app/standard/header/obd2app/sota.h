#ifndef __SOTA_H_
#define __SOTA_H_

int start_sota_app ();
int get_3g_fd ();

#endif
