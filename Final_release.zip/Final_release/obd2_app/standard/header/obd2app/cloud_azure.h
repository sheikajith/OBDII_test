#ifndef __CLOUD_AZURE__
#define __CLOUD_AZURE__
#include "openssl/ssl.h"
#include "openssl/err.h"
#include <sys/socket.h>
#include <resolv.h>
#include <netdb.h>
#include <curl/curl.h>

typedef enum QoS {
        QOS0 = 0,
        QOS1 = 1
} QoS;


typedef struct iotfclient
{
	CURL *curl;
	int sockfd;
	int o_init_state;
}Iotfclient;

typedef struct config_azure{
        struct sockaddr_in addr;
        char deviceid[32];
	char hostname[128];
        char host[128];
	char http_deviceId[64];
	char http_deviceType[64];
	char IoTHubName[64];
//	char IoTHubName[100];
	char sas[256];
//	char sas[128];
        int port;
	char url[128];
	char transactionId[128];
	float fuel_used;
	char backup_battery_expire[64];
	char time_zone[64];

}config_azure;

config_azure cfg_azure;

Iotfclient iotfclient;
int get_cloud_config ();
size_t RecvResponseCallback ( char *, size_t, size_t, char *);
#endif
