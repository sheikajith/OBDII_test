#ifndef __COMMON__
#define __COMMON__

#include <netinet/in.h>
#include <signal.h>
#include "accelerometer.h"
#include "gyroscope.h"
#include <semaphore.h>
#include <mqueue.h>

#define MODE1 0x1
#define MODE2 0x2
#define MODE3 0x3
#define MODE4 0x4
#define MODE5 0x5
#define MODE6 0x6
#define MODE7 0x7
#define MODE8 0x8
#define MODE9 0x9

#define ENABLE_OBD_DEBUG

#ifdef ENABLE_OBD_DEBUG
#define IOBD_DEBUG(...)\
{\
	printf("DEBUG:   %s L#%d ", __func__, __LINE__);  \
	printf(__VA_ARGS__); \
	printf("\n"); \
}
#else
#define IOBD_DEBUG(...)
#endif

#define FREQ_GPSUPDATE 		0x0
#define FREQ_CARSTATUS 		0x1
#define FREQ_ACCELEROMETER 	0x2
#define FREQ_DTCCODE 		0x3
#define FREQ_GYROSCOPE 		0x4
#define FREQ_ANALYTICS		0x5

#define FREQ_ELEMENTS 10

typedef struct frequency
{
	char name[24];
	char select[5];
	int value;
}frequency;

typedef struct mode_pid
{
	double data;
	short int mode;
	char pid[10];
	char topic[100];
	char description[40];
	char raw_data[64];
}mode_pid;

typedef struct car_parameters{
	int no_of_pids;
	mode_pid * modepid;
}car_parameters;

typedef struct _xml{
        frequency freq[FREQ_ELEMENTS];
        car_parameters car_params;
}_xml;  

typedef void(*SLEEP)(void);
typedef struct slp_wkp_ptrs
{ 
	SLEEP slp;
	SLEEP wake;
	SLEEP slp_dis;
}SLEEP_WAKE; 

typedef void(*FPTR)(char *);
typedef struct ign_fun_ptrs
{
	FPTR ign_ON;
	FPTR ign_OFF;
	FPTR dis_stat;
	FPTR bat_drain;
	FPTR pnc_btn;
	FPTR crash_det;
	FPTR osm_cb;
}IGN_PTRS;

typedef struct _IO_PIN_STATUS_{
	short din1;
        short din2;
        short dout1[2];
        short dout2[2];
        short ain1;
}IO_PIN_STATE;

#define MAX_MSG_SIZE            256

typedef enum mode1_pid{
	ENGINE_LOAD = 0x04,
	ENGINE_COOLANT_TEMP,
	RPM = 0x0C,
	VEHICLE_SPEED,
	MAF_RATE = 0x10,
	RUNTIME_ENGINE_START = 0x1F,
	FUEL_LEVEL = 0x2F,
	DISTANCE_DTC_CLEAR = 0x31,
	CTRL_MODULE_VOLT = 0x42,
	AIR_TEMP = 0x46,
	OIL_TEMP = 0x5C,
	FUEL_RATE = 0x5E
}mode1_pid;

typedef enum mode9_pid{
	CMD_VIN = 0x02
}mode9_pid;

#define ON                                              1
#define OFF                                             2
#define MAX_MESSAGES                                    100
#define MAX_MSG_SIZE                                    256

#define IW_OBD_SUCCESS 0
#define IW_OBD_FAILURE -1

int get_accelerometer(accelerometer_api_priv *adata);
int init(IGN_PTRS *,SLEEP_WAKE *,_xml * xml_objs);
int get_imei_modem(char *);
int get_car_data(car_parameters *outcarparams);
void get_time (char *);
int set_cell_network_mode (int);
int flight_mode_off();
int flight_mode_on();
int drive_gpio_state ();
int update_io_function ();
void get_limit(void);
int evt_limits (void);
int update_time_limit ();
int _pause_ ();
int indicate_ignition_off_completed();

int get_gps_rmc_data(char *, size_t *);
int get_gps_vlw_data(char *, size_t *);
int get_gps_gsv_data(char *, size_t *);
int get_gps_gga_data(char *, size_t *);
int get_gps_gsa_data(char *, size_t *);
int get_gps_vtg_data(char *, size_t *);
int get_sim_id(char *sim_id);
int get_gsm_signal_level(char *signal_range);
float get_ext_power_voltage();
int hw_init(void);
int init_ign_dis_handler(void);
int check_protocol( int );
int check_mode(void);
int start_pm_client();
int get_gsm_cell_id(char *cell_id);
int get_gsm_lac_code(char *area_code);
int raw_can_enable(void);
int get_car_mode();
void server_connection_complete(void);
#if 0
float get_internal_battery_voltage();
float get_internal_battery_current();
#endif
int update_gpio_info (IO_PIN_STATE *);
#endif
