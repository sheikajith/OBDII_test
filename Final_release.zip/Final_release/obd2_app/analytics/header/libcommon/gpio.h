#ifndef __GPIO_H__
#define __GPIO_H__


#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define INPUT 1
#define OUTPUT 0
#define GPIO_HIGH		1
#define GPIO_LOW		0
#define MODEM_PWRKEY		47
#define STATUS_LED		77
#define MODEM_USB_SWITCH	78
#define BATTERY_CE		120
#define	REG_12V			92
#define REG_3V3			91
#define REG_4V4			90
#define DOUT1			36
#define DOUT2			38
#define RELAY			1
#define BUZZER			2
#define INTERPRETTER_CAN_EN	32
#define CPU_CAN_EN		67

int gpio_export(int gpio);
int get_gpio(int gpio, int * value);
int set_gpio_direction(int gpio, int direction);
int set_gpio_value(int gpio, short value);
int clear_cache (int);

#endif
