#include "application.h"
#include "gyroscope.h"
#include "analytics.h"
#include "analytics_queue.h"
#include "analytics_events.h"
#include "analytics_pkt_process.h"
#include "analytics_pkt_json.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "gpio.h"
#include "usb.h"

static bool flag = false;
double tot_odometer;
int fat_flag = 0;
static double old_val = 0.0;
int odo_updated = 0;
static int a_pkt_process_thread_create = 0;
static int analytics_thread_l1_create = 0;
static int analytics_thread_l2_create = 0;

int analytics_init()
{
	int rc = 0;
        rc = evt_limits ();
	if (rc < 0)
		IOBD_DEBUG_LEVEL1 ("evt_limits failed %d",rc);

	rc = update_time_limit ();
	if (rc < 0)
		IOBD_DEBUG_LEVEL1 ("update_time_limit failed %d",rc);

        /*set event limits as macro*/
        get_limit();

        /* Init Semaphore*/
        if (sem_init(&data_analytics.analytics_q_sem, 0, 1) == -1)
        {
                IOBD_DEBUG_LEVEL2("Sem Create Failed\r\n");
                rc = -2;
        }

        if (init_an_mq() == -1)
        {
                IOBD_DEBUG_LEVEL2("Message Queue Create Failed\r\n");
                rc = -3;
        }

	return rc;

}

int enable_analytics()
{
	int rc = 0;

	if(analytics_thread_init()<0)
	{
		IOBD_DEBUG_LEVEL2 ("init_analytics_thread failure \n");
		rc = -1;
	}

	return rc;
}

int analytics_thread_init()
{
    if( a_pkt_process_thread_create == 0)
    {
        if(pthread_create(&(a_handle[0]), NULL, (void*) a_pkt_process_thread, NULL) != OBD2_APP_SUCCESS){
            IOBD_DEBUG_LEVEL2 (" pthread_create for a_pkt_process_thread failed.%d \r\n",errno);
            printf("\n");
            printf("\n");
            printf("\n");
            system( "free -h" );
            printf("\n");
            printf("\n");
            printf("\n");
            return OBD2_APP_FAILURE;
        }
        else{
            IOBD_DEBUG_LEVEL4 (" a_pkt_process_thread is created\n");
            if (pthread_detach (a_handle[0]) != OBD2_APP_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("a_pkt_process_thread: pthread_detach failed %d",errno);
            a_pkt_process_thread_create = 1;
        }
    }
    else
    {
         IOBD_DEBUG_LEVEL4 (" a_pkt_process_thread is already created\n");
    }

    if( analytics_thread_l1_create == 0 )
    {
        if(pthread_create(&(a_handle[1]), NULL, (void*) analytics_thread_l1, NULL) != OBD2_APP_SUCCESS){
            IOBD_DEBUG_LEVEL2 (" pthread_create for analytics_thread_l1 failed. %d\r\n",errno);
            printf("\n");
            printf("\n");
            printf("\n");
            system( "free -h" );
            printf("\n");
            printf("\n");
            printf("\n");
            return OBD2_APP_FAILURE;
        }
        else{
//            IOBD_DEBUG_LEVEL4 (" analytics_thread_l1 is created\n");
            IOBD_DEBUG_LEVEL2 (" analytics_thread_l1 is created\n");
            if (pthread_detach (a_handle[1]) != OBD2_APP_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("analytics_thread_l1 :pthread_detach failed %d",errno);
            analytics_thread_l1_create = 1;
        }
    }
    else
    {
         IOBD_DEBUG_LEVEL4 ("analytics_thread_l1_create is already created\n");
    }

    if( analytics_thread_l2_create == 0 ) 
    {
        if(pthread_create(&(a_handle[2]), NULL, (void*) analytics_thread_l2, NULL) != OBD2_APP_SUCCESS){
            IOBD_DEBUG_LEVEL2 (" pthread_create for analytics_thread_l2 failed %d\r\n",errno);
            printf("\n");
            printf("\n");
            printf("\n");
            system( "free -h" );
            printf("\n");
            printf("\n");
            printf("\n");
            return OBD2_APP_FAILURE;
        }
        else{
//            IOBD_DEBUG_LEVEL4 (" analytics_thread_l2 is created\n");
            IOBD_DEBUG_LEVEL2 (" analytics_thread_l2 is created\n");
            if (pthread_detach (a_handle[2]) != OBD2_APP_SUCCESS)
                IOBD_DEBUG_LEVEL2 ("analytics_thread_l2: pthread_detach failed %d",errno);
            analytics_thread_l2_create = 1;
        }
    }
    else
    {
//         IOBD_DEBUG_LEVEL4 ("analytics_thread_l2_create is already created\n");
         IOBD_DEBUG_LEVEL2 ("analytics_thread_l2_create is already created\n");
    }

    return OBD2_APP_SUCCESS;
}

void a_pkt_process_thread(void)
{
	process_analytics_data_packets();
	IOBD_DEBUG_LEVEL2("a_pkt_process_thread exit \n");
    a_pkt_process_thread_create = 0;
}

void analytics_thread_l1 (void)
{
    printf("Entering analytics_thread_l1 #####################################\n" );
	int rc = OBD2_APP_SUCCESS;
	//struct obd_data obd_qdata;
	car_parameters carparams;

	i_analytics.h_acc_brk.prev_speed = -1;
	i_analytics.crash.prev_speed = -1;

	while(!dmClient.interrupt){
//		IOBD_DEBUG_LEVEL4 ("car_analytics_thread while + \n");
		IOBD_DEBUG_LEVEL2 ("car_analytics_thread while + \n");
		if(appClient.appSleep == APP_SLEEP){
			break;
		}
		get_car_data(&carparams);
		convert_raw_data(&carparams);
//		IOBD_DEBUG_LEVEL4 ("car_data.veh_speed  %lf car_data.rpm  %lf  car_data.distance_dtc_clear  %d\n",car_data.veh_speed,car_data.rpm,car_data.distance_dtc_clear);
		IOBD_DEBUG_LEVEL2 ("car_data.veh_speed  %lf car_data.rpm  %lf  car_data.distance_dtc_clear  %d\n",car_data.veh_speed,car_data.rpm,car_data.distance_dtc_clear);
		rc = car_data_analytics(car_data.veh_speed,car_data.rpm,car_data.distance_dtc_clear);

		if(rc < 0){
			IOBD_DEBUG_LEVEL2("Analytics failed! \n");
		}
//		IOBD_DEBUG_LEVEL4 ("car_analytics_thread while - \n");
		IOBD_DEBUG_LEVEL2 ("car_analytics_thread while - \n");
	}
#if 0
	obd_qdata.msg_type = EXIT_ANALYTICS;
	rc = send_msg_an_q(&obd_qdata);
        if(rc < 0)
        {
              IOBD_DEBUG_LEVEL2(" EXIT_ANALYTICS send to message_queue failed!\n");
        }
#endif
	IOBD_DEBUG_LEVEL2("analytics_thread_l1 exit \n");
    analytics_thread_l1_create = 0;
}

int ParseVLW(struct gps_vlw_t *gps_vlw, size_t nbytes)
{
        int j,k,l;
        char field[20][100] = {{0}};

        if (gps_vlw == NULL || nbytes <= 0)
                return OBD2_APP_FAILURE;

        for(j=0,k=0,l=0;j<nbytes;j++,l++)
        {
                for(;(gps_vlw->nmea[j] != ',') && (gps_vlw->nmea[j] != '\0');k++,j++)
                {
                        field[l][k] = gps_vlw->nmea[j];
                }
                field[l][k] = '\0';
                k=0;
        }

        gps_vlw->odo = atof(field[5]) * 1.94;//multiply by 2 because value are less actually for eg: 1KM we are getting 0.5KM

        IOBD_DEBUG_LEVEL2("VLW: %s \n",gps_vlw->nmea);
        IOBD_DEBUG_LEVEL2("###GPS odometer: %f \n",gps_vlw->odo);
        return OBD2_APP_SUCCESS;
}

void analytics_thread_l2 (void)
{

    printf("Entering analytics_thread_l2 #####################################\n" );
	char payload[128]={0};
	char ts[64]={0};
	struct obd_data obd_qdata;
#if GYRO_ENABLE
	double G;
#endif
	int ret = OBD2_APP_SUCCESS;
	int rc = OBD2_APP_SUCCESS;

	while(!dmClient.interrupt){
//		IOBD_DEBUG_LEVEL4("analytics_thread_l2 while + \n");
		IOBD_DEBUG_LEVEL2("analytics_thread_l2 while + \n");
		if(appClient.appSleep == APP_SLEEP){
			i_analytics.idle.car_idle_on = 0;
			i_analytics.idle.idle_start = 0;
            i_analytics.odo_updated = 0;
			break;
		}
#if GYRO_ENABLE
		if (usb_app.src.harsh == SRC_ACCELEROMETER)
			rc = harsh_cornering_acc (&G);
		else if (usb_app.src.harsh == SRC_GYROSCOPE)
			rc = harsh_cornering(&G);

		if (rc == 1){
			memset(payload,0,sizeof(payload));
            memset( &obd_qdata, 0, sizeof( struct obd_data ) );

			IOBD_DEBUG_LEVEL2("**********************************HARSH CORNERING %f********************************\n",G);
			get_time(ts);


			rc = final_payload_frame (ts, &obd_qdata, "HARSH");
			obd_qdata.msg_type = HARSH;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				IOBD_DEBUG_LEVEL2(" HARSH send to server failed!\n");
			}

		}
#endif
#if 0
		memset(payload,0,sizeof(payload));
		if(fatigue_detection ()== 1){
			get_time(ts);
			IOBD_DEBUG_LEVEL2("********************************FATIGUE DETECTED************************************\n");

			rc = final_payload_frame (ts, &obd_qdata, "FATIGUE_ON");
			obd_qdata.msg_type = FATIGUE_ON;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				IOBD_DEBUG_LEVEL2(" FATIGUE_ON send to server failed!\n");
			}
		}
#endif
		memset(payload,0,sizeof(payload));
		ret = excess_idling(car_data.rpm,car_data.veh_speed);
		if(ret == 1){

            memset( &obd_qdata, 0, sizeof( struct obd_data ) );
			get_time(ts);
			IOBD_DEBUG_LEVEL2("*************************************CAR IDLE ON************************************\n");


			rc = final_payload_frame (ts, &obd_qdata, "IDLE_ON");
			obd_qdata.msg_type = IDLE_ON;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				IOBD_DEBUG_LEVEL2(" IDLE_ON send to server failed!\n");
			}
		}
		if(ret == -1){
            memset( &obd_qdata, 0, sizeof( struct obd_data ) );
			get_time(ts);
			IOBD_DEBUG_LEVEL2("*************************************CAR IDLE OFF***********************************\n");

			rc = final_payload_frame (ts, &obd_qdata, "IDLE_OFF");
			obd_qdata.msg_type = IDLE_OFF;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				IOBD_DEBUG_LEVEL2(" IDLE_OFF send to server failed!\n");
			}
		}

		memset(payload,0,sizeof(payload));
		/*Add option to check vehicle or GPS*/

//		if (usb_app.src.o_spd == SRC_GPS){ 
		if(total_odometer() == 1)
		{
			IOBD_DEBUG_LEVEL4("*************************************TOTAL ODOMETER %f\n********************************",tot_odometer);
		}
		
		if (usb_app.src.o_spd == SRC_GPS){ 
			rc = over_speed_detection(usb_app.gps_speed);
		}else{	
			rc = over_speed_detection(car_data.veh_speed);
		}
		if (rc == BUZZER_ON){
            memset( &obd_qdata, 0, sizeof( struct obd_data ) );
			get_time(ts);

			IOBD_DEBUG_LEVEL2("************************** OVER SPEED ALERT-- %f*****************************\n",car_data.veh_speed);

			rc = final_payload_frame (ts, &obd_qdata, "OVERSPEED");
			obd_qdata.msg_type = OVERSPEED;
			rc = send_msg_an_q(&obd_qdata);
#ifdef __BUZZER__
			/*Switch ON the Buzzer*/
			//IOBD_DEBUG_LEVEL2("in overspeed usb_app.io.dout1[0] %d usb_app.io.dout2[0] %d\n",usb_app.io.dout1[0], usb_app.io.dout2[0]);
			if (usb_app.io.dout1[0] == 2){
				set_gpio_value (DOUT1, BUZZER_ON);
			}
			else if (usb_app.io.dout2[0] == 2)
				set_gpio_value (DOUT2, BUZZER_ON);
#endif
			if(rc < 0)
			{
				IOBD_DEBUG_LEVEL2("OVER SPEED ALERT data send to queue failed!\n");
			}
		}
		else if(rc == BUZZER_OFF) {
#ifdef __BUZZER__
			/*Switch OFF Buzzer*/
			if (usb_app.io.dout1[0] == 2){
			set_gpio_value (DOUT1, BUZZER_OFF);
			}
			else if (usb_app.io.dout2[0] == 2)
				set_gpio_value (DOUT2, BUZZER_OFF);
#endif
		}	

		if(over_temp_detection(car_data.Eng_cool_temp) == 1){
            memset( &obd_qdata, 0, sizeof( struct obd_data ) );
			get_time(ts);

			IOBD_DEBUG_LEVEL2("************************** OVER TEMP ALERT-- %f*****************************\n",car_data.Eng_cool_temp);


			rc = final_payload_frame (ts, &obd_qdata, "OVERTEMP");
			obd_qdata.msg_type = OVERTEMP;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				IOBD_DEBUG_LEVEL2("OVER TEMP ALERT data send to server failed!\n");
			}
		}

		memset(payload,0,sizeof(payload));


		usleep(500000);
//		IOBD_DEBUG_LEVEL4("analytics_thread_l2 while - \n");
		IOBD_DEBUG_LEVEL2("analytics_thread_l2 while - \n");
	}
	IOBD_DEBUG_LEVEL2 ("analytics_thread_l2 exit \n");
    analytics_thread_l2_create = 0;
}


int check_digital_input(){

	int rc = 0;
	char ts[64]={0};

	struct obd_data obd_qdata;

	rc = get_d_input_state();
	if(rc < 0)
	{
		IOBD_DEBUG_LEVEL2("Failed to read digital input state \n");
		goto exit;
	}
	else{
		if(i_analytics.d_input.saved_state!=rc){

            memset( &obd_qdata, 0, sizeof( struct obd_data ) );
			get_time(ts);
			IOBD_DEBUG_LEVEL2("********************* DIGITAL INPUT CHANGED from %d to %d *********************\n",i_analytics.d_input.saved_state,rc);
			i_analytics.d_input.saved_state = rc;
			strcpy(obd_qdata.data,ts);
			obd_qdata.msg_type = DGT_INP;
			rc = send_msg_an_q(&obd_qdata);

			if(rc < 0)
			{
				IOBD_DEBUG_LEVEL2("Digital Input ALERT data send to server failed!\n");
			}
		}
	}

exit:
	IOBD_DEBUG_LEVEL2("check_digital_input \n");
	return 0;

}

int get_d_input_state()
{

	return 0;
}

int over_temp_detection(double temp)
{
	int rc = 0;

	if(temp > i_analytics.o_temp.o_temp_threshold){

		if(i_analytics.o_temp.notify == 0){
			i_analytics.o_temp.notify = 1;	
			IOBD_DEBUG_LEVEL2("************************ OVERTEMP temp = %f**************************\n",temp);
			rc = 1;
		}
	}
	else{
		i_analytics.o_temp.notify = 0;
	}

	return rc;
}

int over_speed_detection(double speed)
{
	IOBD_DEBUG_LEVEL4("in overspeed detection\n");
	int rc = -1;
	int duration = 0;
	

	if(speed > i_analytics.o_spd.o_spd_threshold)
	{
		if(i_analytics.o_spd.is_o_spd == 0){
			if(i_analytics.o_spd.trigger!=1)
			{
				gettimeofday(&i_analytics.o_spd.sot,NULL);
				i_analytics.o_spd.trigger = 1;
			}
			else{
				gettimeofday(&i_analytics.o_spd.eot, NULL);
				duration = ((i_analytics.o_spd.eot.tv_usec - i_analytics.o_spd.sot.tv_usec) + (i_analytics.o_spd.eot.tv_sec - i_analytics.o_spd.sot.tv_sec)*1000000)/1000000;
			}
			IOBD_DEBUG_LEVEL4("Speed more than threshold! speed %f for %d seconds \n",speed,duration);
			if(duration >= i_analytics.o_spd.duration)
			{
				IOBD_DEBUG_LEVEL4("************************OVER SPEED ALERT   speed = %f**************************\n",speed);
				i_analytics.o_spd.trigger = 0;
				i_analytics.o_spd.is_o_spd = 1;
				rc = BUZZER_ON;
			}
		}
	}
	else if (i_analytics.o_spd.is_o_spd == 1)
	{
		i_analytics.o_spd.trigger = 0;
		i_analytics.o_spd.is_o_spd = 0;
		rc = BUZZER_OFF;
	}
	else 
		rc = -1;

	IOBD_DEBUG_LEVEL4("out overspeed detection rc = %d\n",rc);
	return rc;
}


/******************RPM DETECTION******************/
int rpm_detection (double speed,double rpm)         
{ 
IOBD_DEBUG_LEVEL4("rpm_detection rpm is %lf\n",rpm);
	if(rpm > i_analytics.o_rpm.rpm_threshold)
	{
		if(speed == 0 && i_analytics.o_rpm.mode_idle != 1)
		{
			IOBD_DEBUG_LEVEL4("*******************RPM DETECTED AT IDLE MODE-- r=%f s=%f********************\n",rpm,speed);
			i_analytics.o_rpm.mode_idle  = 1;
			return 1;
		}
		else if(speed > 0 && i_analytics.o_rpm.mode_ride != 1)
		{
			IOBD_DEBUG_LEVEL4("*******************RPM DETECTED AT RIDE MODE-- r=%f s=%f*********************\n",rpm,speed);
			i_analytics.o_rpm.mode_ride = 1;
			return 2;
		}
	}
	else
	{
		i_analytics.o_rpm.mode_idle = 0;
		i_analytics.o_rpm.mode_ride = 0;
	}
	return 0;
}

/**************HARSH ACCELERATION and BRAKING****************/

int harsh_acc_braking (double speed)
{
	int rc = 0;
	if(i_analytics.h_acc_brk.prev_speed == -1)
	{
		i_analytics.h_acc_brk.prev_speed = speed;
	}
	else
	{
		i_analytics.h_acc_brk.cur_speed = speed;
		IOBD_DEBUG_LEVEL4("prev_speed = %lf , cur_speed = %lf\n",i_analytics.h_acc_brk.prev_speed,i_analytics.h_acc_brk.cur_speed);
		i_analytics.h_acc_brk.acc = (((i_analytics.h_acc_brk.cur_speed-i_analytics.h_acc_brk.prev_speed)*5)/(9.80665*1*18));
		IOBD_DEBUG_LEVEL4("acc = %f in HARSH ACCELERATION and BREAKING\n",i_analytics.h_acc_brk.acc);

		if (i_analytics.h_acc_brk.acc >= i_analytics.h_acc_brk.acc_threshold)
		{	
			IOBD_DEBUG_LEVEL4("*******************HARSH ACCELERATION-- speed1 = %f speed2 = %f acc = %f*******************\n",i_analytics.h_acc_brk.prev_speed,i_analytics.h_acc_brk.cur_speed,i_analytics.h_acc_brk.acc);
			rc = 1;
		}

		if(i_analytics.h_acc_brk.acc <= i_analytics.h_acc_brk.brk_threshold)
		{
			IOBD_DEBUG_LEVEL4("*********************HARSH BREAKING-- speed1 = %f speed2 = %f acc = %f*********************\n",i_analytics.h_acc_brk.prev_speed,i_analytics.h_acc_brk.cur_speed,i_analytics.h_acc_brk.acc);
			rc = -1;
		}
		i_analytics.h_acc_brk.prev_speed = i_analytics.h_acc_brk.cur_speed;
	} 
	return rc;

}

int harsh_acc_braking_acc ()
{
	int rc = 0;
	double gyro_set = 0.1;
	gyroscope_api_priv g_value;

	if (i_analytics.h_acc_brk.h_acc == 1){
		rc = 1;
		i_analytics.h_acc_brk.h_acc = 0;
		goto exit;
	}
	else if (i_analytics.h_acc_brk.h_brk == 1){
		rc = -1;
		i_analytics.h_acc_brk.h_brk = 0;
		goto exit;
	}
	
	rc = get_accelerometer (&i_analytics.g_adata);
	if (rc != OBD2_APP_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("get_accelerometer failed in analytics");
	rc = get_gyroscope (&g_value);
	if (rc != OBD2_APP_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("get_gyroscope failed in analytics");

	IOBD_DEBUG_LEVEL2 ("H_ACC_BRK_ACC : i_analytics.g_adata.xaxis - %lf %lf %lf\n", i_analytics.g_adata.x, i_analytics.g_adata.y, g_value.z);
	
	//i_analytics.g_adata.x -= diff;
 
	if (i_analytics.g_adata.x >= i_analytics.h_acc_brk.acc_threshold || i_analytics.g_adata.y >= i_analytics.h_acc_brk.acc_threshold) 
	{
		if (g_value.z < gyro_set && g_value.z > (-1 * gyro_set)){
			IOBD_DEBUG_LEVEL2 ("*******************HARSH ACCELERATION****************acc = %lf\n",i_analytics.g_adata.x);
			rc = 1;
		}
	}
	if(i_analytics.g_adata.x <= i_analytics.h_acc_brk.brk_threshold || i_analytics.g_adata.y <= i_analytics.h_acc_brk.brk_threshold)
	{
		if (g_value.z < gyro_set && g_value.z > (-1 * gyro_set)){
		IOBD_DEBUG_LEVEL2 ("*******************HARSH BREAKING****************acc = %lf\n",i_analytics.g_adata.x);
		rc = -1;
		}
	}
	IOBD_DEBUG_LEVEL4 ("out harsh_acc_braking rc = %d\n",rc);
exit:
	return rc;

}
/*********************FATIGUE DETECTION***********************/

int fatigue_detection (void)
{
	int rc = 0;
		IOBD_DEBUG_LEVEL4 ("in fatigue_detection i_analytics.drive_start %d \n",i_analytics.ftg.drive_start);
	if(i_analytics.ftg.drive_start == 1)
	{
		gettimeofday(&i_analytics.ftg.eot, NULL);
		i_analytics.ftg.duration = ((i_analytics.ftg.eot.tv_usec - i_analytics.ftg.sot.tv_usec) + (i_analytics.ftg.eot.tv_sec - i_analytics.ftg.sot.tv_sec)*1000000)/1000000;

		IOBD_DEBUG_LEVEL4 ("duration inside fatigue detection %d FAT_Limit %d \n",i_analytics.ftg.duration,i_analytics.ftg.ftg_threshold);
		if(i_analytics.ftg.duration > i_analytics.ftg.ftg_threshold)
		{
			IOBD_DEBUG_LEVEL4 ("*********************FATIGUE DETECTED************************\n");
			i_analytics.ftg.drive_start = 0;
			rc = 1;
		}
	}
	else
	{	
		gettimeofday(&i_analytics.ftg.sot, NULL);
		i_analytics.ftg.drive_start = 1;
	}
	return rc;
}

int excess_idling (double rpm,double speed)
{

	//	static int idle_start = 0,car_idle_set = 0;
	//	static struct timeval sot,eot;

	if(rpm > 400)//checking minimum rpm for ignition ON condition
	{
		if(speed == 0)
		{
			if (i_analytics.idle.idle_start == 0)
			{
				gettimeofday(&i_analytics.idle.sot,NULL);
				i_analytics.idle.idle_start = 1;
			}

			gettimeofday(&i_analytics.idle.eot, NULL);
			i_analytics.idle.duration = ((i_analytics.idle.eot.tv_usec - i_analytics.idle.sot.tv_usec) + (i_analytics.idle.eot.tv_sec - i_analytics.idle.sot.tv_sec)*1000000)/1000000;
			IOBD_DEBUG_LEVEL4 ("duration inside idl_duration %d \n",i_analytics.idle.duration);

			if(i_analytics.idle.duration >= i_analytics.idle.idle_threshold)
			{
				if(i_analytics.idle.car_idle_on == 0)
				{
					IOBD_DEBUG_LEVEL2 ("*****************************CAR IDLE ON-- rpm = %f speed = %f ***************************\n",rpm,speed);
					i_analytics.idle.car_idle_on = 1;
					return 1;
				}
			}
		}	
		else
		{
			if(i_analytics.idle.car_idle_on == 1)
			{
				IOBD_DEBUG_LEVEL2 ("****************************CAR IDLE OFF-- rpm = %f speed = %f ***********************************\n",rpm,speed);
				i_analytics.idle.car_idle_on = 0;
				i_analytics.idle.idle_start = 0;
				return -1;
			}
		}
	}
	IOBD_DEBUG_LEVEL4 ("out excess_idling\n");
	return 0;
}

int total_odometer ()
{

	int rc = 0;
	double cur_val = 0.0;
	size_t nbytes;
	long int sz;
	char val_buf[32] = {0};
	static double old_odo_base = 0;
	double base = usb_app.limit.tot_odo;
	double val1 = 0.0,val2 = 0.0;
	int fb;//fb = base file ;
	int fp1,fp2;// fp1 = file 1(odometer1.txt) ; fp2 = file 2(odometer2.txt)
	int file_write = 0;
	double file_value = 0;


	get_gps_vlw_data(i_analytics.gps.gps_vlw.nmea, &nbytes);

    rc = ParseVLW(&i_analytics.gps.gps_vlw, nbytes);
	if (rc != OBD2_APP_SUCCESS){
		IOBD_DEBUG_LEVEL2 ("ParseVLW failed\n");
    }else{
        if (i_analytics.gps.gps_vlw.odo < old_val && i_analytics.odo_updated == 0 )
        {
            printf("i_analytics.gps.gps_vlw.odo < old_val && i_analytics.odo_updated == 0 \n" );
            old_val = i_analytics.gps.gps_vlw.odo;
        }
        else if( i_analytics.gps.gps_vlw.odo > old_val && i_analytics.odo_updated == 0 )
        {
            printf("i_analytics.gps.gps_vlw.odo > old_val && i_analytics.odo_updated == 0 case \n" );
            i_analytics.odo_updated = 1;
        }
	}
	if (car_data.veh_speed < 1.000000 && flag == true) // to avoid counting the odo value from gps when car is not moving.
		return -1;
	if(flag == false)
	{
		if(!access("/odo_config.txt", F_OK ))
		{
			if ((fb = open ("/odo_config.txt", O_RDONLY)) == OBD2_APP_FAILURE)
			{
				IOBD_DEBUG_LEVEL2("1.Can't open odo_config.txt for reading base value \n");
				rc = -1;
				goto jump;
			}
			find_file_size("/odo_config.txt", &sz);
			read (fb, val_buf, sz);
			old_odo_base = atof(val_buf);//scanning old base value
			IOBD_DEBUG_LEVEL4 ("old_odo_base is %f",old_odo_base);
			close(fb);
		}
jump:		old_val = i_analytics.gps.gps_vlw.odo;
		flag = true;
		rc = 1;
	}
	IOBD_DEBUG_LEVEL2 ("************************T_ODO********i_analytics.gps.gps_vlw.odo %f\n", i_analytics.gps.gps_vlw.odo);

	if (base != old_odo_base){
		old_odo_base = base;
		if((fb = open("/odo_config.txt", O_WRONLY|O_CREAT|O_SYNC)) == OBD2_APP_FAILURE)//open base file for getting base value
		{
			IOBD_DEBUG_LEVEL2("1.Can't open odo_config.txt for reading base value \n");
			rc = -1;
		}else{
			memset (val_buf,'\0',sizeof(val_buf));
			sprintf (val_buf,"%f",base);
			if (write (fb, val_buf, strlen(val_buf)) == OBD2_APP_FAILURE){
				IOBD_DEBUG_LEVEL2 ("write_failed with %d",errno);
			}
			else{
				fdatasync(fb);
				rc = posix_fadvise(fb, 0,0,POSIX_FADV_DONTNEED);
				if (rc)
					IOBD_DEBUG_LEVEL2 ("2. posix_fadvise is %d",rc);
			}
			close(fb);
		}
		IOBD_DEBUG_LEVEL2 ("************************base_value is  %f old_odo_base  %f \n",base, old_odo_base);
		system ("rm -rf /odometer*");
		system ("sync");
		flag = false;//to write first time whenever base value updated
	}		

	if(((access("/odometer1.txt", F_OK )) && (access("/odometer2.txt", F_OK ))))// if both file does not exists.
	{
		IOBD_DEBUG_LEVEL3 ("both file does not exist\n");
		if((fp1 = open("/odometer1.txt", O_WRONLY|O_CREAT|O_SYNC)) == OBD2_APP_FAILURE)//create file1
		{
			IOBD_DEBUG_LEVEL2("1.Can't open odometer1.txt \n");
			rc = -1;
		}else{
			close(fp1);
		}

		if(!access("/sample.xml", F_OK ))
		{
			IOBD_DEBUG_LEVEL2 ("************************%s:base value is %f\n",__func__, usb_app.limit.tot_odo);
			file_value = usb_app.limit.tot_odo;
			file_write = 1;
		}
		else
		{
			file_value = base;
			IOBD_DEBUG_LEVEL2 ("************************%s:file value is %f\n",__func__, file_value);
			file_write = 1;
		}

	}

	else if(((!access("/odometer1.txt", F_OK)) && (!access("/odometer2.txt", F_OK))))//if both file exists considering one file is corrupted
	{

		if ((fp1 = open ("/odometer1.txt", O_RDONLY)) == OBD2_APP_FAILURE)	
		{
			IOBD_DEBUG_LEVEL2("2.Can't open odometer1.txt \n");
			rc = -1;
		}else {
			memset (val_buf,'\0',sizeof(val_buf));
			find_file_size("/odometer1.txt", &sz);
			read (fp1, val_buf, sz);
			//	read (fp1, val_buf, sizeof(int));
			val1 = atof(val_buf);//scanning old base value
			close(fp1);
		}
		if ((fp2 = open ("/odometer2.txt", O_RDONLY)) == OBD2_APP_FAILURE)
		{
			IOBD_DEBUG_LEVEL2("2.Can't open odometer2.txt \n");
			rc = -1;
		}else{
			memset (val_buf,'\0',sizeof(val_buf));
			find_file_size("/odometer2.txt", &sz);
			read (fp2, val_buf, sz);
			val2 = atof(val_buf);//scanning old base value
			close(fp2);
		}
		if(val1 == 0.0)//check file 1 corrupted
		{
			file_value = val2 + i_analytics.gps.gps_vlw.odo; //+1 = while writing if device unplugged ; +1 = for updating 2nd time condition true
			file_write = 1;
		}
		else if (val2 == 0.0)//check file2 corrupted
		{
			file_value = val1 + i_analytics.gps.gps_vlw.odo;//+1 = while writing if device unplugged ; +1 = for updating 2nd time condition true
			file_write = 2;
		}
	}
	else if(!access("/odometer1.txt", F_OK))//if file1 exists       
	{
		if ((fp1 = open ("/odometer1.txt", O_RDONLY)) == OBD2_APP_FAILURE)	
		{
			IOBD_DEBUG_LEVEL2("3.Can't open odometer1.txt \n");
			rc = -1;
		}else{
			memset (val_buf,'\0',sizeof(val_buf));
			find_file_size("/odometer1.txt", &sz);
			read (fp1, val_buf, sz);
			cur_val = atof(val_buf);//last updated value
			close(fp1);
		}
		IOBD_DEBUG_LEVEL4 ("3.before cur_val = %f : %s\n",cur_val, val_buf);
		file_value = cur_val;
		file_write = 2;
	}
	else if(!access("/odometer2.txt", F_OK))//if file2 exists
	{
		if ((fp2 = open ("/odometer2.txt", O_RDONLY)) == OBD2_APP_FAILURE)	
		{
			IOBD_DEBUG_LEVEL2("4.Can't open odometer1.txt \n");
			rc = -1;
		}else{
			memset (val_buf,'\0',sizeof(val_buf));
			find_file_size("/odometer2.txt", &sz);
			read (fp2, val_buf, sz);
			//read (fp2, val_buf, sizeof(int));
			cur_val = atof(val_buf);
			close(fp2);
		}
		IOBD_DEBUG_LEVEL2 ("4.before cur_val = %f : %s\n",cur_val, val_buf);
		file_value = cur_val;
		file_write = 1;
	}

	if (i_analytics.gps.gps_vlw.odo > old_val)//checking for increment in distance
	{
		cur_val = file_value + (i_analytics.gps.gps_vlw.odo - old_val);
		/* save current value as old value */
		old_val = i_analytics.gps.gps_vlw.odo;
		IOBD_DEBUG_LEVEL2 ("i_analytics.gps.gps_vlw.odo %f cur_val %f \n",i_analytics.gps.gps_vlw.odo ,cur_val);
		rc = 1;
	}
	else{
		/* Dont update the file, Value not updated, same as previous */
		cur_val = file_value;
		IOBD_DEBUG_LEVEL2 ("cur_value is %f\n",cur_val);
		if(flag != false){
			/* Dont write to file, as the value is same as previous */
			file_write = 0;
		}
		else{
			/* If its first time, dont avoid writing to file */
			flag = true;
		}
	}

	if(file_write == 1)
	{
		if((fp1 = open("/odometer1.txt", O_WRONLY|O_CREAT|O_SYNC)) == OBD2_APP_FAILURE)//create file1
		{
			IOBD_DEBUG_LEVEL2("3.Can't open odometer1.txt errno %d \n",errno);
		}else{
			memset (val_buf,'\0',sizeof(val_buf));
			sprintf (val_buf,"%f",cur_val);
			if (write (fp1, val_buf, strlen(val_buf)) == OBD2_APP_FAILURE){
				IOBD_DEBUG_LEVEL2 ("write_failed with %d",errno);
			}else{
				fdatasync(fp1);
				rc = posix_fadvise(fp1, 0,0,POSIX_FADV_DONTNEED);
				if (rc)
					IOBD_DEBUG_LEVEL2 ("3. posix_fadvise is %d",rc);
			}

			close(fp1);
			IOBD_DEBUG_LEVEL2 ("value written to odometer1.txt\n");
			system("sync");
		}
		if(!access("/odometer2.txt", F_OK))
			system("rm /odometer2.txt");
		system("sync");
	}
	else if (file_write == 2)
	{
		if((fp1 = open("/odometer2.txt", O_WRONLY|O_CREAT|O_SYNC)) == OBD2_APP_FAILURE)//create file1
		{
			IOBD_DEBUG_LEVEL2("3.Can't open odometer2.txt errno %d\n",errno);
		}
		else{
			IOBD_DEBUG_LEVEL4 ("3.odometer2.txt file opened successfully\n");
			memset (val_buf,'\0',sizeof(val_buf));
			sprintf (val_buf,"%f",cur_val);
			if (write (fp1, val_buf, strlen(val_buf)) == OBD2_APP_FAILURE){
				IOBD_DEBUG_LEVEL2 ("write_failed with %d",errno);
			}else{
				fdatasync(fp1);
				rc = posix_fadvise(fp1, 0,0,POSIX_FADV_DONTNEED);
				if (rc)
					IOBD_DEBUG_LEVEL2 ("4. posix_fadvise is %d",rc);
			}
			close(fp1);
			IOBD_DEBUG_LEVEL4 ("value written to odometer2.txt\n");
			system("sync");
		}
		if(!access("/odometer1.txt", F_OK))
			system("rm /odometer1.txt");
		system("sync");
	}
	tot_odometer = cur_val;//updating odometer value
	i_analytics.t_odo.tot_odometer = cur_val;
	IOBD_DEBUG_LEVEL2 ("TOTAL_ODOMETER %f*********\n",i_analytics.t_odo.tot_odometer);
	return rc;
}

int find_file_size (const char *file_name, long int *sz)
{
	struct stat st; /*declare stat variable*/
	int ret;

	/*!< Check input arguments */
	if ((file_name == NULL) || (sz == NULL))
		return OBD2_APP_FAILURE;

	/*get the size using stat()*/
	if(stat(file_name,&st)==0){
		*sz = st.st_size;
		ret = OBD2_APP_SUCCESS;
	}
	else {
		IOBD_DEBUG_LEVEL2 ("#########%s: failed\n", __func__);
		*sz = sizeof (long int); 
		ret = OBD2_APP_FAILURE;
	}

	return ret;
}

double get_tot_odometer()
{
	return i_analytics.t_odo.tot_odometer;

}

int crash_detection (double speed)
{
	int rc = 0;
	IOBD_DEBUG_LEVEL4 ("in  crash detection \n");
	if(i_analytics.crash.prev_speed == -1)
	{
		i_analytics.crash.prev_speed = speed;
	}
	else
	{
		i_analytics.crash.cur_speed = speed;
		//              printf("speed2 = %f in HARSH ACCELERATION and BRAKING\n",speed2);
		i_analytics.crash.acc = (((i_analytics.crash.cur_speed-i_analytics.crash.prev_speed)*5)/(9.80665*1*18));
		//speed1 = speed2;
		IOBD_DEBUG_LEVEL4 ("acc = %f in  CRASH DETECTION\n",i_analytics.crash.acc);
		if (i_analytics.crash.acc <= i_analytics.crash.crash_threshold)
		{
			IOBD_DEBUG_LEVEL4("*******************CRASH DETECTION-- speed1 = %f speed2 = %f acc = %f*******************\n",i_analytics.crash.prev_speed,i_analytics.crash.cur_speed,i_analytics.crash.acc);
			rc = 1;
		}
		i_analytics.crash.prev_speed = i_analytics.crash.cur_speed;
	}
	IOBD_DEBUG_LEVEL4 ("out  crash detection \n");
	return rc;

}

int harsh_cornering_acc (double *G)
{
	int rc = 0;
	double gyro_set = 0.4;
	gyroscope_api_priv g_value;
	accelerometer_api_priv adata;
	*G = 0.0;

	rc = get_gyroscope (&g_value);
	if (rc != OBD2_APP_SUCCESS)
		IOBD_DEBUG_LEVEL2 ("get_gyroscope failed in harsh_analytics");
	rc = get_accelerometer (&adata);
	IOBD_DEBUG_LEVEL4 ("H_COR_ACC: i_analytics.g_adata.xaxis - %lf %lf %lf\n", adata.x, adata.y, g_value.z);
	if (rc == 0){//added peru
		IOBD_DEBUG_LEVEL4("***********************ACC VALUE********************\n");
		IOBD_DEBUG_LEVEL4 ("acc.y %f\n",adata.y);
		IOBD_DEBUG_LEVEL4 ("H_COR_LIMIT = %f\n",i_analytics.h_crn.dps_threshold);
		//	*G = adata.y;

		if((adata.x > i_analytics.h_crn.dps_threshold) || (adata.y > i_analytics.h_crn.dps_threshold)){
			if (g_value.z > gyro_set || g_value.z < (-1 *gyro_set)){
				if (adata.x > i_analytics.h_crn.dps_threshold)
					*G = adata.x;
				else
					*G = adata.y;

				IOBD_DEBUG_LEVEL4("*********************************HARSH CORNERING %lf %lf ********************************\n", adata.x, adata.y);
				rc = 1;
			}
			else{
				if (adata.x > i_analytics.h_acc_brk.acc_threshold || adata.y > i_analytics.h_acc_brk.acc_threshold)
					i_analytics.h_acc_brk.h_acc = 1;
			}
		}
	//	*G = adata.x;
		if (adata.x < (-1 *i_analytics.h_crn.dps_threshold) || (adata.y < (-1 * i_analytics.h_crn.dps_threshold))){
                        if (g_value.z > gyro_set || g_value.z < (-1 * gyro_set)){
				if (adata.x < (-1 *i_analytics.h_crn.dps_threshold))
					*G = adata.x;
				else
					*G = adata.y;
						
				IOBD_DEBUG_LEVEL4("*********************************HARSH CORNERING %lf %lf ********************************\n", adata.x, adata.y);
                                rc = 1;
                        }
			else{
				if (adata.x < i_analytics.h_acc_brk.brk_threshold || adata.y < i_analytics.h_acc_brk.brk_threshold)
					i_analytics.h_acc_brk.h_brk = 1;
			}
                }

	}
	else
		IOBD_DEBUG_LEVEL2("Gyro failed in H_COR with rc = %d\n",rc);
	return rc;
}


int harsh_cornering (double *G)
{
	int rc = 0;
	//double dps,RPM;
	gyroscope_api_priv g_value;

	rc = get_gyroscope (&g_value);

	if (rc == 0){//added peru
		IOBD_DEBUG_LEVEL4 ("H_COR_LIMIT = %f\n",i_analytics.h_crn.dps_threshold);
		*G = g_value.z ; 
		IOBD_DEBUG_LEVEL4 ("Gz %f , %f\n", g_value.z, *G);
#if 0
		dps = g_value.z;
		IOBD_DEBUG_LEVEL2("dps = %f\n",dps);
		if(dps > i_analytics.h_crn.dps_threshold || dps < -i_analytics.h_crn.dps_threshold){
			/* Revolutions per minute according to gyroscope dps values */
			RPM = dps/6;
			/* Constant * 90feet(radius) * RPM square */

			*G = 0.000001118 * 27432 * (RPM * RPM);
			IOBD_DEBUG_LEVEL2("G = %f\n",*G);
			if(*G > 0.28){
				IOBD_DEBUG_LEVEL2("*********************************HARSH CORNERING %f********************************\n",*G);
				rc = 1;
			}
		}
#endif
			if(*G > i_analytics.h_crn.dps_threshold || *G < (-1 * i_analytics.h_crn.dps_threshold)){
				IOBD_DEBUG_LEVEL4 ("*********************************HARSH CORNERING %f********************************\n",*G);
				rc = 1;
			}
	}
	else
		IOBD_DEBUG_LEVEL3("Gyro failed in H_COR with rc = %d\n",rc);
	return rc;
}


int car_data_analytics(double vehicle_speed, double rpm, int distance_dtc_clear)
{
	int rc = 0;
	int ret = 0;
	char payload[128]={0};
	struct obd_data obd_qdata;

	int get_gps = 0;
	char ts[100]={0};

	if ((usb_app.src.h_acc == SRC_ACCELEROMETER)||(usb_app.src.h_brk == SRC_ACCELEROMETER))
		ret = harsh_acc_braking_acc ();
	else if ((usb_app.src.h_acc == SRC_VEHICLE_SPEED)||(usb_app.src.h_brk == SRC_VEHICLE_SPEED)) 
		ret = harsh_acc_braking (vehicle_speed);

	if(ret == 1){
		get_time(ts);
		if(get_gps == 0){
			get_gps = 1;
		}
		IOBD_DEBUG_LEVEL2("**********************************HARSH ACCELERATION %s ********************************\n",ts);
	
        memset( &obd_qdata, 0, sizeof( struct obd_data ) );	
		rc = final_payload_frame (ts, &obd_qdata, "HARSH_ACC");
		obd_qdata.msg_type = HARSH_ACC;
		rc = send_msg_an_q(&obd_qdata);
		if(rc < 0)
		{
			IOBD_DEBUG_LEVEL2(" HARSH_ACC send to server failed!\n");
		}
		else
                	IOBD_DEBUG_LEVEL3 ("HARSH_ACC event sent to message queue");

	}
	if(ret == -1){
		get_time(ts);

		if(get_gps == 0){
			get_gps = 1;
		}

		IOBD_DEBUG_LEVEL2("************************************HARSH BRAKING %s **********************************\n",ts);

        memset( &obd_qdata, 0, sizeof( struct obd_data ) );
		strcpy(obd_qdata.data,ts);
		rc = final_payload_frame (ts, &obd_qdata, "HARSH_BRK");

		obd_qdata.msg_type = HARSH_BRK;
		rc = send_msg_an_q(&obd_qdata);

		if(rc < 0)
		{
			IOBD_DEBUG_LEVEL2(" HARSH_BRK send to server failed!\n");
		}
	}
	memset(payload,0,sizeof(payload));
#if 0
	 if (usb_app.src.crash == SRC_ACCELEROMETER){
                ret = crash_detection_acc (acc.x_axis);
	}else if (usb_app.src.h_acc == SRC_VEHICLE_SPEED){
	        ret = crash_detection(vehicle_speed);
	}
#endif
	if (usb_app.src.h_acc == SRC_VEHICLE_SPEED){
                ret = crash_detection(vehicle_speed);
        }

	if(ret == 1){
		get_time(ts);

		if(get_gps == 0){
			get_gps = 1;
		}

        memset( &obd_qdata, 0, sizeof( struct obd_data ) );
		IOBD_DEBUG_LEVEL2("**********************************CRASH DETECTION********************************\n");
		rc = final_payload_frame (ts, &obd_qdata, "CRASH");
		obd_qdata.msg_type = CRASH;
		rc = send_msg_an_q(&obd_qdata);

		if(rc < 0)
		{
			IOBD_DEBUG_LEVEL2(" CRASH send to server failed!\n");
		}
		else
                	IOBD_DEBUG_LEVEL3 ("CRASH event sent to message queue");

	}

	memset(payload,0,sizeof(payload));

	ret = rpm_detection (vehicle_speed,rpm);
	if(ret == 1 ){
		get_time(ts);

		if(get_gps == 0){

			get_gps = 1;
		}

        memset( &obd_qdata, 0, sizeof( struct obd_data ) );
		IOBD_DEBUG_LEVEL2("*******************RPM DETECTED AT IDLE MODE-- r=%f s=%f********************\n",rpm,vehicle_speed);

		rc = final_payload_frame (ts, &obd_qdata, "RPM_OVER");
		obd_qdata.msg_type = RPM_OVER;
		rc = send_msg_an_q(&obd_qdata);
		if(rc < 0)
		{
			IOBD_DEBUG_LEVEL2("RPM_OVER at idle, send to server failed!\n");
		}
		else
                	IOBD_DEBUG_LEVEL3 ("RPM_OVER event sent to message queue");
	}
	if(ret == 2 ){
		get_time(ts);

		if(get_gps == 0){
			get_gps = 1;
		}

        memset( &obd_qdata, 0, sizeof( struct obd_data ) );
		IOBD_DEBUG_LEVEL2("*******************RPM DETECTED AT RIDE MODE-- r=%f s=%f*********************\n",rpm,vehicle_speed);            

		rc = final_payload_frame (ts, &obd_qdata, "RPM_OVER");
		obd_qdata.msg_type = RPM_OVER;
		rc = send_msg_an_q(&obd_qdata);

		if(rc < 0)
		{
			IOBD_DEBUG_LEVEL2("RPM_OVER at idle, send to server failed!\n");
		}
	}

	return 0;
}


int send_data_to_cloud(char * packet,int event)
{
	int rc = 0;
	struct obd_data obd_qdata;
    memset( &obd_qdata, 0, sizeof( struct obd_data ) );
	obd_qdata.msg_type = event;
	memset(obd_qdata.data,0x0,256);
	strncpy(obd_qdata.data,packet, strlen(packet));
	rc = send_msg_an_q(&obd_qdata);

	return rc;
}

void get_limit()
{
	if (usb_app.src.h_acc == SRC_VEHICLE_SPEED){
		i_analytics.h_acc_brk.acc_threshold = ((usb_app.limit.h_acc*5)/(9.80665*1*18));
		IOBD_DEBUG_LEVEL3("i_analytics.h_acc_brk.acc_threshold = %lf\n",i_analytics.h_acc_brk.acc_threshold);
	}
	else if(usb_app.src.h_acc == SRC_ACCELEROMETER){
		i_analytics.h_acc_brk.acc_threshold = usb_app.limit.h_acc;
		IOBD_DEBUG_LEVEL3("i_analytics.h_acc_brk.acc_threshold = %lf\n",i_analytics.h_acc_brk.acc_threshold);
	}
	if (usb_app.src.h_brk == SRC_VEHICLE_SPEED){
		i_analytics.h_acc_brk.brk_threshold = ((usb_app.limit.h_brk * 5 * -1)/(9.80665*1*18)); 
		IOBD_DEBUG_LEVEL3("i_analytics.h_acc_brk.brk_threshold = %lf\n",i_analytics.h_acc_brk.brk_threshold);
	}
	else if (usb_app.src.h_brk == SRC_ACCELEROMETER){
		i_analytics.h_acc_brk.brk_threshold = usb_app.limit.h_brk * -1;
		IOBD_DEBUG_LEVEL3("i_analytics.h_acc_brk.brk_threshold = %lf\n",i_analytics.h_acc_brk.brk_threshold);
	}
	if (usb_app.src.crash == SRC_VEHICLE_SPEED){
		i_analytics.crash.crash_threshold = ((usb_app.limit.crash * 5 * -1)/(9.80665*1*18));
		IOBD_DEBUG_LEVEL3("1.i_analytics.crash.crash_threshold = %lf usb_app.src.crash = %d\n",i_analytics.crash.crash_threshold,usb_app.src.crash);
	}
	else if(usb_app.src.crash == SRC_ACCELEROMETER){
		i_analytics.crash.crash_threshold = usb_app.limit.crash * -1;
		IOBD_DEBUG_LEVEL3("2.i_analytics.crash.crash_threshold = %lf usb_app.src.crash = %d\n",i_analytics.crash.crash_threshold,usb_app.src.crash);
	}
	if (usb_app.src.harsh == SRC_GYROSCOPE){
		i_analytics.h_crn.dps_threshold = usb_app.limit.harsh/10.0;
		IOBD_DEBUG_LEVEL3("1.i_analytics.h_crn.dps_threshold = %lf\n",i_analytics.h_crn.dps_threshold);
	}
	else if (usb_app.src.harsh == SRC_ACCELEROMETER){
		i_analytics.h_crn.dps_threshold = usb_app.limit.harsh;
		IOBD_DEBUG_LEVEL3("2.i_analytics.h_crn.dps_threshold = %lf\n",i_analytics.h_crn.dps_threshold);
	}

	i_analytics.o_spd.o_spd_threshold = usb_app.limit.o_spd;
	IOBD_DEBUG_LEVEL3("i_analytics.o_spd.o_spd_threshold = %d\n",i_analytics.o_spd.o_spd_threshold);
	i_analytics.o_rpm.rpm_threshold = usb_app.limit.rpm;
	IOBD_DEBUG_LEVEL3("i_analytics.o_rpm.rpm_threshold = %lf\n",i_analytics.o_rpm.rpm_threshold);
	i_analytics.ftg.ftg_threshold = usb_app.limit.fat;
	IOBD_DEBUG_LEVEL3("i_analytics.ftg.ftg_threshold = %d\n",i_analytics.ftg.ftg_threshold);
	i_analytics.idle.idle_threshold = usb_app.limit.idle;
	IOBD_DEBUG_LEVEL3("i_analytics.idle.idle_threshold = %d\n",i_analytics.idle.idle_threshold);
	i_analytics.o_temp.o_temp_threshold = usb_app.limit.o_temp;
	IOBD_DEBUG_LEVEL3("i_analytics.o_temp.o_temp_threshold = %lf\n",i_analytics.o_temp.o_temp_threshold);
}

int evt_limits ()
{
	int rc = 0;
	char value [10];
	bzero (value,sizeof(value));
	/*!< HARSH_BRK_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_BRK, FIELD_NAME_SRC, value);
	usb_app.src.h_brk = atoi (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.src.h_brk = %d\n",usb_app.src.h_brk);
	/*!< HARSH_ACC_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_ACC, FIELD_NAME_SRC, value);
	usb_app.src.h_acc = atoi (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.src.h_acc = %d\n",usb_app.src.h_acc);
	/*!< CRASH_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_CRASH, FIELD_NAME_SRC, value);
	usb_app.src.crash = atoi (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.src.crash = %d\n",usb_app.src.crash);
	/*!< HARSH_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_HARSH, FIELD_NAME_SRC, value);
	usb_app.src.harsh = atoi (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.src.harsh = %d\n",usb_app.src.harsh);
	/*!< O_SPEED_SRC */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_OSPD, FIELD_NAME_SRC, value);
	usb_app.src.o_spd = atoi (value);
	IOBD_DEBUG_LEVEL3 ("usb_app.src.o_spd = %d\n",usb_app.src.o_spd);
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_OSPD, FIELD_NAME_DUR, value);
	i_analytics.o_spd.duration = atoi (value);
	IOBD_DEBUG_LEVEL3 ("i_analytics.o_spd.duration = %d\n",i_analytics.o_spd.duration);
	/*!< add lock to limits*/
	/*!< CRASH_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_CRASH, FIELD_NAME_THRESH, value);
	usb_app.limit.crash = atof (value);
	IOBD_DEBUG_LEVEL3 ("usb_app.limit.crash = %lf\n",usb_app.limit.crash);
	/*!< RPM_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_RPM, FIELD_NAME_THRESH, value);
	usb_app.limit.rpm = atof (value);
	IOBD_DEBUG_LEVEL3 ("usb_app.limit.rpm = %lf\n",usb_app.limit.rpm);
	/*!< H_ACC_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_ACC, FIELD_NAME_THRESH, value);
	usb_app.limit.h_acc = atof (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.limit.h_acc = %lf\n",usb_app.limit.h_acc);
	/*!< H_BRK_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_BRK, FIELD_NAME_THRESH, value);
	usb_app.limit.h_brk = atof (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.limit.h_brk = %lf\n",usb_app.limit.h_brk);
	/*!< HARSH_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_HARSH, FIELD_NAME_THRESH, value);
	usb_app.limit.harsh = atof (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.limit.harsh = %lf\n",usb_app.limit.harsh);
	/*!< ODOMETER_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_ODO, FIELD_NAME_BASE, value);
	usb_app.limit.tot_odo = atof (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.limit.tot_odo = %f\n",usb_app.limit.tot_odo);
	/*!< O_SPD_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_OSPD, FIELD_NAME_THRESH, value);
	usb_app.limit.o_spd = atoi (value);
	IOBD_DEBUG_LEVEL3 ("usb_app.limit.o_spd = %d\n",usb_app.limit.o_spd);
	/*!< O_TEMP_LIMIT */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_OTEMP, FIELD_NAME_THRESH, value);
	usb_app.limit.o_temp = atof (value);
	IOBD_DEBUG_LEVEL3 ("usb_app.limit.o_temp = %lf\n",usb_app.limit.o_temp);

	return rc;
}


int update_time_limit ()
{
	int rc = 0;
	char value[10];
	/*!< IDL_TIME_LIMIT */
	bzero(value,sizeof (value));
	rc = get_xml_content (SRC_XML_FILE,PARENT_NODE_FREQ ,PARENT_NODE_IDL , value);
	usb_app.limit.idle = atoi (value);
	IOBD_DEBUG_LEVEL3 ("usb_app.limit.idle = %d\n",usb_app.limit.idle);
	/*!< FATIGUE_LIMIT */
	bzero(value,sizeof (value));
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_FREQ, PARENT_NODE_FAT, value);
	usb_app.limit.fat = atoi (value);
	IOBD_DEBUG_LEVEL3 ("usb_app.limit.fat = %d\n",usb_app.limit.fat);
	return rc;

}

int update_io_function ()
{
	int rc = 0;
	char value[2];
	
	IO_PIN_STATE io_pin;
	/*!< DOUT1 */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DOUT1, FIELD_NAME_SRC, value);
	usb_app.io.dout1[0] = atoi (value);
	IOBD_DEBUG_LEVEL4("usb_app.io.dout1[0] = %d\n",usb_app.io.dout1[0]);
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DOUT1, FIELD_NAME_VALUE, value);
	usb_app.io.dout1[1] = atoi (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.io.dout1[1] = %d\n",usb_app.io.dout1[1]);
	/*!< DOUT2 */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DOUT2, FIELD_NAME_SRC, value);
	usb_app.io.dout2[0] = atoi (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.io.dout2[0] = %d\n",usb_app.io.dout2[0]);
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DOUT2, FIELD_NAME_VALUE, value);
	usb_app.io.dout2[1] = atoi (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.io.dout2[1] = %d\n",usb_app.io.dout2[1]);
	/*!< DIN1 */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DIN1, FIELD_NAME_SRC, value);
	usb_app.io.din1 = atoi (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.io.din1 = %d\n",usb_app.io.din1);
	/*!< DIN2 */
	rc = get_xml_content (SRC_XML_FILE, PARENT_NODE_DIN2, FIELD_NAME_SRC, value);
	usb_app.io.din2 = atoi (value);
	IOBD_DEBUG_LEVEL4 ("usb_app.io.din2 = %d\n",usb_app.io.din2);

	io_pin.din1 = usb_app.io.din1;
	io_pin.din2 = usb_app.io.din2;
	io_pin.dout1[0] = usb_app.io.dout1[0];
	io_pin.dout1[1] = usb_app.io.dout1[1];
	io_pin.dout2[0] = usb_app.io.dout2[0];
	io_pin.dout2[1] = usb_app.io.dout2[1];
	io_pin.ain1 = usb_app.io.ain1;
	update_gpio_info (&io_pin);

	return rc;
}

int drive_gpio_state ()
{
	/*Relay - 1 Buzzer - 2*/
	int ret;
	IOBD_DEBUG_LEVEL3("drive_gpio_state +\n");
	ret = set_gpio_value(DOUT1,usb_app.io.dout1[1]);
	ret = set_gpio_value(DOUT2,usb_app.io.dout2[1]);

	IOBD_DEBUG_LEVEL2("drive_gpio_state - %d\n",ret);

	return ret;
}
