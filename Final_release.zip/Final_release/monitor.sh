while true; do

pidof iWaveOBD2FW  > /dev/null
if [ $? != 0 ]; then
echo "iWaveOBD2FW is not running"
i2cset -f -y 1 0x6a 0x11 0x00
sync
sleep 1
i2cset -f -y 1 0x6a 0x10 0x00
sync
sleep 1
reboot
sync
else
#echo "iWaveOBD2FW is running"
free -h
fi
sleep 1
done

