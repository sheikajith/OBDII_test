#include <blackbox.h>
#include <debug.h>
#include <error_macro.h>

LONG get_blackbox_sz (obd_gui_cfg_proto_t *p_proto, ULONG *p_st)
{
	LONG ret = 0;
	FILE *fp;
	int size = 0;

	fp = fopen(BLACKBOX_FILE, "r");

	if (fp == NULL)
	{
		ERROR ("\nFile unable to open ");
	}
	else 
	{
		DEBUG ("\nFile opened ");
	}

	fseek(fp, 0, SEEK_END);    /* file pointer at the end of file */

	size = ftell(fp);   /* take a position of file pointer un size variable */
	
	fseek(fp, 0, SEEK_SET);
	

	DEBUG ("The size of given file is : %d\n", size);    

	*p_st = size;

	fclose(fp);
	return ret;
}

LONG get_blackbox (obd_gui_cfg_proto_t *p_proto, UCHAR *blackbox_payload)
{                                       
        LONG ret = 0;                   
        FILE *fp;               
        int size = 0;
	static int file_ptr = 0; 
                        
        fp = fopen(BLACKBOX_FILE, "rt");
                         
        if (fp == NULL)         
	{
                ERROR ("\nFile unable to open ");
	}
        else
	{
                DEBUG ("\nFile opened ");
	}

        fseek(fp, file_ptr, SEEK_SET);         


	size = fread(blackbox_payload, 1, 1024, fp);

	file_ptr += size;

        DEBUG ("file_ptr : %d\n", file_ptr);

	if (file_ptr == blackbox_sz)
	{
		DEBUG ("All blackbox data read... !!\n");
		file_ptr = 0;
	} 
                                
        fclose(fp);             
        return ret;      
} 
