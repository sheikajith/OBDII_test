#include<os.h>
#include<debug.h>
#include <error_macro.h>
#include <standard_queue.h>

/*!
 * \brief
 *   function to Initilize msg_que .
 *
 * \details
 *   This function will initilize msq_queue.
 *   msq_queue is communication queue between
 *   iWOBD2FW and USB device application 
 *
 * \param [in] param
 *  p_app - pointer to app_priv_t structure.
 */

LONG msg_q_init (app_priv_t *p_app)
{
	LONG ret = OBD_GUI_INF_SUCCESS; 
	p_app->mq = malloc (sizeof (msg_q_t));
	if(p_app->mq == NULL)
	{
		ERROR ("Failed to allocate memory\n");
	}

	p_app->mq->queue = init_mq(MSG_Q); 
	if(p_app->mq->queue < 0)
	{
		ERROR ("Failed to init msg_queue\n");
		ret = E_APP_MSG_Q_INIT;
	}

#if 0
	p_app->mq->start_queue = init_mq(START_MSG_Q); 
	if(p_app->mq->start_queue < 0)
	{
		ERROR ("Failed to init msg_queue\n");
		ret = E_APP_MSG_Q_INIT;
	}
#endif

//	ret = recv_msg_q_frm_fw(p_app->mq->start_queue, buffer, sizeof(buffer));

	

//	DEBUG ("p_app->mq->start_queue = %d\n", p_app->mq->start_queue);

//	DEBUG ("Start ->buffer = %s\n", buffer);


	return ret;
}
