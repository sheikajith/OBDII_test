#include <dwnld.h>
#include <debug.h>
#include <error_macro.h>

/*!
 * \brief
 * upgrade_uboot function to do u-boot upgrade/flashing
 *
 * \details
 * This function is called by Application to upgrade u-boot
 *
 * \param [in] fd
 * File descriptor of Device node
 *
 * \param [in] status
 * message which contain the u-boot status
 *
 * \return
 * Success 0
 * Error -1
 */
int upgrade_uboot()
{
	int ret, fs_ret;
	char command[100];
	strcpy(command, "chmod 777 /firmware_upgrade/uboot/u-boot.imx");
	ret = system(command);
	strcpy(command, "flash_erase /dev/mtd0 0 0");
	ret = system(command);
	usleep(50000);
	strcpy(command, "kobs-ng init -x -v --chip_0_device_path=/dev/mtd0 /firmware_upgrade/uboot/u-boot.imx");
	ret = system(command);
	sleep(10);
	strcpy(command, "sync");
	ret = system(command);
	usleep(50000);
	return 0;
}

/*!
 * \brief
 * upgrade_uImage function to do uImage upgrade/flashing
 *
 * \details
 * This function is called by Application to upgrade uImage
 *
 * \param [in] fd
 * File descriptor of Device node
 *
 * \param [in] status
 * message which contain the uImage status
 *
 * \return
 * Success 0
 * Error -1
 */
int upgrade_uImage()
{
	int ret, um_ret;
	char command[100];
	strcpy(command, "chmod 777 /firmware_upgrade/zImage/zImage.tar.bz2");
	ret = system(command);
	strcpy(command, "flash_erase /dev/mtd1 0 0");
	ret = system(command);
	sleep(10);
	strcpy(command, "flash_erase /dev/mtd2 0 0");
	ret = system(command);
	sleep(10);

	strcpy(command, "tar -xf /firmware_upgrade/zImage/zImage.tar.bz2 -C /firmware_upgrade/zImage/");
	ret = system(command);
	usleep(50000);
	strcpy(command, "nandwrite -p /dev/mtd1 -p /firmware_upgrade/zImage/zImage");
	ret = system(command);
	strcpy(command, "nandwrite -p /dev/mtd2 -p /firmware_upgrade/zImage/imx6ull-iwg18m-sm.dtb");
	ret = system(command);
	strcpy(command, "sync");
	ret = system(command);
	usleep(50000);
//	system("reboot");
	return 0;
}

int upgrade_obd2fw()
{
	int ret;
	char command[200];
	strcpy(command, "chmod 777 /firmware_upgrade/rootfs/Application.tar.bz2");
	ret = system(command);
	usleep(50000);

	strcpy(command, "rm -rf /iwtest/Application/");
	ret = system(command);
	usleep(50000);
	strcpy(command, "tar -xf /firmware_upgrade/rootfs/Application.tar.bz2 -C /iwtest/");
	ret = system(command);
	usleep(50000);
	strcpy(command, "sync");
	ret = system(command);
	usleep(50000);
	system("chmod 777 -R /iwtest/Application/");
	system ("cp -rf /iwtest/Application/libanalytics.so /usr/lib/");
        system ("sync");
	return 0;
}


LONG dwnld_upgrade (obd_gui_cfg_proto_t *proto)
{
	LONG ret =  OBD_GUI_INF_SUCCESS;
	if (flag_uboot_enable == 1)
	{
		upgrade_uboot();
		flag_uboot_enable = 0;
	}
	else if (flag_uImage_enable == 1)
	{
		upgrade_uImage();
		flag_uImage_enable = 0;
	}
	else if (flag_obd2fwapp_enable == 1)
	{
		upgrade_obd2fw();
		flag_obd2fwapp_enable = 0;
	}

	return ret;
}
LONG dwnld_send_rsp (obd_gui_cfg_proto_t *proto, usb_board *p_dwnld_req, USHORT rsp, UCHAR *payload, size_t sz)
{
	usb_board hdr;
	LONG ret =  OBD_GUI_INF_SUCCESS;

	/*!< Validaet input parameter */
	if (proto == NULL || p_dwnld_req == NULL)
	{
		ERROR ("Invalid arguments\n");
	}

	hdr.scr_id = p_dwnld_req->scr_id;
	hdr.cmd_id = rsp;
	hdr.type = p_dwnld_req->type;
	hdr.size = sz;
 
	/*!< Handle all error case */
	protocol_write (proto, &hdr, payload, sz);
	
	return ret;
}

/*!
 * \brief
 * file_exist function to Check presence of a file
 *
 * \details
 * This function is called by Application to Check presence of a file
 *
 * \param [in] filename
 * File name for checking
 *
 * \return
 * File present 1
 * File not present 0
 */
int file_exist (char *filename)
{
        struct stat buffer;
        return (stat (filename, &buffer) == 0);
}


/*!
 * \brief
 * Called to calculate the checksum.
 *
 * \detail
 * Calculate the checksum for the downloaded image
 *
 * \param [in] addr
 * Image buffer array.
 *
 * \param [in] count
 * Payload length.
 *
 * \param [in] prev_chksum 
 * previous checksum.
 *
 * \return
 * Returns sum.
 */
unsigned short checksum(unsigned char *addr, unsigned long count,
                unsigned short prev_chksum)
{
        unsigned short sum = 0,temp = 0;
        sum=prev_chksum;

        while(count > 1)
        {
                temp=(unsigned short)(*((unsigned short*)addr));
                sum=sum+temp;
                addr=addr+2;
                count=count-2;
        }
        if (count > 0)
                sum=sum+(unsigned short)(*((unsigned char *)addr));
        return (sum);
}

/*!
 * \brief
 * recv_data function to download image
 *
 * \details
 * This function is called by Application to download the image
 *
 * \param [in] fd
 * File descriptor of Device node
 *
 * \param [in] recv_packet_size
 * total size of the actual image (excluding CMD and length size)
 *
 * \return
 * Success 0
 * Error -1
 */
LONG dwnld_frame (obd_gui_cfg_proto_t *p_proto, usb_board *p_dwnld_frm, ULONG *p_st)
{
	int bytesReceived = 0;
	static int TtbytesReceived = 0;
	int count = 0;
	static int counter = 0;
	int buf_size_af = 1;
	
	FILE *fp;

	/* Variable which holds final checksum */
	unsigned short chk_sum = 0,old_chk_sum = 0;

	UCHAR cmd_ok = 1;

	chk_sum = 0;
	old_chk_sum = 0;

	/* Create file where data will be stored */
	if (flag_uboot_enable == 1)
	{
		/* Delete already existing file */
		if (update_flag == 1)
		{
			DEBUG ("UBoot Update flag 1\n");
			if (file_exist ("/firmware_upgrade/uboot/u-boot.imx"))
			{
				DEBUG ("File Exists...!! Deleted\n");
				system("rm /firmware_upgrade/uboot/u-boot.imx");
			}
			update_flag = 0;
		}

		fp = fopen("/firmware_upgrade/uboot/u-boot.imx", "ab");
		if(NULL == fp)
		{
			printf("Error opening file");
			*p_st = E_DWNLD_FRM_FP_UBOOT;
		}
	}
	else if (flag_uImage_enable == 1)
	{
		/* Delete already existing file */
		if (update_flag == 1)
		{
			if (file_exist ("/firmware_upgrade/zImage/zImage.tar.bz2"))
			{
				system("rm /firmware_upgrade/zImage/zImage.tar.bz2");
			}
			update_flag = 0;
		}

		fp = fopen("/firmware_upgrade/zImage/zImage.tar.bz2", "ab");
		if(NULL == fp)
		{
			printf("Error opening file");
			*p_st = E_DWNLD_FRM_FP_ZIMAGE;
		}
	}
	else if (flag_obd2fwapp_enable == 1)
	{
		/* Delete already existing file */
		if (update_flag == 1)
		{
			if (file_exist ("/firmware_upgrade/rootfs/Application.tar.bz2"))
			{
				system("rm /firmware_upgrade/rootfs/Application.tar.bz2");
			}
			update_flag = 0;
		}
		fp = fopen("/firmware_upgrade/rootfs/Application.tar.bz2", "ab");
		if(NULL == fp)
		{
			printf("Error opening file");
			*p_st = E_DWNLD_FRM_FP_OBD2FW_APP;
		}
	}

		counter++;

		fwrite(p_dwnld_frm->payload, 1, p_dwnld_frm->size, fp);


		TtbytesReceived += (p_dwnld_frm->size);

		fflush(stdout);

		DEBUG ("Iteration counter = %d  : Bytes received = %d , Total_byte = %d\n", counter, TtbytesReceived, total_img_sz);


	if (bytesReceived < 0) ERROR("ERROR reading from hardware");


	/* This flusing is required since TCP window size is 4096 and transfer is 
	 *  happening with minimum 4096 bytes 
	 */	
	fflush(fp);

	//free(rcv_rsp);
	fclose (fp); 

	*p_st = OBD_GUI_INF_SUCCESS;
	return 0;
}


