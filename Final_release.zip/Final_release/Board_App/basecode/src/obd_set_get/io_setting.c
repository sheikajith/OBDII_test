#include <io_setting.h>
#include <stdio.h>
#include <libxml2.h>
#include <stdlib.h>
#include <debug.h>



LONG get_io_setting(usb_board *p_frame, settings_io_t *p_io_setting)
{

	settings_io_t io_setting = {0};
	UCHAR ain1[1];
	UCHAR dout1[1];
	UCHAR dout2[1];
	UCHAR din1[1];
	UCHAR din2[1];
	UCHAR dout1_value[1];
	UCHAR dout2_value[1];

	get_xml_content(XML_FILE, "ain1","source", ain1);
	get_xml_content(XML_FILE, "dout1","source", dout1);
	get_xml_content(XML_FILE, "dout2","source", dout2);
	get_xml_content(XML_FILE, "din1","source", din1);
	get_xml_content(XML_FILE, "din2","source", din2);
	get_xml_content(XML_FILE, "dout1","value", dout1_value);
	get_xml_content(XML_FILE, "dout2","value", dout2_value);


	memcpy(p_io_setting->ain1, ain1, 1); 
	memcpy(p_io_setting->dout1, dout1, 1); 
	memcpy(p_io_setting->dout2, dout2, 1); 
	memcpy(p_io_setting->din1, din1, 1); 
	memcpy(p_io_setting->din2, din2, 1); 
	memcpy(p_io_setting->dout1_value, dout1_value, 1); 
	memcpy(p_io_setting->dout2_value, dout2_value, 1); 
		
	INFO ("p_io_setting->ain1 = %d\n", p_io_setting->ain1);
	INFO ("p_io_setting->dout1 = %d\n", p_io_setting->dout1);
	INFO ("p_io_setting->dout2 = %d\n", p_io_setting->dout2);
	INFO ("p_io_setting->din1 = %d\n", p_io_setting->din1);
	INFO ("p_io_setting->din2 = %d\n", p_io_setting->din2);
	
        return 0;

}

LONG set_io_setting(usb_board *p_frame)
{

	settings_io_t io_setting = {0};

        UCHAR ain1_xml[5];
        UCHAR dout1_xml[5];
        UCHAR dout2_xml[5];
        UCHAR din1_xml[5];
        UCHAR din2_xml[5];
        UCHAR dout1_value_xml[5];
        UCHAR dout2_value_xml[5];



        UCHAR ain1;
        UCHAR dout1;
        UCHAR dout2;
        UCHAR din1;
        UCHAR din2;
        UCHAR dout1_value;
        UCHAR dout2_value;

        UCHAR ain1_temp[2];
        UCHAR dout1_temp[2];
        UCHAR dout2_temp[2];
        UCHAR din1_temp[2];
        UCHAR din2_temp[2];
        UCHAR dout1_value_temp[2];
        UCHAR dout2_value_temp[2];



	if(p_frame == NULL)
	{
		ERROR("Invalid arguments\n");
	}

	memcpy(&io_setting, p_frame->payload, sizeof(settings_io_t));


     	ain1_temp [0] = io_setting.ain1[0];
        ain1_temp [1] = '\0';
        ain1 = atoi(ain1_temp);


     	dout1_temp [0] = io_setting.dout1[0];
        dout1_temp [1] = '\0';
        dout1 = atoi(dout1_temp);


     	dout2_temp [0] = io_setting.dout2[0];
        dout2_temp [1] = '\0';
        dout2 = atoi(dout2_temp);


     	din1_temp [0] = io_setting.din1[0];
        din1_temp [1] = '\0';
        din1 = atoi(din1_temp);

     	din2_temp [0] = io_setting.din2[0];
        din2_temp [1] = '\0';
        din2 = atoi(din2_temp);


     	dout1_value_temp [0] = io_setting.dout1_value[0];
        dout1_value_temp [1] = '\0';
        dout1_value = atoi(dout1_value_temp);


     	dout2_value_temp [0] = io_setting.dout2_value[0];
        dout2_value_temp [1] = '\0';
        dout2_value = atoi(dout2_value_temp);


	sprintf(ain1_xml, "%d", ain1);
	sprintf(dout1_xml, "%d", dout1);
	sprintf(dout2_xml, "%d", dout2);
	sprintf(din1_xml, "%d", din1);
	sprintf(din2_xml, "%d", din2);
	sprintf(dout1_value_xml, "%d", dout1_value);
	sprintf(dout2_value_xml, "%d", dout2_value);


        INFO ("io_setting->ain1 = %s\n", ain1_xml);
        INFO ("io_setting->dout1 = %s\n", dout1_xml);
        INFO ("io_setting->dout2 = %s\n", dout2_xml);
        INFO ("io_setting->din1 = %s\n", din1_xml);
        INFO ("io_setting->din2 = %s\n", din2_xml);
        INFO ("io_setting->dout1_value = %s\n", dout1_value_xml);
        INFO ("io_setting->dout2_value = %s\n", dout2_value_xml);

        set_xml_content(XML_FILE, "ain1","source", ain1_xml);
        set_xml_content(XML_FILE, "dout1","source", dout1_xml);
        set_xml_content(XML_FILE, "dout2","source", dout2_xml);
        set_xml_content(XML_FILE, "din1","source", din1_xml);
        set_xml_content(XML_FILE, "din2","source", din2_xml);
        set_xml_content(XML_FILE, "dout1","value", dout1_value_xml);
        set_xml_content(XML_FILE, "dout2","value", dout2_value_xml);



	return 0;

}

