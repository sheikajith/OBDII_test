#include <Whitelist_Number.h>
#include<stdio.h>
#include<libxml2.h>
#include<stdlib.h>
#include<debug.h>
#include<string.h>

LONG SOTA_whitelist_number(usb_board *p_frame, SOTA_Whitelist_Number_t *p_Whitelist_Number)
{
//	 printf("SCR_ID = %x,CMD_ID = %x, type = %x, size = %x, crc = %x, payload = %s\n", device_info.scr_id, device_info.cmd_id, device_info.type, device_info.size, device_info.crc, device_info.payload);
	return 0;
}

LONG get_SOTA_whitelist_number(usb_board *p_frame, SOTA_Whitelist_Number_t *p_Whitelist_Number)
{
	SOTA_Whitelist_Number_t Whitelist_Number = {0};
	UCHAR Number1[MAX_NUMBER1_STR_SZ] = {0};
	UCHAR Number2[MAX_NUMBER2_STR_SZ] = {0};
	UCHAR Number3[MAX_NUMBER3_STR_SZ] = {0};
        UCHAR Number4[MAX_NUMBER4_STR_SZ] = {0};
	UCHAR Number5[MAX_NUMBER5_STR_SZ] = {0};
        UCHAR Number6[MAX_NUMBER6_STR_SZ] = {0};
	UCHAR Number7[MAX_NUMBER7_STR_SZ] = {0};
        UCHAR Number8[MAX_NUMBER8_STR_SZ] = {0};
	UCHAR Number9[MAX_NUMBER9_STR_SZ] = {0};
        UCHAR Number10[MAX_NUMBER10_STR_SZ] = {0};
        UCHAR Number11[MAX_NUMBER11_STR_SZ] = {0};
        UCHAR Number12[MAX_NUMBER12_STR_SZ] = {0};
        UCHAR Number13[MAX_NUMBER13_STR_SZ] = {0};
        UCHAR Number14[MAX_NUMBER14_STR_SZ] = {0};
        UCHAR Number15[MAX_NUMBER15_STR_SZ] = {0};
        UCHAR Number16[MAX_NUMBER16_STR_SZ] = {0};
        UCHAR Number17[MAX_NUMBER17_STR_SZ] = {0};
        UCHAR Number18[MAX_NUMBER18_STR_SZ] = {0};
        UCHAR Number19[MAX_NUMBER19_STR_SZ] = {0};
        UCHAR Number20[MAX_NUMBER20_STR_SZ] = {0};


	//Get Parameters from XML File.
	get_xml_content(XML_FILE, "whitelist_Number", "Number1", Number1);
	get_xml_content(XML_FILE, "whitelist_Number", "Number2", Number2);
        get_xml_content(XML_FILE, "whitelist_Number", "Number3", Number3);
        get_xml_content(XML_FILE, "whitelist_Number", "Number4", Number4);
        get_xml_content(XML_FILE, "whitelist_Number", "Number5", Number5);
        get_xml_content(XML_FILE, "whitelist_Number", "Number6", Number6);
        get_xml_content(XML_FILE, "whitelist_Number", "Number7", Number7);
        get_xml_content(XML_FILE, "whitelist_Number", "Number8", Number8);
        get_xml_content(XML_FILE, "whitelist_Number", "Number9", Number9);
        get_xml_content(XML_FILE, "whitelist_Number", "Number10", Number10);
        get_xml_content(XML_FILE, "whitelist_Number", "Number11", Number11);
        get_xml_content(XML_FILE, "whitelist_Number", "Number12", Number12);
        get_xml_content(XML_FILE, "whitelist_Number", "Number13", Number13);
        get_xml_content(XML_FILE, "whitelist_Number", "Number14", Number14);
        get_xml_content(XML_FILE, "whitelist_Number", "Number15", Number15);
        get_xml_content(XML_FILE, "whitelist_Number", "Number16", Number16);
        get_xml_content(XML_FILE, "whitelist_Number", "Number17", Number17);
        get_xml_content(XML_FILE, "whitelist_Number", "Number18", Number18);
        get_xml_content(XML_FILE, "whitelist_Number", "Number19", Number19);
        get_xml_content(XML_FILE, "whitelist_Number", "Number20", Number20);


	INFO ("xml Number1 = %s\n", Number1);
	INFO ("xml Number2 = %s\n", Number2);

	// Copy Parameter to Structure
	memcpy(p_Whitelist_Number->Number1, Number1, MAX_NUMBER1_STR_SZ);
	memcpy(p_Whitelist_Number->Number2, Number2, MAX_NUMBER2_STR_SZ);
        memcpy(p_Whitelist_Number->Number3, Number3, MAX_NUMBER3_STR_SZ);
        memcpy(p_Whitelist_Number->Number4, Number4, MAX_NUMBER4_STR_SZ);
        memcpy(p_Whitelist_Number->Number5, Number5, MAX_NUMBER5_STR_SZ);
        memcpy(p_Whitelist_Number->Number6, Number6, MAX_NUMBER6_STR_SZ);
        memcpy(p_Whitelist_Number->Number7, Number7, MAX_NUMBER7_STR_SZ);
        memcpy(p_Whitelist_Number->Number8, Number8, MAX_NUMBER8_STR_SZ);
        memcpy(p_Whitelist_Number->Number9, Number9, MAX_NUMBER9_STR_SZ);
        memcpy(p_Whitelist_Number->Number10, Number10, MAX_NUMBER10_STR_SZ);
        memcpy(p_Whitelist_Number->Number11, Number11, MAX_NUMBER11_STR_SZ);
        memcpy(p_Whitelist_Number->Number12, Number12, MAX_NUMBER12_STR_SZ);
        memcpy(p_Whitelist_Number->Number13, Number13, MAX_NUMBER13_STR_SZ);
        memcpy(p_Whitelist_Number->Number14, Number14, MAX_NUMBER14_STR_SZ);
        memcpy(p_Whitelist_Number->Number15, Number15, MAX_NUMBER15_STR_SZ);
        memcpy(p_Whitelist_Number->Number16, Number16, MAX_NUMBER16_STR_SZ);
        memcpy(p_Whitelist_Number->Number17, Number17, MAX_NUMBER17_STR_SZ);
        memcpy(p_Whitelist_Number->Number18, Number18, MAX_NUMBER18_STR_SZ);
        memcpy(p_Whitelist_Number->Number19, Number19, MAX_NUMBER19_STR_SZ);
        memcpy(p_Whitelist_Number->Number20, Number20, MAX_NUMBER20_STR_SZ);


	INFO ("Number1 = %s\n", p_Whitelist_Number->Number1);
	INFO ("Number2 = %s\n", p_Whitelist_Number->Number2);
        INFO ("Number3 = %s\n", p_Whitelist_Number->Number3);
        INFO ("Number4 = %s\n", p_Whitelist_Number->Number4);
        INFO ("Number5 = %s\n", p_Whitelist_Number->Number5);
        INFO ("Number6 = %s\n", p_Whitelist_Number->Number6);
        INFO ("Number7 = %s\n", p_Whitelist_Number->Number7);
        INFO ("Number8 = %s\n", p_Whitelist_Number->Number8);
        INFO ("Number9 = %s\n", p_Whitelist_Number->Number9);
        INFO ("Number10 = %s\n", p_Whitelist_Number->Number10);
        INFO ("Number11 = %s\n", p_Whitelist_Number->Number11);
        INFO ("Number12 = %s\n", p_Whitelist_Number->Number12);
        INFO ("Number13 = %s\n", p_Whitelist_Number->Number13);
        INFO ("Number14 = %s\n", p_Whitelist_Number->Number14);
        INFO ("Number15 = %s\n", p_Whitelist_Number->Number15);
        INFO ("Number16 = %s\n", p_Whitelist_Number->Number16);
        INFO ("Number17 = %s\n", p_Whitelist_Number->Number17);
        INFO ("Number18 = %s\n", p_Whitelist_Number->Number18);
        INFO ("Number19 = %s\n", p_Whitelist_Number->Number19);
        INFO ("Number20 = %s\n", p_Whitelist_Number->Number20);


	return 0;
}

LONG set_SOTA_whitelist_number(usb_board *p_frame)
{
	SOTA_Whitelist_Number_t Whitelist_Number = {0};
	UCHAR Number1[MAX_NUMBER1_STR_SZ];
	UCHAR Number2[MAX_NUMBER2_STR_SZ];
        UCHAR Number3[MAX_NUMBER3_STR_SZ];
        UCHAR Number4[MAX_NUMBER4_STR_SZ];
        UCHAR Number5[MAX_NUMBER5_STR_SZ];
        UCHAR Number6[MAX_NUMBER6_STR_SZ];
        UCHAR Number7[MAX_NUMBER7_STR_SZ];
        UCHAR Number8[MAX_NUMBER8_STR_SZ];
        UCHAR Number9[MAX_NUMBER9_STR_SZ];
        UCHAR Number10[MAX_NUMBER10_STR_SZ];
        UCHAR Number11[MAX_NUMBER11_STR_SZ];
        UCHAR Number12[MAX_NUMBER12_STR_SZ];
        UCHAR Number13[MAX_NUMBER13_STR_SZ];
        UCHAR Number14[MAX_NUMBER14_STR_SZ];
        UCHAR Number15[MAX_NUMBER15_STR_SZ];
        UCHAR Number16[MAX_NUMBER16_STR_SZ];
        UCHAR Number17[MAX_NUMBER17_STR_SZ];
        UCHAR Number18[MAX_NUMBER18_STR_SZ];
        UCHAR Number19[MAX_NUMBER19_STR_SZ];
        UCHAR Number20[MAX_NUMBER20_STR_SZ];


	if(p_frame == NULL)
	{
		ERROR("Invalid Argument\n");
	}
		
	memcpy(&Whitelist_Number, p_frame->payload, sizeof(SOTA_Whitelist_Number_t));

	//memcpy(Number1, Whitelist_Number.Number1, MAX_NUMBER1_STR_SZ);
	//memcpy(Number2, Whitelist_Number.Number2, MAX_NUMBER2_STR_SZ);

	//Get Parameters from XML File.
	set_xml_content(XML_FILE, "whitelist_Number", "Number1", Whitelist_Number.Number1);
	set_xml_content(XML_FILE, "whitelist_Number", "Number2", Whitelist_Number.Number2);
        set_xml_content(XML_FILE, "whitelist_Number", "Number3", Whitelist_Number.Number3);
        set_xml_content(XML_FILE, "whitelist_Number", "Number4", Whitelist_Number.Number4);
        set_xml_content(XML_FILE, "whitelist_Number", "Number5", Whitelist_Number.Number5);
        set_xml_content(XML_FILE, "whitelist_Number", "Number6", Whitelist_Number.Number6);
        set_xml_content(XML_FILE, "whitelist_Number", "Number7", Whitelist_Number.Number7);
        set_xml_content(XML_FILE, "whitelist_Number", "Number8", Whitelist_Number.Number8);
        set_xml_content(XML_FILE, "whitelist_Number", "Number9", Whitelist_Number.Number9);
        set_xml_content(XML_FILE, "whitelist_Number", "Number10", Whitelist_Number.Number10);
        set_xml_content(XML_FILE, "whitelist_Number", "Number11", Whitelist_Number.Number11);
        set_xml_content(XML_FILE, "whitelist_Number", "Number12", Whitelist_Number.Number12);
        set_xml_content(XML_FILE, "whitelist_Number", "Number13", Whitelist_Number.Number13);
        set_xml_content(XML_FILE, "whitelist_Number", "Number14", Whitelist_Number.Number14);
        set_xml_content(XML_FILE, "whitelist_Number", "Number15", Whitelist_Number.Number15);
        set_xml_content(XML_FILE, "whitelist_Number", "Number16", Whitelist_Number.Number16);
        set_xml_content(XML_FILE, "whitelist_Number", "Number17", Whitelist_Number.Number17);
        set_xml_content(XML_FILE, "whitelist_Number", "Number18", Whitelist_Number.Number18);
        set_xml_content(XML_FILE, "whitelist_Number", "Number19", Whitelist_Number.Number19);
        set_xml_content(XML_FILE, "whitelist_Number", "Number20", Whitelist_Number.Number20);


	INFO ("Number1 = %s\n", Whitelist_Number.Number1);
	INFO ("Number2 = %s\n", Whitelist_Number.Number2);
        INFO ("Number3 = %s\n", Whitelist_Number.Number3);
        INFO ("Number4 = %s\n", Whitelist_Number.Number4);
        INFO ("Number5 = %s\n", Whitelist_Number.Number5);
        INFO ("Number6 = %s\n", Whitelist_Number.Number6);
        INFO ("Number7 = %s\n", Whitelist_Number.Number7);
        INFO ("Number8 = %s\n", Whitelist_Number.Number8);
        INFO ("Number9 = %s\n", Whitelist_Number.Number9);
        INFO ("Number10 = %s\n", Whitelist_Number.Number10);
        INFO ("Number11 = %s\n", Whitelist_Number.Number11);
        INFO ("Number12 = %s\n", Whitelist_Number.Number12);
        INFO ("Number13 = %s\n", Whitelist_Number.Number13);
        INFO ("Number14 = %s\n", Whitelist_Number.Number14);
        INFO ("Number15 = %s\n", Whitelist_Number.Number15);
        INFO ("Number16 = %s\n", Whitelist_Number.Number16);
        INFO ("Number17 = %s\n", Whitelist_Number.Number17);
        INFO ("Number18 = %s\n", Whitelist_Number.Number18);
        INFO ("Number19 = %s\n", Whitelist_Number.Number19);
        INFO ("Number20 = %s\n", Whitelist_Number.Number20);


	return 0;
}

