#include <app.h>
#include <protocol.h>
#include <hal.h>
#include <os.h>
#include <debug.h>
#include <error_macro.h>
#include <libxml2.h>

/*!
 * \brief
 *   function to Initilize Application .
 *
 * \details
 *   This function will initilize all
 *	 resources related to application 
 *   like HAL, protocol, OS resources
 *
 * \param [in] param
 *  p_app - pointer to app_priv_t structure.
 */

LONG app_init(app_priv_t *p_app)
{

	LONG h_ret, p_ret, m_ret;
	LONG ret = OBD_GUI_INF_SUCCESS;
	obd_gui_cfg_proto_t *proto;

	/* Validate input arguments */
	if(p_app == NULL)
	{
		ERROR("Invalid Arguments\n");
	}

	proto = malloc(sizeof(obd_gui_cfg_proto_t));

	ret = msg_q_init(p_app);
	if(ret != OBD_GUI_INF_SUCCESS)
	{
		ERROR("Failed to initilize Message queue\n");
		ret = E_APP_MSG_Q_INIT; 
	}

	if (ret == OBD_GUI_INF_SUCCESS)
	{
		ret = hal_init (p_app);
		if (ret != OBD_GUI_INF_SUCCESS)
		{
			ERROR ("Failed to initilize hal\n");
			ret = E_APP_HAL_INIT;

		}
		if (ret == OBD_GUI_INF_SUCCESS)
		{
			ret = protocol_init (p_app);
			if(ret != OBD_GUI_INF_SUCCESS)
			{
				ERROR ("Failed to initilize protocol\n");
				ret = E_APP_PROTO_INIT; 
			}
			if ( ret == OBD_GUI_INF_SUCCESS)
			{
				ret = protocol_change_stm(p_app->proto, p_app->proto->prot_stm, PROTOCOL_SM_INIT);
				if (ret != OBD_GUI_INF_SUCCESS)
				{
					ERROR ("Error in Chnaging the state\n");
					ret = E_APP_CHANGE_STATE_M;
				}
				if (ret == OBD_GUI_INF_SUCCESS)
				{
					ret_value = sem_open((const char *)SEM_OPEN_FILE, 0, 0, 0);

					if (ret_value == SEM_FAILED) {
						/*
						 * No such file or directory
						 */
						if (errno == ENOENT) {
							ret_value = sem_open((const char *)SEM_OPEN_FILE,
									O_CREAT | O_EXCL, 0777, 1);
							if (ret_value == SEM_FAILED) {
								ERROR ("Error in creating Semaphore\n");
								ret = E_APP_SEM;	
							}
						}
					}

					
				}
			}

		}
	}

#if 0
	/*!< HW initialization */
	DEBUG ("*******app_init**********\n");
	h_ret = hal_init (p_app); 
	if(h_ret != OBD_GUI_INF_SUCCESS)
	{
		ERROR ("Failed to initilize hal\n");
		ret = E_APP_HAL_INIT;
	}


	/*!< Protocol initialization */
	if (ret == OBD_GUI_INF_SUCCESS)
	{
		p_ret = protocol_init (p_app);
		if(p_ret != 0)
		{
			ERROR ("Failed to initilize protocol\n");
			ret = E_APP_PROTO_INIT; 
		}
		if ( ret == OBD_GUI_INF_SUCCESS)
		{
			ret = protocol_change_stm(p_app->proto, p_app->proto->prot_stm, PROTOCOL_SM_INIT);
		}
		/*!< Wait for connection */
		if ( ret == OBD_GUI_INF_SUCCESS)
		{

#if 1
			if ( ret == OBD_GUI_INF_SUCCESS)
			{
				m_ret = msg_q_init(p_app);
				if(m_ret != 0)
				{
					ERROR("Failed to initilize Message queue\n");
					ret = E_APP_MSG_Q_INIT; 
				}
			DEBUG ("MQ -> Q = %d\n", p_app->mq->queue);
			proto->priv = (void *)p_app;
			}
#endif
		}
	}
#endif
	/*!< OS resources */
	/*!< Semaphore MsgQa, threads and synchronization...... */
	return ret;
}

/*!
 * \brief
 *   function to Update the header of the frame  .
 *
 * \details
 *   This function updates the response header based on
 *   response cmd_id, payload struct size
 * \param [in] param
 *  p_frame - pointer to usb_board structure.
 *  rsp_cmd_hdr   - Respose cmd_id
 *  size- size of the bupayload structffer
 */

LONG update_hdr(usb_board *p_frame, usb_board *p_hdr, USHORT rsp_cmd_hdr, size_t size)
{
	LONG ret = OBD_GUI_INF_SUCCESS;
	memcpy(p_hdr, p_frame, PROTO_HDR_SZ);
	p_hdr->cmd_id = rsp_cmd_hdr;
	p_hdr->size = size;
	
	return ret;	
}
