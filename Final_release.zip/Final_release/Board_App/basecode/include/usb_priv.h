#ifndef __USB_PRIV_H 
#define __USB_PRIV_H 

#include <usb_protcol_typedefs.h>
#include <standard_queue.h>


#define VERBOSE_ENABLE	1
#define VERBOSE_DISABLE	0

#define MAIN_XML		"file.xml"
#define WHITELIST_XML	"whitelist.xml"
#define USERNAME		"OBD"
#define PASSWD			"iWave@OBD"
#define UNIQUE_ID		1234567


#define USB_DEV_NODE           "/dev/ttyGS0"
//#define USB_DEV_NODE           "usb.dat"
#define MSG_Q           "/usb_q"
#define START_MSG_Q           "/fw_to_usb_q"
#define START_READ_BUFFER	1
#define PROTO_HDR_SZ	7
#define PROTO_PAYLOAD_OFFSET	5
#define PROTO_CRC_SZ	2
#define MAX_FRAME_SZ	5120




/**********************************************************/
/******Firmware Download**************/
#define DOWNLOAD_START_CMD              0x07A0
#define DOWNLOAD_FW_CMD                 0x07A1
#define DOWNLOAD_END_CMD                0x07A2


#define DOWNLOAD_START_RSP              0x87A0
#define DOWNLOAD_FW_RSP                 0x87A1
#define DOWNLOAD_END_RSP                0x87A2


/* IMAGE TYPES */
#define IMAGE_UBOOT			49
#define IMAGE_UIMAGE                    50
//#define IMAGE_FILESYSTEM                51
#define IMAGE_OBD2FW_APP                51


UCHAR flag_uboot_enable;
UCHAR flag_uImage_enable;
UCHAR flag_filesystem_enable;
UCHAR flag_obd2fwapp_enable;
UCHAR update_flag;
ULONG total_img_sz;

/**********************************************************/
/******Black Box**************/
#define GET_BLCAK_BOX_SZ_REQ              0x07B0
#define GET_BLCAK_BOX_REQ                 0x07B1
                                
                                
#define GET_BLCAK_BOX_SZ_RSP              0x87B0
#define GET_BLCAK_BOX_RSP                 0x87B1


ULONG blackbox_sz;
ULONG blackbox_frame_sz;


typedef struct dwnld_start_param {
    UCHAR img_type;
    ULONG img_size;
} __attribute__((packed)) dwnld_start_param_t;




enum state_machine
{
	PROTOCOL_SM_START = 0x08B0,
	PROTOCOL_SM_INIT = 0x08B1,
	PROTOCOL_SM_CONNECTED = 0x08B2,
	PROTOCOL_SM_XFER = 0x08B3, 
	PROTOCOL_SM_FW_DOWNLOAD = 0x08B4,
	PROTOCOL_SM_DISCONNECTED = 0x08B5,
	PROTOCOL_SM_INVALID = 0x08B6
};


#define PROTOCOL_SM_START_REQ  0x08B0
#define PROTOCOL_SM_INIT_REQ  0x08B1
#define PROTOCOL_SM_CONNECTED_REQ  0x08B2
#define PROTOCOL_SM_XFER_REQ  0x08B3
#define PROTOCOL_SM_FW_DOWNLOAD_REQ  0x08B4
#define PROTOCOL_SM_DISCONNECTED_REQ  0x08B5


#define PROTOCOL_SM_START_RSP  0x88B0
#define PROTOCOL_SM_INIT_RSP  0x88B1
#define PROTOCOL_SM_CONNECTED_RSP  0x88B2
#define PROTOCOL_SM_XFER_RSP  0x88B3
#define PROTOCOL_SM_FW_DOWNLOAD_RSP  0x88B4
#define PROTOCOL_SM_DISCONNECTED_RSP  0x88B5

enum proto_frame_type
{
	PROTO_FRM_DATA = 0,
	PROTO_FRM_MGMT,
	PROTO_FRM_DWNLD,
	PROTO_FRM_INVALID 
};

#if 0
enum image_type
{
        IMAGE_UBOOT = 0,
        IMAGE_LINUX,
        IMAGE_ROOTFS,
        IMAGE_APP,
	IMAGE_INVALID
};
#endif





ULONG unique_id;
ULONG verbose;
ULONG debug_flag;
CHAR *x_name;
CHAR *w_name ;
CHAR *username;
CHAR *password;


pthread_t proto_notify;

typedef struct dwnld_image
{
#if 0
	enum image_type image;
#endif

}dwnld_image_t;



typedef struct msg_q
{
	mqd_t queue;
         /*!< HW Related data structure */
         /*!< Prtocol Related data structure, state machine diagram, threadid....*/
         /*!< OS Resources Related data structure , IPC, MsgQ, SEM, ....*/


}msg_q_t;


typedef struct obd_hal
{
	int fd;
	void *priv;
         /*!< HW Related data structure */
         /*!< Prtocol Related data structure, state machine diagram, threadid....*/
         /*!< OS Resources Related data structure , IPC, MsgQ, SEM, ....*/


}obd_hal_t;

typedef struct obd_gui_cfg_proto
{
	enum state_machine prot_stm;
	enum proto_frame_type frame_type; //TODO check if this is required??
	void *priv;
	pthread_t proto_thread;
	int read_buffer;
	char recvd_frame[MAX_FRAME_SZ]; 
         /*!< HW Related data structure */
         /*!< Prtocol Related data structure, state machine diagram, threadid....*/
         /*!< OS Resources Related data structure , IPC, MsgQ, SEM, ....*/
}obd_gui_cfg_proto_t;


typedef struct app_priv
{

	/*!< HW Related data structure */
	obd_hal_t *hal;
	/*!< Prtocol Related data structure, state machine diagram, threadid....*/
	obd_gui_cfg_proto_t *proto;
	/*!< Download Related data structure, type of image, ....*/
	dwnld_image_t *image;

	/*!< OS Resources Related data structure , IPC, MsgQ, SEM, ....*/
	msg_q_t *mq;


}app_priv_t;



#endif
