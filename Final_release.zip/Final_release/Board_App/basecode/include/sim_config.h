#ifndef SIM_CONFIG_H_
#define SIM_CONFIG_H_

#include <usb_protcol.h>
#include <string.h>


LONG get_sim_config(usb_board *p_frame, sim_config_t *p_sim_config);

LONG set_sim_config(usb_board *p_frame, sim_config_t *p_sim_config);

#endif /*SIM_CONFIG_H_*/

