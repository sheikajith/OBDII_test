#ifndef __HAL_H 
#define __HAL_H

#include <usb_priv.h>
#include <stdio.h>
#include <poll.h>
#include <unistd.h>


LONG hal_init (app_priv_t *p_app);

LONG hal_read(obd_hal_t *p_hal, UCHAR *p_rdbuf, size_t sz);

LONG hal_write(obd_hal_t *p_hal, UCHAR *p_rdbuf, size_t sz);

#endif
