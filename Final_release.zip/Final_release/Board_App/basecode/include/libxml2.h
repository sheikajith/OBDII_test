#ifndef __LIBXML2__H
#define __LIBXML2__H 

#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>
#include <errno.h>

#define SEM_OPEN_FILE "/sem_16"
#define SEM_4G_FILE "/sem_4g"


#define XML_FILE "/sample.xml"

sem_t *ret_value;
sem_t *ret_4g_value;

int get_xml_content(char *filename, char *parent_node,char *name, char *value);

int set_xml_content(char *filename, char *parent_node,char *name, char *value);

int sem_init_4g (const char* sem_name, sem_t *semapore);


#endif /*__LIBXML2__H*/
