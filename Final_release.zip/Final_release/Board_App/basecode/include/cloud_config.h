#ifndef CLOUD_CONFIG_H_
#define CLOUD_CONFIG_H_

#include <usb_protcol.h>
#include <string.h>


LONG cloud_azure_config(usb_board *p_frame, cloud_azure_config_t *p_azure_cloud_config);

LONG get_cloud_azure_config(usb_board *p_frame, cloud_azure_config_t *p_azure_cloud_config);

LONG set_cloud_azure_config(usb_board *p_frame);

#endif /*CLOUD_CONFIG_H_*/

