#ifndef SOFTWARE_STATUS_H_
#define SOFTWARE_STATUS_H_

#include <usb_protcol.h>
#include <string.h>

LONG get_software_status(usb_board *p_frame, st_software_info_rsp_t *p_software_info);

#endif /*SOFTWARE_STATUS_H_*/

