#ifndef USER_PASS_H_
#define USER_PASS_H_

#include <usb_protcol.h>
#include <string.h>

LONG get_SOTA_User_Pass(usb_board *p_frame, SOTA_UserPass_t *p_User_Pass);

LONG set_SOTA_User_Pass(usb_board *p_frame);

#endif /*USER_PASS_H_ */
