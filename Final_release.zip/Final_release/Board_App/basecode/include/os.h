#ifndef __OS_H 
#define __OS_H

#include <usb_priv.h>
#include <standard_queue.h>
#include <stdlib.h>
#include <usb_protcol_typedefs.h>


LONG msg_q_init (app_priv_t *p_app);

#endif

