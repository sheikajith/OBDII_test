/*!< File Header TODO */
#ifndef __USB_PORTOCOL_TYPESDEF_H 
#define __USB_PORTOCOL_TYPESDEF_H 

/*! extern cplus TODO */
/*!< Typedef for unsigned char */
#define UCHAR   unsigned char
#define USHORT  unsigned short
#define ULONG   unsigned long

#define CHAR    signed char
#define SHORT   signed short
#define LONG    signed long
#define FLOAT   float

#define VUCHAR  volatile unsigned char
#define VUSHORT volatile unsigned short
#define VULONG  volatile unsigned long

#define VCHAR   volatile signed char
#define VSHORT  volatile signed short
#define VLONG   volatile signed long

#if 0
#define PUCHAR  unsigned char *
#define PUSHORT unsigned short *
#define PULONG  unsigned long *

#define PCHAR   signed char *
#define PSHORT  signed short *
#define PLONG   signed long *

#define VPUCHAR     volatile unsigned char *
#define VPUSHORT    volatile unsigned short *
#define VPULONG     volatile unsigned long *

#define VPCHAR      volatile signed char *
#define VPSHORT     volatile signed short *
#define VPLONG      volatile signed long *
#endif

#define PROTOCOL_SUCCESS		(1)


#endif /*!< #ifndef __USB_PORTOCOL_TYPESDEF_H */

