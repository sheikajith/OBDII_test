#ifndef __MSG_QUE_H 
#define __MSG_QUE_H 

#include <usb_protcol_typedefs.h>


// structure for message queue 
typedef struct usb_mesg_buffer { 
    CHAR usb_param_name[100] 
    CHAR usb_param_value[100]; 
} usb_mesg_buffer_t; 
  

int usb_msg_send(struct usb_mesg_buffer buffer);

int usb_msg_recv(struct usb_mesg_buffer *buffer);


#endif
