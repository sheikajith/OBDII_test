#ifndef IO_SETTING_H_
#define IO_SETTING_H_

#include <usb_protcol.h>
#include <string.h>


LONG get_io_setting(usb_board *p_frame, settings_io_t *p_io_setting);

LONG set_io_setting(usb_board *p_frame);


#endif /*IO_SETTING_H_*/

