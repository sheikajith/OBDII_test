#ifndef __USB_PROTOCOL_H
#define __USB_PROTOCOL_H

/*! extern cplus TODO */
#include <usb_protcol_typedefs.h>
#include <stdint.h>

//WINDOW CONSTANTS
/*!< SCREENS IDs*/

//#define CONNECTION_MODULEBASE 				(0x0100)
//#define STATUS_MODULEBASE 				(0x0200)
//#define CONNECTION_WINDOW_1   				(CONNECTION_MODULEBASE + 1)  
#define CONNECTION_WINDW   				(0x0101) 	//1st window 
#define MAIN_WINDOW_ID 					(0x0050) 	//
//STATUS  CONSTANTS
#define STATUS_CPU_WINDOW_ID			(0x0060)
#define STATUS_IO_WINDOW_ID   			(0x0061) 
#define STATUS_GSM_GPRS_WINDOW_ID   	(0x0062) 
#define STATUS_SOFTWARE__WINDOW_ID  	(0x0063)
//SIM CONFIGURATION
#define SIM_CONFIG_WINDOW_ID			(0x0070)
//CLOUD CONFIGURATION
#define CLOUD_CONFIG_WINDOW_ID 			(0x0080)
#define CLOUD_AZURE_CONFIG_WINDOW_ID	(0x0081)
#define CLOUD_AWS_CONFIG_WINDOW_ID		(0x0082)
#define CLOUD_IBM_CONFIG_WINDOW_ID		(0x0083)
#define CLOUD_ORACLE_CONFIG_WINDOW_ID	(0x0084)
#define CLOUD_TCPIP_CONFIG_WINDOW_ID	(0x0085)
//SETTINGS
#define SETTINGS_WINDOW_ID 		    	(0x0090) 
#define SETTINGS_GENERAL_WINDOW_ID 		(0x0091) 
#define SETTINGS_THRSHOLD_WINDOW_ID 	(0x0092) 
#define SETTINGS_IO_WINDOW_ID	  		(0x0093) 
//FIRMWARE
#define FIRMWARE_WINDOW_ID  			(0x00A0) 
//BLACKBOX
#define BLACK_BOX_WINDOW_ID  			(0x00B0)
//IMMOBILIZER
#define IMMOBILIZER_WINDOW_ID  			(0x00C0)
//USRID_PWD
#define USRID_PWD_WINDOW_ID  			(0x00D0)
//SOTA
#define SOTA_WINDOW_ID                          (0x0095)
#define SOTA_WHITELIST_NUMBER_WINDOW_ID         (0x0096)
#define SOTA_USERPASS_WINDOW_ID                 (0x0097)

//CMD ID:
/*!< Command ID to get request for Device Information*/
#define GET_DEV_INFO_REQ   				(0x00B0)
#define CONNECTION_REQ   				(0x00B1)
#define DEV_STATUS_REQ   				(0x00B3)
//STATUS
#define CPU_INFO_REQ 					(0x00CA) 
#define IO_INFO_REQ    					(0x00DA) 
#define GSM_GPRS_INFO_REQ   			(0x00EA) 
#define SOFTWARE_REQ   					(0x00FA) 
//SIM CONFIGUARTION
#define GET_SIM_CONFIG_REQ   				(0x025A)
#define SET_SIM_CONFIG_REQ   				(0x025B)
//CLOUD CONFIGUARTION
#define CLOUD_AZURE_REQ   				(0x02B0) 
#define GET_CLOUD_AZURE_CONFIG_REQ   			(0x02B1)
#define SET_CLOUD_AZURE_CONFIG_REQ   			(0x02B2)
//SETTINGS
#define GET_GEN_SET_REQ   				(0x02C0)
#define SET_GEN_SET_REQ   				(0x02C1)
#define GET_THRSLD_SET_REQ   				(0x02C2)
#define SET_THRSLD_SET_REQ   				(0x02C3)
#define GET_IO_SET_REQ   				(0x02C4)
#define SET_IO_SET_REQ   				(0x02C5)
//SYSTEM REBBOT
#define SYSTEM_REBOOT_REQ 				(0x07C0)
#define SYSTEM_RESET_REQ 				(0x07C1)
//SOTA
#define GET_SOTA_WHITELIST_NUMBER_REQ                   (0x09A0)
#define SET_SOTA_WHITELIST_NUMBER_REQ                   (0x09A1)
#define GET_SOTA_USERPASS_REQ                           (0x09A2)
#define SET_SOTA_USERPASS_REQ                           (0x09A3)

//*!<Command ID to send response for Device Information*/ 
#define GET_DEV_INFO_RSP   				(0x80B0) 
#define CONNECTION_RSP 					(0x80B1) 
#define DEV_STATUS_RSP 					(0x80B3) 
//STATUS
#define CPU_INFO_RSP        			(0x80CA) 
#define IO_INFO_RSP    					(0x80DA) 
#define GSM_GPRS_INFO_RSP   			(0x80EA) 
#define SOFTWARE_RSP   					(0x80FA) 
//SIM CONFIGUARTION
#define GET_SIM_CONFIG_RSP   				(0x825A) 
#define SET_SIM_CONFIG_RSP   				(0x825B)
//CLOUD CONFIGUARTION
#define CLOUD_AZURE_RSP  				(0x82B0) 
#define GET_CLOUD_AZURE_CONFIG_RSP   		(0x82B1)
#define SET_CLOUD_AZURE_CONFIG_RSP   			(0x82B2)
//SETTINGS
#define GET_GEN_SET_RSP   				(0x82C0)
#define SET_GEN_SET_RSP   				(0x82C1)
#define GET_THRSLD_SET_RSP   			(0x82C2)
#define SET_THRSLD_SET_RSP   			(0x82C3)
#define GET_IO_SET_RSP   				(0x82C4)
#define SET_IO_SET_RSP   				(0x82C5)
//SYSTEM REBOOT
#define SYSTEM_REBOOT_RSP 				(0x87C0)
#define SYSTEM_RESET_RSP 				(0x87C1)
//SOTA
#define GET_SOTA_WHITELIST_NUMBER_RSP                   (0x89A0)
#define SET_SOTA_WHITELIST_NUMBER_RSP                   (0x89A1)
#define GET_SOTA_USERPASS_RSP                           (0x89A2)
#define SET_SOTA_USERPASS_RSP                           (0x89A3)

//Data Size defines
/*!<MAX DATA SIZE DEVICE INFO     	 */
#define MAX_DEVICE_NAME_STR_SZ  			32
#define MAX_IMEI_STR_SZ 				16
#define	MAX_EXT_POWER_STR_SZ				20
#define MAX_INT_POWER_STR_SZ 				20

/*!<MAX DATA SIZE STATUS CPU     	 */
#define MAX_PROCESSOR_NAME_STR_SZ  			32
#define MAX_CLK_SPEED_STR_SZ 				 8
#define MAX_DDR3_STR_SZ					32
#define MAX_NAND_STR_SZ 				 8
/*!<MAX DATA SIZE STATUS  IO 		*/
#define MAX_IGNITION_STATUS_STR_SZ 	   		 6
/*!<MAX DATA SIZE STATUS GSM_GPRS      	*/
#define MAX_SIM_STATUS_STR_SZ				 8
#define MAX_NETWORK_STATUS_STR_SZ 			12
/*!<MAX DATA SIZE STATUS SOFTWARE   	*/
#define MAX_LINUX_VERSION_STR_SZ			40

/*!<MAX DATA SIZE SIM CONFIGURATION   	*/
#define MAX_ACCEPOINT_STR_SZ		32				
#define MAX_SIM_USERNAME_STR_SZ 	32
#define MAX_SIM_PASSWORD_STR_SZ		32
#define MAX_APN_NAME_STR_SZ 		32
/*!<MAX DATA SIZE CLOUD AZURE CONFIGURATION   */
#define MAX_PORT_STR_SZ 				8
#define MAX_HOST_STR_SZ    				32
#define MAX_DEVICE_ID_STR_SZ				32
#define MAX_DEVICE_TYPE_STR_SZ				32
#define MAX_IOT_HUB_NAME_STR_SZ     			32
#define MAX_SAS_TOKEN_STR_SZ				256

/*!<MAX DATA SIZE SOTA WHITELIST NUMBER    */
#define MAX_NUMBER1_STR_SZ                 16
#define MAX_NUMBER2_STR_SZ                 16
#define MAX_NUMBER3_STR_SZ                 16 
#define MAX_NUMBER4_STR_SZ                 16 
#define MAX_NUMBER5_STR_SZ                 16 
#define MAX_NUMBER6_STR_SZ                 16 
#define MAX_NUMBER7_STR_SZ                 16 
#define MAX_NUMBER8_STR_SZ                 16 
#define MAX_NUMBER9_STR_SZ                 16 
#define MAX_NUMBER10_STR_SZ                16 
#define MAX_NUMBER11_STR_SZ                16
#define MAX_NUMBER12_STR_SZ                16
#define MAX_NUMBER13_STR_SZ                16 
#define MAX_NUMBER14_STR_SZ                16 
#define MAX_NUMBER15_STR_SZ                16 
#define MAX_NUMBER16_STR_SZ                16 
#define MAX_NUMBER17_STR_SZ                16 
#define MAX_NUMBER18_STR_SZ                16 
#define MAX_NUMBER19_STR_SZ                16 
#define MAX_NUMBER20_STR_SZ                16 
/*!<MAX DATA SIZE SOTA USERNAME AND PASSWORD    */
#define MAX_USERNAME1_STR_SZ               16
#define MAX_PASSWORD1_STR_SZ               16
#define MAX_USERNAME2_STR_SZ               16
#define MAX_PASSWORD2_STR_SZ               16
#define MAX_USERNAME3_STR_SZ               16
#define MAX_PASSWORD3_STR_SZ               16
#define MAX_USERNAME4_STR_SZ               16
#define MAX_PASSWORD4_STR_SZ               16
#define MAX_USERNAME5_STR_SZ               16
#define MAX_PASSWORD5_STR_SZ               16

/*!<MAX DATA SIZE STATUS SOFTWARE   			*/

//Sim Configuration --> network_mode
#define TWOG 1 
#define THREEG 2  
//General Settings --> mode
#define LAB_MODE 1
#define CAR_MODE 2 
//IO Settings dout1,dout1 --> 
#define BUZZER 1
#define RELAY  2

#define MAX_AIN1_STATUS_STR_SZ 32

#define USB_DATA_4096_BYTES	4096

typedef struct  __attribute__((__packed__)) usb_board
{
    uint16_t scr_id;
    uint16_t cmd_id;
    uint8_t type;
    uint16_t size;
    //uint16_t crc;
    //char *payload;
    char payload[1];
} usb_board;

//TODO Following strct can be used for read also, but malloc should be removed
typedef struct  __attribute__((__packed__)) usb_pkt
{
    USHORT scr_id;
    USHORT cmd_id;
    UCHAR type;
    USHORT size;
    USHORT crc;
    //char payload[USB_DATA_4095_BYTES];
    UCHAR payload[USB_DATA_4096_BYTES];
} usb_pkt_t;

//*!<Structure to recieve response for CPU Information*/
typedef struct  __attribute__((__packed__)) st_dev_info
{
    UCHAR device_name[MAX_DEVICE_NAME_STR_SZ];
    UCHAR imei_number[MAX_IMEI_STR_SZ];
    UCHAR ext_power[MAX_EXT_POWER_STR_SZ];
    UCHAR int_battery[MAX_INT_POWER_STR_SZ];
} st_dev_info_t;
#if 1
//*!<Structure to send request for CPU Information*/
typedef struct  __attribute__((__packed__)) st_cpu_info
{
    UCHAR proc_name[MAX_PROCESSOR_NAME_STR_SZ];
    UCHAR clk_speed[MAX_CLK_SPEED_STR_SZ];
    UCHAR ddr3[MAX_DDR3_STR_SZ];
    UCHAR nand[MAX_NAND_STR_SZ];
} st_cpu_info_req_t;
#endif

//*!<Structure to recieve response for IO Information*/
typedef struct  __attribute__((__packed__)) st_io_info
{
    UCHAR ignition_status[1];
    //whether to use double or uchar
    UCHAR ain1[MAX_AIN1_STATUS_STR_SZ];
    
} st_io_info_rsp_t;
#if 0
//*!<Structure to send request for IO Information*/
typedef struct  __attribute__((__packed__)) st_io_info
{
    UCHAR ignition_status[MAX_IGNITION_STATUS_STR_SZ];
    //whether to use double or uchar
    UCHAR ain1[MAX_AIN1_STATUS_STR_SZ];
    
} st_io_info_req_t;
#endif


//*!<Structure to recieve response for GSM_GPRS Information*/
typedef struct  __attribute__((__packed__)) st_gsm_gprs_info
{
    UCHAR sim_status[1];
    UCHAR network_status[1];
    
} st_gsm_gprs_info_rsp_t;

#if 0
//*!<Structure to send request for GSM_GPRS Information*/
typedef struct  __attribute__((__packed__)) st_gsm_gprs_info
{
    UCHAR sim_status[MAX_SIM_STATUS_STR_SZ];
    UCHAR network_status[MAX_NETWORK_STATUS_STR_SZ];
    
} st_gsm_gprs_info_req_t;
#endif


//*!<Structure to recieve response for SOFTWARE Information*/
typedef struct  __attribute__((__packed__)) st_software_info
{
    UCHAR linux_version[MAX_LINUX_VERSION_STR_SZ];
  
    
} st_software_info_t;
#if 1
//*!<Structure to send request for SOFTWARE Information*/
typedef struct  __attribute__((__packed__)) st_software_info_rsp
{
    UCHAR linux_version[MAX_LINUX_VERSION_STR_SZ];
    
} st_software_info_rsp_t;
#endif


//*!<Structure to recieve response for SIM Configuration*/
typedef struct  __attribute__((__packed__)) sim_config
{
    UCHAR apn_name[MAX_APN_NAME_STR_SZ];
    UCHAR access_point[MAX_ACCEPOINT_STR_SZ];
    UCHAR is_sim_passord_requiried[1];
    UCHAR sim_username[MAX_SIM_USERNAME_STR_SZ];  
    UCHAR sim_password[MAX_SIM_PASSWORD_STR_SZ]; 
    //network_mode=2G 1 ,3G=2 
    UCHAR  network_mode[1];
    //flight_mode=ON 1,OFF=2
    UCHAR  flight_mode[1];
    
    
} sim_config_t;
#if 0
//*!<Structure to send request for SIM Configuration*/
typedef struct  __attribute__((__packed__)) sim_config
{
    UCHAR apn_name[MAX_APN_NAME_STR_SZ];
    UCHAR access_point[MAX_ACCEPOINT_STR_SZ];
    UCHAR sim_username[MAX_SIM_USERNAME_STR_SZ];
    UCHAR sim_password[MAX_SIM_PASSWORD_STR_SZ];
    //network_mode=2G 1 ,3G=2  
    UCHAR  network_mode;
    //flight_mode=ON 1,OFF=2
    UCHAR  flight_mode;
    
} sim_config_req_t;
#endif


//*!<Structure to recieve response for CLOUD AZURE Configuration*/
typedef struct  __attribute__((__packed__)) cloud_azure_config
{
    UCHAR host[MAX_HOST_STR_SZ];
    UCHAR port[MAX_PORT_STR_SZ];
    UCHAR device_id[MAX_DEVICE_ID_STR_SZ];
    UCHAR device_type[MAX_DEVICE_TYPE_STR_SZ];
    UCHAR iot_hub_name[MAX_IOT_HUB_NAME_STR_SZ]; //MAX_IOT_HUB_NAME_STR_SZ MAX_SAS_TOKEN_STR_SZ MAX_MODE_STR_SZ MAX_SAMPLING_FREQUENCY_STR_SZ
    UCHAR sas_token[MAX_SAS_TOKEN_STR_SZ];	
    
} cloud_azure_config_t;
#if 0
//*!<Structure to send request for CLOUD AZURE  Configuration*/
typedef struct  __attribute__((__packed__))  cloud_azure_config
{
    UCHAR host[MAX_HOST_STR_SZ];
    //
    UCHAR port[MAX_PORT_STR_SZ]
    UCHAR device_id[MAX_DEVICE_ID_STR_SZ];
    UCHAR device_type[MAX_DEVICE_TYPE_STR_SZ];
    UCHAR iot_hub_name[MAX_IOT_HUB_NAME_STR_SZ]; 
    UCHAR sas_token[MAX_SAS_TOKEN_STR_SZ];	
    
} cloud_azure_config_req_t;
#endif


/*!<Structure to recieve response for Settings General*/
typedef struct  __attribute__((__packed__)) settings_general
{
    //mode=LAB_MODE=1,CAR_MODE=2
    UCHAR mode[1];
    USHORT sampling_frequency;
    USHORT can_sign;
    USHORT fatige_detection;
    USHORT idle_time;
    
} settings_general_t;
#if 0
//*!<Structure to send request for  Settings General*/
typedef struct  __attribute__((__packed__)) settings_general
{
    
    //mode=LAB_MODE=1,CAR_MODE=2 
    UCHAR mode;
    UCHAR sampling_frequency;
    UCHAR can_sign;
    
} settings_general_req_t;
#endif



/*!<Structure to recieve response for Settings Threshold*/
typedef struct  __attribute__((__packed__)) settings_threshold
{

    UCHAR harsh_brake_source[1];
    UCHAR harsh_acceleration_source[1];
    UCHAR crash_source[1];
    UCHAR harsh_source[1];
    UCHAR overspeed_source[1];
    UCHAR odometer_source[1];

    double  harsh_brake_threshold;
    double  harsh_acceleration_threshold;
    double  crash_threshold;
    double harsh_threshold;
    USHORT overspeed_threshold;
    SHORT over_temp_threshold;
    USHORT rpm_threshold;
    double odometer_base;

    USHORT overspeed_duration;
    
    
} settings_threshold_t;
#if 0
//*!<Structure to send request for Settings Threshold*/
typedef struct  __attribute__((__packed__)) settings_threshold
{
    
    UCHAR  harsh_brake_source;
    UCHAR harsh_acceleration_source;
    UCHAR crash_source;
    UCHAR harsh_source;
    UCHAR overspeed_source;
    UCHAR odometer_soruce;
    UCHAR odometer_source;

    double  harsh_brake_threshold;
    double  harsh_acceleration_threshold;
    double  crash_threshold;
    UCHAR harsh_threshold;
    UCHAR overspeed_threshold;
    double odometer_base;

    UCHAR overspeed_duration;
    
} settings_threshold_req_t;
#endif

/*!<Structure to recieve response for  Settings IO*/
typedef struct  __attribute__((__packed__)) settings_io
{
  //dout=BUZZER=1,RELAY=2
  UCHAR ain1[1];
  UCHAR dout1[1];
  UCHAR dout2[1]; 
  UCHAR din1[1]; 
  UCHAR din2[1]; 
  UCHAR dout1_value[1];
  UCHAR dout2_value[1];
}settings_io_t;


#if 0
//*!<Structure to send request for  Settings IO*/

typedef struct  __attribute__((__packed__)) settings_io
{
  //dout=BUZZER=1,RELAY=2
  UCHAR dout1;
  UCHAR dout2; 
}settings_io_req_t;
#endif

/*Yet to put detailed description
	
--> Confirm on the structures
--> Firmware Data Size,Type,Remaining byte,actual data etc

 */
/*!<Structure to recieve response for firmware*/
typedef struct  __attribute__((__packed__)) firmware
{
  UCHAR firmware_type;
  UCHAR file_sytem_type; 
}firmware_rsp_t;


#if 0
//*!<Structure to send request for  Settings firmware*/

typedef struct  __attribute__((__packed__)) firmware
{
  UCHAR firmware_type;
  UCHAR file_sytem_type; 
}firmware_req_t
#endif


//*!<Structure to recieve response for firmware*/
typedef struct  __attribute__((__packed__)) firmware_type
{
  UCHAR firmware_type;
  UCHAR file_sytem_type; 
}firmware_type_rsp_t;


#if 0
//*!<Structure to send request for  Settings firmware*/

typedef struct  __attribute__((__packed__)) firmware_type
{
  uchar white_list[10][10]; 
}firmware_type_req_t;
#endif

//*!<Structure to recieve response for SOTA_Whitelist_Number*/
typedef struct __attribute__((__packed__)) SOTA_Whitelist_Number
{
        UCHAR Number1[MAX_NUMBER1_STR_SZ];
        UCHAR Number2[MAX_NUMBER2_STR_SZ];
        UCHAR Number3[MAX_NUMBER3_STR_SZ];
        UCHAR Number4[MAX_NUMBER4_STR_SZ];
        UCHAR Number5[MAX_NUMBER5_STR_SZ];
        UCHAR Number6[MAX_NUMBER6_STR_SZ];
        UCHAR Number7[MAX_NUMBER7_STR_SZ];
        UCHAR Number8[MAX_NUMBER8_STR_SZ];
        UCHAR Number9[MAX_NUMBER9_STR_SZ];
        UCHAR Number10[MAX_NUMBER10_STR_SZ];
        UCHAR Number11[MAX_NUMBER11_STR_SZ];
        UCHAR Number12[MAX_NUMBER12_STR_SZ];
        UCHAR Number13[MAX_NUMBER13_STR_SZ];
        UCHAR Number14[MAX_NUMBER14_STR_SZ];
        UCHAR Number15[MAX_NUMBER15_STR_SZ];
        UCHAR Number16[MAX_NUMBER16_STR_SZ];
        UCHAR Number17[MAX_NUMBER17_STR_SZ];
        UCHAR Number18[MAX_NUMBER18_STR_SZ];
        UCHAR Number19[MAX_NUMBER19_STR_SZ];
        UCHAR Number20[MAX_NUMBER20_STR_SZ];

} SOTA_Whitelist_Number_t;

#if 0
//*!<Structure to send request for SOTA Whitelist Number */

typedef struct __attribute__((__packed__)) SOTA_Whitelist_Number
{
        UCHAR Number1[MAX_NUMBER1_STR_SZ];
        UCHAR Number2[MAX_NUMBER2_STR_SZ];
        UCHAR Number3[MAX_NUMBER3_STR_SZ];
        UCHAR Number4[MAX_NUMBER4_STR_SZ];
        UCHAR Number5[MAX_NUMBER5_STR_SZ];
        UCHAR Number6[MAX_NUMBER6_STR_SZ];
        UCHAR Number7[MAX_NUMBER7_STR_SZ];
        UCHAR Number8[MAX_NUMBER8_STR_SZ];
        UCHAR Number9[MAX_NUMBER9_STR_SZ];
        UCHAR Number10[MAX_NUMBER10_STR_SZ];
        UCHAR Number11[MAX_NUMBER11_STR_SZ];
        UCHAR Number12[MAX_NUMBER12_STR_SZ];
        UCHAR Number13[MAX_NUMBER13_STR_SZ];
        UCHAR Number14[MAX_NUMBER14_STR_SZ];
        UCHAR Number15[MAX_NUMBER15_STR_SZ];
        UCHAR Number16[MAX_NUMBER16_STR_SZ];
        UCHAR Number17[MAX_NUMBER17_STR_SZ];
        UCHAR Number18[MAX_NUMBER18_STR_SZ];
        UCHAR Number19[MAX_NUMBER19_STR_SZ];
        UCHAR Number20[MAX_NUMBER20_STR_SZ];

} SOTA_Whitelist_Number_req_t;
#endif

//*!<Structure to recieve response for SOTA_UserPass  */
typedef struct __attribute__((__packed__)) SOTA_UserPass
{
        UCHAR Username1[MAX_USERNAME1_STR_SZ];
        UCHAR Password1[MAX_PASSWORD1_STR_SZ];
        UCHAR Username2[MAX_USERNAME2_STR_SZ];
        UCHAR Password2[MAX_PASSWORD2_STR_SZ];
        UCHAR Username3[MAX_USERNAME3_STR_SZ];
        UCHAR Password3[MAX_PASSWORD3_STR_SZ];
        UCHAR Username4[MAX_USERNAME4_STR_SZ];
        UCHAR Password4[MAX_PASSWORD4_STR_SZ];
        UCHAR Username5[MAX_USERNAME5_STR_SZ];
        UCHAR Password5[MAX_PASSWORD5_STR_SZ];

} SOTA_UserPass_t;

#if 0
//*!<Structure to Send response for SOTA_UserPass  */
typedef struct __attribute__((__packed__)) SOTA_UserPass
{
        UCHAR Username1[MAX_USERNAME1_STR_SZ];
        UCHAR Password1[MAX_PASSWORD1_STR_SZ];
        UCHAR Username2[MAX_USERNAME2_STR_SZ];
        UCHAR Password2[MAX_PASSWORD2_STR_SZ];
        UCHAR Username3[MAX_USERNAME3_STR_SZ];
        UCHAR Password3[MAX_PASSWORD3_STR_SZ];
        UCHAR Username4[MAX_USERNAME4_STR_SZ];
        UCHAR Password4[MAX_PASSWORD4_STR_SZ];
        UCHAR Username5[MAX_USERNAME5_STR_SZ];
        UCHAR Password5[MAX_PASSWORD5_STR_SZ];

} SOTA_UserPass_req_t;
#endif

#endif /*!< #ifndef __USB_PROTOCOL_H */
