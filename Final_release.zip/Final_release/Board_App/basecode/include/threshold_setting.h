#ifndef THRESHOULD_SETTING_H_
#define THRESHOULD_SETTING_H_

#include <usb_protcol.h>
#include <string.h>


LONG get_threshold_setting(usb_board *p_frame, settings_threshold_t *p_threshold_setting);

LONG set_threshold_setting(usb_board *p_frame);


#endif /*THRESHOULD_SETTING_H_*/

