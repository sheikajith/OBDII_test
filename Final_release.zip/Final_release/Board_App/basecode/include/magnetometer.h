#ifndef __MAGNETOMETER_H__
#define __MAGNETOMETER_H__

#include <linux/input.h>
#define MAGNETOMETER_ENABLE "echo 1 > /sys/devices/virtual/input/input2/enable"
#define MAGNETOMETER_DISABLE "echo 0 > /sys/devices/virtual/input/input2/enable"

#define PI 3.141592

typedef struct _magnetometer_api_priv
{
	int fd;
	double x,y,z;
	char *node;
} magnetometer_api_priv;

/* global declaration */
int mag_init();
int mag_deinit();
int magnetometer_read(void);

#endif /* #define __MAGNETOMETER_H__ */
