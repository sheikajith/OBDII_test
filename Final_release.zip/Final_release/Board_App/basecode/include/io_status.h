#ifndef IO_STATUS_H_
#define IO_STATUS_H_

#include <usb_protcol.h>
#include <string.h>

int check_adc_voltage (double *); // API from libOBD2.so , so int is used.
LONG get_io_status(usb_board *p_frame, st_io_info_rsp_t *p_io_info_st_rsp);

#endif /*IO_STATUS_H_*/

