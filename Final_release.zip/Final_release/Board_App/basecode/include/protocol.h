#ifndef __PROTOCOL_H 
#define __PROTOCOL_H

#include <usb_priv.h>
#include <stdlib.h>
#include <usb_protcol.h>
#include <crc.h>
#include <app.h>
#include <hal.h>
#include <string.h>
#include <device_info.h>
#include <cpu_status.h>
#include <io_status.h>
#include <gsm_gprs_status.h>
#include <software_status.h>
#include <sim_config.h>
#include <cloud_config.h>
#include <general_setting.h>
#include <threshold_setting.h>
#include <io_setting.h>
#include <dwnld.h>
#include <blackbox.h>
#include <system.h>
#include <Whitelist_Number.h>
#include <User_Pass.h>

LONG protocol_init (app_priv_t *p_app);

LONG protocol_read (obd_gui_cfg_proto_t *p_proto, char *buf, size_t sz);

LONG protocol_write (obd_gui_cfg_proto_t *p_proto, usb_board *p_hdr, UCHAR *payload, size_t sz);

LONG protocol_change_stm (obd_gui_cfg_proto_t *p_proto,enum state_machine old_stm, enum state_machine new_stm);

LONG protocol_start (obd_gui_cfg_proto_t *p_proto);

#endif 


